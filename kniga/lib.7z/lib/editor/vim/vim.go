
// ----------------------------------
https://console.dev/articles/neovim-best-code-editor-ide-for-developers/

// ----------------------------------
MarioCarrion/init.vim
https://gist.github.com/MarioCarrion/836dc17e15096b6c2414ce9b0acd93a4

// ----------------------------------
MarioCarrion/go.vim
https://gist.github.com/MarioCarrion/99f6a6110796cff5df118822472a0bc9

// ----------------------------------
https://medium.com/pragmatic-programmers/configuring-vim-to-develop-go-programs-e839641da4ac
https://medium.com/@stayleanstayfocused/neovim-setup-for-golang-programming-68ebf59336d9

https://pepa.holla.cz/2021/03/01/golang-debugging-application-in-neovim/