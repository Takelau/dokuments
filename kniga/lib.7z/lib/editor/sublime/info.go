
// Golang Build
C+S+b
 > Build      go build
 > Run        go run
 > Test       go test
 > Benchmark  go test -bench=.
 > Install    go install
 > Clean      go clean

F5  go run -v {current_filename}
F7  go build -v
F8  go clean -v
F9  go test -v

// LSP
C+A+m    Панель ссылок  
S+F12    Find References | F4 - Next,  S+F4 - Prev
F12      Goto Definition
C+r      Goto Symbol
C+S+r    Goto Symbol in Project

