
/usr/share/code/code --no-sandbox --unity-launch %F    <-- fedora
/usr/share/code/code --no-sandbox --unity-launch %F  <-- ubuntu

// ----------------------------------
Docker in Visual Studio Code
https://code.visualstudio.com/docs/containers/overview

// ----------------------------------
Debug containerized apps
https://code.visualstudio.com/docs/containers/debug-common

// ----------------------------------
Use Docker Compose
https://code.visualstudio.com/docs/containers/docker-compose

// ----------------------------------
Docker в качестве среды разработки
https://docs.microsoft.com/ru-ru/learn/modules/use-docker-container-dev-env-vs-code/

// ----------------------------------
Начало работы с Docker
https://docs.microsoft.com/ru-ru/visualstudio/docker/tutorials/docker-tutorial

// ----------------------------------
Remote Development with VS Code
https://code.visualstudio.com/blogs/2019/05/02/remote-development

// ----------------------------------
Create a devcontainer.json file
https://code.visualstudio.com/docs/remote/create-dev-container#_create-a-devcontainerjson-file