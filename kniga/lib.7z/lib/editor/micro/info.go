
// ----------------------------------
Ctl-q   // закрыть
Ctl-o   // открыть
Ctr-s   // сохранить

Ctrl-b   // Run a shell command

Ctl+h    // <-- Back Space
Ctl+<|>  // перемещение по словам
Alt+<|>  // вначало / конец строки
Alt+{|}  // Move cursor to previous empty line  НЕ РАБОТАЮТ

Ctl+Sft+<|>   // выделить слово слева/справа
Sft+Home|End  // Выделить с начала/до конца строки

Ctl+l n  // переход к строке n
Ctl+w    // переключение между 2-я областями

Ctl-t    // новая вкладка
Alt-,    // предыдущая
Alt-.    // следующая

Ctl-f    // поиск
Ctl-n    // искать дальше
Ctl-p    // искать в предыдущем


// ----------------------------------
Ctrl-e

> help
> help commands
> help defaultkeys  // list
> help keybindings  // information
> help colors
> help options      // list of all the options you can customize
> help plugins

Ctrl-w             // move between splits
> vsplit filename  // open a new split
> hsplit filename 
> tab 'filename'
> tabmove '[-+]?n' // Moves the active tab to another slot n

> open 'filename'
> reload
> replaceall 'search' 'value'
> cd 'path'  // Change the working directory
> pwd        // Print the current working directory
> raw
> quit

> bind 'key' 'action'    // bindings.json
> set 'option' 'value''  // settings.json
> show 'option'
> run 'sh-command'


// ----------------------------------
> plugin list
> plugin install 'pl'
> plugin remove 'pl'
> plugin update 'pl'
> plugin search 'pl'

micro -plugin install filemanager
micro -plugin install lsp

git clone https://github.com/AndCake/micro-plugin-lsp ~/.config/micro/plug/lsp

// Filemanager
| Command  | Keybinding(s)              | What it does                                                                                |
| :------- | :------------------------- | :------------------------------------------------------------------------------------------ |
| `tree`   | -                          | Open/close the tree                                                                         |
| -        | <kbd>Tab</kbd> & MouseLeft | Open a file, or go into the directory. Goes back a dir if on `..`                           |
| -        | <kbd>→</kbd>               | Expand directory in tree listing                                                            |
| -        | <kbd>←</kbd>               | Collapse directory listing                                                                  |
| -        | <kbd>Shift ⬆</kbd>         | Go to the target's parent directory                                                         |
| -        | <kbd>Alt Shift {</kbd>     | Jump to the previous directory in the view                                                  |
| -        | <kbd>Alt Shift }</kbd>     | Jump to the next directory in the view                                                      |
| `rm`     | -                          | Prompt to delete the target file/directory your cursor is on                                |
| `rename` | -                          | Rename the file/directory your cursor is on, using the passed name                          |
| `touch`  | -                          | Make a new file under/into the file/directory your cursor is on, using the passed name      |
| `mkdir`  | -                          | Make a new directory under/into the file/directory your cursor is on, using the passed name |


// ----------------------------------
> set colorscheme ...
// 256 color
monokai  - also the default colorscheme
zenburn
gruvbox
darcula
twilight
railscast
bubblegum  - light theme
// 16 color
simple
solarized  - must have the solarized color palette in your terminal to use this colorscheme properly
cmc-16
cmc-paper
geany
// True color
solarized-tc
atom-dark
cmc-tc
gruvbox-tc
material-tc


// ----------------------------------
// Options
autoindent: true
colorcolumn: 0
colorscheme: default
cursorline: true
clipboard: 
	external - accesses clipboard via an external tool, such as xclip/xsel or wl-clipboard on Linux 
	terminal - accesses the clipboard via your terminal emulator
	internal - micro will use an internal clipboard
diffgutter: false
encoding: utf-8
savecursor: false   <--
scrollbar: false    <--
scrollmargin: 3
scrollspeed: 2
tabsize: 4          <--
tabstospaces : false
wordwrap: false
xterm: false


