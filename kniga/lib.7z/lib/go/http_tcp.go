
// Pipe
net.Pipe() (Conn, Conn)

// Conn - tcp tcp(4-6) udp, udp(4-6), ip, ip4(4-6), unix, unixgram, unixpacket
net.Dial(network, address string) (Conn, error)
net.DialTimeout(network, address string, timeout time.Duration) (Conn, error)
net.DialContext(ctx context.Context, network, address string) (Conn, error)

// Conn File
net.FileConn(f *os.File) (c Conn, err error)

// TCP
net.ResolveTCPAddr(network, address string) (*TCPAddr, error)
net.DialTCP(network string, laddr, raddr *TCPAddr) (*TCPConn, error)
(c *TCPConn) Close() error
(c *TCPConn) CloseRead() error
(c *TCPConn) CloseWrite() error
(c *TCPConn) Read(b []byte) (int, error)
(c *TCPConn) ReadFrom(r io.Reader) (int64, error)
(c *TCPConn) Write(b []byte) (int, error)
(c *TCPConn) File() (f *os.File, err error)

net.ListenTCP(network string, laddr *TCPAddr) (*TCPListener, error)
(l *TCPListener) Accept() (Conn, error)
(l *TCPListener) AcceptTCP() (*TCPConn, error)
(l *TCPListener) Close() error
(l *TCPListener) File() (f *os.File, err error)

// IP
net.DialIP(network string, laddr, raddr *IPAddr) (*IPConn, error)
net.ListenIP(network string, laddr *IPAddr) (*IPConn, error)
(c *IPConn) Close() error
(c *IPConn) File() (f *os.File, err error)
(c *IPConn) Read(b []byte) (int, error)
(c *IPConn) ReadFrom(b []byte) (int, Addr, error)
(c *IPConn) ReadFromIP(b []byte) (int, *IPAddr, error)
(c *IPConn) ReadMsgIP(b, oob []byte) (n, oobn, flags int, addr *IPAddr, err error)
(c *IPConn) Write(b []byte) (int, error)
(c *IPConn) WriteTo(b []byte, addr Addr) (int, error)
(c *IPConn) WriteToIP(b []byte, addr *IPAddr) (int, error)
(c *IPConn) WriteMsgIP(b, oob []byte, addr *IPAddr) (n, oobn int, err error)

// Listen
net.Listen(network, address string) (Listener, error)         // "tcp", "tcp4", "tcp6", "unix" or "unixpacket" [IPv4 -> "tcp4"]
net.ListenPacket(network, address string) (PacketConn, error) // "udp", "udp4", "udp6", "unixgram" [IPv4 -> "udp4"]
net.FileListener(f *os.File) (ln Listener, err error)

net.ParseIP(s string) IP
(ip IP) DefaultMask() IPMask
(ip IP) Equal(x IP) bool

net.SplitHostPort(hostport string) (host, port string, err error)

// RPC
rpc.ServeConn(conn io.ReadWriteCloser)

rpc.Dial(network, address string) (*Client, error)
rpc.DialHTTP(network, address string) (*Client, error)
rpc.NewClient(conn io.ReadWriteCloser) *Client
(client *Client) Close() error
(client *Client) Call(serviceMethod string, args interface{}, reply interface{}) error
(client *Client) Go(serviceMethod string, args interface{}, reply interface{}, done chan *Call) *Call

rpc.Accept(lis net.Listener)
rpc.NewServer() *Server
(server *Server) Accept(lis net.Listener)
(server *Server) ServeConn(conn io.ReadWriteCloser)
(server *Server) ServeHTTP(w http.ResponseWriter, req *http.Request)
(server *Server) HandleHTTP(rpcPath, debugPath string)


// --------------------------------
//    Client Net
// --------------------------------
//  Dial
package main
import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strings"
)

func main() {
	c,_ := net.Dial("tcp", "127.0.0.1:2000")
//r,_ := net.ResolveTCPAddr("tcp4", "127.0.0.1:2000")
//c,_ := net.DialTCP("tcp4", nil, r)     // nолько для TCP
	for {
		reader := bufio.NewReader(os.Stdin)  // ввод с консоли
		text, _ := reader.ReadString('\n')

		fmt.Fprintf(c, text+"\n")            // отправка текста на сервер
		
		message, _ := bufio.NewReader(c).ReadString('\n')
		fmt.Print("->: " + message)          // ответ от сервера

		if strings.TrimSpace(string(text)) == "STOP" {
			fmt.Println("TCP client exiting...")
			return
		}
	}
}

// --------------------------------
// DialContext
package main
import (
	"context"
	"log"
	"net"
	"time"
)

func main() {
	var d net.Dialer
	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()

	c,_ := d.DialContext(ctx, "tcp", "127.0.0.1:2000")
	defer conn.Close()

	if _, err := c.Write([]byte("test")); err != nil {
		log.Fatal(err)
	}
}


// --------------------------------
//    Server Net
// --------------------------------
l,_ := net.Listen("tcp", PORT)
c,_ := l.Accept()
// 1
for {
	data,_ := bufio.NewReader(c).ReadString('\n');
	if strings.TrimSpace(string(data)) == "STOP" { break; }
}
// 2
buffer := make([]byte, 1024)
for {
	n,_ := c.Read(buffer)
	if strings.TrimSpace(string(buffer[0:n])) == "STOP" { conn.Close(); return; }
}

// --------------------------------
// Listen
package main
import 
(	"bufio"
	"net"
	"os"
	"strings"
)

func handleConnection(c net.Conn) {
	defer c.Close()
	for {
		netData, err := bufio.NewReader(c).ReadString('\n');   if err != nil { os.Exit(100); }
		str := strings.TrimSpace(string(netData));             if str == "STOP" { break; }
		c.Write([]byte(string("Re:"+str+"\n")))
	}
}

func main() {
	l,_ := net.Listen("tcp4", "127.0.0.1:2000")  // func Listen(network, address string) (Listener, error)
//s,_ := net.ResolveTCPAddr("tcp", ":2000")    // func ResolveTCPAddr(network, address string) (*TCPAddr, error)
//l,_ := net.ListenTCP("tcp", s)               // func ListenTCP(network string, laddr *TCPAddr) (*TCPListener, error)
	defer l.Close()
	for {
		c,err := l.Accept()
		if err != nil { os.Exit(100); }
		go handleConnection(c)
	}
}


// --------------------------------
//    RPC / Call & Go
// --------------------------------
package sRPC

type MyFloats struct {
	A1, A2 float64
}

type Quotient struct {
	Quo, Rem float64
}

type MyInterface interface {
	Multiply(a *MyFloats, reply *float64) error
	Power(a *MyFloats, reply *float64) error
	Divide(a *MyFloats, quo *Quotient) error
}
// --------------------------------
// Client
package main
import (
	"fmt"
	"net/rpc"
	m "my/sRPC"
)

func main() {
	args := m.MyFloats{16, -0.5}
	c,err := rpc.Dial("tcp", "127.0.0.1:2000");          if err != nil { fmt.Println(err); return; }

	// Synchronous call
	var reply1 float64
	err = c.Call("MyInterface.Power", args, &reply1);    if err != nil { fmt.Println(err); return; }
	fmt.Printf("Reply (Power): %f\n", reply1)

	// Asynchronous call
	args = m.MyFloats{}
	reply2 := new(m.Quotient)
	dCall := c.Go("MyInterface.Divide", args, reply2, nil)
	rCall := <-dCall.Done
	if rCall.Error != nil { fmt.Printf("error:%s \n",rCall.Error); }
	fmt.Printf("%f \n", reply2.Quo)
}
// --------------------------------
// Server
package main
import (
	"fmt"
	"math"
	"net"
	"net/rpc"
	m "my/sRPC"
	"errors"
)

type MyInterface struct{}

func Power(x, y float64) float64 {
	return math.Pow(x, y)
}

func (t *MyInterface) Multiply(a *m.MyFloats, reply *float64) error {
	*reply = a.A1 * a.A2
	return nil
}

func (t *MyInterface) Power(a *m.MyFloats, reply *float64) error {
	*reply = Power(a.A1, a.A2)
	return nil
}

func (t *MyInterface) Divide(a *m.MyFloats, quo *m.Quotient) error {
	if a.A1 == 0 {
		return errors.New("divide by zero")
	}
	quo.Quo = a.A1 + a.A2
	quo.Rem = a.A1 - a.A2
	return nil
}

func main() {
	myInterface := new(MyInterface)
	rpc.Register(myInterface)

	t,_ := net.ResolveTCPAddr("tcp4", "127.0.0.1:2000")  // (*TCPAddr, error)
	l,_ := net.ListenTCP("tcp4", t)     // (*TCPListener, error)
	defer l.Close()

	for {
		con,err := l.Accept();  if err != nil { continue; }  // (Conn, error)
		fmt.Printf("%s\n", con.RemoteAddr())
		go func(c net.Conn) {
			defer c.Close()
			rpc.ServeConn(c)  // ServeConn(conn io.ReadWriteCloser)
		}(con)
	}
}


// --------------------------------
//    RPC / HTTP
// --------------------------------
// Client
c,_ := rpc.DialHTTP("tcp", "127.0.0.1:2000")
defer c.Close()
err    = c.Call("Arith.Multiply", args, &reply)  // Synchronous
dCall := c.Go("Arith.Divide", args, reply, nil)  // Asynchronous
rCall := <-dCall.Done
// --------------------------------
// Server
my := new(MyInterface)
rpc.Register(my)
rpc.HandleHTTP()
// v1
l,_ := net.Listen("tcp", "127.0.0.1:2000")
go http.Serve(l, nil)
// v2
err := http.ListenAndServe("127.0.0.1:2000", nil)
