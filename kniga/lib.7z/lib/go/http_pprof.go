
// --------------------------------
//    pprof
// --------------------------------
import (
	"net/http"
	"net/http/pprof"
	"os"
)

m := http.NewServeMux()
m.HandleFunc("/", h1)
m.HandleFunc("/time", h2)
m.HandleFunc("/debug/pprof/",          pprof.Index)
m.HandleFunc("/debug/pprof/cmdline",   pprof.Cmdline)
m.HandleFunc("/debug/pprof/profile",   pprof.Profile)
m.HandleFunc("/debug/pprof/symbol",    pprof.Symbol)
m.HandleFunc("/debug/pprof/trace",     pprof.Trace)
err := http.ListenAndServe(":8001", m)
if err != nil { return; } 

1 go run main.go
2 go tool pprof http://localhost:8001/debug/pprof/profile
3 http://localhost:8001/debug/pprof/
4 ab -k -c 10 -n 100000 "http://localhost:8001/time"
