
// --------------------------------
//    Basic Auth
// --------------------------------
// server
// go run $GOROOT/src/crypto/tls/generate_cert.go --ecdsa-curve P256 --host localhost
func main() {
  addr     := flag.String("addr", ":4000", "HTTPS network address")
  certFile := flag.String("certfile", "cert.pem", "certificate PEM file")
  keyFile  := flag.String("keyfile", "key.pem", "key PEM file")
  flag.Parse()

  mux := http.NewServeMux()
  mux.HandleFunc("/", func(w http.ResponseWriter, req *http.Request) {
    if req.URL.Path != "/" {
      http.NotFound(w, req)
      return
    }
  })

  mux.HandleFunc("/secret/", func(w http.ResponseWriter, req *http.Request) {
    user, pass, ok := req.BasicAuth()
    if ok && verifyUserPass(user, pass) {    // проверка логтна и пароля
      fmt.Fprintf(w, "You get to see the secret\n")
    } else {
      w.Header().Set("WWW-Authenticate", `Basic realm="api"`)  // отправка предложения "WWW-Authenticate" выполнить базовую авторизацию | api - произвольное наименование области
      http.Error(w, "Unauthorized", http.StatusUnauthorized)   // 401 (Unauthorized)
    }
  })

  srv := &http.Server{
    Addr:    *addr,
    Handler: mux,
    TLSConfig: &tls.Config{
      MinVersion:               tls.VersionTLS13,
      PreferServerCipherSuites: true,
    },
  }

  err := srv.ListenAndServeTLS(*certFile, *keyFile)
  log.Fatal(err)
}

var usersPasswords = map[string][]byte{
  "joe":  []byte("$2a$12$aMfFQpGSiPiYkekov7LOsu63pZFaWzmlfm1T8lvG6JFj2Bh4SZPWS"),
  "mary": []byte("$2a$12$l398tX477zeEBP6Se0mAv.ZLR8.LZZehuDgbtw2yoQeMjIyCNCsRW"),
}

func verifyUserPass(username, password string) bool {
  wantPass, hasUser := usersPasswords[username]
  if !hasUser { return false; }
  if cmperr := bcrypt.CompareHashAndPassword(wantPass, []byte(password)); cmperr == nil { return true; }
  return false
}

// client
// go run client.go  -user joe  -pass 1234  -addr localhost:4000/secret/
func main() {
  addr := flag.String("addr", "localhost:4000", "HTTPS server address")
  certFile := flag.String("certfile", "cert.pem", "trusted CA certificate")
  user := flag.String("user", "", "username")
  pass := flag.String("pass", "", "password")
  flag.Parse()

  cert, err := os.ReadFile(*certFile)
  if err != nil { log.Fatal(err); }
  certPool := x509.NewCertPool()
  if ok := certPool.AppendCertsFromPEM(cert); !ok { log.Fatalf("unable to parse cert from %s", *certFile); }

  client := &http.Client{
    Transport: &http.Transport{
      TLSClientConfig: &tls.Config{
        RootCAs: certPool,
      },
    },
  }

  req, err := http.NewRequest(http.MethodGet, "https://"+*addr, nil);       if err != nil { log.Fatal(err); }
  req.SetBasicAuth(*user, *pass)

  resp, err := client.Do(req);         if err != nil { log.Fatal(err); }
  defer resp.Body.Close()

  html, err := io.ReadAll(resp.Body);  if err != nil { log.Fatal(err); }
  fmt.Println("HTTP Status:", resp.Status)
  fmt.Println("Response body:", string(html))
}

