
// --------------------------------
//    Test
// --------------------------------
func NewRequest(method, target string, body io.Reader) *http.Request
func NewRecorder() *ResponseRecorder    // <- http.ResponseWriter
func NewServer(handler http.Handler) *Server
func NewTLSServer(handler http.Handler) *Server
func NewUnstartedServer(handler http.Handler) *Server // returns a new Server but doesn't start it

type ResponseRecorder struct { // <- http.ResponseWriter
	Code       int          // Code is the HTTP response code set by WriteHeader
	HeaderMap  http.Header  // Deprecated
	Body      *bytes.Buffer
	Flushed    bool         // Flushed is whether the Handler called Flush.
}
func (rw *ResponseRecorder) Flush()
func (rw *ResponseRecorder) Header() http.Header
func (rw *ResponseRecorder) Result() *http.Response  // StatusCode, Header, Body
func (rw *ResponseRecorder) Write(buf []byte) (int, error)
func (rw *ResponseRecorder) WriteHeader(code int)
func (rw *ResponseRecorder) WriteString(str string) (int, error)

type Server struct {
	URL          string      // base URL of form http://ipaddr:port with no trailing slash
	Listener     net.Listener
	EnableHTTP2  boo l       // Go 1.14
	TLS         *tls.Config
	Config      *http.Server // Config may be changed after calling NewUnstartedServer and before Start or StartTLS.
}
func (s *Server) Start()
func (s *Server) StartTLS()
func (s *Server) Close()    // blocks until all outstanding requests on this server have completed
func (s *Server) CloseClientConnections()
func (s *Server) Client() *http.Client
func (s *Server) Certificate() *x509.Certificate

// --------------------------------
// NewRecorder
import (
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
)
func main() {
	handler := func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "<html><body>Hello World!</body></html>")
	}

	r := httptest.NewRequest("GET", "http://example.com/foo", nil)
	w := httptest.NewRecorder()
	handler(w, r)

	resp := w.Result()
	body, _ := io.ReadAll(resp.Body)

	fmt.Println(resp.StatusCode)
	fmt.Println(resp.Header.Get("Content-Type"))
	fmt.Println(string(body))
}

// --------------------------------
// HTTP2
package main
import (
	"fmt"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
)

func main() {
	ts := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "Hello, %s", r.Proto)
	}))
	ts.EnableHTTP2 = true
	ts.StartTLS()     // <--
	defer ts.Close()

	res,_ := ts.Client().Get(ts.URL)
	greeting,_ := io.ReadAll(res.Body)
	res.Body.Close()

	fmt.Printf("%s", greeting)
}

// --------------------------------
package main
import (
	"fmt"
	"net/http"
	"os"
)

func CheckStatusOK(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, `Fine!`)
}

func StatusNotFound(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusNotFound)
}

func MyHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Serving: %s\n", r.URL.Path)
	fmt.Printf("Served: %s\n", r.Host)
}

func main() {
	PORT := ":8001"
	arguments := os.Args
	if len(arguments) == 1 { fmt.Println("Using default port number: ", PORT)
	} else {                 PORT = ":" + arguments[1] }

	http.HandleFunc("/CheckStatusOK", CheckStatusOK)
	http.HandleFunc("/StatusNotFound", StatusNotFound)
	http.HandleFunc("/", MyHandler)

	err := http.ListenAndServe(PORT, nil);  if err != nil { fmt.Println(err); return; }
}

// ---
package main
import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestCheckStatusOK(t *testing.T) {
	req, err := http.NewRequest("GET", "/CheckStatusOK", nil);  if err != nil { fmt.Println(err); return; }
	w := httptest.NewRecorder()  // <--
	handler := http.HandlerFunc(CheckStatusOK)
	handler.ServeHTTP(w, req)
	if rr.Code != http.StatusOK {    t.Errorf("handler returned %v", rr.Code); }
	if rr.Body.String() != `Fine!` { t.Errorf("handler returned %v", rr.Body.String()); }
}

func TestStatusNotFound(t *testing.T) {
	req, err := http.NewRequest("GET", "/StatusNotFound", nil)
	if err != nil { fmt.Println(err); return; }
	w := httptest.NewRecorder()
	handler := http.HandlerFunc(StatusNotFound)
	handler.ServeHTTP(w, req)
	if rr.Code != http.StatusNotFound { t.Errorf("handler returned %v", rr.Code); }
}

go test main.go main_test.go -v --count=1



