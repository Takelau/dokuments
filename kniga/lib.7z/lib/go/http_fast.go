
https://pkg.go.dev/github.com/valyala/fasthttp#pkg-constants

requestHandler := func(ctx *fasthttp.RequestCtx) {	
	ctx.SetContentType("foo/bar")
	ctx.SetStatusCode(fasthttp.StatusOK)
	ctx.SetStatusCode(fasthttp.StatusNotFound)

	ctx.Response.Header.Set("Foo-Bar", "baz")
	fmt.Fprintf(ctx, "this is the second part of body\n")
	ctx.SetBody([]byte("this is completely new body contents"))
	ctx.Error("not found", fasthttp.StatusNotFound)
}

// Get  & Post
Name := string(ctx.QueryArgs().Peek("Name"))

r.Body -> ctx.PostBody()
r.URL.Path -> ctx.Path()
r.URL -> ctx.URI()
r.Method -> ctx.Method()
r.Header -> ctx.Request.Header
r.Header.Get() -> ctx.Request.Header.Peek()
r.Host -> ctx.Host()
r.Form -> ctx.QueryArgs() + ctx.PostArgs()
r.PostForm -> ctx.PostArgs()
r.FormValue() -> ctx.FormValue()
r.FormFile() -> ctx.FormFile()
r.MultipartForm -> ctx.MultipartForm()
r.RemoteAddr -> ctx.RemoteAddr()
r.RequestURI -> ctx.RequestURI()
r.TLS -> ctx.IsTLS()
r.Cookie() -> ctx.Request.Header.Cookie()
r.Referer() -> ctx.Referer()
r.UserAgent() -> ctx.UserAgent()
w.Header() -> ctx.Response.Header
w.Header().Set() -> ctx.Response.Header.Set()
w.Header().Set("Content-Type") -> ctx.SetContentType()
w.Header().Set("Set-Cookie") -> ctx.Response.Header.SetCookie()
w.Write() -> ctx.Write(), ctx.SetBody(), ctx.SetBodyStream(), ctx.SetBodyStreamWriter()
w.WriteHeader() -> ctx.SetStatusCode()
w.(http.Hijacker).Hijack() -> ctx.Hijack()
http.Error() -> ctx.Error()
http.FileServer() -> fasthttp.FSHandler(), fasthttp.FS
http.ServeFile() -> fasthttp.ServeFile()
http.Redirect() -> ctx.Redirect()
http.NotFound() -> ctx.NotFound()
http.StripPrefix() -> fasthttp.PathRewriteFunc

var (
	// both buffers are uninitialized
	dst []byte
	src []byte
)
dst = append(dst, src...)  // is legal if dst is nil and/or src is nil
copy(dst, src)             // is legal if dst is nil and/or src is nil
(string(src) == "")        // is true if src is nil
(len(src) == 0)            // is true if src is nil
src = src[:0]              // works like a charm with nil src
// this for loop doesn't panic if src is nil
for i, ch := range src {
	doSomething(i, ch)
}


type RequestCtx struct {
	// Incoming request - Copying Request by value is forbidden. Use pointer to Request instead.
	Request Request
	// Outgoing response - Copying Response by value is forbidden. Use pointer to Response instead.
	Response Response
}
func (ctx *RequestCtx) Done() <-chan struct{}
func (ctx *RequestCtx) Deadline() (deadline time.Time, ok bool)
func (ctx *RequestCtx) Host() []byte
func (ctx *RequestCtx) Err() error
func (ctx *RequestCtx) Error(msg string, statusCode int)
func (ctx *RequestCtx) FormFile(key string) (*multipart.FileHeader, error)
func (ctx *RequestCtx) FormValue(key string) []byte
func (ctx *RequestCtx) IsConnect() bool
func (ctx *RequestCtx) PostArgs() *Args
func (ctx *RequestCtx) PostBody() []byte
func (ctx *RequestCtx) QueryArgs() *Args
func (ctx *RequestCtx) Redirect(uri string, statusCode int)
func (ctx *RequestCtx) Referer() []byte
func (ctx *RequestCtx) RemoteAddr() net.Addr
func (ctx *RequestCtx) RemoteIP() net.IP
func (ctx *RequestCtx) SetConnectionClose()
func (ctx *RequestCtx) SetContentType(contentType string)
func (ctx *RequestCtx) Write(p []byte) (int, error)
func (ctx *RequestCtx) WriteString(s string) (int, error)

type Request struct {
	Header RequestHeader
}
func (req *Request) Host() []byte
func (req *Request) Body() []byte
func (req *Request) BodyWriteTo(w io.Writer) error
func (req *Request) BodyWriter() io.Writer
func (req *Request) CopyTo(dst *Request)
func (req *Request) PostArgs() *Args
func (req *Request) Read(r *bufio.Reader) error
func (req *Request) RequestURI() []byte
func (req *Request) ResetBody()
func (req *Request) String() string
func (req *Request) URI() *URI
func (req *Request) Write(w *bufio.Writer) error
func (req *Request) WriteTo(w io.Writer) (int64, error)

type Response struct {
	Header ResponseHeader
	// Flush headers as soon as possible without waiting for first body bytes.
	ImmediateHeaderFlush bool
	// Response.Read() skips reading body if set to true.
	// Use it for reading HEAD responses.
	SkipBody bool
}
func (resp *Response) SendFile(path string) error
func (resp *Response) SetBody(body []byte)
func (resp *Response) SetBodyString(body string)
func (resp *Response) SetBodyStream(bodyStream io.Reader, bodySize int)
func (resp *Response) SetBodyStreamWriter(sw StreamWriter)
func (resp *Response) SetStatusCode(statusCode int)
func (resp *Response) StatusCode() int
func (resp *Response) String() string
func (resp *Response) Write(w *bufio.Writer) error
func (resp *Response) WriteTo(w io.Writer) (int64, error)

type RequestHeader struct {}
func (h *RequestHeader) ConnectionClose() bool
func (h *RequestHeader) ContentLength() int
func (h *RequestHeader) ContentType() []byte
func (h *RequestHeader) Cookie(key string) []byte
func (h *RequestHeader) CookieBytes(key []byte) []byte
func (h *RequestHeader) DelAllCookies()
func (h *RequestHeader) DelCookie(key string)
func (h *RequestHeader) DelCookieBytes(key []byte)
func (h *RequestHeader) Header() []byte
func (h *RequestHeader) Host() []byte
func (h *RequestHeader) Read(r *bufio.Reader) error
func (h *RequestHeader) Referer() []byte
func (h *RequestHeader) Set(key, value string)
func (h *RequestHeader) SetCookie(key, value string)
func (h *RequestHeader) UserAgent() []byte
func (h *RequestHeader) Write(w *bufio.Writer) error
func (h *RequestHeader) WriteTo(w io.Writer) (int64, error)

// -------------------------------
// Client, HostClient и PipelineClient
Fasthttp.Client     - можно делать запросы на любой сайт интернета
Fasthttp.HostClient - специализированный клиент для общения с только одним сервером
Fasthttp.PipelineClient - позволяет управлять pipeline-запросами на сервер или на какое-то ограниченное количество серверов
  doc -> https://habr.com/ru/post/443378/

// -------------------------------
// fasthttp.Do(req, resp)
func ExampleGetWithFastHttpManagedBuffers() {
	url := "https://golang.org/"

	// Acquire a request instance
	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)
	req.SetRequestURI(url)

	// Acquire a response instance
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	err := fasthttp.Do(req, resp)
	if err != nil { fmt.Printf("Client get failed: %s\n", err);  return; }
	if resp.StatusCode() != fasthttp.StatusOK {
		fmt.Printf("Expected status code %d but got %d\n", fasthttp.StatusOK, resp.StatusCode())
		return
	}
	body := resp.Body()
	fmt.Printf("Response body is: %s", body)
}

// -------------------------------
// fasthttp.Get(body, url)
func ExampleGetWithSelfManagedBuffers() []byte {
	url := "https://golang.org/"

	var body []byte // This buffer could be acquired from a custom buffer pool

	statusCode, body, err := fasthttp.Get(body, url)
	if err != nil {
		fmt.Printf("Client get failed: %s\n", err)
		return nil
	}
	if statusCode != fasthttp.StatusOK {
		fmt.Printf("Expected status code %d but got %d\n", fasthttp.StatusOK, statusCode)
		return nil
	}

	fmt.Printf("Response body is: %s", body)

	return body
}

// -------------------------------
// fiber logger - https://docs.gofiber.io/api/middleware/logger
file, err := os.OpenFile("./123.log", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
if err != nil { log.Fatalf("error opening file: %v", err); }
defer file.Close()
app.Use(logger.New(logger.Config{ Output: file, }))

type Config struct {
	Output io.Writer  // Default: os.Stderr
}

// -------------------------------
"github.com/gofiber/fiber/v2/middleware/recover"
app.Use(recover.New())
