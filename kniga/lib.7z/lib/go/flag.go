package main
import (
	"flag"
	"fmt"
)

func main() {
	// go run name.go -O=100 -k false
	minusK := flag.Bool("k", true, "k flag")
	minusO := flag.Int("O", 1, "O flag")
	flag.Parse()

	valueK := *minusK
	valueO := *minusO
	valueO++

	fmt.Println("-k:", valueK)
	fmt.Println("-O:", valueO)
}


// --------------------------------
package main
import (
	"flag"
	"fmt"
	"strings"
)

type NamesFlag struct {
	Names []string
}

/*
// для 'flag.Var()' требуется определить интерфейс Value
type Value interface {
	String() string
	Set(string) error
}
*/

func (s *NamesFlag) GetNames() []string { return s.Names; }
func (s *NamesFlag) String()     string { return fmt.Sprint(s.Names); }
func (s *NamesFlag) Set(v string) error {
	if len(s.Names) > 0 { return fmt.Errorf("Only once!"); }
	names := strings.Split(v, ",")
	for _, item := range names {
		s.Names = append(s.Names, item)
	}
	return nil
}

func main() {
	// go run name.go -names=A,B,C 1 two Three
	var manyNames NamesFlag
	minusK := flag.Int("k", 0, "An int")
	minusO := flag.String("o", "X", "The name")
	flag.Var(&manyNames, "names", "Comma-separated list")
	flag.Parse()

	fmt.Println("-k:", *minusK)   // -k: 0
	fmt.Println("-o:", *minusO)   // -o: X

	for i, item := range manyNames.GetNames() {
		fmt.Println(i, "-", item)        // [0-A, 1-B, 2-C]
	}

	for index, val := range flag.Args() {
		fmt.Println(index, ":", val)     // [0:1, 1:two, 2:Three]
	}
}

// --------------------------------
// flag URL
package 
import (
	"flag"
	"fmt"
	"net/url"
)

type URLValue struct {
	URL *url.URL
}

func (v URLValue) String() string {
	if v.URL != nil { return v.URL.String(); }
	return ""
}

func (v URLValue) Set(s string) error {
	u, err := url.Parse(s)
	if err != nil { return err; }
	*v.URL = *u
	return nil
}

func main() {
	u := URLValue{ URL: &url.URL{} }
	flag.Var(&u, "url", "URL to parse")
	flag.Parse()
	fmt.Println(u.URL.Scheme, u.URL.Host)  // http mail.ru
}


// --------------------------------
//    Cobra
// --------------------------------
package main
import (
	"fmt"
	"github.com/spf13/cobra"
	"os"
)

var s string
var i int
var b bool

var f1 = &cobra.Command{Use: "f1", Long: "flags 1 command", Run: f1Func}
var f2 = &cobra.Command{Use: "f2", Long: "flags 2 command", Run: f2Func}
var root = &cobra.Command{Use: "nami", Long: "Nami command description."}

func init() {
	f1.Flags().StringVarP(&s, "string", "s", "foo", "a string") // -s, --string string a string (default "foo")
	err := f1.MarkFlagRequired("s")
	if err != nil {
		fmt.Println("err:", err)
	}
	f2.Flags().IntVarP(&i, "number", "i", 12, "an integer")
	f2.Flags().BoolVarP(&b, "boolean", "b", false, "a boolean")
	root.AddCommand(f1, f2)
}

func f1Func(cmd *cobra.Command, args []string) {
	fmt.Println("s:", s)
	fmt.Println("args:", args)
}

func f2Func(cmd *cobra.Command, args []string) {
	fmt.Println("i:", i)
	fmt.Println("b:", b)
	fmt.Println("args:", args)
}

func main() {
	if err := root.Execute(); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}


