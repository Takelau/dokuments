package main

import (
	"errors"
	"fmt"
	"math/rand"
	"sync"
	"time"
)

var errNF = errors.New("not found")
var count *Count

const (
	MIN int = 0
	MAX int = 10
)

func init() {
	rand.Seed(time.Now().Unix())
	count = &Count{}
}

// --------------
//   Count
// --------------
type Count struct {
	mx sync.Mutex
	n  int
}

func (c *Count) add() {
	c.mx.Lock()
	c.n++
	c.mx.Unlock()
}

func (c *Count) get() int {
	c.mx.Lock()
	defer c.mx.Unlock()
	return c.n
}

// --------------
//   A
// --------------
type A struct {
	mx sync.RWMutex
	b  map[int]*B
}

func NewA() *A {
	a := &A{b: map[int]*B{}}
	for i := MIN; i < MAX; i++ {
		go func(n int) {
			a.set(n, NewB())
		}(i)
	}
	return a
}

func (a *A) set(idx int, b *B) {
	a.mx.Lock()
	a.b[idx] = b
	a.mx.Unlock()
}

func (a *A) get(idx int) (*B, bool) {
	a.mx.RLock()
	b, ok := a.b[idx]
	a.mx.RUnlock()
	return b, ok
}

func (a *A) run(x int) {
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		b, ok := a.get(n)
		if ok {
			go func(x int, y int) {
				b.run(x, y)
			}(x, i)
		}
	}

	// v1
	a.mx.Lock()
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		b, _ := a.b[n]  // var 1.1
		a.b[n] = b      //
		a.b[n] = NewB() // var 1.2
	}
	a.mx.Unlock()

	// v2
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		go func(n int) {
			a.set(n, NewB())
		}(n)
	}
}

// --------------
//   B
// --------------
type B struct {
	mx sync.RWMutex
	c  map[int]*C
}

func NewB() *B {
	b := &B{c: map[int]*C{}}
	for i := MIN; i < MAX; i++ {
		go func(n int) {
			b.set(n, NewC())
		}(i)
	}
	return b
}

func (b *B) set(idx int, c *C) {
	b.mx.Lock()
	b.c[idx] = c
	b.mx.Unlock()
}

func (b *B) get(idx int) (*C, bool) {
	b.mx.RLock()
	c, ok := b.c[idx]
	b.mx.RUnlock()
	return c, ok
}

func (b *B) run(x int, y int) {
	// fmt.Println("  B run")
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		c, ok := b.get(n)
		if ok {
			go func(x int, y int, z int) {
				c.run(x, y, z)
			}(x, y, i)
		}
	}

	// v1
	b.mx.Lock()
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		c, _ := b.c[n] // v1.1

		d, _ := c.d[n] // <-- race
		c.d[n] = d + n // <-- race

		b.c[n] = c      //
		b.c[n] = NewC() // v1.2
	}
	b.mx.Unlock()

	// v2
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		go func(n int) {
			b.set(n, NewC())
		}(n)
	}
}

// --------------
//   C
// --------------
type C struct {
	mx sync.RWMutex
	d  map[int]int
}

func NewC() *C {
	c := &C{d: map[int]int{}}
	for i := MIN; i < MAX; i++ {
		go func(n int) {
			c.set(n, n)
		}(i)
	}
	return c
}

func (c *C) set(idx int, n int) {
	c.mx.Lock()
	c.d[idx] = n
	c.mx.Unlock()
}

func (c *C) get(idx int) (int, bool) {
	c.mx.RLock()
	d, ok := c.d[idx]
	c.mx.RUnlock()
	return d, ok
}

func (c *C) run(x int, y int, z int) {
	fmt.Printf("a:%d b:%d c:%d \n", x, y, z)
	for i := MIN; i < MAX; i++ {
		n := random(MIN, MAX)
		k, ok := c.get(i)
		if ok {
			n = n + k
		}
		c.set(i, n)

		// счетчик
		count.add()
	}
}

// --------------
//   Main
// --------------
func main() {
	a := NewA()

	for i := MIN; i < MAX; i++ {
		go func(n int) {
			a.run(n)
		}(i)
	}

	time.Sleep(time.Millisecond * 1000)
	fmt.Println("count run:", count.get())
}

func random(min, max int) int {
	return rand.Intn(max-min) + min
}
