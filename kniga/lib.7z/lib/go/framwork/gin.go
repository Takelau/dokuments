
// --------------------------------
//    Gin
// --------------------------------
GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS

r := gin.Default() // Logger and Recovery
r := gin.New()     // without middleware
r.LoadHTMLGlob("templates/**/*")

gin.DisableConsoleColor()
r.SetTrustedProxies([]string{"192.168.1.2"})  // список довереных прокси


// --------------------------------
// Read
// GET /test?s1=Jane&s2=Doe
r.GET("/test", func(c *gin.Context) {
	s1 := c.DefaultQuery("s1", "Guest")
	s2 := c.Query("s2")
})

// GET /user/john
r.GET("/user/:name", func(c *gin.Context) {
	name := c.Param("name")
})

r.POST("/user/:name/*action", func(c *gin.Context) {
	b := c.FullPath() == "/user/:name/*action" // true
})

r.POST("/form_post", func(c *gin.Context) {
	s1 := c.DefaultPostForm("s1", "anonymous")
	s2 := c.PostForm("s2")
})

// POST /post?id=1234&page=1 HTTP/1.1
// Content-Type: application/x-www-form-urlencoded
// name=manu&message=this_is_great
router.POST("/post", func(c *gin.Context) {
	id := c.Query("id")
	page := c.DefaultQuery("page", "0")
	name := c.PostForm("name")
	message := c.PostForm("message")
})

// POST /post?ids[a]=1234&ids[b]=hello HTTP/1.1
// Content-Type: application/x-www-form-urlencoded
// names[first]=thinkerou&names[second]=tianou
router.POST("/post", func(c *gin.Context) {
	ids   := c.QueryMap("ids")
	names := c.PostFormMap("names")
})

// Upload file
r.MaxMultipartMemory = 8 << 20  // 8 MiB
r.POST("/upload", func(c *gin.Context) {
	file, _ := c.FormFile("file") // file.Filename
	c.SaveUploadedFile(file, dst) // Upload the file to specific dst.
})

// Multiple files
r.MaxMultipartMemory = 8 << 20  // 8 MiB
r.POST("/upload", func(c *gin.Context) {
	form, _ := c.MultipartForm()
	files := form.File["upload[]"]
	for _, file := range files {  // file.Filename
		c.SaveUploadedFile(file, dst)  // Upload the file to specific dst.
	}
})

// redirect
c.Redirect(http.StatusMovedPermanently, "http://www.google.com/")  // GET
c.Redirect(http.StatusFound, "/foo")                               // POST
// ---
r.GET("/test", func(c *gin.Context) {
	c.Request.URL.Path = "/test2"
	r.HandleContext(c)
})
r.GET("/test2", func(c *gin.Context) {
	c.JSON(200, gin.H{"hello": "world"})
})


// --------------------------------
// Wreate
c.HTML(http.StatusOK, "index.tmpl", gin.H{"title":"Main website",})
c.JSON(http.StatusOK, gin.H{"status":"posted",})
c.String(http.StatusOK, "Hello %s", name)

// --------------------------------
// Status
http.StatusOK
http.StatusBadRequest
http.StatusUnauthorized


// --------------------------------
// Validation
github.com/go-playground/validator
ID     string   `uri:"id" binding:"required,uuid"` <- c.ShouldBindUri(&p)     // r.GET("/:name/:id", ...
Domain string   `header:"Domain"`                  <- c.ShouldBindHeader(&p)  // curl -H "rate:300" -H "domain:music" 127.0.0.1:8080/
Colors []string `form:"colors[]"`                  <- c.ShouldBind(&p)        // HTML checkboxes

Avatar *multipart.FileHeader `form:"avatar" binding:"required"`  <- // curl -X POST -v --form name=user --form "avatar=@./avatar.png" http://localhost:8080/profile
  c.ShouldBind(&form)
  err := c.SaveUploadedFile(form.Avatar, form.Avatar.Filename)

Birthday   time.Time `form:"birthday"   time_format:"2006-01-02" time_utc:"1"`
UnixTime   time.Time `form:"unixTime"   time_format:"unix"`
CreateTime time.Time `form:"createTime" time_format:"unixNano"`


// --------------------------------
// Middleware
r := gin.New()
r.Use(gin.Logger())
r.Use(gin.Recovery())
r.GET("/benchmark", MyBenchLogger(), benchEndpoint)
authorized := r.Group("/")
authorized.Use(AuthRequired()) {
	authorized.POST("/login", loginEndpoint)
	authorized.POST("/submit", submitEndpoint)
}

// Recovery Custom
r.Use(gin.CustomRecovery(func(c *gin.Context, recovered interface{}) {
	if err, ok := recovered.(string); ok {
		c.String(http.StatusInternalServerError, fmt.Sprintf("error: %s", err))
	}
	c.AbortWithStatus(http.StatusInternalServerError)
}))

// Custom Middleware 1
func Logger() gin.HandlerFunc {
	return func(c *gin.Context) {
		t := time.Now()
		c.Set("example", "12345")  // Set example variable
		// !!! before request !!!
		c.Next()
		// !!! after request !!!
		latency := time.Since(t)
		log.Print(latency)
		status := c.Writer.Status()  // access the status we are sending
		log.Println(status)
	}
}
func main() {
	r := gin.New()
	r.Use(Logger())
	r.GET("/test", func(c *gin.Context) {
		example := c.MustGet("example").(string)
		log.Println(example)  // it would print: "12345"
	})
	r.Run(":8080")
}

// Custom Middleware 2  ( https://github.com/unrolled/secure )
import "github.com/unrolled/secure"
func main() {
	secureMiddleware := secure.New(secure.Options{ FrameDeny: true, })
	secureFunc := func() gin.HandlerFunc {
		return func(c *gin.Context) {
			if err := secureMiddleware.Process(c.Writer, c.Request); err != nil {
				c.Abort(); return
			}
			if status := c.Writer.Status(); status > 300 && status < 399 { // redirect status
				c.Abort()
			}
		}
	}()
	router := gin.Default()
	router.Use(secureFunc)
	router.GET("/", func(c *gin.Context) {
		c.String(200, "X-Frame-Options header is now `DENY`.")
	})
	router.Run("127.0.0.1:3000")
}


// --------------------------------
// Log file
f, _ := os.Create("gin.log")
gin.DefaultWriter = io.MultiWriter(f)

// Log format
r.Use(gin.LoggerWithFormatter(func(param gin.LogFormatterParams) string {
	return fmt.Sprintf("%s - [%s] \"%s %s %s %d %s \"%s\" %s\"\n",
		param.ClientIP,
		param.TimeStamp.Format(time.RFC1123),
		param.Method,
		param.Path,
		param.Request.Proto,
		param.StatusCode,
		param.Latency,
		param.Request.UserAgent(),
		param.ErrorMessage,
	)
}))



