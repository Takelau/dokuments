
// --------------------------------
//    Gin Src
// --------------------------------
// mode
const EnvGinMode = "GIN_MODE"
func init() {
	mode := os.Getenv(EnvGinMode)
	SetMode(mode)
}

func SetMode(value string)    // {debug, release, test} debug <- default
func Mode() string

func ForceConsoleColor()      // consoleColorMode = forceColor    {autoColor, disableColor, forceColor}
func DisableConsoleColor()    // consoleColorMode = disableColor
func IsDebugging() bool
func DisableBindValidation()  // closes the default validator


// --------------------------------
//    Engine
// --------------------------------
type Engine struct {
	RouterGroup
	RedirectTrailingSlash bool   // /foo/ -> /foo  status  GET:301, ALL:307
	RedirectFixedPath bool       // /FOO and /..//Foo -> /foo
	RemoveExtraSlash bool
	MaxMultipartMemory int64
	...
}
func Default() *Engine
func New() *Engine
func (engine *Engine) Run(addr ...string) (err error)
func (engine *Engine) RunFd(fd int) (err error)
func (engine *Engine) RunListener(listener net.Listener) (err error)
func (engine *Engine) RunTLS(addr, certFile, keyFile string) (err error)
func (engine *Engine) RunUnix(file string) (err error)
func (engine *Engine) ServeHTTP(w http.ResponseWriter, req *http.Request)
func (engine *Engine) Use(middleware ...HandlerFunc) IRoutes


// --------------------------------
//    Context
// --------------------------------
type Context struct {
	Request *http.Request
	Writer   ResponseWriter
	Params   Params
	Keys     map[string]interface{}  // Keys is a key/value pair exclusively for the context of each request.
	Errors   errorMsgs               // Errors is a list of errors attached to all the handlers/middlewares who used this context.
	Accepted []string                // Accepted defines a list of manually accepted formats for content negotiation.
}
func (c *Context) Abort()
func (c *Context) AbortWithError(code int, err error) *Error
func (c *Context) AbortWithStatus(code int)
func (c *Context) AbortWithStatusJSON(code int, jsonObj interface{})


