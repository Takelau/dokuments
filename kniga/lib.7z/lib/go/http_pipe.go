
// --------------------------------
//    Pipe
// --------------------------------
Pipe creates a synchronous, in-memory, full duplex network connection

// --------------------------------
func Pipe() (Conn, Conn)

// --------------------------------

