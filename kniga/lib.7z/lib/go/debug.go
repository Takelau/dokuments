
// --------------------------------
//    Delve
// --------------------------------
go get -u github.com/go-delve/delve/cmd/dlv
go get -u github.com/aarzilli/gdlv

dlv version
dlv debug | dlv exec ./<name>

(dlv) break main.main