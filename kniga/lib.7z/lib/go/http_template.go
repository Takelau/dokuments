
data := []Entry{{A:10, B:11}, {A:20, B:21}}

// --------------------------------
//    html/template
// --------------------------------
tmp := "t.gohtml"
t := template.Must(template.ParseGlob(tmp))
t.ExecuteTemplate(w, tmp, data)


// --------------------------------
//    text/template
// --------------------------------
t,err := template.New("test").Parse(`{{range .}}A:{{printf "%d" .A}} B:{{printf "%d" .B}}{{end}}`)
t.Execute(os.Stdout, data)
// --------------------------------
// --------------------------------
// --------------------------------


// --------------------------------
//    Template variables
// --------------------------------
$variable := pipeline
{{with $x := "output" | printf "%q"}}{{$x}}{{end}}
{{with $x := "output"}}{{printf "%q" $x}}{{end}}
{{with $x := "output"}}{{$x | printf "%q"}}{{end}}


// --------------------------------
//    Template functions
// --------------------------------
type FuncMap map[string]interface{}
func EmailDealWith(args ...interface{}) string {
  // ... 
}
t = t.Funcs(template.FuncMap{"emailDeal": EmailDealWith})
{{.|emailDeal}}

// -------------------------
eq   arg1 == arg2
ne   arg1 != arg2
lt   arg1 <  arg2
le   arg1 <= arg2
gt   arg1 >  arg2
ge   arg1 >= arg2

{{ if or (ne .Params.lang "japanese") (.Scratch.Get "IsSingle") }}
<div class="content">{{ .Content }}</div>
{{ else }}
<div class="content"></div>
{{ end }}

