
Руны - это значения типа  int32 => тип Go, используемый для представления кодовых пунктов Unicode
Строка - это байтовый срез, предназначенный только для чтения, который может содержать байты любого типа и иметь произвольную длину. Строку можно рассматривать как множество рун
s := "\x40" - строковый литерал
s := "€"    - строковая переменная
r := '€'    - рунный литерал = рунная константа

type byte = uint8
type rune = int32

// unicode-table.com/en/042B/

s := "\xD0\xAB"
fmt.Println(s)                // Ы
fmt.Printf("%s",  s)          // Ы
fmt.Printf("%U",  []rune(s))  // [U+042B]
fmt.Printf("%x",  []byte(s))  // d0ab
fmt.Printf("%x",  s)          // d0ab
fmt.Printf("%q",  s)          // "Ы"
fmt.Printf("%+q", s)          // "\u042b"

s := "Ы"
fmt.Println(s)                // Ы
fmt.Printf("%s",  s)          // Ы
fmt.Printf("%U",  []rune(s))  // [U+042B]    CSS-code:\042B / Unicode (UTF-16BE HEX)
fmt.Printf("%x",  []byte(s))  // d0ab        UTF-8 HEX
fmt.Printf("%x",  s)          // d0ab
fmt.Printf("%q",  s)          // "Ы"
fmt.Printf("%+q", s)          // "\u042b"

s := 'Ы'
fmt.Println(s)                // 1067        HTML-code (&#1067;) / UTF-16BE DEC
fmt.Printf("%s",  s)          // %!s(int32=1067)
fmt.Printf("%U",  s)          // U+042B
fmt.Printf("%x",  []byte(s))  // cannot convert s (type rune) to type []byte
fmt.Printf("%x",  s)          // 42b
fmt.Printf("%q",  s)          // 'Ы'
fmt.Printf("%+q", s)          // '\u042b'

strings.Contains("seafood", "foo")    // true
strings.ContainsAny("fail", "ui")     // true
strings.ContainsRune("aardvark", 97)  // true
strings.Fields() - разбивает строку на основе пробельных символов, определенных в функции unicode.IsSpace()
strings.Split("ab cd", "")
strings.Split("a/b", string(filepath.Separator))  // '/'-filepath.Separator==os.PathSeparator, ':'-filepath.ListSeparator==os.PathListSeparator
strings.Replace("ab cd ef", "", "_", 1)  // 1 - макс кол-во замен
strings.SplitAfter("123++432++", "++"))  // [123++ 432++ ]

strings.TrimFunc("123 abc ABC \t .", trimFun)  // abc ABC
trimFun := func(c rune) bool { return !unicode.IsLetter(c); }

strings.ToUpper(str)
strings.ToLower(str)
strings.HasPrefix("Abcd", "Ab")   // true
strings.HasSuffix("Abcd", "cd")   // true
strings.Index("Abcd", "b")        // 1
strings.Count("cheese", "e")      // 3

strings.TrimSpace(str)
strings.TrimLeft(str)
strings.TrimRight(str)

unicode.ToLower(r rune) rune
unicode.ToUpper(r rune) rune
unicode.In(r rune, ranges ...*RangeTable) bool
unicode.IsLetter(r rune) bool   // (L)
unicode.IsDigit(r rune) bool    // десятичная цифра 
unicode.IsNumber(r rune) bool   // число (N)
unicode.IsGraphic(r rune) bool  // letters, marks, numbers, punctuation, symbols, and spaces (L,M,N,P,S,Zs)
unicode.IsPrint(r rune) bool    // ... но ASCII space ONLY, U+0020
unicode.IsSpace(r rune) bool    // '\t', '\n', '\v', '\f', '\r', ' ', U+0085 (NEL), U+00A0 (NBSP).

utf8.RuneLen(r rune) int
utf8.RuneCount(p []byte) int
utf8.RuneCountInString(s string) (n int)
utf8.ValidRune(r rune) bool
utf8.ValidString(s string) bool
utf8.DecodeRune(p []byte) (r rune, size int)
utf8.DecodeRuneInString(s string) (r rune, size int)
utf8.EncodeRune(p []byte, r rune) int   // r > p

bytes.Title(s []byte) []byte
bytes.ToLower(s []byte) []byte
bytes.Runes(s []byte) []rune
bytes.ContainsRune(b []byte, r rune) bool
bytes.Count(s, sep []byte) int                 // bytes.Count([]byte("cheese"), []byte("e"))
bytes.ReplaceAll(s, old, new []byte) []byte    // bytes.ReplaceAll([]byte("aaa"), []byte("a"), []byte("b"))

strconv.Atoi(s string) (int, error)                                 // str -> int
strconv.ParseFloat(s string, bitSize int) (float64, error)          // ("3.1415926535",32) !!!  -> 3.1415927410125732
strconv.ParseInt(s string, base int, bitSize int) (i int64, err error)
strconv.FormatInt(i int64, base int) string                         // (int64(-42), 10)         -> "-42"
strconv.FormatUint(i uint64, base int) string                       // (uint64(42), 10)         -> "42"
strconv.FormatFloat(f float64, fmt byte, prec, bitSize int) string  // (-3.1415926535,'f',4,64) -> "-3.1416"

strconv.IsGraphic(r rune) bool   // letters, marks, numbers, punctuation, symbols, and spaces
strconv.IsPrint(r rune) bool     // letters,        numbers, punctuation, symbols  and ASCII space

strconv.AppendQuote(dst []byte, s string) []byte          // "Freddie's ☺" + "☺"   -> Freddie's ☺"☺"
strconv.AppendQuoteRune(dst []byte, r rune) []byte        // "Freddie's ☺" + '☺'   -> Freddie's ☺'☺'
strconv.AppendQoteRuneToASCII(dst []byte, r rune) []byte  // "Freddie's" + '☺'     -> Freddie's'\u263a'
strconv.AppendQuoteToASCII(dst []byte, s string) []byte   // "Freddie's" + `"☺'☺"` -> Freddie's"\"\u263a'\u263a\""

// --------------------------------
s := "foö";      fmt.Printf("%T %v\n", s, s) // "string foö"
r := []rune(s);  fmt.Printf("%T %v\n", r, r) // "[]int32 [102 111 246]"
b := []byte(s);  fmt.Printf("%T %v\n", b, b) // "[]uint8 [102 111 195 182]"
// --------------------------------
str := "!"               // ASCII = 33
string(str[0] + byte(3)) // 33 + 3 = $
string(byte(36)))        // $
// --------------------------------
c1 := 'Ы';   fmt.Printf("%v %d %s \n", reflect.TypeOf(c1), c1, string(c1))     // int32 1067 Ы
c2 := "Ы";   fmt.Printf("%v %d %s \n", reflect.TypeOf(c2[0]), byte(c2[0]), c2) // uint8 208 Ы
// --------------------------------
const sL = "\x99\x00ab\x50\x00\x23\x50\x29\x9c"
if unicode.IsPrint(rune(sL[i])) { fmt.Printf("%c", sL[i]); }
// --------------------------------
unicode.To(unicode.UpperCase, 'g'))  // 'G'
// --------------------------------
str := "Hello, 世界"
for len(str) > 0 {
	r, size := utf8.DecodeLastRuneInString(str)
	fmt.Printf("%c %v\n", r, size)  //  порунно в обратном порядке
	str = str[:len(str)-size]
}
// --------------------------------
valid := "Hello, 世界"
invalid := string([]byte{0xff, 0xfe, 0xfd})
fmt.Println(valid,   utf8.ValidString(valid))    // Hello, 世界 true
fmt.Println(invalid, utf8.ValidString(invalid))  // ���         false
// --------------------------------
str := "Hello, 世界"
fmt.Println("bytes =", len(str))                     // 13
fmt.Println("runes =", utf8.RuneCountInString(str))  // 9
// --------------------------------
var buf bytes.Buffer;   defer buf.Reset()
buf.Write([]byte("abc123"))
b := make([]byte, 2)
for {
	n, err := buf.Read(b)
	if err == io.EOF || err != nil { break; }
	fmt.Printf("%s : %d \n", b[:n], n)
}
// --------------------------------
s := "тест тест тест тест Й"
	r := strings.NewReader(s)
	b := make([]byte, 2)
	str := ""
	for {
		n, _ := r.Read(b[0:])
		str = str + string(b[:n])
	}
// --------------------------------
var buf bytes.Buffer;   defer buf.Reset()
buf.Write([]byte("йцу123"))

for {
	r, n, err := buf.ReadRune()
	if err == io.EOF { break; }
	fmt.Printf("%s c:%d \n", string(r), n)  // й c:2
}

for _, r := range bytes.Runes(buf.Bytes()) {
	fmt.Printf("%s c:%d b:%d \n", string(r), utf8.RuneLen(r), len(string(r)))  // Й c:2 b:2
}
// --------------------------------