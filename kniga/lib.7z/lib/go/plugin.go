
-buildmode=plugin

func Open(path string) (*Plugin, error)
func (p *Plugin) Lookup(symName string) (Symbol, error)

// --------------------------------
package main

import (
	"fmt"
	"os"
	"plugin"
)

type Sayer interface {
	Says() string
}

func main() {
	if len(os.Args) != 2 {
		fmt.Println("usage: run main/main.go animal")
		os.Exit(1)
	}

	name := os.Args[1]
	module := fmt.Sprintf("./%s/%s.so", name, name)

	_, err := os.Stat(module)
	if os.IsNotExist(err) { fmt.Println("can't find an animal named", name);  os.Exit(1); }

	p, err := plugin.Open(module)
	if err != nil { fmt.Println(err); os.Exit(1); }

	symbol, err := p.Lookup("Animal")
	if err != nil { fmt.Println(err); os.Exit(1); }

	animal, ok := symbol.(Sayer)
	if !ok { fmt.Println("that's not an Sayer"); os.Exit(1); }

	fmt.Printf("A %s says: %q\n", name, animal.Says())
}

// fox/fox.go
package main
type fox struct{}
func (f fox) Says() string {
	return "ring-ding-ding-ding-dingeringeding!"
}
var Animal fox

//  duck/duck.go
package main
type duck struct{}
func (d duck) Says() string {
	return "quack!"
}
var Animal duck

go build -buildmode=plugin -o duck/duck.so duck/duck.go
