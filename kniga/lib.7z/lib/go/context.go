
ctx, cancel := context.WithCancel(context.Background())
defer cancel()

ctx, cancel := context.WithTimeout(context.Background(), time.Duration(5)*time.Second)
defer cancel()

deadline := time.Now().Add(time.Duration(5) * time.Second)
ctx, cancel := context.WithDeadline(context.Background(), deadline)
defer cancel()

type Context interface {
	Deadline() (deadline time.Time, ok bool)
	Done() <-chan struct{}
	Err() error
	Value(key interface{}) interface{}
}

// -------------------------------
// Done
func (p *Pool) Acquire(ctx context.Context) (...) {
	if doneChan := ctx.Done(); doneChan != nil {
		select {
		case <-ctx.Done():
			...
			return nil, ctx.Err()
		default:
		}
	}
}

// -------------------------------
// WithCancel
package main
import (
	"context"
	"fmt"
)

func main() {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	gen := func(ctx context.Context) <-chan int {
		dst := make(chan int)
		n := 1
		go func() {
			for {
				select {
					case <-ctx.Done(): return
					case dst <- n:     n++
				}
			}
		}()
		return dst
	}

	for n := range gen(ctx) {
		if n == 5 {
			cancel()   // выходим из горутины самостоятельно
			break
		}
		fmt.Println(n)
	}
}

// -------------------------------
// WithDeadline
d := time.Now().Add(1 * time.Millisecond)
ctx, cancel := context.WithDeadline(context.Background(), d)
defer cancel()

select {
case <-time.After(1 * time.Second):
	fmt.Println("overslept")
case <-ctx.Done():
	fmt.Println(ctx.Err())
}

// -------------------------------
// WithTimeout
d := time.Millisecond
ctx, cancel := context.WithTimeout(context.Background(), d)
defer cancel()

select {
case <-time.After(1 * time.Second):
	fmt.Println("overslept")
case <-ctx.Done():
	fmt.Println(ctx.Err()) // prints "context deadline exceeded"
}

// -------------------------------
// cancel if Err
finc newStream(ctx context.Context, ...) (err error) {
	var cancel context.CancelFunc
	if timeOut != nil && timeOut >= 0 {
		ctx, cancel = context.WithTimeout(ctx, timeOut)
	} else {
		ctx, cancel = context.WithCancel(ctx)
	}
	defer func() { if err != nil { cancel(); } }()
}
