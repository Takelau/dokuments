
git tag v1.1.1
git push origin v1.1.1

// --------------------------------
//    Модули
// --------------------------------
go mod init [<имя пакета>]
go mod vendor  // ведение каталога модулей в папке проекта | вызывать только после 'go mod init'
go mod tidy    // удалит неиспользуемый модуль, либо удалит комментарий // indirect
go mod download
GO111MODULE=on

go list -m -json
go list -m -u all  // все модули, которые являются зависимостями текущего модуля, вместе с последней доступной версией для каждого
go list -m -u example.com/module          // Показать последнюю версию, доступную для конкретного модуля
go list -m -versions example.com/module   // список доступных версий модуля

// подключение модуля
go get example.com/module@(v1.2.3 | latest | commithash | branchname)
require example.com/module v1.2.3

// удаление зависимости
go mod tidy
go get example.com/module@none  // также понижает или удаляет другие зависимости, которые зависят от удаленного модуля

// подмена не опубликованного модуля локальной версией
go mod edit -replace=example.com/module@v0.0.0-unpublished=../module
go get -d example.com/module@v0.0.0-unpublished
require example.com/module v0.0.0-unpublished
replace example.com/module v0.0.0-unpublished => ../module

// подмена модулф его форком
go list -m example.com/module
go mod edit -replace=example.com/module@v1.2.3=example.com/myfork/module v1.2.3-fixed
require example.com/module v1.2.3
replace example.com/module v1.2.3 => example.com/myfork/module v1.2.3-fixed

// кто использует модуль?
go mod why -m github.com/jackc/pgx/v4
go mod graph | grep github.com/jackc/pgx/v4

// прокси-сервер модуля
GOPROXY="https://proxy.example.com(,|)https://proxy2.example.com" // [,-404 или 410  |-любая ошибка]

// --------------------------------
// package myModule
go mod init
git add .
git commit -a -m "Initial version 1.0.0"
git push
git tag v1.0.0
git push -q origin v1.0.0

// package main
export GO111MODULE=on
go run .
go mod init <name_module>

// --------------------------------
// переход на версию v2
git checkout -b v2
git push --set-upstream origin v2
nano go.mod
module github.com/<module>/v2
git commit -a -m "Using 2.0.0"
git tag v2.0.0
git push --tags origin v2

// package main
import (
	v2 "github.com/<module>/v2"
)


// --------------------------------
//    Пакеты
// --------------------------------
mkdir ~/go/src/apack
go install apack
cd ~/go/pkg/linux_amd64/

// генерация пакета apack.o
go tool compile apack.go  -> apack.o

