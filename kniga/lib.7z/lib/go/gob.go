
"encoding/gob"

func save(fname string, data *map[string]myElement) error {
	err := os.Remove(fname);             if err != nil { return err; }
	saveTo, err := os.Create(fname);     if err != nil { return err; }
	defer saveTo.Close()
	encoder := gob.NewEncoder(saveTo)
	err = encoder.Encode(*data);         if err != nil { return err; }
	return nil
}

func load(fname string, data *map[string]myElement) error {
	loadFrom, err := os.Open(fname)
	defer loadFrom.Close();              if err != nil { return err; }
	decoder := gob.NewDecoder(loadFrom)
	decoder.Decode(data)
	return nil
}
