
// --------------------------------
// exec.Command() + cmd.Run()
	cmd := exec.Command("tr", "a-z", "A-Z")
	cmd.Stdin = strings.NewReader("some input")
	var out bytes.Buffer
	cmd.Stdout = &out
	err := cmd.Run()
	if err != nil { log.Fatal(err); }
	fmt.Printf("in all caps: %q\n", out.String())  // <- in all caps: "SOME INPUT"

// --------------------------------
// exec.Command() + cmd.CombinedOutput()
cmd := exec.Command("sh", "-c", "echo stdout; echo 1>&2 stderr")
outErr, err := cmd.CombinedOutput()
if err != nil { log.Fatal(err); }
fmt.Printf("%s\n", outErr)  // <- stdout stderr

// --------------------------------
// exec.Command() + cmd.Output()
out, err := exec.Command("date").Output()
if err != nil { log.Fatal(err); }
fmt.Printf("The date is %s\n", out)  // <- The date is Sat Mar  5 16:34:29 UTC 2022

// --------------------------------
// exec.CommandContex + cmd.Run()
ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond);  defer cancel()
if err := exec.CommandContext(ctx, "sleep", "5").Run(); err != nil {
	// This will fail after 100 milliseconds. The 5 second sleep will be interrupted.
}


// --------------------------------
//   SRC
// --------------------------------
func Command(name string, arg ...string) *Cmd {
	cmd := &Cmd{
		Path: name,
		Args: append([]string{name}, arg...),
	}
	if filepath.Base(name) == name {
		if lp, err := LookPath(name); err != nil {
			cmd.lookPathErr = err
		} else {
			cmd.Path = lp
		}
	}
	return cmd
}

//
func CommandContext(ctx context.Context, name string, arg ...string) *Cmd {
	if ctx == nil { panic("nil Context"); }
	cmd := Command(name, arg...)
	cmd.ctx = ctx
	return cmd
}

//
func (c *Cmd) CombinedOutput() ([]byte, error) {
	if c.Stdout != nil { return nil, errors.New("exec: Stdout already set"); }
	if c.Stderr != nil { return nil, errors.New("exec: Stderr already set"); }
	var b bytes.Buffer
	c.Stdout = &b
	c.Stderr = &b
	err := c.Run()
	return b.Bytes(), err
}

//
func (c *Cmd) Output() ([]byte, error) {
	if c.Stdout != nil { return nil, errors.New("exec: Stdout already set"); }
	var stdout bytes.Buffer
	c.Stdout = &stdout

	captureErr := c.Stderr == nil
	if captureErr {
		c.Stderr = &prefixSuffixSaver{N: 32 << 10}
	}

	err := c.Run()
	if err != nil && captureErr {
		if ee, ok := err.(*ExitError); ok {
			ee.Stderr = c.Stderr.(*prefixSuffixSaver).Bytes()
		}
	}
	return stdout.Bytes(), err
}

//
func (c *Cmd) StdoutPipe() (io.ReadCloser, error) {
	...
	pr, pw, err := os.Pipe()
	if err != nil {
		return nil, err
	}
	c.Stdout = pw
	c.closeAfterStart = append(c.closeAfterStart, pw)
	c.closeAfterWait  = append(c.closeAfterWait, pr)
	return pr, nil
}

//
func (c *Cmd) StderrPipe() (io.ReadCloser, error) {
	...
	pr, pw, err := os.Pipe()
	if err != nil {
		return nil, err
	}
	c.Stderr = pw
	c.closeAfterStart = append(c.closeAfterStart, pw)
	c.closeAfterWait  = append(c.closeAfterWait, pr)
	return pr, nil
}

// Start() + Wait()  !!!
func (c *Cmd) Run() error {
	if err := c.Start(); err != nil { return err; }
	return c.Wait()
}

//
func (c *Cmd) Start() error {
	if c.ctx != nil {
		select {
		case <-c.ctx.Done():
			c.closeDescriptors(c.closeAfterStart)
			c.closeDescriptors(c.closeAfterWait)
			return c.ctx.Err()
		default:
		}
	}
	// создание файловых дескрипторов потоков (*Cmd).stdin, (*Cmd).stdout, (*Cmd).stderr
	c.childFiles = make([]*os.File, 0, 3+len(c.ExtraFiles))
	type F func(*Cmd) (*os.File, error)
	for _, setupFd := range []F{(*Cmd).stdin, (*Cmd).stdout, (*Cmd).stderr} {
		fd, err := setupFd(c)
		if err != nil {
			c.closeDescriptors(c.closeAfterStart)
			c.closeDescriptors(c.closeAfterWait)
			return err
		}
		c.childFiles = append(c.childFiles, fd)
	}
	c.childFiles = append(c.childFiles, c.ExtraFiles...)
	// Process
	c.Process, err = os.StartProcess(c.Path, c.argv(), &os.ProcAttr{   // Start Process
		Dir:   c.Dir,
		Files: c.childFiles,
		Env:   addCriticalEnv(dedupEnv(envv)),
		Sys:   c.SysProcAttr,
	})
	if err != nil { ... }
	// c.waitDone
	if c.ctx != nil {
		c.waitDone = make(chan struct{})    // если используется Контекст, то требуется вызов Wait(), иначе го-рутина может зависнуть
		go func() {
			select {
			case <-c.ctx.Done():  c.Process.Kill()  // завертешие зависшего процесса
			case <-c.waitDone:
			}
		}()
	}

	return nil
}

// ожидает 
func (c *Cmd) Wait() error {
	state, err := c.Process.Wait()
	if c.waitDone != nil { close(c.waitDone); }  // освобождение го-рутины Start()
	c.ProcessState = state

	var copyError error
	for range c.goroutine {
		if err := <-c.errch; err != nil && copyError == nil { copyError = err; }
	}

	c.closeDescriptors(c.closeAfterWait)  // fd.Close()

	if err != nil {              return err
	} else if !state.Success() { return &ExitError{ProcessState: state}; }

	return copyError
}
