
openssl req -newkey rsa:2048 -nodes -keyout server.key -x509 -days 365 -out server.crt
curl -i -XPUT --http2 https://http2.golang.org/ECHO -d hello

// --------------------------------
// http2 + Push()
package main
import (
	"log"
	"net/http"
)

func main() {
	srv := &http.Server{Addr:":8000", Handler:http.HandlerFunc(handle)}
	log.Fatal(srv.ListenAndServeTLS("server.crt", "server.key"))
}

func handle(w http.ResponseWriter, r *http.Request) {
	log.Printf("Got connection: %s", r.Proto)
	
	if pusher, ok := w.(http.Pusher); ok {
		options := &http.PushOptions{ Header: http.Header{ "Accept-Encoding": r.Header["Accept-Encoding"], }, }
		if err := pusher.Push("/app.js", options); err != nil {
			log.Printf("Failed to push: %v", err)
		}
	}

	w.Write([]byte("Hello"))
}

// client
package main
import (
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"golang.org/x/net/http2"
)
const url = "https://localhost:8000"
var httpVersion = flag.Int("version", 2, "HTTP version")

func main() {
	flag.Parse()
	client := &http.Client{}

	caCert, err := ioutil.ReadFile("server.crt");  if err != nil { log.Fatalf("Reading server certificate: %s", err); }
	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)

	tlsConfig := &tls.Config{
		RootCAs: caCertPool,
	}

	// Use the proper transport in the client
	switch *httpVersion {
	case 1:
		client.Transport = &http.Transport{
			TLSClientConfig: tlsConfig,
		}
	case 2:
		client.Transport = &http2.Transport{
			TLSClientConfig: tlsConfig,
		}
	}

	resp, err := client.Get(url);            if err != nil { log.Fatalf("Failed get: %s", err); }
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body);  if err != nil { log.Fatalf("Failed reading response body: %s", err); }
	fmt.Printf("Got response %d: %s %s\n", resp.StatusCode, resp.Proto, string(body))
}

// --------------------------------
// h2c - https://github.com/GoogleCloudPlatform/golang-samples/tree/master/run/h2c
package main
import (
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"golang.org/x/net/http2"
)

func main() {
	port := "8080"
	if v := os.Getenv("PORT"); v != "" { port = v; }
	addr := net.JoinHostPort("", port)

	lis, err := net.Listen("tcp", addr);   if err != nil { log.Fatal(err); }

	http.HandleFunc("/", handler)

	server := http2.Server{}
	opts := &http2.ServeConnOpts{
		Handler: http.DefaultServeMux,
	}

	for {
		conn, err := lis.Accept()
		if err != nil { log.Printf("failed to accept connection: %v", err); }
		go server.ServeConn(conn, opts)
	}
}

func handler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "This request is served over %s protocol.", r.Proto)
}

// --------------------------------
// h2c only
// golang.org/x/net/http2/h2c
h2 := http2.Server{}
l, err := net.Listen("tcp", "0.0.0.0:1010")
for {
	conn, err := l.Accept()
	h2.ServeConn(conn, &http2.ServeConnOpts{
		Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "Hello, %v, http: %v", r.URL.Path, r.TLS == nil)
	}),
})

// --------------------------------
// h2c + h1
handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
	fmt.Fprint(w, "Hello world")
})

h2s := &http2.Server{}
h1s := &http.Server{
	Addr:    ":8080",
	Handler: h2c.NewHandler(handler, h2s),
}
log.Fatal(h1s.ListenAndServe())

// --------------------------------
// h2c + Context - https://github.com/golang/net/blob/master/http2/h2c/h2c_test.go
	baseCtx := context.WithValue(context.Background(), "testkey", "testvalue")

	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.ProtoMajor != 2 {                           t.Errorf("Request wasn't handled by h2c.  Got ProtoMajor=%v", r.ProtoMajor) }
		if r.Context().Value("testkey") != "testvalue" { t.Errorf("Request doesn't have expected base context: %v", r.Context()) }
		fmt.Fprint(w, "Hello world")
	})

	h2s := &http2.Server{}
	h1s := httptest.NewUnstartedServer(NewHandler(handler, h2s))
	h1s.Config.BaseContext = func(_ net.Listener) context.Context {
		return baseCtx
	}
	h1s.Start()
	defer h1s.Close()

	client := &http.Client{
		Transport: &http2.Transport{
			AllowHTTP: true,
			DialTLS: func(network, addr string, _ *tls.Config) (net.Conn, error) {
				return net.Dial(network, addr)
			},
		},
	}

	resp, err := client.Get(h1s.URL);    if err != nil { t.Fatal(err) }
	_, err = ioutil.ReadAll(resp.Body);  if err != nil { t.Fatal(err) }
	if err := resp.Body.Close(); err != nil { t.Fatal(err) }

// --------------------------------
// client -> h2c
client := http.Client{
    Transport: &http2.Transport{
        // So http2.Transport doesn't complain the URL scheme isn't 'https'
        AllowHTTP: true,
        // Pretend we are dialing a TLS endpoint.
        // Note, we ignore the passed tls.Config
        DialTLS: func(network, addr string, cfg *tls.Config) (net.Conn, error) {
            return net.Dial(network, addr)
        },
    },
}
resp, _ := client.Get(url)
fmt.Printf("Client Proto: %d\n", resp.ProtoMajor)