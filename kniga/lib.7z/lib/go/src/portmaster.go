
// --------------------------------
//    Portmaster
// --------------------------------
/** ./pack **/
./cmds/portmaster-core/pack  build
./cmds/portmaster-start/pack build


// main()
./cmds/integrationtest/main.go:14
./cmds/portmaster-core/main.go:32   // <--
./cmds/portmaster-start/main.go:82
./cmds/trafficgen/main.go:31
./cmds/updatemgr/main.go:54
./cmds/winkext-test/main.go:35

// init()
./broadcasts/module.go:22
./cmds/integrationtest/netstate.go:15
./cmds/portmaster-start/dirs.go:11
./cmds/portmaster-start/install_windows.go:22
./cmds/portmaster-start/main.go:66
./cmds/portmaster-start/recover_linux.go:63
./cmds/portmaster-start/run.go:58
./cmds/portmaster-start/service_windows.go:45
./cmds/portmaster-start/show.go:12
./cmds/portmaster-start/update.go:21
./cmds/portmaster-start/verify.go:34
./cmds/portmaster-start/version.go:73
./cmds/trafficgen/main.go:24
./cmds/updatemgr/main.go:49
./cmds/updatemgr/purge.go:11
./cmds/updatemgr/release.go:33
./cmds/updatemgr/scan.go:10
./cmds/updatemgr/sign.go:18
./cmds/winkext-test/main.go:28
./compat/module.go:39
./core/base/global.go:23
./core/base/module.go:13
./core/base/profiling.go:13
./core/config.go:18
./core/core.go:29
./core/pmtesting/testing.go:35
./firewall/filter.go:12                            modules.Register("filter", nil, nil, nil, "core", "interception", "intel")
./firewall/interception.go:53                      modules.Register("interception", interceptionPrep, interceptionStart, interceptionStop, "base", "updates", "network", "notifications", "profiles")
./firewall/interception/interception.go:17           flag.BoolVar(&disableInterception, "disable-interception", false, "disable packet interception; this breaks a lot of functionality")
./firewall/interception/introspection.go:20          flag.StringVar(&packetMetricsDestination, "write-packet-metrics", "", "write packet metrics to the specified file")
./firewall/interception/nfqueue_linux.go:37          flag.BoolVar(&experimentalNfqueueBackend, "experimental-nfqueue", false, "(deprecated flag; always used)")
./firewall/interception/nfqueue_linux.go:47          flag.BoolVar(&experimentalNfqueueBackend, "experimental-nfqueue", false, "(deprecated flag; always used)")
./firewall/preauth.go:20                             resolver.SetLocalAddrFactory(PermittedAddr) & netenv.SetLocalAddrFactory(PermittedAddr)
./intel/customlists/module.go:40
./intel/filterlists/database.go:65
./intel/filterlists/module.go:30
./intel/geoip/database.go:18
./intel/geoip/module.go:13
./intel/module.go:11
./nameserver/config.go:22                            flag.StringVar(&nameserverAddress, "nameserver-address", defaultNameserverAddress, "set default nameserver address; configuration is stronger")
./nameserver/module.go:34                          modules.Register("nameserver", prep, start, stop, "core", "resolver")
./netenv/location_test.go:10
./netenv/main.go:19                                modules.Register(ModuleName, prep, start, nil)
./netenv/online-status.go:166
./netenv/os_android.go:14
./netquery/module_api.go:27
./network/module.go:15                             modules.Register("network", prep, start, nil, "base", "netenv", "processes")   // tcp4ProcFile = "/proc/net/tcp"
./network/packet/parse.go:158
./network/state/system_default.go:18
./process/module.go:15                             modules.Register("processes", prep, start, nil, "profiles", "updates")
./process/special.go:31
./process/tags/appimage_unix.go:11
./process/tags/interpreter_unix.go:18
./process/tags/net.go:8
./process/tags/snap_unix.go:11
./process/tags/svchost_windows.go:13
./process/tags/winstore_windows.go:14
./profile/module.go:23
./resolver/main.go:24
./resolver/main_test.go:15
./resolver/resolver_test.go:21
./status/module.go:14
./ui/module.go:11
./updates/helper/signing.go:31
./updates/main.go:82
