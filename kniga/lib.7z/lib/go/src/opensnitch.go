
// --------------------------------
//    OpenSnitch
// --------------------------------
// package netfilter
type Packet struct {
	Packet          gopacket.Packet
	Mark            uint32
	verdictChannel  chan VerdictContainer
	UID             uint32
	NetworkProtocol uint8
}
// package conman
type Connection struct {
	Protocol string
	SrcIP    net.IP
	SrcPort  uint
	DstIP    net.IP
	DstPort  uint
	DstHost  string

	Entry    *netstat.Entry
	Process  *procmon.Process
	pkt      *netfilter.Packet
}
// package netstat
type Entry struct {
	Proto   string
	SrcIP   net.IP
	SrcPort uint
	DstIP   net.IP
	DstPort uint
	UserId  int
	INode   int
}

// package procmon
type Process struct {
	ID          int
	Comm        string
	Path        string
	Args        []string
	Env         map[string]string
	CWD         string
	Descriptors []*procDescriptors
	IOStats     *procIOstats
	Status      string
	Stat        string
	Statm       *procStatm
	Stack       string
	Maps        string
}

// --------------------------------

// package main
func onPacket(packet netfilter.Packet) {
	con := conman.Parse(packet, true)  // <- *Connection{}
	_ = acceptOrDeny(&packet, con)
}

// package conman
func Parse(nfp netfilter.Packet, interceptUnknown bool) *Connection {
	if nfp.IsIPv4() {
		con, err := NewConnection(&nfp)
		return con
	}

	con, err := NewConnection6(&nfp)
	return con
}

func NewConnection(nfp *netfilter.Packet) (c *Connection, err error) {
	ipv4 := nfp.Packet.Layer(layers.LayerTypeIPv4)
	ip, ok := ipv4.(*layers.IPv4)
	c = &Connection{
		SrcIP:   ip.SrcIP,
		DstIP:   ip.DstIP,
		DstHost: dns.HostOr(ip.DstIP, ""),
		pkt:     nfp,
	}
	return newConnectionImpl(nfp, c, "")
}

func newConnectionImpl(nfp *netfilter.Packet, c *Connection, protoType string) (cr *Connection, err error) {
	c.Entry = &netstat.Entry{
		Proto:   c.Protocol,
		SrcIP:   c.SrcIP,
		SrcPort: c.SrcPort,
		DstIP:   c.DstIP,
		DstPort: c.DstPort,
		UserId:  -1,
		INode:   -1,
	}
	pid := -1
	uid := -1
	1.
	if procmon.MethodIsEbpf() {  // return monitorMethod = "ebpf"
		pid, uid, err = ebpf.GetPid(c.Protocol, c.SrcPort, c.SrcIP, c.DstIP, c.DstPort)
		if err != nil { return nil, nil; }
	}
	if pid < 0 {
		var inodeList []int
		2.  // повторяет вызов в функции 'ebpf.GetPid()'
		uid, inodeList = netlink.GetSocketInfo(c.Protocol, c.SrcIP, c.SrcPort, c.DstIP, c.DstPort)   // package "nami/netlink"
		for n, inode := range inodeList {
			pid = procmon.GetPIDFromINode(inode, fmt.Sprint(inode, c.SrcIP, c.SrcPort, c.DstIP, c.DstPort))  // tries to get the PID from a socket inode
			if pid != -1 {
				c.Entry.INode = inode   // log.Debug("[%d] PID found %d [%d]", n, pid, inode)
				break
			}
		}
	}
	3.
	if pid == os.Getpid() {
		c.Process = procmon.NewProcess(pid, "")
		return c, nil
	}
	4.
	if c.Process = procmon.FindProcess(pid, showUnknownCons); c.Process == nil {
		return nil, fmt.Errorf("Could not find process by its pid %d for: %s", pid, c)
	}
	return c, nil
}

// package ebpf
func GetPid(proto string, srcPort uint, srcIP net.IP, dstIP net.IP, dstPort uint) (int, int, error) {
	1. // looks up a connection in bpf map and returns PID
	if pid, uid := getPidFromEbpf(proto, srcPort, srcIP, dstIP, dstPort); pid != -1 {
		return pid, uid, nil
	}
	2. // searches those TCP connections which were already established at the time when opensnitch started
	if proto == "tcp" || proto == "tcp6" {
		if pid, uid, err := findInAlreadyEstablishedTCP(proto, srcPort, srcIP, dstIP, dstPort); err == nil {
			return pid, uid, nil
		}
	}
	3. // using netlink.GetSocketInfo to check if UID is 0 (in-kernel connection)
	if uid, _ := daemonNetlink.GetSocketInfo(proto, srcIP, srcPort, dstIP, dstPort); uid == 0 {
		return -100, -100, nil
	}
	if !findAddressInLocalAddresses(srcIP) {
		// systemd-resolved sometimes makes a TCP Fast Open connection to a DNS server (8.8.8.8 on my machine)
		// and we get a packet here with **source** (not detination!!!) IP 8.8.8.8
		// Maybe it's an in-kernel response with spoofed IP because wireshark does not show neither
		// resolved's TCP Fast Open packet, nor the response
		// Until this is better understood, we simply do not allow this machine to make connections with
		// arbitrary source IPs
		return -1, -1, fmt.Errorf("eBPF packet with unknown source IP: %s", srcIP)
	}
	return -1, -1, nil
}

// --- Go package ebpf
var (
	m            *elf.Module
	ebpfMaps      map[string]*ebpfMapsForProto
	ebpfCache    *ebpfCacheType
	hostByteOrder binary.ByteOrder  // binary.LittleEndian | binary.BigEndian
)
type ebpfMapsForProto struct {
	counterMap *elf.Map   // "github.com/iovisor/gobpf/elf"
	bpfmap     *elf.Map
}
type ebpfCacheType struct {
	Items map[string]*ebpfCacheItem
	sync.RWMutex
}
type ebpfCacheItem struct {
	Key      []byte
	LastSeen int64
	UID      int  // <-- UID
	Pid      int  // <-- PID
	Hits     uint
}

func Start() error {
	m = elf.NewModule("/etc/opensnitchd/opensnitch.o")
	ebpfMaps = map[string]*ebpfMapsForProto{
		"tcp":  { counterMap: m.Map("tcpcounter"),   bpfmap:m.Map("tcpMap")   },  // SEC("maps/tcpcounter") tcpcounter,      SEC("maps/tcpMap") tcpMap
		"tcp6": { counterMap: m.Map("tcpv6counter"), bpfmap:m.Map("tcpv6Map") },  // SEC("maps/tcpv6counter") tcpv6counter,  SEC("maps/tcpv6Map") tcpv6Map
		"udp":  { counterMap: m.Map("udpcounter"),   bpfmap:m.Map("udpMap")   },
		"udp6": { counterMap: m.Map("udpv6counter"), bpfmap:m.Map("udpv6Map") },
	}
	...
}

// --- C
struct tcp_key_t {
	u16 sport;
	u32 daddr;
	u16 dport;
	u32 saddr;
}__attribute__((packed));

struct tcp_value_t{
	pid_size_t pid;
	uid_size_t uid;
	u64 counter;
}__attribute__((packed));

struct bpf_map_def SEC("maps/tcpMap") tcpMap = {
	.type = BPF_MAP_TYPE_HASH,
	.key_size   = sizeof(struct tcp_key_t),
	.value_size = sizeof(struct tcp_value_t),
	.max_entries = MAPSIZE+1,
};

struct bpf_map_def SEC("maps/tcpcounter") tcpcounter = {
	.type = BPF_MAP_TYPE_ARRAY,
	.key_size   = sizeof(u32),
	.value_size = sizeof(u64),
	.max_entries = 1,
};

SEC("kretprobe/tcp_v4_connect")
int kretprobe__tcp_v4_connect(struct pt_regs *ctx)
{
	u64 pid_tgid = bpf_get_current_pid_tgid();
	u64 *skp = bpf_map_lookup_elem(&tcpsock, &pid_tgid);
	if (skp == NULL) {return 0;}

	struct sock *sk;
	__builtin_memset(&sk, 0, sizeof(sk));
	sk = (struct sock *)*skp;

	struct tcp_key_t tcp_key;
    __builtin_memset(&tcp_key, 0, sizeof(tcp_key));
	bpf_probe_read(&tcp_key.dport, sizeof(tcp_key.dport), &sk->__sk_common.skc_dport);
	bpf_probe_read(&tcp_key.sport, sizeof(tcp_key.sport), &sk->__sk_common.skc_num);
	bpf_probe_read(&tcp_key.daddr, sizeof(tcp_key.daddr), &sk->__sk_common.skc_daddr);
	bpf_probe_read(&tcp_key.saddr, sizeof(tcp_key.saddr), &sk->__sk_common.skc_rcv_saddr);
	
	u32 zero_key = 0;
	u64 *val = bpf_map_lookup_elem(&tcpcounter, &zero_key);
	if (val == NULL){return 0;}

	struct tcp_value_t tcp_value;
	__builtin_memset(&tcp_value, 0, sizeof(tcp_value));
	tcp_value.pid = pid_tgid >> 32;
	tcp_value.uid = bpf_get_current_uid_gid() & 0xffffffff;
	tcp_value.counter = *val;
	bpf_map_update_elem(&tcpMap, &tcp_key, &tcp_value, BPF_ANY);

	u64 newval = *val + 1;
	bpf_map_update_elem(&tcpcounter, &zero_key, &newval, BPF_ANY);
	bpf_map_delete_elem(&tcpsock, &pid_tgid);
	return 0;
};

// ---

1. // looks up a connection in bpf map and returns PID
func getPidFromEbpf(proto string, srcPort uint, srcIP net.IP, dstIP net.IP, dstPort uint) (pid int, uid int) {
	var key   []byte  // srcPort + dstIP + dstPort + srcIP
	var value []byte
	var isIP4 bool = (proto == "tcp") || (proto == "udp") || (proto == "udplite")

	if isIP4 {
		key   = make([]byte, 12)
		value = make([]byte, 24)
		copy(key[2:6], dstIP)
		binary.BigEndian.PutUint16(key[6:8], uint16(dstPort))
		copy(key[8:12], srcIP)
	} else { // IPv6
		key   = make([]byte, 36)
		value = make([]byte, 24)
		copy(key[2:18], dstIP)
		binary.BigEndian.PutUint16(key[18:20], uint16(dstPort))
		copy(key[20:36], srcIP)
	}
	hostByteOrder.PutUint16(key[0:2], uint16(srcPort))

	// поиск в кэше
	k := fmt.Sprint(proto, srcPort, srcIP.String(), dstIP.String(), dstPort)  // "tcp80192.168.1.7192.168.1.20041000"
	cacheItem, isInCache := ebpfCache.isInCache(k)
	if isInCache {
		deleteEbpfEntry(proto, unsafe.Pointer(&key[0]))  // ? зачем ?
		return cacheItem.Pid, cacheItem.UID
	}

	// поиск в 'bpfmap'
	err := m.LookupElement(ebpfMaps[proto].bpfmap, unsafe.Pointer(&key[0]), unsafe.Pointer(&value[0]))
	if err != nil {
		// sometimes srcIP is 0.0.0.0. Happens especially with UDP sendto()
		// for example: 57621:10.0.3.1 -> 10.0.3.255:57621 , reported as: 0.0.0.0 -> 10.0.3.255
	}
	if err != nil && proto == "udp" && srcIP.String() == dstIP.String() {
		// It has srcIP and dstIP == 0.0.0.0 in ebpf map
	}
	if err != nil {  // key not found in bpf maps
		return -1, -1
	}

	pid = int(hostByteOrder.Uint32(value[0:4]))
	uid = int(hostByteOrder.Uint32(value[8:12]))
	ebpfCache.addNewItem(k, key, pid, uid)
	return pid, uid
}

func (e *ebpfCacheType) isInCache(key string) (item *ebpfCacheItem, found bool) {
	item, found = e.Items[key]
	if found {
		if item.isValid() {      e.update(key, item);
		} else { found = false;  delete(e.Items, key); }
	}
	...
}

func (e *ebpfCacheType) addNewItem(key string, itemKey []byte, pid, uid int) {
	e.Lock()
	defer e.Unlock()
	e.Items[key] = NewEbpfCacheItem(itemKey, pid, uid)
}

func (i *ebpfCacheItem) isValid() bool {
	lastSeen := time.Now().Sub( time.Unix(0, i.LastSeen) )
	return int(lastSeen.Seconds()) < 20
}

func deleteEbpfEntry(proto string, key unsafe.Pointer) bool {
	if err := m.DeleteElement(ebpfMaps[proto].bpfmap, key); err != nil { return false; }
	return true
}

2.  // searches those TCP connections which were already established at the time when opensnitch started
// package ebpf
type alreadyEstablishedConns struct {
	TCP   map[*daemonNetlink.Socket]int  // import daemonNetlink "nami/netlink"
	TCPv6 map[*daemonNetlink.Socket]int
	sync.RWMutex
}

var (
	alreadyEstablished = alreadyEstablishedConns{
		TCP:   make(map[*daemonNetlink.Socket]int),
		TCPv6: make(map[*daemonNetlink.Socket]int),
	}
)

func findInAlreadyEstablishedTCP(proto string, srcPort uint, srcIP net.IP, dstIP net.IP, dstPort uint) (int, int, error) {
	alreadyEstablished.RLock()
	defer alreadyEstablished.RUnlock()

	var _alreadyEstablished map[*daemonNetlink.Socket]int
	if proto == "tcp" {         _alreadyEstablished = alreadyEstablished.TCP
	} else if proto == "tcp6" { _alreadyEstablished = alreadyEstablished.TCPv6; }

	for sock, v := range _alreadyEstablished {
		if (*sock).ID.SourcePort == uint16(srcPort) && (*sock).ID.Source.Equal(srcIP) &&
			(*sock).ID.Destination.Equal(dstIP) && (*sock).ID.DestinationPort == uint16(dstPort) {
			return v, int((*sock).UID), nil
		}
	}
	return -1, -1, fmt.Errorf("eBPF inode not found")
}

3. // asks the kernel via netlink for a given connection
// package netlink
func GetSocketInfo(proto string, srcIP net.IP, srcPort uint, dstIP net.IP, dstPort uint) (uid int, inodes []int) {
	if sockList, err := SocketGet(family, ipproto, uint16(srcPort), uint16(dstPort), srcIP, dstIP); err == nil {
		for n, sock := range sockList {
			if sock.ID.SourcePort == uint16(srcPort) && sock.ID.Source.Equal(srcIP) && (sock.ID.DestinationPort == uint16(dstPort)) && ((sock.ID.Destination.IsGlobalUnicast() || sock.ID.Destination.IsLoopback()) && sock.ID.Destination.Equal(dstIP)) {
				inodes = append([]int{int(sock.INode)}, inodes...)
				continue
			}
		}
	}
	return uid, inodes
}

// ---

2. // tries to get the PID from a socket inode
// package procmon
func GetPIDFromINode(inode int, inodeKey string) int {
	// proc
	if cachedPidInode := inodesCache.getPid(inodeKey); cachedPidInode != -1 {
		return cachedPidInode
	}
	cachedPid, pos := pidsCache.getPid(inode, inodeKey, expect)
	if cachedPid != -1 {
		inodesCache.add(inodeKey, "", cachedPid)
		return cachedPid
	}
	// audit
	if MethodIsAudit() {
		...
	}
}
