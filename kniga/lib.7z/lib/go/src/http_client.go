
type Client struct {
	Transport  RoundTripper
	Timeout    time.Duration
	...
}

type RoundTripper interface {
	RoundTrip(*Request) (*Response, error)
}

type Transport struct {
	DialContext func(ctx context.Context, network, addr string) (net.Conn, error)
	...
}

func (t *Transport) RoundTrip(req *Request) (*Response, error) {
	return t.roundTrip(req)
}

func (t *Transport) roundTrip(req *Request) (*Response, error) {
	ctx := req.Context()
	trace := httptrace.ContextClientTrace(ctx)
	...
	for {
		...
		treq := &transportRequest{Request: req,  trace: trace,  cancelKey: cancelKey}
		cm, err := t.connectMethodForRequest(treq)
		pconn, err := t.getConn(treq, cm)
		resp, err = pconn.roundTrip(treq)
		return resp, nil
	}
}

// --------------------------------



