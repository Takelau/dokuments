
// --------------------------------
//    Gin
// --------------------------------

func main() {
	r := gin.Default()
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})
	r.Run()
}

// --------------------------------
//    Info
// --------------------------------
type Engine struct {
	RouterGroup
	RedirectTrailingSlash bool   // true   Enables automatic redirection : /foo/ -> /foo | status code 301 for GET requests and 307 for all other request methods
	RedirectFixedPath bool       // false  /FOO and /..//Foo -> /foo                     | status code 301 for GET requests and 307 for all other request methods
	HandleMethodNotAllowed bool  // false  request is answered with 'Method Not Allowed' and HTTP status code 405
	ForwardedByClientIP bool     // true
	UseRawPath bool              // false  If enabled, the url.RawPath will be used to find parameters
	UnescapePathValues bool      // true   If true, the path value will be unescaped
	...
}

type RouterGroup struct {  // is used internally to configure router
	Handlers HandlersChain
	basePath string
	engine   *Engine
	root     bool
}

type HandlersChain []HandlerFunc
type HandlerFunc func(*Context)

func (group *RouterGroup) POST(relativePath string, handlers ...HandlerFunc) IRoutes { return group.handle(http.MethodPost, relativePath, handlers); }
func (group *RouterGroup) GET(relativePath string, handlers ...HandlerFunc) IRoutes {  return group.handle(http.MethodGet, relativePath, handlers); }
func (group *RouterGroup) Handle(httpMethod, relativePath string, handlers ...HandlerFunc) IRoutes {
	if matches, err := regexp.MatchString("^[A-Z]+$", httpMethod); !matches || err != nil { panic("http method " + httpMethod + " is not valid"); }
	return group.handle(httpMethod, relativePath, handlers)
}
func (group *RouterGroup) handle(httpMethod, relativePath string, handlers HandlersChain) IRoutes {
	absolutePath := group.calculateAbsolutePath(relativePath)
	handlers = group.combineHandlers(handlers)
	group.engine.addRoute(httpMethod, absolutePath, handlers)
	return group.returnObj()
}

// --------------------------------
//    Engine
// --------------------------------
func Default() *Engine {
	engine := New()
	engine.Use(Logger(), Recovery())
	return engine
}

func New() *Engine {
	engine := &Engine{
		RouterGroup: RouterGroup{ Handlers:nil, basePath:"/", root:true, },
		...
	}
	engine.RouterGroup.engine = engine
	engine.pool.New = func() interface{} { return engine.allocateContext(); }
	return engine
}

func (engine *Engine) allocateContext() *Context {
	v := make(Params, 0, engine.maxParams)
	skippedNodes := make([]skippedNode, 0, engine.maxSections)
	return &Context{engine: engine, params: &v, skippedNodes: &skippedNodes}
}

func (engine *Engine) Use(middleware ...HandlerFunc) IRoutes {
	engine.RouterGroup.Use(middleware...)
	engine.rebuild404Handlers()
	engine.rebuild405Handlers()
	return engine
}

func (engine *Engine) Run(addr ...string) (err error) {
	defer func() { debugPrintError(err) }()
	if engine.isUnsafeTrustedProxies() { debugPrint("[WARNING] You trusted all proxies, this is NOT safe."); }

	address := resolveAddress(addr)
	err = http.ListenAndServe(address, engine)
	return
}

type Server struct {
	Addr              string
	Handler           Handler 
	TLSConfig        *tls.Config
	MaxHeaderBytes    int
	ReadTimeout       time.Duration
	ReadHeaderTimeout time.Duration
	WriteTimeout      time.Duration
	IdleTimeout       time.Duration
	BaseContext func(net.Listener) context.Context   // If BaseContext is nil, the default is context.Background()
	ConnContext func(ctx context.Context, c net.Conn) context.Context  // modifies the context used for a new connection c
	...
}

func ListenAndServe(addr string, handler Handler) error {
	server := &Server{Addr: addr, Handler: handler}
	return server.ListenAndServe()
}

func (srv *Server) ListenAndServe() error {
	if srv.shuttingDown() { return ErrServerClosed; }
	addr := srv.Addr
	if addr == "" { addr = ":http"; }
	ln, err := net.Listen("tcp", addr);    if err != nil { return err; }
	return srv.Serve(ln)
}

func (srv *Server) Serve(l net.Listener) error {
	...
	baseCtx := context.Background()
	if srv.BaseContext != nil {
		baseCtx = srv.BaseContext(origListener)
		if baseCtx == nil {
			panic("BaseContext returned a nil context")
		}
	}

	var tempDelay time.Duration

	ctx := context.WithValue(baseCtx, ServerContextKey, srv)
	for {
		rw, err := l.Accept()
		if err != nil {
			if ne, ok := err.(net.Error); ok && ne.Temporary() {
				// алгоритм задержки
				time.Sleep(tempDelay)
				continue
			}
		}
		connCtx := ctx
		if cc := srv.ConnContext; cc != nil {
			connCtx = cc(connCtx, rw);   if connCtx == nil { panic("ConnContext returned nil"); }
		}
		tempDelay = 0
		c := srv.newConn(rw)
		c.setState(c.rwc, StateNew, runHooks) // before Serve can return
		go c.serve(connCtx)
	}
}

func (srv *Server) newConn(rwc net.Conn) *conn {
	c := &conn{ server:srv, rwc:rwc, }
	return c
}

func (c *conn) serve(ctx context.Context) {
	c.remoteAddr = c.rwc.RemoteAddr().String()
	...
	serverHandler{c.server}.ServeHTTP(w, w.req)
	w.cancelCtx()
}