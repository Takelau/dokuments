
// DEPRECATED
type CloseNotifier interface { }
type ProtocolError struct { ErrorString string }

// --------------------------------

const DefaultMaxHeaderBytes = 1 << 20 // 1 MB
const DefaultMaxIdleConnsPerHost = 2
const TimeFormat = "Mon, 02 Jan 2006 15:04:05 GMT"
const TrailerPrefix = "Trailer:"

const (
	SameSiteDefaultMode SameSite = iota + 1
	SameSiteLaxMode
	SameSiteStrictMode
	SameSiteNoneMode
)

var ServerContextKey    = &contextKey{"http-server"}
var LocalAddrContextKey = &contextKey{"local-addr"}

var DefaultClient = &Client{}
var DefaultServeMux = &defaultServeMux
var NoBody = noBody{}   // Read always returns EOF and Close always returns nil

func Error(w ResponseWriter, error string, code int)
func Handle(pattern string, handler Handler)                              // http.Handle("/count", new(countHandler))  type countHandler struct {...}  func (h *countHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {...}
func HandleFunc(pattern string, handler func(ResponseWriter, *Request))   // http.HandleFunc("/h1", h1)  h1 := func(w http.ResponseWriter, r *http.Request) {...}

func ListenAndServe(addr string, handler Handler) error                        // http.HandleFunc("/h1", h1)                                                  http.ListenAndServe(":8080", nil)
func ListenAndServeTLS(addr, certFile, keyFile string, handler Handler) error  // http.HandleFunc("/", func(w http.ResponseWriter, req *http.Request) {...}   http.ListenAndServeTLS(":8443", "cert.pem", "key.pem", nil)

func MaxBytesReader(w ResponseWriter, r io.ReadCloser, n int64) io.ReadCloser  // limiting of incoming request bodies
func NotFound(w ResponseWriter, r *Request)
func Redirect(w ResponseWriter, r *Request, url string, code int)

func Serve(l net.Listener, handler Handler) error   // accepts incoming HTTP connections + new service goroutine
func ServeTLS(l net.Listener, handler Handler, certFile, keyFile string) error
func ServeContent(w ResponseWriter, req *Request, name string, modtime time.Time, content io.ReadSeeker)
func ServeFile(w ResponseWriter, r *Request, name string)

func SetCookie(w ResponseWriter, cookie *Cookie)
func StatusText(code int) string

// --------------------------------

type Client struct {
	Timeout       time.Duration
	Transport     RoundTripper    // If nil, DefaultTransport is used
	CheckRedirect func(req *Request, via []*Request) error   // If not nil, the client calls it befor following an HTTP redirect
	Jar           CookieJar       // insert relevant cookies into every outbound Request, and is updated with the cookie values of every inbound Response
}
func (c *Client) CloseIdleConnections()
func (c *Client) Do(req *Request) (*Response, error)
func (c *Client) Get(url string) (resp *Response, err error)
func (c *Client) Head(url string) (resp *Response, err error)
func (c *Client) Post(url, contentType string, body io.Reader) (resp *Response, err error)
func (c *Client) PostForm(url string, data url.Values) (resp *Response, err error)

type Transport struct {
	DialContext         func(ctx context.Context, network, addr string) (net.Conn, error)
	DialTLSContext      func(ctx context.Context, network, addr string) (net.Conn, error)
	TLSClientConfig    *tls.Config
	TLSHandshakeTimeout time.Duration
	MaxIdleConns        int
	MaxIdleConnsPerHost int
	...
}

// --------------------------------

type Handler interface {                      // A Handler responds to an HTTP request
	ServeHTTP(ResponseWriter, *Request)
}
func AllowQuerySemicolons(h Handler) Handler  // ; -> &
func FileServer(root FileSystem) Handler      // http.Handle("/", http.FileServer(http.Dir("/tmp")))
func NotFoundHandler() Handler { return HandlerFunc(NotFound) }
func RedirectHandler(url string, code int) Handler  // 3xx {StatusMovedPermanently | StatusFound | StatusSeeOther}
func StripPrefix(prefix string, h Handler) Handler  // http.Handle("/tmpfiles/", http.StripPrefix("/tmpfiles/", http.FileServer(http.Dir("/tmp"))))
func TimeoutHandler(h Handler, dt time.Duration, msg string) Handler

type HandlerFunc func(ResponseWriter, *Request)
func (f HandlerFunc) ServeHTTP(w ResponseWriter, r *Request)

// --------------------------------

type Header map[string][]string
func (h Header) Add(key, value string)
func (h Header) Clone() Header
func (h Header) Del(key string)
func (h Header) Get(key string) string
func (h Header) Set(key, value string)
func (h Header) Values(key string) []string
func (h Header) Write(w io.Writer) error
func (h Header) WriteSubset(w io.Writer, exclude map[string]bool) error
//	Header = map[string][]string{
//		"Accept-Encoding": {"gzip, deflate"},
//		"Accept-Language": {"en-us"},
//		"Foo": {"Bar", "two"},}

// --------------------------------

type ServeMux struct {
	mu    sync.RWMutex
	m     map[string]muxEntry
	es    []muxEntry // slice of entries sorted from longest to shortest.
	hosts bool       // whether any patterns contain hostnames
}
func NewServeMux() *ServeMux
func (mux *ServeMux) Handle(pattern string, handler Handler)
func (mux *ServeMux) HandleFunc(pattern string, handler func(ResponseWriter, *Request))
func (mux *ServeMux) Handler(r *Request) (h Handler, pattern string)
func (mux *ServeMux) ServeHTTP(w ResponseWriter, r *Request)

type Server struct {
	Addr       string
	Handler    Handle
	TLSConfig *tls.Config
	ReadTimeout       time.Duration
	ReadHeaderTimeout time.Duration
	WriteTimeout      time.Duration
	IdleTimeout       time.Duration
	MaxHeaderBytes  int
	TLSNextProto    map[string]func(*Server, *tls.Conn, Handler)
	ErrorLog       *log.Logger   // logger
	ConnState   func(net.Conn, ConnState)           // callback function that is called when a client connection changes state
	BaseContext func(net.Listener) context.Context  // base context for incoming requests on this serve
	ConnContext func(ctx context.Context, c net.Conn) context.Context
}
func (srv *Server) Close() error
func (srv *Server) ListenAndServe() error
func (srv *Server) ListenAndServeTLS(certFile, keyFile string) error
func (srv *Server) RegisterOnShutdown(f func())
func (srv *Server) Serve(l net.Listener) error
func (srv *Server) ServeTLS(l net.Listener, certFile, keyFile string) error
func (srv *Server) SetKeepAlivesEnabled(v bool)
func (srv *Server) Shutdown(ctx context.Context) error

// --------------------------------

type PushOptions struct {
	Method string   // "GET" or "HEAD". Empty means "GET"
	Header Header
}

type Pusher interface {  // HTTP/2 server push
	Push(target string, opts *PushOptions) error
}

type Request struct {    // HTTP method (GET, POST, PUT, etc.)
	Method string
	URL       *url.URL
	Proto      string      // "HTTP/1.0"
	ProtoMajor int         // 1
	ProtoMinor int         // 0
	Header     Header      // map[string][]string
	Trailer    Header
	Body       io.ReadCloser
	GetBody func() (io.ReadCloser, error)   // return a new copy of Body
	ContentLength    int64 // {-1-length is unknown, >= 0-maybe read from Body, [0 && Body!=nil]-length is unknown}
	TransferEncoding []string
	Close      bool        // re-use of TCP connection
	Host       string
	Form       url.Values
	PostForm   url.Values
	MultipartForm *multipart.Form
	RemoteAddr string
	RequestURI string
	Cancel   <-chan struct{}  // Deprecated ?
	Response  *Response
}

// for Client.Do || Transport.RoundTrip
func NewRequest(method, url string, body io.Reader) (*Request, error)
func NewRequestWithContext(ctx context.Context, method, url string, body io.Reader) (*Request, error)  
func ReadRequest(b *bufio.Reader) (*Request, error)  // [HTTP/1.x] reads and parses an incoming request from b

type Response struct {
	Status        string // e.g. "200 OK"
	StatusCode    int    // e.g. 200
	Proto         string // e.g. "HTTP/1.0"
	ProtoMajor    int    // e.g. 1
	ProtoMinor    int    // e.g. 0
	Header        Header
	Trailer       Header
	Body          io.ReadCloser
	ContentLength int64
	TransferEncoding []string
	Close         bool
	Uncompressed  bool
	TLS          *tls.ConnectionState
	Request      *Request
}

func Head(url string) (resp *Response, err error)
func Get(url string) (resp *Response, err error)
func Post(url, contentType string, body io.Reader) (resp *Response, err error)
func PostForm(url string, data url.Values) (resp *Response, err error)
func ReadResponse(r *bufio.Reader, req *Request) (*Response, error)

type ResponseWriter interface {
	Header() Header
	Write([]byte) (int, error)
	WriteHeader(statusCode int)
}

type RoundTripper interface {    // executes a single HTTP transaction
	RoundTrip(*Request) (*Response, error)
}

func NewFileTransport(fs FileSystem) RoundTripper


// --------------------------------
//    File Server
// --------------------------------
// v1
http.Handle("/", http.FileServer(http.Dir("/tmp")))
http.Handle("/", http.FileServer(http.FS(fsys)))
http.Handle("/tmpfiles/", http.StripPrefix("/tmpfiles/", http.FileServer(http.Dir("/tmp"))))
http.ListenAndServe(":8080", nil)
// v2
http.ListenAndServe(":8080", http.FileServer(http.Dir("/usr/share/doc")))


// --------------------------------
//    HTTP Server
// --------------------------------
func NotFound(w ResponseWriter, r *Request) { Error(w, "404 page not found", StatusNotFound) }
func NotFoundHandler() Handler { return HandlerFunc(NotFound) }

type Handler interface {
	ServeHTTP(ResponseWriter, *Request)
}

// Redirect
func RedirectHandler(url string, code int) Handler {
	return &redirectHandler{url, code}
}

// Serve
func Serve(l net.Listener, handler Handler) error {
	srv := &Server{Handler: handler}
	return srv.Serve(l)
}

// ListenAndServe
func ListenAndServe(addr string, handler Handler) error {
	server := &Server{Addr: addr, Handler: handler}
	return server.ListenAndServe()
}

func ServeTLS(l net.Listener, handler Handler, certFile, keyFile string) error {
	srv := &Server{Handler: handler}
	return srv.ServeTLS(l, certFile, keyFile)
}

// Redirect to a fixed URL
type redirectHandler struct {
	url  string
	code int
}

func (rh *redirectHandler) ServeHTTP(w ResponseWriter, r *Request) {
	Redirect(w, r, rh.url, rh.code)
}

// adapter
type HandlerFunc func(ResponseWriter, *Request)
func (f HandlerFunc) ServeHTTP(w ResponseWriter, r *Request) {
	f(w, r)
}

// ServeMux
type ServeMux struct {
	mu    sync.RWMutex
	m     map[string]muxEntry
	es    []muxEntry // slice of entries sorted from longest to shortest.
	hosts bool       // whether any patterns contain hostnames
}

type muxEntry struct {
	h       Handler
	pattern string
}

// NewServeMux allocates and returns a new ServeMux.
func NewServeMux() *ServeMux { return new(ServeMux) }
var DefaultServeMux = &defaultServeMux
var defaultServeMux ServeMux

func (mux *ServeMux) Handle(pattern string, handler Handler) {
	mux.mu.Lock()
	defer mux.mu.Unlock()
	...
	e := muxEntry{h: handler, pattern: pattern}
	mux.m[pattern] = e
	if pattern[len(pattern)-1] == '/' {
		mux.es = appendSorted(mux.es, e)
	}
}

// ServeMax.HandleFunc
func (mux *ServeMux) HandleFunc(pattern string, handler func(ResponseWriter, *Request)) {
	if handler == nil {
		panic("http: nil handler")
	}
	mux.Handle(pattern, HandlerFunc(handler))
}

// Handle
func Handle(pattern string, handler Handler) { DefaultServeMux.Handle(pattern, handler) }

func HandleFunc(pattern string, handler func(ResponseWriter, *Request)) {
	DefaultServeMux.HandleFunc(pattern, handler)
}

// Server
type Server struct {
	Addr     string
	Handler  Handler
	mu       sync.Mutex
	doneChan chan struct{}
}

func (srv *Server) ListenAndServe() error {
	if srv.shuttingDown() {
		return ErrServerClosed
	}
	addr := srv.Addr
	if addr == "" {
		addr = ":http"
	}
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	return srv.Serve(ln)
}

type Listener interface {
	Accept() (Conn, error)  // Accept waits for and returns the next connection to the listener.
	Close() error           // Any blocked Accept operations will be unblocked and return errors.
	Addr() Addr             // Addr returns the listener's network address.
}

func Listen(network, address string) (Listener, error) {  // net.Listen(...)
	var lc ListenConfig
	return lc.Listen(context.Background(), network, address)  // появление контекста
}

func (srv *Server) Serve(l net.Listener) error {
	...
	origListener := l
	if err := srv.setupHTTP2_Serve(); err != nil {
		return err
	}
	...
	baseCtx = srv.BaseContext(origListener)
	ctx := context.WithValue(baseCtx, ServerContextKey, srv)  // var ServerContextKey = &contextKey{"http-server"}  / r.Context().Value(ServerContextKey).(*Server)
	for {
		rw, err := l.Accept()
		connCtx := ctx
		if cc := srv.ConnContext; cc != nil { connCtx = cc(connCtx, rw); }  // пользовательский контекст
		c := srv.newConn(rw)
		c.setState(c.rwc, StateNew) // before Serve can return
		go c.serve(connCtx)         // <-- ServeHTTP()
	}
}

func (srv *Server) newConn(rwc net.Conn) *conn {
	c := &conn{
		server: srv,
		rwc:    rwc,
	}
	return c
}

// conn
type conn struct {
	...
	server *Server
	rwc     net.Conn
}

func (c *conn) serve(ctx context.Context) {
	ctx = context.WithValue(ctx, LocalAddrContextKey, c.rwc.LocalAddr())   // var LocalAddrContextKey = &contextKey{"local-addr"}
	defer func() { err := recover(); }     // recover()
	...
	ctx, cancelCtx := context.WithCancel(ctx)
	c.cancelCtx = cancelCtx
	defer cancelCtx()
	...
	for {
		w, err := c.readRequest(ctx)
		...
		serverHandler{c.server}.ServeHTTP(w, w.req)  // <-- 
		w.cancelCtx()
		w.finishRequest()
	}
}

// serverHandler
type serverHandler struct {
	srv *Server
}

func (sh serverHandler) ServeHTTP(rw ResponseWriter, req *Request) {
	handler := sh.srv.Handler
	if handler == nil {
		handler = DefaultServeMux
	}
	if req.RequestURI == "*" && req.Method == "OPTIONS" {
		handler = globalOptionsHandler{}
	}
	handler.ServeHTTP(rw, req)  // <-- ServeMux.ServeHTTP(rw, req)
}

func (mux *ServeMux) ServeHTTP(w ResponseWriter, r *Request) {
	...
	h, _ := mux.Handler(r)
	h.ServeHTTP(w, r)
}

func (mux *ServeMux) Handler(r *Request) (h Handler, pattern string) {
	...
	return mux.handler(host, r.URL.Path)
}

func (mux *ServeMux) handler(host, path string) (h Handler, pattern string) {
	...
	if mux.hosts { h, pattern = mux.match(host + path); }
	if h == nil {  h, pattern = mux.match(path); }
}


// --------------------------------
//    HTTP Client
// --------------------------------
var DefaultClient = &Client{}

var DefaultTransport RoundTripper = &Transport{
	Proxy: ProxyFromEnvironment,
	DialContext: (&net.Dialer{
		Timeout:    30 * time.Second,
		KeepAlive:  30 * time.Second,
		DualStack:  true,
	}).DialContext,
	ForceAttemptHTTP2:     true,
	MaxIdleConns:          100,
	IdleConnTimeout:       90 * time.Second,
	TLSHandshakeTimeout:   10 * time.Second,
	ExpectContinueTimeout: 1 * time.Second,
}

func Get(url string) (resp *Response, err error) {
	return DefaultClient.Get(url)
}

func (c *Client) Get(url string) (resp *Response, err error) {
	req, err := NewRequest("GET", url, nil)
	return c.Do(req)
}

func NewRequest(method, url string, body io.Reader) (*Request, error) {
	return NewRequestWithContext(context.Background(), method, url, body)   // context.Background()
}

func NewRequestWithContext(ctx context.Context, method, url string, body io.Reader) (*Request, error) {
	u.Host = removeEmptyPort(u.Host)
	req := &Request{
		ctx:        ctx,
		Method:     method,     // GET
		URL:        u,
		Proto:      "HTTP/1.1",
		ProtoMajor: 1,
		ProtoMinor: 1,
		Header:     make(Header),
		Body:       rc,
		Host:       u.Host,
	}
	if body != nil {
		switch v := body.(type) {
		case *bytes.Buffer:
			req.ContentLength = int64(v.Len())
			buf := v.Bytes()
			req.GetBody = func() (io.ReadCloser, error) {   // req.GetBody
				r := bytes.NewReader(buf)
				return ioutil.NopCloser(r), nil
			}
		case *bytes.Reader:
			...
		case *strings.Reader:
			...
		default:
	}
	return req, nil
}

func (c *Client) Do(req *Request) (*Response, error) {
	return c.do(req)
}

func (c *Client) do(req *Request) (retres *Response, reterr error) {
	var(
		deadline      = c.deadline()  // use c.Timeout
		reqs          []*Request
		resp          *Response
		reqBodyClosed = false    // have we closed the current req.Body?
		// Redirect behavior:
		redirectMethod string
		includeBody    bool
	)
	for {
		if len(reqs) > 0 {
			ireq := reqs[0]
			req = &Request{
				Method:   redirectMethod,
				Response: resp,
				URL:      u,
				Header:   make(Header),
				Host:     host,
				Cancel:   ireq.Cancel,
				ctx:      ireq.ctx,
			}
			if includeBody && ireq.GetBody != nil {
				req.Body, err     = ireq.GetBody()
				req.ContentLength = ireq.ContentLength
			}
			if resp.ContentLength == -1 || resp.ContentLength <= maxBodySlurpSize {
				io.CopyN(ioutil.Discard, resp.Body, maxBodySlurpSize)  // var Discard io.Writer = devNull(0)
			}
			resp.Body.Close()
		}

		reqs = append(reqs, req)
		var err error
		var didTimeout func() bool
		if resp, didTimeout, err = c.send(req, deadline); err != nil { ... }  // <--

		var shouldRedirect bool
		redirectMethod, shouldRedirect, includeBody = redirectBehavior(req.Method, resp, reqs[0])  // 301, 302, 303 | 307, 308
		if !shouldRedirect {
			return resp, nil   // <--
		}

		req.closeBody()  // r.Body.Close()
	}
}

func (c *Client) deadline() time.Time {
	if c.Timeout > 0 { return time.Now().Add(c.Timeout); }
	return time.Time{}
}

func (c *Client) send(req *Request, deadline time.Time) (resp *Response, didTimeout func() bool, err error) {
	...
	resp, didTimeout, err = send(req, c.transport(), deadline)
	return resp, nil, nil
}

func (c *Client) transport() RoundTripper {
	if c.Transport != nil {
		return c.Transport
	}
	return DefaultTransport
}

func send(ireq *Request, rt RoundTripper, deadline time.Time) (resp *Response, didTimeout func() bool, err error) {
	req := ireq
	...
	stopTimer, didTimeout := setRequestCancel(req, rt, deadline)
	resp, err = rt.RoundTrip(req)

	if !deadline.IsZero() {
		resp.Body = &cancelTimerBody{
			stop:          stopTimer,
			rc:            resp.Body,
			reqDidTimeout: didTimeout,
		}
	}
	return resp, nil, nil
}

func setRequestCancel(req *Request, rt RoundTripper, deadline time.Time) (stopTimer func(), didTimeout func() bool) {
	cancel := make(chan struct{})
	req.Cancel = cancel

	doCancel := func() {
		close(cancel)
	}

	timer := time.NewTimer(time.Until(deadline))
	go func() {
		select {
			...
		case <-timer.C:         // deadline() -> req.Cancel
			timedOut.setTrue()
			doCancel()
		}
	}()

	return stopTimer, timedOut.isSet
}

func (t *Transport) RoundTrip(req *Request) (*Response, error) {
	return t.roundTrip(req)
}

func (t *Transport) roundTrip(req *Request) (*Response, error) {
	ctx := req.Context()
	trace := httptrace.ContextClientTrace(ctx)
	origReq := req
	cancelKey := cancelKey{origReq}

	for {
		select {
		case <-ctx.Done():
			req.closeBody()
			return nil, ctx.Err()
		default:
		}

		treq := &transportRequest{Request:req, trace:trace, cancelKey:cancelKey}
		cm, err := t.connectMethodForRequest(treq)

		pconn, err := t.getConn(treq, cm)
		resp, err = pconn.roundTrip(treq)
		
		resp.Request = origReq
		return resp, nil
	}
}

func (t *Transport) getConn(treq *transportRequest, cm connectMethod) (pc *persistConn, err error) {
	w := &wantConn{
		cm:         cm,
		key:        cm.key(),
		ctx:        ctx,
		ready:      make(chan struct{}, 1),
		beforeDial: testHookPrePendingDial,
		afterDial:  testHookPostPendingDial,
	}
	defer func() {
		if err != nil { w.cancel(t, err); }
	}()

	t.queueForDial(w)

	select {
	case <-w.ready:
		return w.pc, w.err
	}
}

func (t *Transport) queueForDial(w *wantConn) {
	...
	go t.dialConnFor(w)
	return
}

func (t *Transport) dialConnFor(w *wantConn) {
	pc, err := t.dialConn(w.ctx, w.cm)
	t.putOrCloseIdleConn(pc)
}

func (t *Transport) dialConn(ctx context.Context, cm connectMethod) (pconn *persistConn, err error) {
	pconn = &persistConn{
		t:        t,
		cacheKey: cm.key(),
		...
	}

	if cm.scheme() == "https" { pconn.conn, err = t.customDialTLS(ctx, "tcp", cm.addr())
	} else {                    pconn.conn, err := t.dial(ctx, "tcp", cm.addr()); }

	switch {
		case cm.proxyURL.Scheme == "socks5": ...
		case cm.targetScheme == "http":      ...
		case cm.targetScheme == "https":     ...
	}

	return pconn, nil
}

func (t *Transport) dial(ctx context.Context, network, addr string) (net.Conn, error) {
	...
	if t.DialContext != nil {
		return t.DialContext(ctx, network, addr)
	}
	return zeroDialer.DialContext(ctx, network, addr)
}

func (d *Dialer) DialContext(ctx context.Context, network, address string) (Conn, error) {
	sd := &sysDialer{
		Dialer:  *d,
		network: network,
		address: address,
	}

	var c Conn
	if len(fallbacks) > 0 { c, err = sd.dialParallel(ctx, primaries, fallbacks)
	} else {                c, err = sd.dialSerial(ctx, primaries)
	}

	if tc, ok := c.(*TCPConn); ok && d.KeepAlive >= 0 {
		setKeepAlive(tc.fd, true)
	}

	return c, nil
}

func (sd *sysDialer) dialSingle(ctx context.Context, ra Addr) (c Conn, err error) {
	la := sd.LocalAddr
	switch ra := ra.(type) {
	case *TCPAddr:
		la, _ := la.(*TCPAddr);      c, err = sd.dialTCP(ctx, la, ra)
	case *UDPAddr:
		la, _ := la.(*UDPAddr);      c, err = sd.dialUDP(ctx, la, ra)
	case *IPAddr:
		la, _ := la.(*IPAddr);       c, err = sd.dialIP(ctx, la, ra)
	case *UnixAddr:
		la, _ := la.(*UnixAddr);     c, err = sd.dialUnix(ctx, la, ra)
	default:
		return nil, &OpError{Op: "dial", Net: sd.network, Source: la, Addr: ra, Err: &AddrError{Err: "unexpected address type", Addr: sd.address}}
	}
	return c, nil
}

func (sd *sysDialer) dialTCP(ctx context.Context, laddr, raddr *TCPAddr) (*TCPConn, error) {
	return sd.doDialTCP(ctx, laddr, raddr)
}

func (sd *sysDialer) doDialTCP(ctx context.Context, laddr, raddr *TCPAddr) (*TCPConn, error) {
	fd, err := internetSocket(ctx, sd.network, laddr, raddr, syscall.SOCK_STREAM, 0, "dial", sd.Dialer.Control)
	return newTCPConn(fd), nil
}

func newTCPConn(fd *netFD) *TCPConn {
	c := &TCPConn{conn{fd}}
	setNoDelay(c.fd, true)
	return c
}

func setNoDelay(fd *netFD, noDelay bool) error {
	err := fd.pfd.SetsockoptInt(syscall.IPPROTO_TCP, syscall.TCP_NODELAY, boolint(noDelay))
	runtime.KeepAlive(fd)
	return wrapSyscallError("setsockopt", err)
}

func SetsockoptInt(fd, level, opt int, value int) (err error) {
	var n = int32(value)
	return setsockopt(fd, level, opt, unsafe.Pointer(&n), 4)
}

func setsockopt(s int, level int, name int, val unsafe.Pointer, vallen uintptr) (err error) {
	_, _, e1 := Syscall6(SYS_SETSOCKOPT, uintptr(s), uintptr(level), uintptr(name), uintptr(val), uintptr(vallen), 0)
	if e1 != 0 {
		err = errnoErr(e1)
	}
	return
}