
// --------------------------------
// json.Marshal() -> sync.Pool + sync.Map <- map[reflect.Type]encoderFunc

a := map[string]int{"a":5, "b":7}
b,_ := json.Marshal(a)   // {"a":5,"b":7}

func Marshal(v interface{}) ([]byte, error) {
	e := newEncodeState()
	err := e.marshal(v, encOpts{escapeHTML: true})
	if err != nil { return nil, err; }

	buf := append([]byte(nil), e.Bytes()...)
	encodeStatePool.Put(e)

	return buf, nil
}

// ---
var encodeStatePool sync.Pool

type encodeState struct {
	bytes.Buffer // accumulated output
	scratch      [64]byte
	ptrLevel     uint
	ptrSeen      map[interface{}]struct{}
}

func newEncodeState() *encodeState {
	if v := encodeStatePool.Get(); v != nil {
		e := v.(*encodeState)
		e.Reset()                       // func (b *Buffer) Reset() { b.buf = b.buf[:0]; ... }
		if len(e.ptrSeen) > 0 { panic("ptrEncoder.encode should have emptied ptrSeen via defers"); }
		e.ptrLevel = 0
		return e
	}
	return &encodeState{ptrSeen: make(map[interface{}]struct{})}
}

func (e *encodeState) marshal(v interface{}, opts encOpts) (err error) {
	...
	e.reflectValue(reflect.ValueOf(v), opts)
	return nil
}

func (e *encodeState) reflectValue(v reflect.Value, opts encOpts) {
	valueEncoder(v)(e, v, opts)
}

// ---
type encoderFunc func(e *encodeState, v reflect.Value, opts encOpts)

var encoderCache sync.Map // map[reflect.Type]encoderFunc

func valueEncoder(v reflect.Value) encoderFunc {
	if !v.IsValid() {
		return invalidValueEncoder
	}
	return typeEncoder(v.Type())
}

func typeEncoder(t reflect.Type) encoderFunc {
	if fi, ok := encoderCache.Load(t); ok {
		return fi.(encoderFunc)
	}
	...
	f = newTypeEncoder(t, true)
	encoderCache.Store(t, f)
	return f
}

func newTypeEncoder(t reflect.Type, allowAddr bool) encoderFunc {
	...
	switch t.Kind() {
	case reflect.Int:     return intEncoder
	case reflect.String:  return stringEncoder
	case reflect.Map:     return newMapEncoder(t)
	default:              return unsupportedTypeEncoder
	}
}

// ---
type mapEncoder struct {
	elemEnc encoderFunc
}

func (me mapEncoder) encode(e *encodeState, v reflect.Value, opts encOpts) {
	...
}