
package sharedRPC
type MyFloats struct {
	A1, A2 float64
}
type MyInterface interface {
	Multiply(arguments *MyFloats, reply *float64) error
	Power(arguments *MyFloats, reply *float64) error
}
// go install sharedRPC

// client
package main
import (
	"fmt"
	"net/rpc"
	"os"
	"sharedRPC"
)
func main() {
	args := sharedRPC.MyFloats{16, -0.5}
	var reply float6

	c, err := rpc.Dial("tcp", "127.0.0.1:3000");  if err != nil {...}
	// Synchronous call
	err = c.Call("MyInterface.Multiply", args, &reply);  if err != nil { fmt.Println(err); }
	fmt.Printf("Reply (Multiply): %f\n", reply)
	// Synchronous call
	err = c.Call("MyInterface.Power", args, &reply);  if err != nil { fmt.Println(err); }
	fmt.Printf("Reply (Power): %f\n", reply)
	// Asynchronous call
	divCall := c.Go("MyInterface.Power", args, &reply, nil)
	replyCall := <-divCall.Done
}

// server
package main
import (
	"fmt"
	"math"
	"net"
	"net/rpc"
	"os"
	"sharedRPC"
)
type MyInterface struct{}
func Power(x, y float64) float64 {
	return math.Pow(x, y)
}
func (t *MyInterface) Multiply(arguments *sharedRPC.MyFloats, reply *float64) error {
	*reply = arguments.A1 * arguments.A2
	return nil
}
func (t *MyInterface) Power(arguments *sharedRPC.MyFloats, reply *float64) error {
	*reply = Power(arguments.A1, arguments.A2)
	return nil
}
func main() {
	myInterface := new(MyInterface)
	rpc.Register(myInterface)

	t, err := net.ResolveTCPAddr("tcp4", "127.0.0.1:3000");  if err != nil {...}
	l, err := net.ListenTCP("tcp4", t);  if err != nil {...}

	for {
		c, err := l.Accept()
		if err != nil { continue; }
		fmt.Printf("%s\n", c.RemoteAddr())
		rpc.ServeConn(c)
	}
}

// --------------------------------

