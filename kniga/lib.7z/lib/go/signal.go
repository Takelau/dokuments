package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"
)

func handleSignal(signal os.Signal) {
	fmt.Println("handle:", signal)
}

func main() {
	sigs := make(chan os.Signal, 1)
	done := make(chan bool, 1)

	signal.Notify(sigs) // все сигналы
//signal.Notify(sigs, os.Interrupt, syscall.SIGINT)

	go func() {
		sig := <-sigs
		switch sig {
			case os.Interrupt:     fmt.Println("int:", sig);  done <- true
			case syscall.SIGTERM:  handleSignal(sig);         os.Exit(0)
			case syscall.SIGTSTP:  fmt.Println("stp:", sig);  os.Exit(0)
			default:               fmt.Println("def:", sig);  done <- true
		}
	}()

	<-done
	signal.Stop(sigs)
	fmt.Println("done Exit")
}

// --------------------------------


