package main
import (
	"fmt"
)

type Shape interface {
	Area()      float64
	Perimeter() float64
}

type Square struct {
	X float64
	Y float64
}

func (s *Square) Area() float64 { return s.X * s.X; }
func (s *Square) Perimeter() float64 { return 4 * s.X; }

func Calculate(x Shape) {
	v,ok := x.(*Square)
	if ok { fmt.Println("Is a square:", v); }  // Is a square: &{10 5}
	fmt.Println(x.Perimeter())                 // 40
}

func main() {
	x := &Square{X:10, Y:5}
	fmt.Println("Perimeter:", x.Perimeter())
	Calculate(x)
}


// --------------------------------
// Mod && Plugin
// --------------------------------
// build '.so' | $d = './mod'
for d in $(find . -maxdepth 1 -type d | grep -v '^.$'); do \
	go build -buildmode plugin -o $d.so $d; \
done

// ./mod/main.go
package main
import (
	"C"
	"fmt"
)
type Dog interface {
	Name() string
}
func Command(d dog) { fmt.Println(d.Name()); }

// main.go | <- go run main.go mod.so
package main
import (
	"fmt"
	"os"
	"plugin"
)

type Dog interface {
	Name() string
}

type lucy struct{}
func (l *lucy) Name() string { return "Lucy" }

func main() {
	if len(os.Args) != 2 { os.Exit(1); }  // go run main.go dog.go sit.so
	pluginPath := os.Args[1]

	p,_ := plugin.Open(pluginPath)
	cmdFunc,_ := p.Lookup("Command")

	cmd, ok := cmdFunc.(func(Dog));    if !ok { os.Exit(1); }
	cmd(&lucy{})
}

// --------------------------------
package main

type device interface {
	on()
	off()
	increaseVolume()
	decreaseVolume()
}

type command interface { execute() }

type onCommand struct { device device }
func (c *onCommand) execute() { c.device.on() }

type offCommand struct { device device }
func (c *offCommand) execute() { c.device.off() }

type increaseVolumeCommand struct { device device }
func (c *increaseVolumeCommand) execute() { c.device.increaseVolume() }

type decreaseVolumeCommand struct { device device }
func (c *decreaseVolumeCommand) execute() { c.device.decreaseVolume() }

type tv struct {
	isOn bool
	volume int
}

func (t *tv) on() {  t.isOn = true;   fmt.Println("Turning tv on"); }
func (t *tv) off() { t.isOn = false;  fmt.Println("Turning tv off"); }

func (t *tv) increaseVolume() {
	if t.isOn {
		if t.volume >= 0 && t.volume < 100 {
			t.volume++;  fmt.Printf("Increased volume to %d\n", t.volume)
		} else {       fmt.Println("Max volume.") }
	} else {         fmt.Println("Cannot change volume, tv is off.") }
}

func (t *tv) decreaseVolume() {
    if t.isOn {
        if t.volume > 0 && t.volume <= 100 {
            t.volume--;  fmt.Printf("Decreased volume to %d\n", t.volume)
        } else {         fmt.Println("Min volume.") }
    } else {             fmt.Println("Cannot change volume, tv is off.") }
}

type button struct { command command }
func (b *button) press() { b.command.execute() }

func main() {
	tv := &tv {
		isOn: false,
		volume: 10,
	}

	// Instantiate commands
	onCommand  := &onCommand{ device: tv, }
	offCommand := &offCommand{ device: tv, }
	increaseVolumeCommand := &increaseVolumeCommand { device: tv, }
	decreaseVolumeCommand := &decreaseVolumeCommand { device: tv, }

	// Instantiate buttons
	onButton  := &button{ command: onCommand, }
	offButton := &button{ command: offCommand, }
	increaseVolumeButton := &button { command: increaseVolumeCommand, }
	decreaseVolumeButton := &button { command: decreaseVolumeCommand, }

	// Execute
	increaseVolumeButton.press()
	onButton.press()
	increaseVolumeButton.press()
	decreaseVolumeButton.press()
	offButton.press()
}