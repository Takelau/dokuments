
// -------------------------------
// runtime/pprof
cpu,_ := os.Create("cpu.out")
err := pprof.StartCPUProfile(cpu)
defer pprof.StopCPUProfile()

mem,_ := os.Create("mem.out")
err = pprof.WriteHeapProfile(mem)

https://github.com/google/pprof/blob/master/doc/README.md
go tool pprof [options] source
go tool pprof -http=[host]:[port] [options] source
go tool pprof -http=localhost:8080 /tmp/cpu.out
(pprof) top          // возвращает десять лучших записей в текстовой форме
(pprof) top10 --cum  // возвращает совокупное время выполнения для каждой функции
(pprof) list main.N1 // информацию о производительности функции
(pprof) pdf


// -------------------------------
//  github.com/pkg/profile
defer profile.Start(profile.ProfilePath("/tmp")).Stop()
defer profile.Start(profile.MemProfile).Stop()


// --------------------------------
//    net/http/pprof | 600
// --------------------------------
package main
import (
	"fmt"
	"net/http"
	"net/http/pprof"
	"os"
	"time"
)

func myHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Serving: %s\n", r.URL.Path)
	fmt.Printf("Served: %s\n", r.Host)
}

func timeHandler(w http.ResponseWriter, r *http.Request) {
	t := time.Now().Format(time.RFC1123)
	Body := "The current time is:"
	fmt.Fprintf(w, "<h1 align=\"center\">%s</h1>", Body)
	fmt.Fprintf(w, "<h2 align=\"center\">%s</h2>\n", t)
	fmt.Fprintf(w, "Serving: %s\n", r.URL.Path)
	fmt.Printf("Served time for: %s\n", r.Host)
}

func main() {
	r := http.NewServeMux()
	r.HandleFunc("/time", timeHandler)
	r.HandleFunc("/",     myHandler)
	r.HandleFunc("/debug/pprof/",        pprof.Index)
	r.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	r.HandleFunc("/debug/pprof/profile", pprof.Profile)
	r.HandleFunc("/debug/pprof/symbol",  pprof.Symbol)
	r.HandleFunc("/debug/pprof/trace",   pprof.Trace)

	err := http.ListenAndServe(":8001", r)
	if err != nil {
		fmt.Println(err)
		return
	}
}


// --------------------------------
//    trace
// --------------------------------
go tool trace <source.out> -> http://127.0.0.1:50383  // 530
// -------------------------------
package main
import (
	"fmt"
	"os"
	"runtime"
	"runtime/trace"   // <-
	"time"
)

func printStats(mem runtime.MemStats) {
	runtime.ReadMemStats(&mem)
	fmt.Println("mem.Alloc:",      mem.Alloc)
	fmt.Println("mem.TotalAlloc:", mem.TotalAlloc)
	fmt.Println("mem.HeapAlloc:",  mem.HeapAlloc)
	fmt.Println("mem.NumGC:",      mem.NumGC)
	fmt.Println("Num CPUs:",       runtime.NumCPU())
	fmt.Println("Num Goroutines:", runtime.NumGoroutine())
	fmt.Println("-----")
}

func main() {
	f,_ := os.Create("/tmp/trace.out")
	_ := trace.Start(f)
	defer trace.Stop()

	var mem runtime.MemStats
	printStats(mem)
	// ...
	printStats(mem)
}
