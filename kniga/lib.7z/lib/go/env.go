
val := os.Getenv("NAME")
val, ok := os.LookupEnv("NAME")

// --------------------

GOCACHE="/home/takelau/.cache/go-build"
GOENV="/home/takelau/.config/go/env"

GOPATH="/home/takelau/c7w_sftp"
GOMODCACHE="/home/takelau/c7w_sftp/pkg/mod"

GOROOT="/home/takelau/go"
GOTOOLDIR="/home/takelau/go/pkg/tool/linux_amd64"

// --------------------

https://pkg.go.dev/cmd/go#hdr-Environment_variables

GO111MODULE  "off", "on", or "auto"
GCCGO        'go build -compiler=gccgo'
GOARCH       "amd64, 386, arm, ppc64"
GOBIN        The directory where 'go install' will install a command
GOCACHE      The directory store cached
GOMODCACHE   The directory downloaded modules
GODEBUG      See 'go doc runtime' for details
GOENV        The location of the Go environment configuration file
GOFLAGS
GOINSECURE   
GOOS         "linux, darwin, windows, netbsd"
GOPATH       'go help gopath'
GOPROXY
GOPRIVATE, GONOPROXY, GONOSUMDB
GOROOT       The root of the go tree
GOSUMDB      The name of checksum database to use and optionally its public key and URL
GOTMPDIR     The directory write temporary source files
GOVCS        Lists version control commands -> 'go help vcs'
