

// --------------------------------
//    list  247
// --------------------------------
package main
import (
	"container/list"
	"fmt"
	"strconv"
)

func printList(l *list.List) {
	for t := l.Back(); t != nil; t = t.Prev() {
		fmt.Print(t.Value, " ") // 5 2 1 4 3
	}
	fmt.Println()
	for t := l.Front(); t != nil; t = t.Next() {
		fmt.Print(t.Value, " ") // 3 4 1 2 5
	}
	fmt.Println()
}

func main() {
	values := list.New()
	e1 := values.PushBack("1")   // 1
	e2 := values.PushBack("2")   // 1 2
	values.PushFront("3")        // 3 1 2
	values.InsertBefore("4", e1) // 3 4 1 2
	values.InsertAfter("5", e2)  // 3 4 1 2 5  | t.Next()
	values.Remove(e2)            // 3 4 1 5
	values.Remove(e2)            // 3 4 1 5
	values.InsertAfter("55", e2) // 3 4 1 5
	values.PushBackList(values)  // 3 4 1 5 3 4 1 5
	printList(values)

	values.Init() // Empty list

	for i := 0; i < 20; i++ {
		values.PushFront(strconv.Itoa(i)) // 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0
	}
	printList(values)
}


// --------------------------------
//    ring  249
// --------------------------------
package main
import (
	"container/ring"
	"fmt"
)

var size int = 10

func main() {
	myRing := ring.New(size)
	fmt.Printf("Empty ring:%v   len:%d \n", *myRing, myRing.Len())

	for i := 0; i < myRing.Len(); i++ { // вариант перебора элементов кольца
		myRing.Value = i
		fmt.Print(myRing.Value, " ")  // 0 1 2 3 4 5 6 7 8 9
		myRing = myRing.Next()
	}
	myRing.Value = 100              // 100 1 2 3 4 5 6 7 8 9

	sum := 0
	myRing.Do(func(x interface{}) { // вариант перебора элементов кольца
		t := x.(int)
		sum = sum + t
	})
	fmt.Printf("\nSum:%d \n", sum)  // Sum:145

	for i := 0; i < myRing.Len()+2; i++ {
		fmt.Print(myRing.Value, " ")  // 100 1 2 3 4 5 6 7 8 9 100 1
		myRing = myRing.Next()
	}
}

