
rand.Seed(time.Now().Unix())
rand.Seed(time.Now().UnixNano())


// --------------------------------
//    random 
// --------------------------------
//
r := rand.New(rand.NewSource(time.Now().UnixNano()))
seq := r.Uint32()


// --------------------------------
// 253
import {
 "math/rand"
 "time"
}
rand.Seed(time.Now().Unix())
func random(min, max int) int {
	return rand.Intn(max-min) + min
}  
chr := string(str[0] + byte(random(0,94)))   // str = "!"


// --------------------------------
// 254
package main
import (
	"crypto/rand"
	"encoding/base64"
	"fmt"
)

func generateBytes(n int64) ([]byte, error) {
	b := make([]byte, n)
	_, err := rand.Read(b)
	if err != nil {
		return nil, err
	}
	return b, nil
}

func generatePass(s int64) (string, error) {
	b, err := generateBytes(s)
	return base64.URLEncoding.EncodeToString(b), err
}

func main() {
	var LENGTH int64 = 8
	myPass, err := generatePass(LENGTH)
	if err != nil { ... }
	fmt.Println( myPass[0:LENGTH] )   // cSPuN9qw
}
