
// --------------------------------
/*
{
  "ID_SERVER": 3,
  "SERVER_TYPE": 3,
  "IP_ANAMI": "172.16.10.97",
  "IP_DB_MAG": "172.16.10.34",
  "LANGUAGE": "russian"
}
*/
package main
import (
	"encoding/json"
)

const CONFIG_FILE string = `/nami/config/anami.cfg`
var gCfg Configure

type Configure struct {
	ID_SERVER    uint32
	SERVER_TYPE  uint16
	IP_ANAMI     string
	IP_DB_MAG    string
	LANGUAGE     string
}

func configRead() {
  file,err := os.Open(CONFIG_FILE);  checkErr(err);
	decoder := json.NewDecoder(file);

	err = decoder.Decode(&gCfg);       checkErr(err);
	file.Close();
}

func init() {
	configRead()
}

// --------------------------------
func Marshal(v interface{}) ([]byte, error)
func Unmarshal(data []byte, v interface{}) error

type Config struct {
	Host string
	Port uint16
	Tags map[string]string
}

// запись
c := Config{
	Host: "localhost",
	Port: 1313,
	Tags: map[string]string{"env": "dev"},
}
bytes, err := json.Marshal(c)
fmt.Println(string(bytes))  // {"Host":"localhost","Port":1313,"Tags":{"env":"dev"}}

// чтение
c := Config{}
bytes := []byte(`{"Host":"127.0.0.1","Port":1234,"Tags":{"foo":"bar"}}`)
err := json.Unmarshal(bytes, &c)

// --------------------------------
// Декодирование произвольного JSON
bytes := []byte(`{"Foo":"Bar", "Number":1313, "Tags":{"A":"B"}}`)
var f interface{}
err := json.Unmarshal(bytes, &f)

m := f.(map[string]interface{})
fmt.Printf("<%T> %v\n", m, m)  // <map[string]interface {}> map[Number:1313 Foo:Bar Tags:map[A:B]]
fmt.Printf("<%T> %v\n", m["Number"], m["Number"])  // <float64> 1313

// --------------------------------
// Наблюдение за изменениями
1. отслеживание по одному файлу
https://github.com/fsnotify/fsnotify

package main
import (
	"github.com/fsnotify/fsnotify"
	"log"
)

func main() {
	watcher, err := fsnotify.NewWatcher()
	if err != nil { log.Fatal(err); }
	defer watcher.Close()

	done := make(chan bool)
	go func() {
		for {
			select {
			case event, ok := <-watcher.Events:
				if !ok { return; }
				log.Println("event:", event)
				if event.Op&fsnotify.Write == fsnotify.Write {
					log.Println("modified file:", event.Name)
				}
			case err, ok := <-watcher.Errors:
				if !ok { return; }
				log.Println("error:", err)
			}
		}
	}()

	err = watcher.Add("/tmp/foo")
	if err != nil { log.Fatal(err); }
	<-done
}


2. все файлы в текущей директори
https://efreitasn.dev/posts/inotify-api/

package main
import (
	"bytes"
	"fmt"
	"log"
	"unsafe"

	"golang.org/x/sys/unix"
)

func main() {
	fd, err := unix.InotifyInit1(0)
	if err != nil { log.Fatalf("err: %v\n", err); }
	defer unix.Close(fd)

	_, err = unix.InotifyAddWatch(
		fd, ".",  // все файлы в директории
		unix.IN_CREATE|unix.IN_DELETE|unix.IN_CLOSE_WRITE|unix.IN_MOVED_TO|unix.IN_MOVED_FROM|unix.IN_MOVE_SELF,
	)
	if err != nil { log.Fatalf("err: %v\n", err); }

	var buff [(unix.SizeofInotifyEvent + unix.NAME_MAX + 1) * 20]byte

	for {
		offset := 0
		n, err := unix.Read(fd, buff[:])
		if err != nil { log.Fatalf("err: %v\n", err); }

		for offset < n {
			e := (*unix.InotifyEvent)(unsafe.Pointer(&buff[offset]))

			nameBs := buff[offset+unix.SizeofInotifyEvent : offset+unix.SizeofInotifyEvent+int(e.Len)]
			name := string(bytes.TrimRight(nameBs, "\x00"))
			if len(name) > 0 && e.Mask&unix.IN_ISDIR == unix.IN_ISDIR {
				name += " (dir)"
			}

			switch {
			case e.Mask&unix.IN_CREATE == unix.IN_CREATE:            fmt.Printf("CREATE %v\n", name)
			case e.Mask&unix.IN_DELETE == unix.IN_DELETE:            fmt.Printf("DELETE %v\n", name)
			case e.Mask&unix.IN_CLOSE_WRITE == unix.IN_CLOSE_WRITE:  fmt.Printf("CLOSE_WRITE %v\n", name)
			case e.Mask&unix.IN_MOVED_TO == unix.IN_MOVED_TO:        fmt.Printf("IN_MOVED_TO [%v] %v\n", e.Cookie, name)
			case e.Mask&unix.IN_MOVED_FROM == unix.IN_MOVED_FROM:    fmt.Printf("IN_MOVED_FROM [%v] %v\n", e.Cookie, name)
			case e.Mask&unix.IN_MOVE_SELF == unix.IN_MOVE_SELF:      fmt.Printf("IN_MOVE_SELF %v\n", name)
			}

			offset += int(unix.SizeofInotifyEvent + e.Len)
		}
	}
}

