
// --------------------------------
//    Read
// --------------------------------
jo := &jSort{}
jsonPOST(r,jo)

func jsonPOST(r *http.Request, obj interface{}) bool {
	err := json.NewDecoder(r.Body).Decode(obj)
	if ldb.logErrPr(0,err) { return false; }
	return true
}
// --------------------------------
func codeGET(r *http.Request, key string) (string,bool) {
	code := r.URL.Query().Get(key)
	if !validCode(code) { return "",false; }
	return code,true
}
// --------------------------------
func cookieGet(r *http.Request, pr *ccProject, key string) (string,bool) {
	c,err := r.Cookie(key);  if err != nil {
		// debug("cookieGet key:%s  err:%s", key, err.Error());
		return ``,false;
	}
	if !validCode(c.Value) { return "",false; }
	return c.Value,true
}


// --------------------------------
//    Write
// --------------------------------
/* text/plain; charset=utf-8       */
/* application/json; charset=utf-8 */
func jsonWrite(pr *ccProject, code int, w http.ResponseWriter, obj interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-cache, no-store, must-revalidate")
//w.Header().Set("Server", "nginx")
	w.WriteHeader(code)
	err := json.NewEncoder(w).Encode(&obj)
	if ldb.logErr(pr,err) {  }
// jsonBytes, err := json.Marshal(obj);  if err != nil { return err; }  w.Write(jsonBytes)
}
// --------------------------------
func jsonError(code int, w http.ResponseWriter, msg string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
//w.Header().Set("Server", "nginx")
	w.WriteHeader(200)
	err := json.NewEncoder(w).Encode(&H{"error":msg, "code":code})
	if ldb.logErrPr(0,err) {  }
}
// --------------------------------
func htmlWrite(w http.ResponseWriter, tmpl string, data interface{}) {
	err := templates.ExecuteTemplate(w,tmpl,&data)
	if ldb.logErrPr(0,err) {
		http.Error(w,"Error: 500",http.StatusInternalServerError)
	}
}
// --------------------------------
func xmlWrite(w http.ResponseWriter, data []byte) {
	w.Header().Set("Content-Type", "application/xml; charset=utf-8")
	w.WriteHeader(200)
	w.Write(data)
}
// --------------------------------
func strWrite(w http.ResponseWriter, str string) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(200)
	io.WriteString(w,str)  // "\xEF\xBB\xBF"
}
// --------------------------------
func strError(code int, w http.ResponseWriter, msg string) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	http.Error(w,msg,code)
}