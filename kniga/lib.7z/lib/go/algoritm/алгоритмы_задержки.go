
// --------------------------------
// фиксированная задежка по времени
res, err := SendRequest()
for err != nil {
	time.Sleep(2 * time.Second)
	res, err = SendRequest()
}

// --------------------------------
// случайная задержка по времени
res, err := SendRequest()
base, cap := time.Second, time.Minute
for backoff := base; err != nil; backoff <<= 1 {
	if backoff > cap {
		backoff = cap
	}
	jitter := rand.Int63n(int64(backoff * 3))
	sleep  := base + time.Duration(jitter)
	time.Sleep(sleep)
	res, err = SendRequest()
}

// --------------------------------


