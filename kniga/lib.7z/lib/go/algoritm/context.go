
// -------------------------------
//    WithTimeout
// -------------------------------

package main

import (
	"context"
	"fmt"
	"time"
)

type Responder interface {
	Desc() (string, error)
}

type Piple struct {
	Name string
}

func (p Piple) Desc() (string, error) {
	return "Piple struct", nil
}

func A() (Responder, error) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	res, err := B(ctx)
	if err != nil {
		return nil, err
	}

	return res.(Piple), nil
}

func B(ctx context.Context) (Responder, error) {
	res := make(chan Responder)
	go C(ctx, res)

	for {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case r, ok := <-res:
			if !ok {
				return nil, nil
			}
			return r, nil
		}
	}
}

func C(ctx context.Context, res chan Responder) {
	time.Sleep(time.Second)
	res <- Piple{Name: "Piter"}
}

type HandlerFunc func() (Responder, error)

func A1() (Responder, error) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	res, err := B1(C1, ctx)()
	if err != nil {
		return nil, err
	}

	return res.(Piple), nil
}

func B1(h HandlerFunc, ctx context.Context) HandlerFunc {
	return func() (Responder, error) {
		var Err error
		res := make(chan Responder)

		go func() {
			data, err := h()
			if err != nil {
				close(res)
				Err = err
			} else {
				res <- data
			}
		}()

		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case Resp, ok := <-res:
			if !ok {
				return nil, Err
			}
			return Resp, nil
		}
	}
}

func C1() (Responder, error) {
	time.Sleep(time.Second * 1)
	// return nil, errors.New("C1 error")
	return Piple{Name: "Piter"}, nil
}

func main() {
	str, err := A()
	fmt.Println("A()", str, err)

	str, err = A1()
	fmt.Println("A1()", str, err)
}

// -------------------------------
//    WithValue
// -------------------------------
package main
import (
	"context"
	"fmt"
)

func main() {
	type favContextKey string

	f := func(ctx context.Context, k favContextKey) {
		if v := ctx.Value(k); v != nil {
			fmt.Println("found:", v, " <- ", k);  return;
		}
		fmt.Println("key not found:", k)
	}

	k := favContextKey("language")
	y := favContextKey("color")
	x := favContextKey("number")

	ctx1 := context.WithValue(context.Background(), k, "Go")
	ctx2 := context.WithValue(ctx1, k, "Rust")
	ctx3 := context.WithValue(ctx1, y, "Blue")
	ctx4 := context.WithValue(ctx2, x, "One")

	f(ctx1, k) // found: Go  <-  language
	f(ctx2, k) // found: Rust  <-  language

	f(ctx3, y) // found: Blue  <-  color
	f(ctx4, x) // found: One  <-  number

	f(ctx3, k) // found: Go  <-  language
	f(ctx4, k) // found: Rust  <-  language

	f(ctx4, y) // key not found: color
}