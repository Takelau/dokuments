
// --------------------------------
//    Очереди ( FIFO )
// --------------------------------
package main
import (
	"fmt"
)

type Piple struct {
	Age  int
	Next *Piple
}

func push(p *Piple, age int) *Piple {
	return &Piple{age, p}
}

func pop(p *Piple) (int, bool) {  // age, стэк пуст
	if p == nil {
		return 0, true
	}

	if (p.Next) == nil {
		return p.Age, true
	}

	prev := p
	for (p.Next) != nil {
		prev = p
		p = p.Next
	}

	age := (prev.Next).Age
	prev.Next = nil
	return age, false
}

func travers(p *Piple) {
	for p != nil {
		fmt.Printf("%d -> ", p.Age)
		p = p.Next
	}
	fmt.Println()
}

func main() {
	a := &Piple{19, nil}
	a = push(a, 35)
	a = push(a, 18)

	travers(a) // 18 -> 35 -> 19 ->

	_, complite := pop(a)
	if complite {
		a = nil
	}

	travers(a) // 18 -> 35 ->
}

// --------------------------------
package main
import (
	"fmt"
)

type Node struct {
	Value int
	Next  *Node
}

var size = 0
var queue = new(Node)

func Push(t *Node, v int) bool {
	if queue == nil {
		queue = &Node{v, nil}
		size++
		return true
	}

	t = &Node{v, queue}
	queue = t

	size++
	return true
}

func Pop(t *Node) (int, bool) {
	if size == 0 {
		return 0, false
	}
	if size == 1 {
		queue = nil
		size--
		return t.Value, true
	}
	temp := t
	for (t.Next) != nil {
		temp = t
		t = t.Next
	}
	v := (temp.Next).Value
	temp.Next = nil
	size--
	return v, true
}

func traverse(t *Node) {
	if size == 0 {
		fmt.Println("Empty Queue!")
		return
	}
	for t != nil {
		fmt.Printf("%d -> ", t.Value)
		t = t.Next
	}
	fmt.Println()
}

func main() {
	queue = nil

	for i := 0; i < 5; i++ {
		Push(queue, i)
	}
	traverse(queue)            // 4 -> 3 -> 2 -> 1 -> 0 ->
	fmt.Println("Size:", size) // Size: 5

	v, b := Pop(queue)
	if b {
		fmt.Println("Pop:", v)   // Pop: 0
	}
	fmt.Println("Size:", size) // Size: 4

	v, b = Pop(queue)
	if b {
		fmt.Println("Pop:", v)   // Pop: 1
	}
	fmt.Println("Size:", size) // Size: 3

	traverse(queue)            // 4 -> 3 -> 2 ->

}
