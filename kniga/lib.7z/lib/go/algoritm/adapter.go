package main

import (
	"fmt"
)

// Интерфейс действия
type Handler interface {
	Do(int)
}

// Действие
type Action func(int)

func (f Action) Do(i int) {
	f(i)
}

// Хранилище дейсвий
type Matrix struct {
	m map[string]Handler
}

func (m *Matrix) Add(patern string, h Handler) {
	if m.m == nil {
		m.m = make(map[string]Handler)
	}
	m.m[patern] = h
}

func (m *Matrix) Relise(patern string) Handler {
	h, ok := m.m[patern]
	if ok {
		return h
	}
	return nil
}

// Создание хранилища
func NewMartix() *Matrix {
	return &Matrix{}
}

func Sum() Handler {
	return Action(func(i int) {
		fmt.Println("%d", i+i)
	})
}

func main() {
	m := NewMartix()
	m.Add("sum", Sum())
	m.Relise("sum").Do(1) // 2
}
