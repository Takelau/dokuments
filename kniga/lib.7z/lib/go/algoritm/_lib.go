
// --------------------------------
//    Переключатели
// --------------------------------
type atomicBool int32
func (b *atomicBool) isSet() bool { return atomic.LoadInt32((*int32)(b)) != 0 }
func (b *atomicBool) setTrue()    { atomic.StoreInt32((*int32)(b), 1) }
func (b *atomicBool) setFalse()   { atomic.StoreInt32((*int32)(b), 0) }


// --------------------------------
//    Текст
// --------------------------------

https://github.com/lesismal/llib/blob/master/bytes/buffer.go
https://github.com/lesismal/llib/blob/master/bytes/pool.go

var b1 = make([]byte, n)[0:0]
var b2 [][]byte <- len()


