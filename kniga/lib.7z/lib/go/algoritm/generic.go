
package main
import(
	"fmt"
)

type Number interface {
	type int, float64
}

func MultiplyTen[T Number](a T) T{
	return a*10
}

func main() {
	fmt.Println(MultiplyTen(10))
	fmt.Println(MultiplyTen(5.55))
}

// --------------------------------
func (g GenericSlice[T]) Print() {
	for _, v := range g {
		fmt.Println(v)
	}
}

func Print [T any](g GenericSlice[T]) {
	for _, v := range g {
		fmt.Println(v)
	}
}

func main() {
	g := GenericSlice[int]{1,2,3}
	g.Print() //1 2 3
	Print(g)  //1 2 3
}

// --------------------------------
// --------------------------------
// --------------------------------
