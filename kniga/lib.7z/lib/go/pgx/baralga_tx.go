
import (
	"github.com/jackc/pgx/v4"
	"github.com/jackc/pgx/v4/pgxpool"
	// env
	"github.com/kelseyhightower/envconfig"
)

type config struct {
	Db         string `default:"postgres://postgres:postgres@localhost:5432/baralga"`
	DbMaxConns int32  `default:"3"`
)

type app struct {
	Conn   *pgx.Conn
	Config *config
	// model
	RepositoryTxer     RepositoryTxer     // Tx
	ProjectRepository  ProjectRepository  // Project
}

func newApp() (*app, error) {
	var c config
	envconfig.Process("baralga", &c)

	app := &app{
		Router: chi.NewRouter(),
		Config: &c,
	}
	app.routes()

	return app, nil
}

func (a *app) run() error {
	connPool, _ := connect(a.Config.Db, a.Config.DbMaxConns)
	defer connPool.Close()

	a.RepositoryTxer    = NewDbRepositoryTxer(connPool)
	a.ProjectRepository = NewDbProjectRepository(connPool)
}

// Tx
import (
	"context"
	"github.com/jackc/pgx/v4/pgxpool"
	"github.com/pkg/errors"
)

const contextKeyTx contextKey = 1

type RepositoryTxer interface {
	InTx(ctx context.Context, txFuncs ...func(ctxWithTx context.Context) error) error
}

type DbRepositoryTxer struct {
	connPool *pgxpool.Pool
}

var _ RepositoryTxer = (*DbRepositoryTxer)(nil)

func NewDbRepositoryTxer(connPool *pgxpool.Pool) *DbRepositoryTxer {
	return &DbRepositoryTxer{
		connPool: connPool,
	}
}

func (txer *DbRepositoryTxer) InTx(ctx context.Context, txFuncs ...func(ctxWithTx context.Context) error) error {
	tx, err := txer.connPool.Begin(ctx)
	if err != nil { return err; }

	ctxWithTx := context.WithValue(ctx, contextKeyTx, tx)

	for _, txFunc := range txFuncs {
		err = txFunc(ctxWithTx)
		if err != nil {
			rb := tx.Rollback(ctx)
			if rb != nil { return errors.Wrap(rb, "rollback error") }
			return err
		}
	}

	err = tx.Commit(ctx)
	if err != nil { return err; }

	return nil
}

// Project
type DbProjectRepository struct {
	connPool *pgxpool.Pool
}

var _ ProjectRepository = (*DbProjectRepository)(nil)

func NewDbProjectRepository(connPool *pgxpool.Pool) *DbProjectRepository {
	return &DbProjectRepository{
		connPool: connPool,
	}
}

type ProjectRepository interface {
	FindProjects(ctx context.Context, organizationID uuid.UUID, pageParams *paged.PageParams) (*ProjectsPaged, error)
	FindProjectsByIDs(ctx context.Context, organizationID uuid.UUID, projectIDs []uuid.UUID) ([]*Project, error)
	FindProjectByID(ctx context.Context, organizationID, projectID uuid.UUID) (*Project, error)
	InsertProject(ctx context.Context, project *Project) (*Project, error)
	UpdateProject(ctx context.Context, organizationID uuid.UUID, project *Project) (*Project, error)
	ArchiveProjectByID(ctx context.Context, organizationID, projectID uuid.UUID) error
	DeleteProjectByID(ctx context.Context, organizationID, projectID uuid.UUID) error
}

// select []id
func (r *DbProjectRepository) FindProjectsByIDs(ctx context.Context, organizationID uuid.UUID, projectIDs []uuid.UUID) ([]*Project, error) {
	rows, err := r.connPool.Query(ctx, `SELECT project_id as id, title, description, active FROM projects WHERE org_id = $1 AND project_id = any($2) ORDER by title ASC`, organizationID, projectIDs)
	if err != nil { return nil, err; }
	defer rows.Close()

	var projects []*Project
	for rows.Next() {
		var (
			id          string
			title       string
			description sql.NullString
			active      bool
		)

		err = rows.Scan(&id, &title, &description, &active)
		if err != nil { return nil, err; }

		project := &Project{
			ID:          uuid.MustParse(id),
			Title:       title,
			Description: description.String,
			Active:      active,
		}
		projects = append(projects, project)
	}

	return projects, nil
}

// insert
func (r *DbProjectRepository) InsertProject(ctx context.Context, project *Project) (*Project, error) {
	tx := ctx.Value(contextKeyTx).(pgx.Tx)

	_, err := tx.Exec(ctx, `INSERT INTO projects (project_id, title, active, description, org_id) VALUES ($1, $2, $3, $4, $5)`, project.ID, project.Title, project.Active, project.Description, project.OrganizationID)
	if err != nil { return nil, err; }

	return project, nil
}

// update
func (r *DbProjectRepository) UpdateProject(ctx context.Context, organizationID uuid.UUID, project *Project) (*Project, error) {
	tx := ctx.Value(contextKeyTx).(pgx.Tx)

	row := tx.QueryRow(ctx, `UPDATE projects SET title = $3, description = $4, active = $5 WHERE project_id = $1 AND org_id = $2 RETURNING project_id`, project.ID, organizationID, project.Title, project.Description, project.Active)

	var id string
	err := row.Scan(&id)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) { return nil, ErrProjectNotFound; }
		return nil, err
	}

	return project, nil
}

// delete
func (r *DbProjectRepository) DeleteProjectByID(ctx context.Context, organizationID, projectID uuid.UUID) error {
	tx := ctx.Value(contextKeyTx).(pgx.Tx)

	_, err := tx.Exec(ctx, `DELETE FROM activities WHERE project_id = $1 AND org_id = $2`, projectID, organizationID)
	if err != nil { return err; }

	row := tx.QueryRow(ctx, `DELETE FROM projects WHERE project_id = $1 AND org_id = $2 RETURNING project_id`, projectID, organizationID)

	var id string
	err = row.Scan(&id)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) { return ErrProjectNotFound; }
		return err
	}

	if id != projectID.String() { return ErrProjectNotFound; }
	return nil
}
