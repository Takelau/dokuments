
https://pkg.go.dev/cmd/cgo

C.char, C.schar, C.uchar  // signed, unsigned char
C.short, C.ushort         // unsigned short
C.int, C.uint
C.long, C.ulong
C.longlong, C.ulonglong   // long long, unsigned long long
C.float, C.double, C.complexfloat, C.complexdouble

C.struct_stat, C.union_stat, C.enum_stat
C.sizeof_T, C.sizeof_struct_stat

func C.CString(string) *C.char                // Go string -> C string
func C.CBytes([]byte) unsafe.Pointer          // Go []byte -> C array
func C.GoString(*C.char) string               // C string  -> Go string
func C.GoStringN(*C.char, C.int) string       // C data with explicit length -> Go string
func C.GoBytes(unsafe.Pointer, C.int) []byte  // C data with explicit length -> Go []byte

// --------------------------------
//    Import
// --------------------------------
// #include <stdio.h>
// #include <errno.h>
import "C"


// --------------------------------
//    C references to Go
// --------------------------------
func MyFunction(arg1, arg2 int, arg3 string) int64 {...}
func MyFunction2(arg1, arg2 int, arg3 string) (int64, *C.char) {...}

extern GoInt64 MyFunction(int arg1, int arg2, GoString arg3);
extern struct MyFunction2_return MyFunction2(int arg1, int arg2, GoString arg3);
