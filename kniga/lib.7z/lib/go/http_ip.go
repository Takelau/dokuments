
// --------------------------------
//    Ip
// --------------------------------
func DialIP(network string, laddr, raddr *IPAddr) (*IPConn, error)
func ListenIP(network string, laddr *IPAddr) (*IPConn, error)
func (c *IPConn) Close() error
// --
func (c *IPConn) Read(b []byte) (int, error)
func (c *IPConn) ReadFrom(b []byte) (int, Addr, error)
func (c *IPConn) ReadFromIP(b []byte) (int, *IPAddr, error)
func (c *IPConn) ReadMsgIP(b, oob []byte) (n, oobn, flags int, addr *IPAddr, err error)
// --
func (c *IPConn) Write(b []byte) (int, error)
func (c *IPConn) WriteTo(b []byte, addr Addr) (int, error)
func (c *IPConn) WriteToIP(b []byte, addr *IPAddr) (int, error)
func (c *IPConn) WriteMsgIP(b, oob []byte, addr *IPAddr) (n, oobn int, err error)
// --
func (c *IPConn) SetDeadline(t time.Time) error
func (c *IPConn) SetReadDeadline(t time.Time) error
func (c *IPConn) SetWriteDeadline(t time.Time) error
// --
func (c *IPConn) SetReadBuffer(bytes int) error
func (c *IPConn) SetWriteBuffer(bytes int) error
// --
func (c *IPConn) LocalAddr() Addr
func (c *IPConn) RemoteAddr() Addr
func (c *IPConn) File() (f *os.File, err error)
func (c *IPConn) SyscallConn() (syscall.RawConn, error)

// --------------------------------
// icmp
conn, _ := net.ListenIP("ip4:icmp", &net.IPAddr{IP: net.ParseIP("127.0.0.1")})
defer conn.Close()
conn.SetReadDeadline(time.Now().Add(time.Duration(5) * time.Second))

// --------------------------------
// icmp
netaddr, _ := net.ResolveIPAddr("ip4", "127.0.0.1")
conn, _ := net.ListenIP("ip4:icmp", netaddr)
buf := make([]byte, 1024)
n, _, _ := conn.ReadFrom(buf)
fmt.Println(buf[:n])

// --------------------------------
addr,err := net.ResolveIPAddr("ip4", "127.0.0.1")
conn, err := net.ListenIP("ip:253", addr)
buf := make([]byte, 9999)
for {
	n, ra, err := conn.ReadFromIP(buf)
	s := string(buf[:n]
	s = strings.TrimSpace(s)
}
