package main

import (
	"fmt"
	"os"
	"os/exec"
	"runtime"

	"github.com/vishvananda/netlink"
	"github.com/vishvananda/netns"
)

func main() {
	// skipUnlessRoot(t)
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	pid1ns, err := netns.GetFromPid(1)
	if err != nil {
		panic(err)
	}

	fmt.Printf("pid1ns: %+v \n", pid1ns)

	err = netns.Set(pid1ns)
	if err != nil {
		panic(err)
	}

	// chan for ProcEvent
	ch := make(chan netlink.ProcEvent)
	done := make(chan struct{})
	defer close(done)
	errChan := make(chan error)

	if err := netlink.ProcEventMonitor(ch, done, errChan); err != nil {
		panic(err)
	}

	// bad command
	cmd := exec.Command("false")
	if err := cmd.Start(); err != nil {
		panic(err)
	}
	fmt.Printf("bad cmd.pid:%d \n", cmd.Process.Pid)

	// first we wait for proc - i.e. childTgid is cmd.Process.Pid
	fmt.Println(" --- 1 --- ")
	for {
		e := <-ch
		fmt.Printf("os.Getpid:%+v \ne:%+v \nmsg:%+v \n", os.Getpid(), e, e.Msg)
		if e.Msg.Tgid() == uint32(os.Getpid()) {
			forkEvent, ok := e.Msg.(*netlink.ForkProcEvent)
			fmt.Printf("forkEvent:%+v \n", forkEvent)
			if ok && forkEvent.ChildTgid == uint32(cmd.Process.Pid) {
				break
			}
		}
	}

	// wait for exec event
	fmt.Println(" --- 2 --- ")
	for {
		e := <-ch
		fmt.Printf("os.Getpid:%+v \ne:%+v \nmsg:%+v \nTgid:%d == cmd.pid:%d \n", os.Getpid(), e, e.Msg, e.Msg.Tgid(), cmd.Process.Pid)
		if e.Msg.Tgid() == uint32(cmd.Process.Pid) {
			forkEvent, ok := e.Msg.(*netlink.ExecProcEvent)
			fmt.Printf("forkEvent:%+v \n", forkEvent)
			if ok {
				break
			}
		}
	}

	// wait complite out to StdOut | StdErr
	_ = cmd.Wait()

	// wait exit process event
	fmt.Println(" --- 3 --- ")
	for {
		e := <-ch
		fmt.Printf("os.Getpid:%+v \ne: %+v \nmsg:%+v Tgid:%d == pid:%d \n", os.Getpid(), e, e.Msg, e.Msg.Tgid(), cmd.Process.Pid)
		if e.Msg.Tgid() == uint32(cmd.Process.Pid) {
			if exitEvent, ok := e.Msg.(*netlink.ExitProcEvent); ok {
				fmt.Printf("exitEvent: %+v \n", exitEvent)
				if exitEvent.ExitCode != 256 {
					fmt.Printf("Expected error code 256 (-1), but got %+v \n", exitEvent)
				}
				break
			}
		}
	}

	done <- struct{}{}
}
