
// --------------------------------
// binary.Read
package main
import (
	"bytes"
	"encoding/binary"
	"fmt"
)

type Piple struct {
	PI   float64
	Uate uint8
	Mine [5]byte
	Too  uint16
}

func main() {
	b := []byte{0x6f, 0x12, 0x83, 0xc0, 0xca, 0x21, 0x09, 0x40, 0x7d, 0xd0, 0xab, 0xd0, 0x99, 0x00, 0x0a, 0x00}
	r := bytes.NewReader(b)

	d := Piple{}
	if err := binary.Read(r, binary.LittleEndian, &d); err != nil { fmt.Println("binary.Read failed:", err); }

	fmt.Println(d.PI)           // 3.1415
	fmt.Println(d.Uate)         // 125
	fmt.Printf("%q \n", d.Mine) // "ЫЙ\x00"  <-- 0xd0, 0xab, 0xd0, 0x99, 0x00
	fmt.Println(d.Too)          // 10
}

// --------------------------------
// binary.Write
package main
import (
	"bytes"
	"encoding/binary"
	"fmt"
)

type Piple struct {
	PI   float64
	Uate uint8
	Mine [5]byte
	Too  uint16
}

func main() {
	var buf bytes.Buffer
	d := Piple{
		3.1415,
		125,
		[5]byte{0xd0, 0xab, 0xd0, 0x99},  // "ЫЙ\x00"
		10,
	}

	err := binary.Write(&buf, binary.LittleEndian, &d)
	if err != nil { fmt.Println("binary.Write failed:", err); }

	fmt.Printf("%d {%# x} \n", buf.Len(), buf.Bytes()) // 16 {0x6f 0x12 0x83 0xc0 0xca 0x21 0x09 0x40 0x7d 0xd0 0xab 0xd0 0x99 0x00 0x0a 0x00}
}
