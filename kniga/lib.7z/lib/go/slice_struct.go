package main
import (
	"fmt"
)

type Piple struct {
	Age int
}

func main() {
	p := []Piple{ {Age: 10}, {Age: 11}, {Age: 12}, }
	p0(&p[0])
	p1(&p)
	fmt.Printf("%+v \n", p)  // [{Age:20} {Age:11} {Age:12} {Age:21}] 
}

func p0(p *Piple) {
	p.Age = 20
}

func p1(p *[]Piple) {
	*p = append(*p, Piple{Age: 21})
}

// --------------------------------
package main
import (
	"fmt"
)

type Piple struct {
	Age int
}

func main() {
	p := []*Piple{ {Age: 10}, {Age: 11}, {Age: 12}, }
	p0(p[0])
	p1(&p)
	for i := 0; i < len(p); i++ {
		fmt.Printf("%+v \n", *p[i])  // {Age:20} {Age:11} {Age:12} {Age:21}
	}
}

func p0(p *Piple) {
	p.Age = 20
}

func p1(p *[]*Piple) {
	*p = append(*p, &Piple{Age: 21})
}

// --------------------------------
package main
import (
	"fmt"
)

func main() {
	// var a []int
	// a := new([0]int)[:]
	// a := make([]int, 0)
	a := []int{}

	a = append(a, 10)
	a = append(a, 10)
	a = append(a, 10)

	a0(&a)
	a1(a)

	fmt.Printf("%v \n", a)  // [10 10 200 20]
}

func a0(a *[]int) {
	*a = append(*a, 20)
}

func a1(a []int) {
	a[len(a)-2] = 200
}
