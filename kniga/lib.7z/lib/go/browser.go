

// CSP
Content-Security-Policy: default-src 'self'                 // исключая поддомены
Content-Security-Policy: default-src 'self' *.trusted.com   // + поддомены
Content-Security-Policy: default-src 'self'; img-src *; media-src media1.com media2.com; script-src userscripts.example.com
Content-Security-Policy: default-src https://onlinebanking.jumbobank.com  // только по HTTPS и только из одного источника
Content-Security-Policy: default-src 'self'; report-uri http://example.com/collector.cgi   // отправка отчетов
{
  "csp-report": {
    "document-uri": "http://example.com/signup.html",
    "referrer": "",
    "blocked-uri": "http://example.com/css/style.css",
    "violated-directive": "style-src cdn.example.com",
    "original-policy": "default-src 'none'; style-src cdn.example.com; report-uri /_/csp-reports"
  }
}

// XSS
w.Header().Set("X-XSS-Protection", "1")
	0 - Отключает фильтрацию XSS
	1 - браузер удалит небезопасное содержимое
	1; mode=block - браузер предотвратит отображение страницы, если заметит атаку


// --------------------------------
//    Кеширование
// --------------------------------
// Полное отсутствие кеширования
Cache-Control: no-store
Cache-Control: no-cache, no-store, must-revalidate
// Кешировать, но проверять актуальность
Cache-Control: no-cache
// Приватные (private) и общие (public) кеши
Cache-Control: private
Cache-Control: public
// Срок действия
Cache-Control: max-age=31536000
// Проверка актуальности
Cache-Control: must-revalidate  -> Валидация кеша
// Валидация кеша
ETag           => If-None-Match       // сильный валидатор
Last-Modified  => If-Modified-Since   // слабый валидатор (1-секундное разрешение)
// Изменяющиеся ответы
Vary: User-Agent


// HTTPS вместо HTTP
Strict-Transport-Security: max-age=<expire-time>    // Время, в секундах, которое браузер должен помнить, что сайт доступен только с помощью HTTPS

