
// --------------------------------
//    Testing
// --------------------------------
import "testing"
import "testing/quick"  - тестирование методом "черного ящика"

go test f.go f_test.go -v  // тестирование
go test name* -v           // расширенный вывод отчета (RUN + PASS + FAIL)
go test name* -v -count=1  // запускать указанное кол-во раз (отключает кеш)
go test name* -v -run='F2' // только для имен функций соовт-х регулярному выражению
go test name* -v -timeout 15s
// --------------------------------
go test -cover                   // покрытие тестами
go test -coverprofile=<name>.out // 1.  создание отчета о покрытии кода
go tool cover -func=<name>.out   // 2.1 анализ файла отчета (консоль)
go tool cover -html=<name>.out   // 2.2 ... браузер
go tool cover -html=<name>.out -o output.html  // 2.3 ... в виде отчета
// --------------------------------
go test -benchmem -bench=. name.go name_test.go

// --------------------------------
ginkgo -nodes=N   runs your tests in N parallel processes and print out coherent output in realtime
ginkgo -cover     runs your tests using Go code coverage tool
ginkgo convert    converts an XUnit-style testing package to a Ginkgo-style package
ginkgo -focus="REGEXP" and ginkgo -skip="REGEXP" allow you to specify a subset of tests to run via regular expression
ginkgo -r         runs all tests suites under the current directory
ginkgo -v         prints out identifying information for each tests just before it runs

// --------------------------------
func Test<Name>(*testing.T)
func Benchmark<Name>(*testing.B)
// Subtests and Sub-benchmarks
func TestFoo(t *testing.T) {
	t.Run("A=1", func(t *testing.T) { ... })
}

// Test
type T struct {}
func (c *T) Cleanup(f func())  // вызывается в конце теста
func (t *T) Deadline() (deadline time.Time, ok bool)
func (c *T) Errorf(format string, args ...any)
func (c *T) Fail()         // marks failed + continues execution
func (c *T) FailNow()      // marks failed + stops + continue next test
func (c *T) Failed() bool  // reports whether the function has failed
func (c *T) Fatalf(format string, args ...any)  // ~ Logf()
func (c *T) Logf(format string, args ...any)
func (c *T) Name() string  // name of the running (sub-) test or benchmark
func (t *T) Parallel()     // run in parallel with other parallel tests
func (t *T) Run(name string, f func(t *T)) bool
func (t *T) Setenv(key, value string)  // ~ os.Setenv(key, value)
func (c *T) SkipNow()      // execution will continue at the next test or benchmark

bytes.Equal(in, out)   // in,out = []byte

"github.com/stretchr/testify/assert"
assert := assert.New(t)
assert.Equal(t, 123, 123, "they should be equal")
assert.NotEqual(t, 123, 456, "they should not be equal")
assert.Nil(t, object)
if assert.NotNil(t, object) { assert.Equal(t, "Something", object.Value); }

"github.com/stretchr/testify/mock"


// --------------------------------
//    Benchmark
// --------------------------------
go test -bench=. name.go name_test.go             // '-bench=' - какие функции запускать
go test -benchmem -bench=. name.go name_test.go   // + mem

вывод: Benchmark30fibo2-8   300   4430097 ns/op   0 B/op   0 allocs/op
  8       - кол-во горутин ( == GOMAXPROCS)
  300     - сколько раз была выполнена соответствующая функция
  4494213 - средне время выполнения
  0 B/op      - среднее количество памяти
  0 allocs/op - количество операций выделения памяти

// Benchmark
type B struct { N int }
func (c *B) Cleanup(f func())  // вызывается в конце теста
func (c *B) Fail()         // marks failed + continues execution
func (c *B) FailNow()      // marks failed + stops + continue next test
func (c *B) Failed() bool  // reports whether the function has failed
func (c *B) Fatalf(format string, args ...any)
func (c *B) Logf(format string, args ...any)
func (c *B) Name() string  // name of the running (sub-) test or benchmark
func (b *B) ReportMetric(n float64, unit string)
func (b *B) ResetTimer()   // deletes user-reported metrics
func (b *B) Run(name string, f func(b *B)) bool  // N=1
func (b *B) RunParallel(body func(*PB))          // creates multiple goroutines

