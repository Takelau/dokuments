
// --------------------------------
//    HTTP & Postgre | 539
// --------------------------------
package main
import (
	"database/sql"
	"fmt"
	_ "github.com/lib/pq"
	"net/http"
	"os"
	"time"
)

func myHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Serving: %s\n", r.URL.Path)
	fmt.Printf("Served: %s\n", r.Host)
}

func timeHandler(w http.ResponseWriter, r *http.Request) {
	t := time.Now().Format(time.RFC1123)
	Body := "The current time is:"
	fmt.Fprintf(w, "<h1 align=\"center\">%s</h1>", Body)
	fmt.Fprintf(w, "<h2 align=\"center\">%s</h2>\n", t)
	fmt.Fprintf(w, "Serving: %s\n", r.URL.Path)
	fmt.Printf("Served time for: %s\n", r.Host)
}

func getData(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("Serving: %s\n", r.URL.Path)
	fmt.Printf("Served: %s\n", r.Host)
	db, err := sql.Open("postgres", "user=postgres dbname=s2 sslmode=disable")
	if err != nil { fmt.Fprintf(w, "<h1 align=\"center\">%s</h1>", err);  return; }
	rows, err := db.Query("SELECT * FROM users")
	if err != nil { fmt.Fprintf(w, "<h3 align=\"center\">%s</h3>\n", err);  return; }
	defer rows.Close()
	for rows.Next() {
		var id int
		var firstName string
		var lastName string
		err = rows.Scan(&id, &firstName, &lastName)
		if err != nil { fmt.Fprintf(w, "<h1 align=\"center\">%s</h1>\n", err);  return; }
		fmt.Fprintf(w, "<h3 align=\"center\">%d, %s, %s</h3>\n", id, firstName, lastName)
	}
	err = rows.Err()
	if err != nil { fmt.Fprintf(w, "<h1 align=\"center\">%s</h1>", err); return }
}

func main() {
	PORT := ":8001"
	arguments := os.Args
	if len(arguments) != 1 {
		PORT = ":" + arguments[1]
	}
	fmt.Println("Using port number: ", PORT)
	http.HandleFunc("/time", timeHandler)
	http.HandleFunc("/getdata", getData)
	http.HandleFunc("/", myHandler)
	err := http.ListenAndServe(PORT, nil)
	if err != nil { fmt.Println(err); return; }
}

// Test
package main
import (
	"database/sql"
	_ "github.com/lib/pq"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
)

func Test_record(t *testing.T) {
	create_table()
	insert_record("INSERT INTO users (first_name, last_name) VALUES ('John', 'Doe')")
	// тестируем страницу "/getdata" GET запросом
	rr := httptest.NewRecorder()          // httptest
	req, err := http.NewRequest("GET", "/getdata", nil);     if err != nil { return; }
	handler := http.HandlerFunc(getData)  // <-- getData() - тестируемая функция
	handler.ServeHTTP(rr, req)

	status := rr.Code
	if status != http.StatusOK {
		t.Errorf("Handler returned %v", status)
	}
	if rr.Body.String() != "<h3 align=\"center\">1, John, Doe</h3>\n" {
		t.Errorf("Wrong server response!")
	}

	drop_table()
}

func Test_count(t *testing.T) {
	var count int
	create_table()
	// запись в таблицу
	insert_record("INSERT INTO users (first_name, last_name) VALUES ('Epifanios', 'Doe')")
	insert_record("INSERT INTO users (first_name, last_name) VALUES ('Mihalis', 'Tsoukalos')")
	insert_record("INSERT INTO users (first_name, last_name) VALUES ('Mihalis', 'Unknown')")

	db, err := sql.Open("postgres", "user=postgres dbname=s2 sslmode=disable")
	if err != nil { fmt.Println(err); return; }
	// проверка записи в таблицу
	row := db.QueryRow("SELECT COUNT(*) FROM users")
	err = row.Scan(&count)
	if count != 3 { t.Errorf("Select query returned %d", count); }

	db.Close()
	drop_table()
}

func Test_queryDB(t *testing.T) {
	create_table()
	db, err := sql.Open("postgres", "user=postgres dbname=s2 sslmode=disable")
	if err != nil { fmt.Println(err); return; }
	// тестовая запись
	insert_record("INSERT INTO users (first_name, last_name) VALUES ('Random Text', '123456')")
	// проверка записи корректным образом
	rows, err := db.Query(`SELECT * FROM users WHERE last_name=$1`, `123456`)
	if err != nil { fmt.Println(err); return; }
	var col1 int
	var col2 string
	var col3 string
	for rows.Next() {
		rows.Scan(&col1, &col2, &col3)
	}
	if col2 != "Random Text" { t.Errorf("first_name returned %s", col2); }
	if col3 != "123456" {      t.Errorf("last_name returned %s", col3);  }

	db.Close()
	drop_table()
}

func create_table() {
	connStr := "user=postgres dbname=s2 sslmode=disable"
	db, err := sql.Open("postgres", connStr)
	if err != nil { fmt.Println(err); }
	const query = `
	CREATE TABLE IF NOT EXISTS users (
	id SERIAL PRIMARY KEY,
	first_name TEXT,
	last_name TEXT
	)`
	_, err = db.Exec(query)
	if err != nil { fmt.Println(err); return; }
	db.Close()
}

func drop_table() {
	connStr := "user=postgres dbname=s2 sslmode=disable"
	db, err := sql.Open("postgres", connStr)
	if err != nil { fmt.Println(err); return; }
	_, err = db.Exec("DROP TABLE IF EXISTS users")
	if err != nil { fmt.Println(err); return; }
	db.Close()
}

func insert_record(query string) {
	connStr := "user=postgres dbname=s2 sslmode=disable"
	db, err := sql.Open("postgres", connStr)
	if err != nil { fmt.Println(err); return; }
	_, err = db.Exec(query)
	if err != nil { fmt.Println(err); return; }
	db.Close()
}

