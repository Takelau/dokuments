
go test -benchmem -bench=. benchmarkMe.go benchmarkMe_test.go

// --------------------------------
//    Benchmark
// --------------------------------
package main
import (
	"fmt"
)

func fibo1(n int) int {
	if n == 0 {        return 0;
	} else if n == 1 { return 1;
	} else {           return fibo1(n-1) + fibo1(n-2); }
}

func main() {
	fmt.Println(fibo1(40))
}

// ---

package main
import (
	"testing"
)
var result int

func benchmarkfibo1(b *testing.B, n int) {  // v2
	var r int
	for i := 0; i < b.N; i++ {
		r = fibo1(n)
	}
	result = r  // этот прием не позволяет компилятору выполнять любые оптимизации, которые бы отменили запуск функции
}

func Benchmark30fibo1(b *testing.B) {
	benchmarkfibo1(b, 30)
}


// --------------------------------
//    Run Parallel
// --------------------------------
import (
	"bytes"
	"testing"
	"text/template"
)

func main() {
	testing.Benchmark(func(b *testing.B) {
		templ := template.Must(template.New("test").Parse("Hello, {{.}}!"))
		b.RunParallel(func(pb *testing.PB) {   // create GOMAXPROCS goroutines
			var buf bytes.Buffer
			for pb.Next() {
				buf.Reset()
				templ.Execute(&buf, "World")
			}
		})
	})
}


// --------------------------------
//    Бенчмаркинг буферизованной записи
// --------------------------------
package main
import (
	"fmt"
	"math/rand"
	"os"
	"strconv"
)
var BUFFERSIZE int
var FILESIZE int

func random(min, max int) int {
	return rand.Intn(max-min) + min
}

func createBuffer(buf *[]byte, count int) {
	*buf = make([]byte, count)
	if count == 0 { return }
	for i := 0; i < count; i++ {
		intByte := byte(random(0, 100))
		if len(*buf) > count { return }
		*buf = append(*buf, intByte)
	}
}

func Create(dst string, b, f int) error {
	_ := os.Stat(dst)
	destination,_ := os.Create(dst)
	defer destination.Close()
	buf := make([]byte, 0)
	for {
		createBuffer(&buf, b)
		buf = buf[:b]
		if _, err := destination.Write(buf); err != nil { return err }
		if f < 0 { break }
		f = f - len(buf)
	}
	return err
}

func main() {
	output := "/tmp/randomFile"
	BUFFERSIZE, _ = strconv.Atoi(os.Args[1])
	FILESIZE, _   = strconv.Atoi(os.Args[2])

	Create(output, BUFFERSIZE, FILESIZE)
	eos.Remove(output)
}

// ---

package main
import (
	"fmt"
	"os"
	"testing"
)
var ERR error

func benchmarkCreate(b *testing.B, buffer, filesize int) {
	var err error
	for i := 0; i < b.N; i++ {
		err = Create("/tmp/random", buffer, filesize)
	}
	ERR = err
	os.Remove("/tmp/random")
}

func Benchmark1Create(b *testing.B) {
	benchmarkCreate(b, 1, 1000000)
}

func Benchmark10Create(b *testing.B) {
	benchmarkCreate(b, 10, 1000000)
}

func Benchmark1000Create(b *testing.B) {
	benchmarkCreate(b, 1000, 1000000)
}

go test -bench=. -benchmem name.go name_test.go



