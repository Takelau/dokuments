
// --------------------------------
//    Fuzzing
// --------------------------------
func FuzzHex(f *testing.F) {
  for _, seed := range [][]byte{{}, {0}, {9}, {0xa}, {0xf}, {1, 2, 3, 4}} {
    f.Add(seed)
  }

  f.Fuzz(func(t *testing.T, in []byte) {
    enc := hex.EncodeToString(in)
    out, err := hex.DecodeString(enc)
    if err != nil {            t.Fatalf("%v: decode: %v", in, err); }
    if !bytes.Equal(in, out) { t.Fatalf("%v: not equal after round trip: %v", in, out); }
  })
}

// --------------------------------
//    deep.Equal
// --------------------------------
package main_test
import (
	"testing"
	"github.com/go-test/deep"
)

type T struct {
	Name    string
	Numbers []float64
}

func TestDeepEqual(t *testing.T) {
	t1 := T{Name:"Isabella", Numbers:[]float64{1.13459, 2.29343, 3.010100010},}
	t2 := T{Name:"Isabella", Numbers:[]float64{1.13459, 2.29843, 3.010100010},}
	if diff := deep.Equal(t1, t2); diff != nil {
		t.Error(diff)
	}
}

// --------------------------------
//    Test
// --------------------------------
import "testing"
func TestF2(t *testing.T) {
	if f2(0)  != 0  { t.Error(`f2(0) != 0`);   }
	if f2(1)  != 1  { t.Error(`f2(1) != 1`);   }
	if f2(2)  != 1  { t.Error(`f2(2) != 1`);   }
	if f2(10) != 55 { t.Error(`f2(10) != 55`); }
}
go test name.go name_test.go -run='F2' -v

// ------------------------------
func TestArea(t *testing.T) {
	areaTests := []struct {
		name    string
		shape   Shape
		hasArea float64
	}{
		{name: "Rectangle", shape: Rectangle{Width: 12, Height: 6}, hasArea: 72.0},
		{name: "Circle",    shape: Circle{Radius: 10},              hasArea: 314.1592653589793},
		{name: "Triangle",  shape: Triangle{Base: 12, Height: 6},   hasArea: 36.0},
	}
	for _, tt := range areaTests {
		t.Run(tt.name, func(t *testing.T) {
			got := tt.shape.Area()
			if got != tt.hasArea {
				t.Errorf("%#v got %.2f want %.2f", tt.shape, got, tt.hasArea)
			}
		})
	}
}
go test -run TestArea/Rectangle

// --------------------------------
//    reflect.DeepEqual
// --------------------------------
package main_test
import (
	"testing"
	"github.com/go-test/deep"
)

type T struct {
	Name    string
	Numbers []float64
}

func TestDeepEqual(t *testing.T) {
	t1 := T{ Name:"Isabella", Numbers:[]float64{1.13459, 2.29343, 3.010100010}, }
	t2 := T{ Name:"Isabella", Numbers:[]float64{1.13459, 2.29843, 3.010100010}, }
	if diff := deep.Equal(t1, t2); diff != nil { t.Error(diff) }
}

t.Errorf("%d want 1", got)


