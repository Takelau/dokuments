
// --------------------------------
//    testing/quick | 546
// --------------------------------
// quick.Value - заполнение структуры случайными данными
package main
import (
	"fmt"
	"math/rand"
	"reflect"
	"testing/quick"
	"time"
)

func main() {
	type point3D struct {
		X, Y, Z int8
		S       float32
		Str     string
	}

	p   := reflect.TypeOf(point3D{})
	ran := rand.New(rand.NewSource(time.Now().Unix()))

	x,_ := quick.Value(p, ran)  // <--
	fmt.Printf("%#v \n", x)
}


// --------------------------------
// quick.Check - проверка условия методом "черного ящика"
package main
import (
	"fmt"
)

func Add(x, y uint16) uint16 {
	var i uint16
	for i = 0; i < x; i++ {
		y++
	}
	return y
}

func main() {
	fmt.Println(Add(0, 0))
}

// ---

package main
import (
	"testing"
	"testing/quick"
)
var N = 1000000

func TestWithSystem(t *testing.T) {
	condition := func(a, b uint16) bool {
		return Add(a, b) == (b + a);
	}
	err := quick.Check(condition, &quick.Config{ MaxCount:N })
	if err != nil { t.Errorf("Error: %v", err); }
}

func TestWithItself(t *testing.T) {
	condition := func(a, b uint16) bool {
		return Add(a, b) == Add(b, a);
	}
	err := quick.Check(condition, &quick.Config{ MaxCount:N })
	if err != nil { t.Errorf("Error: %v", err); }
}

go test -v name*
