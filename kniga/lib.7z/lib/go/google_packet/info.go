
import "github.com/google/gopacket/layers"
import "github.com/google/gopacket"

eth := gopacket.NewPacket(packetData, layers.LayerTypeEthernet, gopacket.Default)  // ethernet packet
ip6 := gopacket.NewPacket(packetData, layers.LayerTypeIPv6, gopacket.Default)      // IPv6 header and everything it contains
tcp := gopacket.NewPacket(packetData, layers.LayerTypeTCP, gopacket.Default)       // TCP header and its payload

packet := gopacket.NewPacket(packetData, layers.LayerTypeEthernet, gopacket.Default)

// --------------------------------
// TCP
if tcpLayer := packet.Layer(layers.LayerTypeTCP); tcpLayer != nil {  // TCP layer
	tcp, _ := tcpLayer.(*layers.TCP)
	fmt.Printf("src:%d dst:%d \n", tcp.SrcPort, tcp.DstPort)
}
for _, layer := range packet.Layers() {
	fmt.Println("PACKET LAYER:", layer.LayerType())
}

//
if app := packet.ApplicationLayer(); app != nil { ... }
if err := packet.ErrorLayer();       err != nil { ... }


// --------------------------------
// Creating Packet Data
1.
ip := &layers.IPv4{
  SrcIP: net.IP{1, 2, 3, 4},
  DstIP: net.IP{5, 6, 7, 8},
  ...
}
buf  := gopacket.NewSerializeBuffer()
opts := gopacket.SerializeOptions{}  // See SerializeOptions for more details.
err := ip.SerializeTo(buf, opts)
if err != nil { panic(err) }
fmt.Println(buf.Bytes())  // prints out a byte slice containing the serialized IPv4 layer.

2.
buf := gopacket.NewSerializeBuffer()
opts := gopacket.SerializeOptions{}
gopacket.SerializeLayers(buf, opts,
  &layers.Ethernet{},
  &layers.IPv4{},
  &layers.TCP{},
  gopacket.Payload([]byte{1, 2, 3, 4}))
packetData := buf.Bytes()


// --------------------------------
// Flow And Endpoint  /  https://pkg.go.dev/github.com/google/gopacket?utm_source=godoc#hdr-Flow_And_Endpoint
packet := gopacket.NewPacket(myPacketData, layers.LayerTypeEthernet, gopacket.Lazy)

1.  // Get src & dst -> reverse
netFlow  := packet.NetworkLayer().NetworkFlow()
src, dst := netFlow.Endpoints()
reverseFlow := gopacket.NewFlow(dst, src)

2.  // map flows
flows := map[gopacket.Endpoint]chan gopacket.Packet
// Send all TCP packets to channels based on their destination port
if tcp := packet.Layer(layers.LayerTypeTCP); tcp != nil {
  flows[tcp.TransportFlow().Dst()] <- packet
}

3.  // Look for all packets with the same source and destination network address
if net := packet.NetworkLayer(); net != nil {
  src, dst := net.NetworkFlow().Endpoints()
  if src == dst { fmt.Println("Fishy packet has same network source and dst: %s", src); }
}

4.  // Find all packets coming from UDP port 1000 to UDP port 500
interestingFlow := gopacket.FlowFromEndpoints(layers.NewUDPPortEndpoint(1000), layers.NewUDPPortEndpoint(500))
if t := packet.NetworkLayer(); t != nil && t.TransportFlow() == interestingFlow { fmt.Println("Found that UDP flow I was looking for!"); }

5.  // load-balancing
channels := [8]chan gopacket.Packet
for i := 0; i < 8; i++ {
  channels[i] = make(chan gopacket.Packet)
  go packetHandler(channels[i])
}
for packet := range getPackets() {
  if net := packet.NetworkLayer(); net != nil {
    channels[int(net.NetworkFlow().FastHash()) & 0x7] <- packet
  }
}


// --------------------------------
// Parser  /  https://pkg.go.dev/github.com/google/gopacket?utm_source=godoc#hdr-Fast_Decoding_With_DecodingLayerParser
1.  // NewDecodingLayerParser
func main() {
  var eth layers.Ethernet
  var ip4 layers.IPv4
  var ip6 layers.IPv6
  var tcp layers.TCP
  parser := gopacket.NewDecodingLayerParser(layers.LayerTypeEthernet, &eth, &ip4, &ip6, &tcp)
  decoded := []gopacket.LayerType{}
  for packetData := range somehowGetPacketData() {
    if err := parser.DecodeLayers(packetData, &decoded); err != nil {
      fmt.Fprintf(os.Stderr, "Could not decode layers: %v\n", err)
      continue
    }
    for _, layerType := range decoded {
      switch layerType {
        case layers.LayerTypeIPv6:
          fmt.Println("    IP6 ", ip6.SrcIP, ip6.DstIP)
        case layers.LayerTypeIPv4:
          fmt.Println("    IP4 ", ip4.SrcIP, ip4.DstIP)
      }
    }
  }
}

2.  // DecodingLayerContainer + AddDecodingLayer
dlp := gopacket.NewDecodingLayerParser(LayerTypeEthernet)
dlp.SetDecodingLayerContainer(gopacket.DecodingLayerSparse(nil))
var eth layers.Ethernet
dlp.AddDecodingLayer(&eth)
// ... add layers and use DecodingLayerParser as usual...

3.  // DecodingLayerContainer + Put
func main() {
  var eth layers.Ethernet
  var ip4 layers.IPv4
  var ip6 layers.IPv6
  var tcp layers.TCP
  dlc := gopacket.DecodingLayerContainer(gopacket.DecodingLayerArray(nil))
  dlc = dlc.Put(&eth)
  dlc = dlc.Put(&ip4)
  dlc = dlc.Put(&ip6)
  dlc = dlc.Put(&tcp)
  // you may specify some meaningful DecodeFeedback
  decoder := dlc.LayersDecoder(LayerTypeEthernet, gopacket.NilDecodeFeedback)
  decoded := make([]gopacket.LayerType, 0, 20)
  for packetData := range somehowGetPacketData() {
    lt, err := decoder(packetData, &decoded)
    if err != nil { fmt.Fprintf(os.Stderr, "Could not decode layers: %v\n", err);  continue; }
    if lt != gopacket.LayerTypeZero { fmt.Fprintf(os.Stderr, "unknown layer type: %v\n", lt);  continue; }
    for _, layerType := range decoded {
      // examine decoded layertypes just as already shown above
    }
  }
}



