package main

import (
	"fmt"
	"sync"
	"time"
)

// dst - общий канал приема
// src - срез с каналами отправки
func PlexIn(src ...<-chan int) <-chan int {
	dst := make(chan int)
	var wg sync.WaitGroup

	wg.Add(len(src))
	for _, ch := range src {
		go func(c <-chan int) {
			defer wg.Done()
			for n := range c { // требует close(c)
				dst <- n
			}
		}(ch)
	}

	go func() {
		wg.Wait()
		close(dst)
	}()
	return dst
}

func SendIn() []<-chan int {
	src := make([]<-chan int, 0)

	for i := 0; i < 3; i++ {
		ch := make(chan int)
		src = append(src, ch)

		go func() {
			defer close(ch) // необходимо для 'for range' PlexIn()
			for i := 1; i <= 5; i++ {
				ch <- i
				time.Sleep(time.Second)
			}
		}()
	}

	return src
}

func main() {
	// несколько отправителей и один сборщик
	src := SendIn()        // make([]<-chan int, 0)
	dst := PlexIn(src...)  // make(chan int)
	// обработчик
	for d := range dst {
		fmt.Println(d)
	}
}
