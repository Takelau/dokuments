package main

import (
	"fmt"
	"sync"
)

// dst - срез каналов обработки
// src - каналами отправки
func PlexOut(src chan int, n int) []<-chan int {
	dst := make([]<-chan int, 0)

	for i := 0; i < n; i++ { // Создать n выходных каналов
		ch := make(chan int)
		dst = append(dst, ch)

		go func() {
			defer close(ch)
			for val := range src {
				ch <- val
			}
		}()
	}

	return dst
}

func SendOut() chan int {
	src := make(chan int)

	go func() {
		for i := 1; i <= 10; i++ {
			src <- i
		}
		close(src)
	}()

	return src
}

func main() {
	// один отправителей и много обработчиков
	src := SendOut()       // make(chan int)
	dst := PlexOut(src, 5) // make([]<-chan int, 0)

	var wg sync.WaitGroup // Использовать WaitGroup для ожидания, пока
	wg.Add(len(dst))      // не закроются выходные каналы
	for i, ch := range dst {
		// обработчик
		go func(i int, d <-chan int) {
			defer wg.Done()
			for val := range d {
				fmt.Printf("#%d got %d\n", i, val)
			}
		}(i, ch)
	}
	wg.Wait()
}
