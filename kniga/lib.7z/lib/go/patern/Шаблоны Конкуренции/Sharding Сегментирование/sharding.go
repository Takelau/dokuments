package main

import (
	"crypto/sha1"
	"fmt"
	"sync"
)

// разделение map[string]interface{}
// на сегменты со своим sync.RWMutex - блокировками

type Shard struct {
	sync.RWMutex                        // Встраивание sync.RWMutex
	m            map[string]interface{} // m содержит информацию о сегменте
}
type ShardedMap []*Shard // ShardedMap является срезом с экземплярами *Shard

func NewShardedMap(nshards int) ShardedMap {
	shards := make([]*Shard, nshards) // Инициализировать срез с экземплярами *Shard
	for i := 0; i < nshards; i++ {
		shard := make(map[string]interface{})
		shards[i] = &Shard{m: shard}
	}
	return shards // ShardedMap ЯВЛЯЕТСЯ срезом с экземплярами *Shard!
}

func (m ShardedMap) getShardIndex(key string) int {
	checksum := sha1.Sum([]byte(key)) // Использовать Sum из "crypto/sha1"
	hash := int(checksum[17])         // Выбрать произвольный байт на роль хеша
	fmt.Println("getShardIndex: ", key, checksum, hash, hash%len(m))
	return hash % len(m) // Взять остаток от деления на len(m), чтобы получить индекс
}

func (m ShardedMap) getShard(key string) *Shard {
	index := m.getShardIndex(key)
	return m[index]
}

func (m ShardedMap) Get(key string) interface{} {
	shard := m.getShard(key)
	shard.RLock()
	defer shard.RUnlock()
	return shard.m[key]
}

func (m ShardedMap) Set(key string, value interface{}) {
	shard := m.getShard(key)
	shard.Lock()
	defer shard.Unlock()
	shard.m[key] = value
}

func (m ShardedMap) Keys() []string {
	keys := make([]string, 0) // Создать пустой срез ключей
	mutex := sync.Mutex{}     // Мьютекс для безопасной записи в keys

	wg := sync.WaitGroup{}    // Создать группу ожидания и установить
	wg.Add(len(m))            // счетчик равным количеству сегментов

	for _, shard := range m { // Запустить сопрограмму для каждого сегмента
		go func(s *Shard) {
			s.RLock()              // Установить блокировку для чтения в s
			for key := range s.m { // Получить ключи из сегмента
				mutex.Lock()
				keys = append(keys, key)
				mutex.Unlock()
			}
			s.RUnlock() // Снять блокировку для чтения
			wg.Done()   // Сообщить WaitGroup, что обработка завершена
		}(shard)
	}
	wg.Wait() // Приостановить выполнение до выполнения

	// всех операций чтения
	return keys // Вернуть срез с ключами
}

func main() {
	shardedMap := NewShardedMap(5)
	//             key      value
	shardedMap.Set("alpha", 1)
	shardedMap.Set("beta", 2)
	shardedMap.Set("gamma", 3)

	fmt.Println(shardedMap.Get("alpha"))
	fmt.Println(shardedMap.Get("beta"))
	fmt.Println(shardedMap.Get("gamma"))

	keys := shardedMap.Keys()

	for _, k := range keys {
		fmt.Println(k)
	}
}
