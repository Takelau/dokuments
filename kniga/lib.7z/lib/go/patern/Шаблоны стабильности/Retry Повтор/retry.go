package main

import (
	"context"
	"errors"
	"fmt"
	"time"
)

type Handler func(context.Context) (string, error)

// h       - выполняемая функция
// retries - кол-во повторений вызова функции h
// delay   - задержки между повторениями
func Retry(h Handler, retries int, delay time.Duration) Handler {
	return func(ctx context.Context) (string, error) {
		for r := 0; ; r++ {
			response, err := h(ctx)
			if err == nil || r >= retries {
				return response, err
			}

			fmt.Printf("Attempt %d failed; retrying in %v \n", r+1, delay)

			select {
			case <-time.After(delay):
			case <-ctx.Done():
				return "", ctx.Err()
			}
		}
	}
}

var count int

func A(ctx context.Context) (string, error) {
	count++
	if count <= 5 {
		return "fail", errors.New("error")
	} else {
		return "success", nil
	}
}

func main() {
	a := Retry(A, 3, 2*time.Second)
	res, err := a(context.Background()) // суммарное время выполнения 3 * 2 = 6 сек
	fmt.Println(res, err)               // success <nil>
}
