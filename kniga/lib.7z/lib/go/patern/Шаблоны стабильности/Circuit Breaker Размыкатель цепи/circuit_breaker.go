package main

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)

type Circuit func(context.Context) (string, error)

// circuit          - выполняемая функция
// failureThreshold - предельное кол-во завершений с ошибкой
func Breaker(circuit Circuit, failureThreshold uint) Circuit {
	var consecutiveFailures int = 0 // счетчик ошибок. Сбрасывается, если 'circuit(ctx)' выполняется без ошибок
	var lastAttempt = time.Now()    // время последнего вызова 'circuit(ctx)',
	var m sync.RWMutex

	return func(ctx context.Context) (string, error) {
		m.RLock()
		d := consecutiveFailures - int(failureThreshold)

		if d >= 0 {
			// if d > 4 { d = 4; }
			shouldRetryAt := lastAttempt.Add(time.Second * 2 << d)
			fmt.Println("d", d, lastAttempt.Unix(), shouldRetryAt.Unix())
			if !time.Now().After(shouldRetryAt) {
				m.RUnlock()
				return "", errors.New("service unreachable")
			}
		}

		m.RUnlock()
		response, err := circuit(ctx) // <--

		m.Lock()
		defer m.Unlock()

		lastAttempt = time.Now()
		if err != nil {
			consecutiveFailures++ // увеличить счетчик ошибок
			return response, err
		}

		consecutiveFailures = 0 // cбросить счетчик ошибок
		return response, nil
	}
}

func A(ctx context.Context) (string, error) {
	return "", errors.New("A() Error")
}

func main() {
	ctx := context.Background()
	a := Breaker(A, 2)

	for i := 0; i < 50; i++ {
		time.Sleep(time.Second)
		_, err := a(ctx)
		fmt.Println(err)
	}
}
