package main

import (
	"context"
	"fmt"
	"strconv"
	"sync"
	"time"
)

type Handler func(int, context.Context) (string, error)

// h - выполняемая функция
// d - интервал кеширования результата вызова
func DebounceFirst(h Handler, d time.Duration) Handler {
	var m sync.Mutex
	var threshold time.Time
	// кэш выполнения A()
	var result string
	var err error

	return func(i int, ctx context.Context) (string, error) {
		m.Lock()
		defer m.Unlock()

		// возврат закешированных значений
		if time.Now().Before(threshold) {
			return result, err  
		}

		result, err = h(i, ctx)        // вызываемая функция обновляет кэш
		threshold = time.Now().Add(d)  // обновление счетчика кеширования

		return result, err
	}
}

func A(i int, ctx context.Context) (string, error) {
	return strconv.Itoa(i) + " A()", nil
}

func main() {
	ctx := context.Background()
	a := DebounceFirst(A, 2*time.Second) // 2 sec

	for i := 0; i < 20; i++ {
		time.Sleep(time.Millisecond * 500)
		res, _ := a(i, ctx)
		fmt.Println(res)
	}
}
