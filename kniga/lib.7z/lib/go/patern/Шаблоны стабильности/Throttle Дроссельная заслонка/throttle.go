package main

import (
	"context"
	"fmt"
	"strconv"
	"sync"
	"time"
)

type Handler func(int, context.Context) (string, error)

// h      - выполняемая функция
// max    - прадельное кол-во вызовов h() за время d
// refill - величина восстановления счетчика за интервал
// d      - интервал восстановления счетчика
// tokens - текущий счетчик вызова функции h()
func Throttle(h Handler, max uint, refill uint, d time.Duration) Handler {
	var tokens = max
	var once sync.Once

	return func(i int, ctx context.Context) (string, error) {
		if ctx.Err() != nil {
			return "", ctx.Err()
		}

		once.Do(func() {
			ticker := time.NewTicker(d)

			go func() {
				defer ticker.Stop()
				for {
					select {
					case <-ctx.Done():
						return
					case <-ticker.C:
						t := tokens + refill
						if t > max {
							t = max
						}
						tokens = t
					}
				}
			}()
		})

		// достигнуто предельное кол-во вызовов за интервал d
		if tokens <= 0 {
			return "", fmt.Errorf("too many calls")
		}

		tokens--
		return h(i, ctx)
	}
}

func A(i int, ctx context.Context) (string, error) {
	return strconv.Itoa(i) + " A()", nil
}

func main() {
	ctx := context.Background()
	a := Throttle(A, 3, 3, time.Second)

	for i := 0; i < 50; i++ {
		time.Sleep(time.Millisecond * 100)
		res, err := a(i, ctx)
		fmt.Println(res, err)
	}
}
