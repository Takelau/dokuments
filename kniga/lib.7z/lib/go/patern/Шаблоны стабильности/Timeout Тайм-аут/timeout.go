package main

import (
	"context"
	"fmt"
	"time"
)

type Responder interface {
	Desc() (string, error)
}

type Piple struct {
	Name string
}

func (p Piple) Desc() (string, error) {
	return "Piple struct", nil
}

type HandlerFunc func() (Responder, error)

func A() (Responder, error) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	wrap := B(C, ctx)
	res, err := wrap()
	if err != nil {
		return nil, err
	}

	return res.(Piple), nil
}

func B(h HandlerFunc, ctx context.Context) HandlerFunc {
	return func() (Responder, error) {
		var Err error
		res := make(chan Responder)

		go func() {
			data, err := h()
			if err != nil {
				close(res)
				Err = err
			} else {
				res <- data
			}
		}()

		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case Resp, ok := <-res:
			if !ok {
				return nil, Err
			}
			return Resp, nil
		}
	}
}

func C() (Responder, error) {
	time.Sleep(time.Second * 1)
	// return nil, errors.New("C1 error")
	return Piple{Name: "Piter"}, nil
}

func main() {
	str, err := A()
	fmt.Println("A()", str, err)
}
