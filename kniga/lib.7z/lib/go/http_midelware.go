
// --------------------------------
//    Middleware
// --------------------------------
package main
import (
	"log"
	"net/http"
)

func midlHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// midle start
		next.ServeHTTP(w, r)
		// midle end
	})
}

func handle(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Hello"))
}

func main() {
	m := http.NewServeMux()
	m.Handle("/", midlHandler(http.HandlerFunc(handle)))

	srv := &http.Server{Addr: ":5000", Handler: m}
	log.Fatal(srv.ListenAndServe())
}

// --------------------------------
import "github.com/unrolled/secure"

var myHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("hello world"))
})

func main() {
	secureMiddleware := secure.New(secure.Options{
		SSLRedirect: true,
		SSLHost:     "localhost:8443", // This is optional in production. The default behavior is to just redirect the request to the HTTPS protocol. Example: http://github.com/some_page would be redirected to https://github.com/some_page.
	})

	app := secureMiddleware.Handler(myHandler)
	// HTTP
	go func() {
		log.Fatal(http.ListenAndServe(":8080", app))
	}()
	// HTTPS
	log.Fatal(http.ListenAndServeTLS(":8443", "cert.pem", "key.pem", app))
}


// --------------------------------
// Logging + PanicRecovery
package middleware

import (
	"log"
	"net/http"
	"runtime/debug"
	"time"
)

func Logging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, req)
		log.Printf("%s %s %s", req.Method, req.RequestURI, time.Since(start))
	})
}

func PanicRecovery(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
				log.Println(string(debug.Stack()))
			}
		}()
		next.ServeHTTP(w, req)
	})
}

// Use
func main() {
	mux := http.NewServeMux()
	server := NewTaskServer()
	mux.HandleFunc("/task/", server.taskHandler)

	handler := middleware.Logging(mux)
	handler = middleware.PanicRecovery(handler)

	log.Fatal(http.ListenAndServe("localhost:"+os.Getenv("SERVERPORT"), handler))
}