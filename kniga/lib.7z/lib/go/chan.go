// в закрытый канал нельзя писать, но можно читать
// нельзя закрыть канал, предназначенный только для приёма данных
// чтение или запись в нулевой канал заблокируют его

type hchan struct {
   qcount    uint           // кол-во элементов в буфере
   dataqsiz  uint           // размерность для буферизированного канала
   buf       unsafe.Pointer // points to an array of dataqsiz elements
   elemsize  uint16         // размер одного элемента в канале
   closed    uint32
   elemtype *_type          // element type
   sendx     uint           // send index
   recvx     uint           // receive index
   recvq     waitq          // list of recv waiters
   sendq     waitq          // list of send waiters
   lock      mutex
}

// -------------------------------
// send && get | close()
package main
import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	wg.Add(1) 

	c := make(chan int)
	go send(c)
	go get(c,&wg)

	wg.Wait()
}

func send(c chan int) {
	c <- 5
	close(c)   // обязательный элемент при работе с 'for n = range c { ... }'
}

func get(c chan int, wg *sync.WaitGroup) {
	defer wg.Done()
	for n := range c {
		fmt.Println(n)
	}
}

// -------------------------------
// context
package main
import (
	"context"
	"fmt"
)

func main() {
	ctx, cancel := context.WithCancel(context.Background())

	gen := func(ctx context.Context) <-chan int {
		dst := make(chan int)
		n := 1
		go func() {
			for {
				select {
					case <-ctx.Done(): return   // выход из горутины
					case dst <- n:     n++
				}
			}
		}()
		return dst
	}

	for n := range gen(ctx) {
		fmt.Println(n)
		if n == 5 {
			cancel()
			break
		}
	}
}

// -------------------------------
// несколько отправителей и один обработчик
package main
import (
	"fmt"
	"sync"
)

func main() {
	var w sync.WaitGroup
	c1 := make(chan string)  // канал отправки
	c2 := make(chan string)  // канал отправки

	w.Add(3)
	go send(c1, 5, "1", &w)
	go send(c2, 10, "2", &w)

	go func() {
		defer w.Done()
		for {
			if c1 == nil && c2 == nil { return; }  // выход из горутины
			select {
			case res, ok := <-c1:
				if !ok {   c1 = nil;                 // нулификация канала c1
				} else {   fmt.Println("c1", res, ok); }
			case res, ok := <-c2:
				if !ok {   c2 = nil;                 // нулификация канала c2
				} else {   fmt.Println("c2", res, ok); }
			}
		}
	}()
	w.Wait()
}

func send(c chan<- string, n int, s string, w *sync.WaitGroup) {
	defer w.Done()
	for i := 0; i < n; i++ { c <- "c" + s; }
	close(c)
}

// -------------------------------
// send && get | канал остановки
package main
import (
	"fmt"
	"sync"
	"time"
)

func main() {
	var wg sync.WaitGroup
	wg.Add(2) 

	c   := make(chan int)
	stp := make(chan bool)  // канал остановки горутины

	go send(c,stp,&wg)
	go get(c,stp,&wg)

	wg.Wait()
}

func send(c chan<- int, stp <-chan bool, wg *sync.WaitGroup) {
	defer wg.Done()
	i:=0
	loop: for {
		select {
			case c <- i:
				i++
			case <-stp:
				close(c)
				break loop
			case <-time.After(time.Second):  // если чтение из канала 'c' производится более 'n' сек
				close(c)
				break loop
		}
	}
}

func get(c <-chan int, stp chan<- bool, wg *sync.WaitGroup) {
	defer wg.Done()
	loop: for {
		select {
			case n,ok := <-c:
				if !ok { break loop; }
				if n == 3 { close(stp); }         // коректный выход из цикла for send()
			case <-time.After(2 * time.Second):  // если данные по каналу 'c' не поступают дольше 'n' сек
				close(stp)
				break loop
		}
	}
}

// -------------------------------
package main
import (
	"fmt"
	"math/rand"
	"time"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	wg.Add(2)

	c := make(chan int)
	go add(c,&wg)
	go send(c,&wg)

	wg.Wait()
}

func send(c chan int, wg *sync.WaitGroup) {
	defer wg.Done()
	t := time.NewTimer(time.Second)  // таймер - type Timer struct { C <-chan Time }
	loop: for {
		select {
			case c <- rand.Intn(10):
			case <-t.C:  // задает время работы цыкла 'for'
				close(c)   // для 'if !ok { break loop; }'
				break loop
		}
	}
}

func add(c chan int, wg *sync.WaitGroup) {
	defer wg.Done()
	sum := 0
	loop: for {
		select {
			case n,ok := <-c:
				if !ok { break loop; }
				sum = sum + n
			case <-time.After(5 * time.Second):  // завершить, если данные не поступают более 'n' сек
				break loop
		}
	}
}


// -------------------------------
// send && get | внешний context
package main
import (
	"context"
	"fmt"
	"sync"
	"time"
)

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(20)*time.Second)
	defer cancel()
	var wg sync.WaitGroup
	c := make(chan int)

	wg.Add(2)
	go send(ctx, c, &wg)
	go get(ctx, c, &wg)
	wg.Wait()
}

func send(ctx context.Context, c chan<- int, wg *sync.WaitGroup) {
	defer wg.Done()
	for i := 0; i < 5; i++ {
		select {
		case c <- i:
		case <-ctx.Done():
			c = nil                // v1: отключение ветки в get() -> выход только через Done()
			// close(c)            // v2: завершение get() через <-c || Done()
			return                 // через 'return'
		}
	}
	if c != nil { close(c); }  // на случай 'break'
}

func get(ctx context.Context, c <-chan int, wg *sync.WaitGroup) {
	defer wg.Done()
	loop: for {
		select {
		case n,ok := <-c:
			if !ok { break loop; }
		case <-ctx.Done():
			return
		}
	}
}

// -------------------------------
// реализация простотого контекста [ context.WithCancel() ] для примера выше
type CtxNami interface {
	Done() <-chan struct{}
	Cancel()
}

type Nami struct {
	done chan struct{}
	mu   sync.Mutex
}

func (n *Nami) Done() <-chan struct{} {
	n.mu.Lock()
	if n.done == nil { n.done = make(chan struct{}); }
	d := n.done   // <--
	n.mu.Unlock()
	return d
}

func (n *Nami) Cancel() {
	n.mu.Lock()
	if n.done == nil { n.done = make(chan struct{});
	} else {           close(n.done); }  // <--
	n.mu.Unlock()
}

// -------------------------------
// пул обработчиков
package main
import (
	"fmt"
	"sync"
	"time"
)

type Client struct {
	id  int
}

type Data struct {
	cl      Client
	idPool  int
}

var client = make(chan Client, 5)
var data   = make(chan Data,   5)

func main() {
	var w sync.WaitGroup
	w.Add(2)
	go sendClient(&w) // имитация отправки запросов от клиета
	go poolClient(5)  // буфер обработчиков клиенских запросов
	go getData(&w)    // вывод результата
	w.Wait()
}

func sendClient(w *sync.WaitGroup) {
	defer w.Done()
	for i:=0; i<20; i++ {
		client <- Client{ id:i }
	}
	close(client)
}

func poolClient(n int) {   // пул обработчиков
	var w sync.WaitGroup     // руппировка клиентских обработчиков
	for i:=0; i<n; i++ {
		w.Add(1)
		go getClient(&w, i)
	}
	w.Wait()
	close(data)
}

func getClient(w *sync.WaitGroup, idp int) {
	defer w.Done()
	for c := range client {
		data <- Data{ cl:c, idPool:idp }
		time.Sleep(time.Second)
	}
}

func getData(w *sync.WaitGroup) {
	defer w.Done()
	for d := range data {
		fmt.Printf("getData idc:%d idpool:%d \n", d.cl.id, d.idPool)
	}
}
