
// ----------------------------
//    Примеры программ
// ----------------------------

// IF
int key, value, result;
key = 1, value = 5678;
result = bpf_map_update_elem(&my_map, &key, &value, BPF_NOEXIST);
if (result == 0)
	printf("Map updated with new element\n");
else
	printf("Failed to update map with new value: %d (%s)\n", result, strerror(errno));

// FOR
int new_key, new_value, it;
for (it = 2; it < 6; it++) {
	new_key   = it;
	new_value = 1234 + it;
	bpf_map_update_elem(map_data[0].fd, &new_key, &new_value, BPF_NOEXIST);
}

// WHILE
int next_key, lookup_key;
lookup_key = -1;
while(bpf_map_get_next_key(map_data[0].fd, &lookup_key, &next_key) == 0) {
	printf("The next key in the map is: '%d'\n", next_key);
	lookup_key = next_key;
}


// ----------------------------
// выводит "Hello, BPF World!" (28)
// bpf_program.c
#include <linux/bpf.h>
#define SEC(NAME) __attribute__((section(NAME), used))

SEC("tracepoint/syscalls/sys_enter_execve") int bpf_prog(void *ctx) {
	char msg[] = "Hello, BPF World!";
	bpf_trace_printk(msg, sizeof(msg));  // печатm сообщений в журнале трассировки ядра
	return 0;
}
char _license[] SEC("license") = "GPL";

// компиляция
clang -O2 -target bpf -c bpf_program.c -o bpf_program.o

// загрузка в ядро
#include <stdio.h>
#include <uapi/linux/bpf.h>
#include "bpf_load.h"

int main(int argc, char **argv) {
	if (load_bpf_file("bpf_program.o") != 0) {
		printf("The kernel didn't load the BPF program\n")
		return -1;
	}
	read_trace_pipe();
	return 0;
}

// compile
TOOLS=../../../tools
INCLUDE=../../../libbpf/include
HEADERS=../../../libbpf/src
clang -o loader -l elf -I${INCLUDE} -I${HEADERS} -I${TOOLS} ${TOOLS}/bpf_load.c loader.c


// ----------------------------
//    CRUD
// ----------------------------
1. // создание карты (map)
int fd;
fd = bpf_create_map(BPF_MAP_TYPE_HASH, sizeof(int), sizeof(int), 100, BPF_F_NO_PREALOC);

// ---
struct bpf_map_def SEC("maps") my_map = {
	 .type        = BPF_MAP_TYPE_HASH,
	 .key_size    = sizeof(int),
	 .value_size  = sizeof(int),
	 .max_entries = 100,
	 .map_flags   = BPF_F_NO_PREALLOC,
};
fd = map_data[0].fd

2. // обновление карты
int key, value, result;
key = 1, value = 5678;
// ЯДРО
result = bpf_map_update_elem(&my_map, &key, &value, BPF_EXIST);
if (result == 0)  printf("Map updated with new element\n");
else              printf("Failed to update map with new value: %d (%s)\n", result, strerror(errno));
// ПП
result = bpf_map_update_elem(map_data[0].fd, &key, &value, BPF_ANY);
if (result == 0)  printf("Map updated with new element\n");
else              printf("Failed to update map with new value: %d (%s)\n", result, strerror(errno));

3. // чтение карты
int key, result; 
int value;  // будет хранить значение ожидаемого элемента
key = 1;
// ЯДРО
result = bpf_map_lookup_elem(&my_map, &key, &value);
if (result == 0)  printf("Value read from the map: '%d'\n", value);
else              printf("Failed to read value from the map: %d (%s)\n", result, strerror(errno));
// ПП
result = bpf_map_lookup_elem(map_data[0].fd, &key, &value);
if (result == 0)  printf("Value read from the map: '%d'\n", value);
else              printf("Failed to read value from the map: %d (%s)\n", result, strerror(errno));

4. // удаление из карты
int key, result;
key = 1;
// ЯДРО
result = bpf_map_delete_element(&my_map, &key);
if (result == 0)  printf("Element deleted from the map\n");
else              printf("Failed to delete element from the map: %d (%s)\n", result, strerror(errno));
// ПП
result = bpf_map_delete_element(map_data[0].fd, &key);
if (result == 0)  printf("Element deleted from the map\n");
else              printf("Failed to delete element from the map: %d (%s)\n", result, strerror(errno));

// ---
int key, value, result, it;
key = 1;
for (it = 0; it < 2; it++) {
	result = bpf_map_lookup_and_delete_element(map_data[0].fd, &key, &value);
	if (result == 0)  printf("Value read from the map: '%d'\n", value);
	else              printf("Failed to read value from the map: %d (%s)\n", result, strerror(errno));
}


// ----------------------------
//    Конкуренция | Semaphore  (57)
// ----------------------------
struct concurrent_element {
	struct bpf_spin_lock semaphore;
	int count;
}
struct bpf_map_def SEC("maps") concurrent_map = {
	.type        = BPF_MAP_TYPE_HASH,
	.key_size    = sizeof(int),
	.value_size  = sizeof(struct concurrent_element),
	.max_entries = 100,
};
BPF_ANNOTATE_KV_PAIR(concurrent_map, int, struct concurrent_element);  // анотация KV

int bpf_program(struct pt_regs *ctx) {
	int key = 0;
	struct concurrent_element init_value = {};
	struct concurrent_element *read_value;

	bpf_map_create_elem(&concurrent_map, &key, &init_value, BPF_NOEXIST);
	read_value = bpf_map_lookup_elem(&concurrent_map, &key);

	bpf_spin_lock(&read_value->semaphore);
	read_value->count += 100;
	bpf_spin_unlock(&read_value->semaphore);
}


// ----------------------------
// структурированный ключ (59)
// BPF_MAP_TYPE_HASH
#define IPV4_FAMILY 1
struct ip_key {
	union {
		__u32 v4_addr;     // ip v4
		__u8 v6_addr[16];  // ip v6
	};
	__u8 family;
};

struct bpf_map_def SEC("maps") counters = {
	.type        = BPF_MAP_TYPE_HASH,
	.key_size    = sizeof(struct ip_key),
	.value_size  = sizeof(uint64_t),
	.max_entries = 100,
	.map_flags   = BPF_F_NO_PREALLOC
};

uint64_t update_counter(uint32_t ipv4) {
	uint64_t value;
	struct ip_key key = {};
	key.v4_addr = ip4;
	key.family  = IPV4_FAMILY;
	bpf_map_lookup_elem(counters, &key, &value);
	(*value) += 1;
}


// ----------------------------
// вызов программ (61)
// BPF_MAP_TYPE_PROG_ARRAY
struct bpf_map_def SEC("maps") programs = {
	.type        = BPF_MAP_TYPE_PROG_ARRAY,
	.key_size    = 4,
	.value_size  = 4,
	.max_entries = 1024,
};

int key = 1;
struct bpf_insn prog[] = {
	BPF_MOV64_IMM(BPF_REG_0, 0), // присваиваем r0 = 0
	BPF_EXIT_INSN(),             // возвращаем r0
};

prog_fd = bpf_prog_load(BPF_PROG_TYPE_KPROBE, prog, sizeof(prog), "GPL");
bpf_map_update_elem(&programs, &key, &prog_fd, BPF_ANY);

// ---
SEC("kprobe/seccomp_phase1") int bpf_kprobe_program(struct pt_regs *ctx) {
	int key = 1;
	// отправка в следующую программу BPF
	bpf_tail_call(ctx, &programs, &key);
	// попадаем сюда, когда дескриптора программы нет в карте
	char fmt[] = "missing program in prog_array map\n";
	bpf_trace_printk(fmt, sizeof(fmt));
	return 0;
}


// ----------------------------
// отслеживание событий (63)
// объявление структуры событий
struct data_t {
	u32  pid;
	char program_name[16];  // ограничение в 16 символов для имен команд
};
// карта для отправки событий в пространство пользователей
struct bpf_map_def SEC("maps") events = {
	.type        = BPF_MAP_TYPE_PERF_EVENT_ARRAY,
	.key_size    = sizeof(int),
	.value_size  = sizeof(u32),
	.max_entries = 2,
};
// программа для захвата и отправки данных в пространство пользователяы
SEC("kprobe/sys_exec") int bpf_capture_exec(struct pt_regs *ctx) {
	data_t data;
	data.pid = bpf_get_current_pid_tgid() >> 32;                         // возвращает идентификатор текущего процесса
	bpf_get_current_comm(&data.program_name, sizeof(data.program_name)); // загружает текущее имя программы
	bpf_perf_event_output(ctx, &events, 0, &data, sizeof(data));         // добавляет данные в карту
	return 0;
}


// ----------------------------
// контроль трафика (65)
struct bpf_map_def SEC("maps") cgroups_map = {
	.type        = BPF_MAP_TYPE_CGROUP_ARRAY,
	.key_size    = sizeof(uint32_t),
	.value_size  = sizeof(uint32_t),
	.max_entries = 1,
};
// контроль базовых ресурсов ЦП для контейнеров Docker
int cgroup_fd, key = 0;
cgroup_fd = open("/sys/fs/cgroup/cpu/docker/cpu.shares", O_RDONLY);
// сохранить информацию в карте
bpf_update_elem(&cgroups_map, &key, &cgroup_fd, 0);


// ----------------------------
// сопоставитель IP-адреса (66)
struct bpf_map_def SEC("maps") routing_map = {
	.type = BPF_MAP_TYPE_LPM_TRIE,
	.key_size = 8,
	.value_size = sizeof(uint64_t),
	.max_entries = 10000,
	.map_flags = BPF_F_NO_PREALLOC,
};

uint64_t value_1 = 1;  struct bpf_lpm_trie_key route_1 = {.data = {192, 168, 0, 0}, .prefixlen = 16};
uint64_t value_2 = 2;  struct bpf_lpm_trie_key route_2 = {.data = {192, 168, 0, 0}, .prefixlen = 24};
uint64_t value_3 = 3;  struct bpf_lpm_trie_key route_3 = {.data = {192, 168, 1, 0}, .prefixlen = 24};

bpf_map_update_elem(&routing_map, &route_1, &value_1, BPF_ANY);
bpf_map_update_elem(&routing_map, &route_2, &value_2, BPF_ANY);
bpf_map_update_elem(&routing_map, &route_3, &value_3, BPF_ANY);

uint64_t result;
struct bpf_lpm_trie_key lookup = {.data = {192, 168, 1, 1}, .prefixlen = 32};
int ret = bpf_map_lookup_elem(&routing_map, &lookup, &result);
if (ret == 0)
printf("Value read from the map: '%d'\n", result);  // 192.168.1.0/24


// ----------------------------
// fd - сохранение карты (74)
static const char * file_path = "/sys/fs/bpf/my_array";

int main(int argc, char **argv) {
	int key, value, fd, added, pinned;

	fd = bpf_create_map(BPF_MAP_TYPE_ARRAY, sizeof(int), sizeof(int), 100, 0);
	if (fd < 0) { printf("Failed to create map: %d (%s)\n", fd, strerror(errno));  return -1; }

	key = 1, value = 1234;
	added = bpf_map_update_elem(fd, &key, &value, BPF_ANY);
	if (added < 0) { printf("Failed to update map: %d (%s)\n", added, strerror(errno));  return -1; }

	pinned = bpf_obj_pin(fd, file_path);
	if (pinned < 0) { printf("Failed to pin map to the file system: %d (%s)\n", pinned, strerror(errno));  return -1; }
	return 0;
}

// fd - чтение карты
static const char * file_path = "/sys/fs/bpf/my_array";

int main(int argc, char **argv) {
	int fd, key, value, result;

	fd = bpf_obj_get(file_path);
	if (fd < 0) { printf("Failed to fetch the map: %d (%s)\n", fd, strerror(errno));  return -1; }

	key = 1;
	result = bpf_map_lookup_elem(fd, &key, &value);
	if (result < 0) { printf("Failed to read value from the map: %d (%s)\n", result, strerror(errno));  return -1; }

	printf("Value read from the map: '%d'\n", value);
	return 0;
}


// ----------------------------
//    bpf = BPF(text = bpf_source)
// ----------------------------
// Kprobes (80) - выводит имя любого двоичного файла, выполняемого в вашей системе
from bcc import BPF
bpf_source = """
int do_sys_execve(struct pt_regs *ctx, void filename, void argv, void envp) {
	char comm[16];
	bpf_get_current_comm(&comm, sizeof(comm));
	bpf_trace_printk("executing program: %s", comm);
	return 0;
}
"""
bpf = BPF(text = bpf_source)                            // загрузка программы в ядро
execve_function = bpf.get_syscall_fnname("execve")      // связывание программы с системным вызовом "execve'
bpf.attach_kprobe(event=execve_function, fn_name="do_sys_execve")
bpf.trace_print()

// ----------------------------
// Kretprobes (81) - см выше
from bcc import BPF
bpf_source = """
int ret_sys_execve(struct pt_regs *ctx) {
	int return_value;
	char comm[16];
	bpf_get_current_comm(&comm, sizeof(comm));
	return_value = PT_REGS_RC(ctx);    // MACROS считывает возвращенное значение из реестра BPF для контекста
	bpf_trace_printk("program: %s, return: %d", comm, return_value);
	return 0;
}
"""
bpf = BPF(text = bpf_source)
execve_function = bpf.get_syscall_fnname("execve")
bpf.attach_kretprobe(event=execve_function, fn_name="ret_sys_execve")
bpf.trace_print()

// ----------------------------
// Tracepoint (83) - трассировка всех приложений в системе, загружающих другие программы BPF
from bcc import BPF
bpf_source = """
int trace_bpf_prog_load(void ctx) {
	char comm[16];
	bpf_get_current_comm(&comm, sizeof(comm));
	bpf_trace_printk("%s is loading a BPF program", comm);
	return 0;
}
"""
bpf = BPF(text = bpf_source)
bpf.attach_tracepoint(tp="bpf:bpf_prog_load", fn_name="trace_bpf_prog_load")  // 'BCC' точка трассировки в подсистеме 'pbf_prog_load'
bpf.trace_print()

// ----------------------------
// Uprobes (85)
// 1. go build main.go -o hello-bpf
package main
import "fmt"
	func main() {
	fmt.Println("Hello, BPF")
}
// 2.
from bcc import BPF
bpf_source = """
int trace_go_main(struct pt_regs *ctx) {
	u64 pid = bpf_get_current_pid_tgid();
	bpf_trace_printk("New hello-bpf process running with PID: %d", pid);
}
"""
bpf = BPF(text = bpf_source)
bpf.attach_uprobe(name="hello-bpf", sym="main.main", fn_name="trace_go_main")
bpf.trace_print()

// ----------------------------
// Uretprobes (86) - измерение времени выполнения функции
bpf_source = """
BPF_HASH(cache, u64, u64);
int trace_start_time(struct pt_regs *ctx) {
	u64 pid = bpf_get_current_pid_tgid();     // id proc
	u64 start_time_ns = bpf_ktime_get_ns();   // время в наносекундах
	cache.update(&pid, &start_time_ns);       // обновление кеша
	return 0;
}
"""
bpf_source += """
static int print_duration(struct pt_regs *ctx) {
	u64 pid = bpf_get_current_pid_tgid();     // id proc
	u64 start_time_ns = cache.lookup(&pid);
	if (start_time_ns == 0) {
		return 0;
	}
	u64 duration_ns = bpf_ktime_get_ns() - start_time_ns;         // расчет времени выполнения функции
	bpf_trace_printk("Function call duration: %d", duration_ns); 
	return 0;
}
"""
bpf = BPF(text = bpf_source)
bpf.attach_uprobe(name="hello-bpf", sym="main.main", fn_name="trace_start_time")
bpf.attach_uretprobe(name="hello-bpf", sym="main.main", fn_name="print_duration")
bpf.trace_print()


// ----------------------------
//    Perf
// ----------------------------
// вывод двоичных файлов часто исполняемых в системе (104)
bpf_source = """
#include <uapi/linux/ptrace.h>
BPF_PERF_OUTPUT(events)                           // макрос карты событий Perf
int do_sys_execve(struct pt_regs *ctx, void filename, void argv, void envp) {
	char comm[16];
	bpf_get_current_comm(&comm, sizeof(comm));
	events.perf_submit(ctx, &comm, sizeof(comm));   // отправка карты в пользовательское пространство
	return 0;
}
"""
bpf = BPF(text = bpf_source)
execve_function = bpf.get_syscall_fnname("execve")
bpf.attach_kprobe(event=execve_function, fn_name="do_sys_execve")

from collections import Counter
aggregates = Counter()                    // счетчик, в качестве ключа - имя запущеной программы
def aggregate_programs(cpu, data, size):  // функция инкремента счетчика
	comm = bpf["events"].event(data)
	aggregates[comm] += 1

bpf["events"].open_perf_buffer(aggregate_programs) // BCC опрашивает события после открытия_кольцевого_буфера
while True:
	try:
		bpf.perf_buffer_poll()
	except KeyboardInterrupt:
		break

for (comm, times) in aggregates.most_common():
	print("Program {} executed {} times".format(comm, times))
