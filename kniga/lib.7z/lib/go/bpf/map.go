
// ----------------------------
//    Атрибуты
// ----------------------------
// https://elixir.bootlin.com/linux/v5.17.5/source/include/uapi/linux/bpf.h#L1256

#include <linux/bpf.h>
int bpf(int cmd,  union bpf_attr *attr,  unsigned int size);

union bpf_attr {       
	// BPF_MAP_CREATE
	struct {
		__u32 map_type;
		__u32 key_size;     // size of key in bytes 
		__u32 value_size;   // size of value in bytes 
		__u32 max_entries;  // maximum number of entries in a map 
		__u32	map_flags;	  // BPF_MAP_CREATE related flags defined above
		__u32	inner_map_fd;	// fd pointing to the inner map 
		__u32	numa_node;	  // numa node (effective only if BPF_F_NUMA_NODE is set)
		char	map_name[BPF_OBJ_NAME_LEN];
		__u32	map_ifindex;	// ifindex of netdev to create on 
		__u32	btf_fd;	    	// fd pointing to a BTF type data 
		__u32	btf_key_type_id;	         // BTF type_id of the key 
		__u32	btf_value_type_id;	       // BTF type_id of the value 
		__u32	btf_vmlinux_value_type_id; // BTF type_id of a kernel-struct stored as the map value
		__u64	map_extra;    // Any per-map-type extra fields
	};
	// BPF_MAP_*_ELEM / BPF_MAP_GET_NEXT_KEY
	struct {
		__u32         map_fd;
		__aligned_u64 key;
		union {
			__aligned_u64 value;
			__aligned_u64 next_key;
		};
		__u64 flags;
	};
	// BPF_MAP_*_BATCH
	struct { ... }
	// BPF_PROG_LOAD
	struct {
		__u32         prog_type;    // one of enum bpf_prog_type
		__u32         insn_cnt;
		__aligned_u64 insns;        // 'const struct bpf_insn *'
		__aligned_u64 license;      // 'const char *'
		__u32         log_level;    // verbosity level of verifier
		__u32         log_size;     // size of user buffer
		__aligned_u64 log_buf;      // user supplied 'char *' buffer
		__u32         kern_version; // checked when prog_type=kprobe (since Linux 4.1)
		__u32	      	prog_flags;
		char		      prog_name[BPF_OBJ_NAME_LEN];
		...
	};
	// BPF_OBJ_*
	// BPF_OBJ_GET_INFO_BY_FD
	// BPF_PROG_ATTACH/DETACH  BPF_PROG_TEST_RUN  BPF_PROG_QUERY  BPF_PROG_BIND_MAP
	// BPF_*_GET_*_ID
	// BPF_RAW_TRACEPOINT_OPEN  BPF_ITER_CREATE  BPF_BTF_LOA
	// BPF_LINK_CREATE  BPF_LINK_UPDATE  BPF_ENABLE_STATS
} __attribute__((aligned(8)));


// ----------------------------
//    Map Types
// ----------------------------
enum bpf_map_type {
	BPF_MAP_TYPE_UNSPEC,  // Reserve 0 as invalid map type
  BPF_MAP_TYPE_HASH,             // <59> Карты хеш-таблиц
  BPF_MAP_TYPE_ARRAY,            // <60> Карты массивов             / 4 байта - размер ключа / элементы нельзя удалить и нельзя уменьшить массив
  BPF_MAP_TYPE_PROG_ARRAY,       // <61> Карты программных массивов / для хранения ссылок на программы BPF / bpf_tail_call() / >4.2 
  BPF_MAP_TYPE_PERF_EVENT_ARRAY, // <62> Карты массивов событий производительности / предназначены для пересылки событий
  BPF_MAP_TYPE_PERCPU_HASH,      // <64> Хеш-карты для каждого процессораs
  BPF_MAP_TYPE_PERCPU_ARRAY,     // <64> Хеш-карты для каждого процессора
  BPF_MAP_TYPE_STACK_TRACE,      // <64> Карты трассировки стека / bpf_get_stackid
  BPF_MAP_TYPE_CGROUP_ARRAY,     // <64> Карты массива контрольной группы / хранят идентификаторы файловых дескрипторов, которые указывают на контрольные группы
  BPF_MAP_TYPE_LRU_HASH,
  BPF_MAP_TYPE_LRU_PERCPU_HASH,
  BPF_MAP_TYPE_LPM_TRIE,         // <66> router
  BPF_MAP_TYPE_ARRAY_OF_MAPS,    // ссылки на другие карты
  BPF_MAP_TYPE_HASH_OF_MAPS,     // ссылки на другие карты
  BPF_MAP_TYPE_DEVMAP,           // <67> redirect / перенаправление сетевого трафика на сетевое стройство
  BPF_MAP_TYPE_CPUMAP,           // <68> redirect / перенаправление сетевого трафика на процессор
  BPF_MAP_TYPE_XSKMAP,           // <68> redirect / перенаправление сетевого трафика на сокет
  BPF_MAP_TYPE_SOCKMAP,          // <68> для пересылки буферов сокетов из текущей программы XDP в другой сокет
  BPF_MAP_TYPE_SOCKHASH,         // ...
  BPF_MAP_TYPE_CGROUP_STORAGE,         // сgroup
  BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE,  // сgroup / хранит разные хеш-таблицы для каждого процессора
  BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,    // + BPF_PROG_TYPE_SK_REUSEPORT -> filter IN packs
  BPF_MAP_TYPE_QUEUE,  // <69> FIFO
  BPF_MAP_TYPE_STACK,  // <71> LIFO
  // See /usr/include/linux/bpf.h for the full list.

  // NEW https://github.com/aquasecurity/libbpfgo
  BPF_MAP_TYPE_DEVMAP_HASH,
	BPF_MAP_TYPE_STRUCT_OPS,
	BPF_MAP_TYPE_RINGBUF,
	BPF_MAP_TYPE_INODE_STORAGE,
	BPF_MAP_TYPE_TASK_STORAGE,
	BPF_MAP_TYPE_BLOOM_FILTER,
};


// ----------------------------
//    CRUD
// ----------------------------
'bpf/bpf_helpers.h'   - для программ работающих в ядре
'tools/lib/bpf/bpf.h' - для программ действующих в пространстве пользователя

1. // создание карты (map)
union bpf_attr {
	struct {
		__u32 map_type;    // одно из значений bpf_map_type
		__u32 key_size;    // размер ключей в байтах
		__u32 value_size;  // размер значений в байтах
		__u32 max_entries; // максимальное количество записей в карте
		__u32 map_flags;   // флаги для модификации того, как создать карту
	};
}

union bpf_attr my_map {
	.map_type    = BPF_MAP_TYPE_HASH,
	.key_size    = sizeof(int),
	.value_size  = sizeof(int),
	.max_entries = 100,
	.map_flags   = BPF_F_NO_PREALLOC,
};
int fd = bpf(BPF_MAP_CREATE, &my_map, sizeof(my_map));  // Если вызов не удался, ядро возвращает значение  -1

// Соглашения ELF для создания карт BPF
// v1
int fd = bpf_create_map(BPF_MAP_TYPE_HASH, sizeof(int), sizeof(int), 100, BPF_F_NO_PREALOC);
// v2
struct bpf_map_def SEC("maps") my_map = {
	 .type        = BPF_MAP_TYPE_HASH,
	 .key_size    = sizeof(int),
	 .value_size  = sizeof(int),
	 .max_entries = 100,
	 .map_flags   = BPF_F_NO_PREALLOC,
};
fd = map_data[0].fd;  // 'map_data' глобальная переменная хранения информации о картах в программе

2. // обновление карты
BPF_ANY {
	BPF_ANY      0 - обновить или создать
	BPF_NOEXIST  1 - создать, если не существует
	BPF_EXIST    2 - обновить, если существует
}
// {0-успех, -1-ошибка}
result = bpf_map_update_elem(&my_map, &key, &value, BPF_ANY);  	      // ЯДРО
result = bpf_map_update_elem(map_data[0].fd, &key, &value, BPF_ANY);  // ПП

3. // чтение
result = bpf_map_lookup_elem(&my_map, &key, &value);         // ЯДРО
result = bpf_map_lookup_elem(map_data[0].fd, &key, &value);  // ПП

4. // удаление
result = bpf_map_delete_element(&my_map, &key);         // ЯДРО
result = bpf_map_delete_element(map_data[0].fd, &key);  // ПП

5. // поиск - ищет ключи, начиная с любой позиции в карте
result = bpf_map_get_next_key(map_data[0].fd, &lookup_key, &next_key);  // ПП
while(bpf_map_get_next_key(map_data[0].fd, &lookup_key, &next_key) == 0) {
	lookup_key = next_key;
}


// ----------------------------
//    Блокировки | BPF_F_LOCK
// ----------------------------
Спин-блокировки работают только в картах хранения массивов, хешей и контрольных групп 
bpf_spin_lock()   - блокирует элемент
bpf_spin_unlock() - разблокирует элемент

