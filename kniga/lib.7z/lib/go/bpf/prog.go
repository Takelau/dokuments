
man2 - https://man7.org/linux/man-pages/man2/bpf.2.html

// ----------------------------
//    PROG
// ----------------------------
char bpf_log_buf[LOG_BUF_SIZE];

int bpf_prog_load(enum bpf_prog_type type,  const struct bpf_insn *insns, int insn_cnt,  const char *license) {
	union bpf_attr attr = {
		.prog_type = type,
		.insns     = ptr_to_u64(insns),
		.insn_cnt  = insn_cnt,
		.license   = ptr_to_u64(license),
		.log_buf   = ptr_to_u64(bpf_log_buf),
		.log_size  = LOG_BUF_SIZE,
		.log_level = 1,     // печатать журнал верификации
	};
	return bpf(BPF_PROG_LOAD, &attr, sizeof(attr));
}

// ----------------------------
//    Prog type
// ----------------------------
enum bpf_prog_type {
- BPF_PROG_TYPE_UNSPEC,         // Reserve 0 as invalid program type
+ BPF_PROG_TYPE_SOCKET_FILTER,  // 3.19  доступ только для наблюдения
+ BPF_PROG_TYPE_SOCK_OPS,
+ BPF_PROG_TYPE_KPROBE,         // 4.1
+ BPF_PROG_TYPE_SCHED_CLS,      // 4.1
+ BPF_PROG_TYPE_SCHED_ACT,      // 4.1
+ BPF_PROG_TYPE_TRACEPOINT,     // Программы трассировки
++BPF_PROG_TYPE_XDP,            // XDP_PASS | XDP_DROP | XDP_TX
+ BPF_PROG_TYPE_PERF_EVENT,     // мониторинг программ
++BPF_PROG_TYPE_CGROUP_SKB,     // cgroups
+ BPF_PROG_TYPE_CGROUP_SOCK,    // когда процесс открывает новый сокет
+ BPF_PROG_TYPE_CGROUP_DEVICE,
+ BPF_PROG_TYPE_CGROUP_SOCK_ADDR,  // PROXY
@ BPF_PROG_TYPE_CGROUP_SYSCT,
@ BPF_PROG_TYPE_CGROUP_SOCKOPT,
+ BPF_PROG_TYPE_LWT_IN,
+ BPF_PROG_TYPE_LWT_OUT,
+ BPF_PROG_TYPE_LWT_XMIT,
+ BPF_PROG_TYPE_LWT_SEG6LOCAL,
+ BPF_PROG_TYPE_SK_SKB,            // LoadBalancer
++BPF_PROG_TYPE_SK_MSG,            // SK_PASS | SK_DROP
+ BPF_PROG_TYPE_SK_REUSEPORT,      // SK_PASS | SK_DROP  + BPF_MAP_TYPE_REUSEPORT_SOCKARRAY -> filter IN packs
@ BPF_PROG_TYPE_SK_LOOKUP,
+ BPF_PROG_TYPE_RAW_TRACEPOINT,
@ BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
+ BPF_PROG_TYPE_LIRC_MODE2,
+ BPF_PROG_TYPE_FLOW_DISSECTOR,
@ BPF_PROG_TYPE_TRACING,
@ BPF_PROG_TYPE_STRUCT_OPS,
@ BPF_PROG_TYPE_EXT,
@ BPF_PROG_TYPE_LSM,
@ BPF_PROG_TYPE_SYSCALL,
  // /usr/include/linux/bpf.h
  // https://github.com/torvalds/linux/blob/master/include/uapi/linux/bpf.h
};

// ----------------------------
//    Prog type
// ----------------------------
* BPF_PROG_TYPE_SOCKET_FILTER
Привязывая программу BPF к открытому сокету, вы получаете доступ ко всем пакетам, проходящим через него 
Программы с сокетными фильтрами не позволяют вам изменять содержимое этих пакетов или их назначение — они дают доступ к ним только для наблюдения

* BPF_PROG_TYPE_KPROBE / 'kprobe'
Это функции, которые можно динамически подключать к определенным точкам вызова в ядре
Виртуальная машина BPF гарантирует, что программы kprobe всегда безопасны при запуске, что является преимуществом по сравнению с традиционными модулями kprobe
SEC("kprobe/sys_exec")    - для проверки аргументов системного вызова 'exec'
SEC("kretprobe/sys_exec") - для проверки возвращаемых значений системного вызова 'exec'

**BPF_PROG_TYPE_XDP / XDP
'XDP_PASS' - пакет должен быть передан следующей подсистеме в ядре
'XDP_DROP' - ядро должно полностью игнорировать этот пакет
'XDP_TX'   - пакет должен быть направлен обратно в сетевую интерфейсную карту /NIC/, через которую был получен

** BPF_PROG_TYPE_TRACEPOINT
Программы трассировки
Точки трассировки — это статические метки в кодовой базе ядра, которые позволяют вводить произвольный код для выполнения трассировки и отладки
'/sys/kernel/debug/tracing/events'     - точки трассировки в системе
'/sys/kernel/debug/tracing/events/bpf' - точки трассировки BPF, для трассировки других BPF рограмм
    'bpf_prog_load' - срабатывает при загрузке других программ BPF

* BPF_PROG_TYPE_RAW_TRACEPOINT
Программы для доступа к необработанным точкам трассировки

* BPF_PROG_TYPE_PERF_EVENT / Perf Event
Perf - это внутренний профилировщик ядра, который генерирует события, предоставляющие данные о производительности для аппаратного и программного обеспечения
Для мониторинга компонентов: от процессора компьютера до любого программного обеспечения, работающего в системе
После связывания программы BPF с событиями Perf ваш код будет выполняться каждый раз, когда Perf генерирует данные для анализа

** BPF_PROG_TYPE_CGROUP_SKB / cgroups
Программы для сокетов контрольных групп
Позволяют связать логику BPF с контрольными группами (cgroups)
Любой пакет, который ядро пытается доставить любому процессу в той же группе, пройдет через один из этих фильтров
~ программы BPF_PROG_TYPE_CGROUP_SKB 'привязаны ко всем процесса внутри группы', а не к конкретным процессам

* BPF_PROG_TYPE_CGROUP_SOCK / Cgroup Open Socket
Программа выполняет код, когда какой-либо процесс в контрольной группе 'открывает сетевой сокет'
Позволяет контролировать то, что происходит, когда процесс открывает новый сокет

* BPF_PROG_TYPE_CGROUP_SOCK_ADDR / 'PROXY'
Позволяет манипулировать IP-адресами и номерами портов, к которым подключаются программы пользовательского пространства

* BPF_PROG_TYPE_CGROUP_DEVICE 
Позволяют решить, может ли операция в пределах контрольной группы быть выполнена 'для данного устройства'
v1 - позволяет устанавливать разрешения для определенных устройств
v2 - такой возможности нет

* BPF_PROG_TYPE_SOCK_OPS
Позволяют 'изменять параметры подключения к сокету' во время выполнения, пока пакет проходит через несколько этапов в сетевом стеке ядра
Могут вызываться несколько раз в течение жизненного цикла соединения
Вызов функции получает аргумент 'op'
Имея эту информацию, можно получить доступ к данным, например к сетевым IP-адресам и портам подключения, а также изменить параметры подключения

* BPF_PROG_TYPE_SK_SKB / 'LoadBalancer'
Предоставляют вам 'доступ к картам сокетов и перенаправлениям сокетов'
Карты сокетов позволяют хранить ссылки на несколько сокетов
Имея эти ссылки, возможно задействовать специальные помощники для перенаправления входящего пакета из одного сокета в другой

** BPF_PROG_TYPE_SK_MSG
Позволяют контролировать, должно ли доставляться сообщение, отправленное в сокет
Перед фильтрацией сообщений ядро копирует данные, содержащиеся в сообщении, чтобы вы могли прочитать их и решить, что с ними делать
'SK_PASS'
'SK_DROP'

* SO_REUSEPORT
Сокетные программы повторного использования портов
Это опция ядра, которая позволяет 'нескольким процессам' на одном хосте применять один и тот же порт

* BPF_PROG_TYPE_SK_REUSEPORT  // + BPF_MAP_TYPE_REUSEPORT_SOCKARRAY -> filter IN packs
Позволяют указать, будет ли программа BPF повторно использовать порт
'SK_DROP' - запретить программам повторно задействовать один и тот же порт
'SK_PASS' - чтобы ядро следовало собственной процедуре повторного применения

* BPF_PROG_TYPE_FLOW_DISSECTOR
Программы разделения потока
Дают гарантии безопасности, которые не может обеспечить встроенный диссектор, например гарантируют 'завершение программы'
Эти BPF-программы могут изменять поток, по которому в ядре идут сетевые пакеты

* BPF_PROG_TYPE_SCHED_CLS
* BPF_PROG_TYPE_SCHED_ACT
Программы классификатора трафика
Позволяют 'классифицировать сетевой трафик' и изменять некоторые свойства пакетов в буфере сокета

* BPF_PROG_TYPE_LWT_IN / BPF_PROG_TYPE_LWT_OUT / BPF_PROG_TYPE_LWT_XMIT / BPF_PROG_TYPE_LWT_SEG6LOCAL
Упрощенные туннельные программы
Позволяют связывать код с упрощенной туннельной инфраструктурой ядра

* BPF_PROG_TYPE_LIRC_MODE2
Программы инфракрасных устройств

