
https://pkg.go.dev/github.com/datadog/datadog-agent/pkg/ebpf

	TCPv4DestroySock   KProbeName = "kprobe/tcp_v4_destroy_sock"  // TCPv4DestroySock   traces the tcp_v4_destroy_sock system call (called for both ipv4 and ipv6)
	TCPv6Connect       KProbeName = "kprobe/tcp_v6_connect"       // TCPv6Connect       traces the v6 connect() system call
	TCPv6ConnectReturn KProbeName = "kretprobe/tcp_v6_connect"    // TCPv6ConnectReturn traces the return value for the v6 connect() system call

	// TCPSendMsg traces the tcp_sendmsg() system call
	TCPSendMsg         KProbeName = "kprobe/tcp_sendmsg"          
	// TCPSendMsgPre410 traces the tcp_sendmsg() system call on kernels prior to 4.1.0. This is created because
	// we need to load a different kprobe implementation
	TCPSendMsgPre410 KProbeName = "kprobe/tcp_sendmsg/pre_4_1_0"
	// TCPSendMsgReturn traces the return value for the tcp_sendmsg() system call
	// XXX: This is only used for telemetry for now to count the number of errors returned
	// by the tcp_sendmsg func (so we can have a # of tcp sent bytes we miscounted)
	TCPSendMsgReturn KProbeName = "kretprobe/tcp_sendmsg"

	TCPGetInfo     KProbeName = "kprobe/tcp_get_info"      // TCPGetInfo     traces the tcp_get_info() system call This probe is used for offset guessing only
	TCPCleanupRBuf KProbeName = "kprobe/tcp_cleanup_rbuf"  // TCPCleanupRBuf traces the tcp_cleanup_rbuf() system call
	TCPClose       KProbeName = "kprobe/tcp_close"         // TCPClose       traces the tcp_close() system call

	UDPSendMsg       KProbeName = "kprobe/udp_sendmsg"            // UDPSendMsg       traces the udp_sendmsg() system call
	UDPSendMsgPre410 KProbeName = "kprobe/udp_sendmsg/pre_4_1_0"  // UDPSendMsgPre410 traces the udp_sendmsg() system call on kernels prior to 4.1.0
	UDPRecvMsg       KProbeName = "kprobe/udp_recvmsg"            // UDPRecvMsg       traces the udp_recvmsg() system call
	UDPRecvMsgPre410 KProbeName = "kprobe/udp_recvmsg/pre_4_1_0"  // UDPRecvMsgPre410 traces the udp_recvmsg() system call on kernels prior to 4.1.0
	UDPRecvMsgReturn KProbeName = "kretprobe/udp_recvmsg"         // UDPRecvMsgReturn traces the return value for the udp_recvmsg() system call
	UDPDestroySock   KProbeName = "kprobe/udp_destroy_sock"       // UDPDestroySock   traces the udp_destroy_sock() function

	TCPRetransmit       KProbeName = "kprobe/tcp_retransmit_skb"  // TCPRetransmit       traces the return value for the tcp_retransmit_skb() system call
	InetCskAcceptReturn KProbeName = "kretprobe/inet_csk_accept"  // InetCskAcceptReturn traces the return value for the inet_csk_accept syscall

	SysSocket           KProbeName = "kprobe/sys_socket"          // SysSocket    traces calls to the socket kprobe
	SysSocketRet        KProbeName = "kretprobe/sys_socket"       // SysSocketRet is the kretprobe for SysSocket
	SysBind             KProbeName = "kprobe/sys_bind"            // SysBind      is the kprobe the bind() syscall.
	SysBindRet          KProbeName = "kretprobe/sys_bind"         // SysBindRet   is the kretprobe for bind().
