
 oreil.ly/lbpf-repo

// ----------------------------
//    DEPRECATED
// ----------------------------
// https://libbpf.readthedocs.io/en/latest/api.html
bpf_object__load (struct bpf_object *obj)  <- bpf_object__load_xattr(struct bpf_object_load_attr *attr)
bpf_object__load (struct bpf_object *obj)  <- bpf_program__load(struct bpf_program *prog)
---
struct bpf_object * bpf_object__open (const char *path)
void bpf_object__close (struct bpf_object *object)       <- bpf_object__unload()
int  bpf_object__btf_fd (const struct bpf_object *obj)

struct bpf_program * bpf_object__next_program (const struct bpf_object *obj, struct bpf_program *prog))
struct bpf_program * bpf_object__prev_program (const struct bpf_object *obj, struct bpf_program *prog)

const  char *        bpf_object__name (const struct bpf_object *obj)
struct bpf_program * bpf_object__find_program_by_name (const struct bpf_object *obj, const char *name)

struct bpf_link * bpf_program__attach (const struct bpf_program *prog)
struct bpf_link * bpf_program__attach_perf_event (const struct bpf_program *prog, int pfd)
struct bpf_link * bpf_program__attach_kprobe (const struct bpf_program *prog, bool retprobe, const char *func_name)
struct bpf_link * bpf_program__attach_tracepoint (const struct bpf_program *prog, const char *tp_category, const char *tp_name)
struct bpf_link * bpf_program__attach_xdp (const struct bpf_program *prog, int ifindex)
const char *      bpf_program__name (const struct bpf_program *prog)
int               bpf_program__fd (const struct bpf_program *prog)
void              bpf_program__unload (struct bpf_program *prog)


// ----------------------------
//    Документация
// ----------------------------
https://www.kernel.org/doc/html/latest/bpf/btf.html                             // BPF Type Format ( BTF_KIND_... )
https://elixir.bootlin.com/linux/v5.17.5/source/include/uapi/linux/bpf.h#L1256  // union bpf_attr {...}
https://man7.org/linux/man-pages/man2/bpf.2.html                                // bpf+sockets example
https://man7.org/linux/man-pages/man7/bpf-helpers.7.html
https://pkg.go.dev/github.com/florianl/go-nfqueue


// ----------------------------
//    Info
// ----------------------------
максимальное количество выполняемых инструкций - 4096

/sys/kernel/debug/tracing/events            // все точки трассировки в системе
/sys/kernel/debug/tracing/events/syscalls/  // syscalls tracepoint

setcap 'cap_net_admin=+ep' /your/executable


// ----------------------------
//    Map (кратко)
// ----------------------------
'bpf/bpf_helpers.h'   - для программ работающих в ядре - код напрямую обращаться к карте в памяти и атомарно обновляет элементы на месте
'tools/lib/bpf/bpf.h' - для программ действующих в пространстве пользователя - код должен отправить сообщение ядру, которое копирует предоставленное значение перед обновлением карты

BPF_MAP_CREATE       - создание карты
BPF_MAP_LOOKUP_ELEM  - ищет элемента по ключу и возвращает его значение
BPF_MAP_UPDATE_ELEM
BPF_MAP_DELETE_ELEM
BPF_MAP_GET_NEXT_KEY - ищет элемента по ключу и возвращает ключ следующего элемента
BPF_PROG_LOAD        - Verify and load an eBPF program, returning a new file descriptor

// CRUD
1. int bpf_create_map(enum bpf_map_type map_type,  unsigned int key_size,  unsigned int value_size,  unsigned int max_entries)
2. int bpf_update_elem(int fd, const void *key, const void *value, uint64_t flags)
3. int bpf_lookup_elem(int fd, const void *key, void *value)
4. int bpf_delete_elem(int fd, const void *key)
5. int bpf_get_next_key(int fd, const void *key, void *next_key)


// ----------------------------
//    Error
// ----------------------------
E2BIG  - The eBPF program is too large or a map reached the 'max_entries' limit
EACCES - rejected because it was deemed unsafe - function constraints don't match the actual types
EBADF  - fd is not an open file descriptor
EINVAL - один из атрибутов недействителен
EFAULT - One of the pointers (key, value, log_buf, insns) is outside the accessible address space
EPERM  - пользователь не имеет достаточных привилегий
ENOMEM - для хранения карты недостаточно памяти
ENOENT - not found / чтение, удаление из карты


// ----------------------------
//    SEC
// ----------------------------
SEC("tracepoint/syscalls/sys_enter_execve") int bpf_prog(void *ctx)  // когда будет обнаружена точка трассировки в системном вызове 'execve' / программа выполняет другую программу
SEC("kprobe/sys_exec") int bpf_capture_exec(struct pt_regs *ctx)     // захват и отправка данных в пространство пользователя
SEC("classifier")  // (152)


// ----------------------------
//    Func (кратко)
// ----------------------------
https://github.com/iovisor/bcc/blob/master/docs/reference_guide.md
https://man7.org/linux/man-pages/man7/bpf-helpers.7.html

// Map (CRUD)
      bpf_create_map()
void *bpf_map_lookup_elem(struct bpf_map *map, const void *key)   // Return Map value associated to key, or NULL
long  bpf_map_update_elem(struct bpf_map *map, const void *key, const void *value, u64 flags)  // Return 0 | -1
long  bpf_map_delete_elem(struct bpf_map *map, const void *key)   // Return 0 | -1

long  bpf_get_next_key(int fd, const void *key, void *next_key)        // Перебор элементов в карте BPF
long  bpf_map_lookup_and_delete_element(map_data[0].fd, &key, &value)  // Поиск и удаление элементов

fd = bpf_obj_get("/sys/fs/bpf/my_map")  // fd карты для её чтения 'result = bpf_map_lookup_elem(fd, &key, &value);'

// Load prog
int bpf_prog_load(enum bpf_prog_type type,  const struct bpf_insn *insns,  int insn_cnt,  const char *license)

// Load elf
    load_bpf_file("hello_world_kern.o")  // загрузка двоичного файла в ядро

// Data
u64 bpf_get_current_pid_tgid(void)   // Returns the process ID in the lower 32 bits and group ID in the upper 32 bits
u64 bpf_get_current_uid_gid(void)    // Returns the user ID and group ID
int bpf_get_current_comm(char *buf, u32 size_of_buf) // name prog (of the executable)
      bpf_get_current_pid_tgid() >> 32
u32 bpf_get_smp_processor_id(void)   // Get the SMP (symmetric multiprocessing) processor id

// Add
int bpf_perf_event_output(struct pt_reg *ctx, struct bpf_map *map, u64 flags, void *data, u64 size)  // добавляет данные в карту

// Output
int bpf_trace_printk(const char *fmt, u32 fmt_size, ...) // печатm сообщений в журнале трассировки ядра /sys/kernel/debug/tracing/trace_pipe
    	bpf_trace_printk("%d\n", key.id);
    	bpf_trace_printk(msg, sizeof(msg));   // char msg[] = "Hello, BPF World!"

// Firewall
long bpf_redirect(u32 ifindex, u64 flags)  // Redirect the packet to another net device of index 'ifindex'
long bpf_sk_redirect_map(struct  sk_buff *skb, struct bpf_map *map, u32 key, u64 flags)        // Redirect the packet to the socket referenced by 'map' at index 'key'
long bpf_sk_redirect_hash(struct sk_buff *skb, struct bpf_map *map, void *key, u64 flags)      // ...
long bpf_msg_redirect_map(struct  sk_msg_buff *msg, struct bpf_map *map, u32 key, u64 flags)   // Redirect it to the socket referenced by 'map' at index 'key'
long bpf_msg_redirect_hash(struct sk_msg_buff *msg, struct bpf_map *map, void *key, u64 flags) // ...

int bpf_tail_call(void *ctx,  struct bpf_map *prog_array_map,  u32 index)  // jump into another eBPF program
    bpf_redirect_map()
    bpf_cgroup_storage_key()

// Блокировки | Mutex
bpf_spin_lock()    // блокирует элемент
bpf_spin_unlock()  // разблокирует элемент


// ----------------------------
//    Fs
// ----------------------------
/sys/fs/bpf  // каталог виртуальной файловой системы
mount -t bpf /sys/fs/bpf /sys/fs/bpf  // если отсутствует

pin = bpf_obj_pin(fd, file_path)  // BPF_PIN_FD  - команда для сохранения объектов BPF в файловой системе
fd  = bpf_obj_get(file_path)      // BPF_OBJ_GET - команда для извлечения объектов BPF, которые были закреплены в файловой системе


// ----------------------------
//    Трассировка
// ----------------------------
// типы
1. Зонды ядра        - Предоставляют динамический доступ к внутренним компонентам ядра 
2. Точки трассировки - Обеспечивают статический доступ к внутренним компонентам ядра 
3. Зонды в пользовательском пространстве  - Дают динамический доступ к программам, работающим в пользовательском пространстве 
4. Статически точки трассировки           - Обеспечивают статический доступ к программам, запущенным в пространстве пользователя 

kprobes    // позволяет вставлять программы BPF перед выполнением любой инструкции ядра
kretprobes // запустит вашу программу BPF после выполнения ядром определенной инструкции и вернет значение
uprobes    // это ловушки, которые ядро вставляет в набор команд программы перед выполнением конкретной инструкции
uretprobes // = kretprobes для программ пользовательского пространства

/sys/kernel/debug/tracing/events - точки трассировки в системе

// Определение точек трассировки (90)
gcc hello_usdt.c -o hello_usdt
1. readelf -n ./hello_usdt   // очень подробный
2. tplist -l ./hello_usdt    // bcc

// Macros BCC
BPF_HASH(cache, u64, u64);  // кэш (86)
BPF_PERF_OUTPUT(events);    // объявление карты событий Perf (105)


// ----------------------------
//    Socket Buffer
// ----------------------------
SKB(sk_buff)    // структура ядра,которая создается и используется для каждого отправленного или полученного пакета
pcap (libpcap)  // packet («пакет») и capture («захват»)


// ----------------------------
//    Util
// ----------------------------
1. BFTool // https://github.com/torvalds/linux/tools/bpf/bpftool <- git checkout v5.10 <- make && make install
echo 1 > /proc/sys/net/core/bpf_jit_enable  // JIT компилятор
sysctl -w kernel.bpf_stats_enabled=1        // включает отображение статистики времени выполнения программ

bpftool --version   // (110)
bpftool feature     // список поддерживваемых в системе BPF функцмй

bpftool prog show   // инфо о всех загруженных программах
bpftool prog show --json id <num> | jq 
bpftool prog show --json id <num> | jq -c '[.id, .type, .loaded_at]'
bpftool prog dump xlated id <num>  // dump всей программы
bpftool prog dump xlated id <num> visual &> output.out  // вывод для отофражения графика
  dot -Tpng output.out -o visual-graph.png

bpftool btf dump id <num>  // отображает типы структур

bpftool map show   // (115)
bpftool map create /sys/fs/bpf/counter type array key 4 value 4 entries 5 name counter  // создание карты и её привязка к файловой системе
bpftool map update id <num> key 1 0 0 0 value 1 0 0 0  // обновление карты
bpftool map dump id <num>

bpftool prog load bpf_prog.o /sys/fs/bpf/bpf_prog  // загрузка программы и её привязка к файловой системе
bpftool prog load bpf_prog.o /sys/fs/bpf/bpf_prog_2 map name counter /sys/fs/bpf/counter  // привызка карты к программе

bpftool perf show           // программы, связанные с точками трассировки в системе: kprobes, uprobes, tracepoints
bpftool net show            // программы, подключенные к xdp, traffic
bpftool cgroup show <name>  // программы, подключенные к контролыным группам
bpftool cgroup tree

bpftool batch file /tmp/example.txt  // применение списка комманд (119)

tcpdump -n 'ip and tcp port 8080'
tcpdump -n 'tcp dst port 8080'
tcpdump -D  // список интерфейсов
tcpdump -n host <ip>
tcpdump -n src host <ip>
tcpdump -n portrange 110-150
tcpdump -n 'host <ip> and (tcp port 80 or tcp port 443)'

// ---

2. BPFTrace // https://github.com/iovisor/bpftrace


// ----------------------------
//    LSM
// ----------------------------
CAP_NET_BIND_SERVICE

// capsh - средство управления обалочкой
capsh --caps='cap_net_bind_service+eip cap_setpcap,cap_setuid,cap_setgid+ep' \
      --keep=1 --user="nobody" \
      --addamb=cap_net_bind_service -- -c "./nami"

// Seccomp
linux/seccomp.h
struct seccomp_data {
	int nr;
	__u32 arch;
	__u64 instruction_pointer;
	__u64 args[6];
};

SECCOMP_RET_ALLOW         // системный вызов просто разрешен
SECCOMP_RET_KILL_PROCESS  // завершение всего процесса сразу же после фильтрации системного вызова
SECCOMP_RET_KILL_THREAD   // завершение текущего потока сразу же после фильтрации системного вызова
SECCOMP_RET_KILL          // алиас для SECCOMP_RET_KILL_THREAD, оставлен для обратной совместимости
SECCOMP_RET_TRAP          // системный вызов запрещен, и сигнал SIGSYS (Bad System Call) отправляется вызывающей его задаче
SECCOMP_RET_ERRNO         // системный вызов не выполняется, SECCOMP_RET_DATA -> errno
SECCOMP_RET_TRACE         // используется для уведомления трассировщика ptrace с помощью PTRACE_O_TRACESECCOMP для перехвата
SECCOMP_RET_LOG           // системный вызов разрешен и зарегистрирован в журнале

EACCESS     // вызывающей стороне не разрешено делать системный вызов
EFAULT      // переданные аргументы (args в структуре seccomp_data) не имеют действительного адреса
EINVAL      // (192)
ENOMEM      // недостаточно памяти для выполнения программы
EOPNOTSUPP  // ядро не поддерживает возврат в аргументах
ESRCH       // возникла проблема при синхронизации другого потока
ENOSYS      // нет трассировщика, прикрепленного к действию SECCOMP_RET_TRACE

