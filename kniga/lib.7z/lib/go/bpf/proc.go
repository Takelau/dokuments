
proc/stat         // github.com/c9s/goprocinfo/blob/master/linux/stat.go
proc/cpuinfo      // github.com/c9s/goprocinfo/blob/master/linux/cpuinfo.go
proc/sockstat      -
proc/net_netstat_1 -

/proc/sys/net/netfilter/nf_conntrack_count  // iptables conntrack statistics
/proc/sys/net/netfilter/nf_conntrack_max    // ...

/proc/%d
/proc/%d/stat	    // github.com/mitchellh/go-ps/blob/master/process_linux.go
/proc/%d/stus
/proc/%d/fd
/proc/%d/net/tcp  // pid > 0

/proc/net/dev     // github.com/shirou/gopsutil/tree/master/net
/proc/net/snmp    // {"ip", "icmp", "icmpmsg", "tcp", "udp", "udplite"}
/proc/net/stat/nf_conntrack   // detailed info about the conntrack table
/proc/net/tcp     // pid == 0

// ----------------
github.com/shirou/gopsutil/blob/master/net/net_unix.go#L93
var constMap = map[string]int{
	"unix": syscall.AF_UNIX,
	"TCP":  syscall.SOCK_STREAM,
	"UDP":  syscall.SOCK_DGRAM,
	"IPv4": syscall.AF_INET,
	"IPv6": syscall.AF_INET6,
}

// ----------------
github.com/shirou/gopsutil/blob/master/net/net_linux.go#L84
type netConnectionKindType struct {
	family   uint32
	sockType uint32
	filename string
}
var kindTCP4 = netConnectionKindType{ family: syscall.AF_INET,   sockType: syscall.SOCK_STREAM,  filename: "tcp", }
var kindTCP6 = netConnectionKindType{ family: syscall.AF_INET6,  sockType: syscall.SOCK_STREAM,  filename: "tcp6", }
var kindUDP4 = netConnectionKindType{ family: syscall.AF_INET,   sockType: syscall.SOCK_DGRAM,   filename: "udp", }
var kindUDP6 = netConnectionKindType{ family: syscall.AF_INET6,  sockType: syscall.SOCK_DGRAM,   filename: "udp6", }
var kindUNIX = netConnectionKindType{ family: syscall.AF_UNIX,                                   filename: "unix", }


// --------------------------------
//    netlink
// --------------------------------
CAP_NET_ADMIN  or  root
4 byte boundary

// The Netlink message
   0                   1                   2                   3
   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
0  |                          Length                             |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
32 |            Type              |           Flags              |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
64 |                      Sequence Number                        |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
96 |                      Process ID (PID)                       |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
128+                            Data

- Length (32 bits)  // the length of the entire message, including both headers and payload
- Type   (16 bits)  // what kind of information the message contains, such as an error, end of multi-part message, etc
- Flags  (16 bits)  // bit flags which indicate that a message is a request, a multi-part message, an acknowledgement of a request, etc
- Sequence Number  (32 bits) // a number used to correlate requests and responses; incremented on each request
- Process ID (PID) (32 bits) // sometimes referred to as port ID; a number used to uniquely identify a particular netlink socket; may or may not be the process’s ID

msg := netlink.Message{
    Header: netlink.Header{
        Length: 16 + 4,           // Length of header, plus payload
        Type: 0,                  // Set to zero on requests
        Flags: netlink.Request | netlink.Acknowledge,  // Indicate that message is a request to the kernel, and we expect an acknowledgement in return
        Sequence: 1,              // Sequence number selected at random
        PID: uint32(os.Getpid()), // PID set to process's ID
    },
    Data: []byte{0x01, 0x02, 0x03, 0x04}, // An arbitrary byte payload. May be in a variety of formats
}

// open
fd, err := unix.Socket(
	unix.AF_NETLINK, // Always used when opening netlink sockets
	unix.SOCK_RAW,   // кажется взаимозаменяемо с SOCK_DGRAM
	protocol,
)

NETLINK_ROUTE     // provides routing and link information
NETLINK_FIREWALL  // provides an interface for a user-space app to receive packets from the firewall
NETLINK_NFLOG     // provides an interface used to communicate between Netfilter and iptables
NETLINK_ARPD      // provides an interface to manage the ARP table from user-space
NETLINK_AUDIT     // provides an interface to the audit subsystem found in Linux kernel versions 2.6.6 and later
NETLINK_IP6_FW    // provides an interface to transport packets from netfilter to user-space
NETLINK_ROUTE6
NETLINK_TAPBASE
NETLINK_NETFILTER // <-- mdlayher/netlink
NETLINK_TCPDIAG
NETLINK_XFRM      // provides an interface to manage the IPsec security association and security policy databases - mostly used by key-manager daemons using the Internet Key Exchange protocol
NETLINK_KOBJECT_UEVENT  // provides the interface in which the kernel broadcasts uevents, typically consumed by udev
NETLINK_GENERIC   // new netlink families, like nl80211, Open vSwitch, etc

// bind
err := unix.Bind(fd, &unix.SockaddrNetlink{
	Family: unix.AF_NETLINK,  // Always used when binding netlink sockets
	Groups: 0,  // A bitmask of multicast groups to join on bind
	Pid: 0,     // 
)

// Send and receiv
b := messageBytes([]byte{0x01, 0x02, 0x03, 0x04})
err := unix.Sendto(b, 0, &unix.SockaddrNetlink{ Family: unix.AF_NETLINK, })

// error
encoded as a signed 32 bit integer (uses system endianness) in the first 4 bytes of the message’s payload

const name = "foo0"
_, err := rtnetlink.InterfaceByName(name)
if err != nil && os.IsNotExist(err) {
    log.Printf("no such device: %q", name)
    return
}

ENOENT    // no such file or directory
EPERM     // permission denied

// events / Multicast groups
const joinLeave = unix.NETLINK_ADD_MEMBERSHIP
const group = 1  // Multicast group ID
err := unix.SetSockoptInt( fd, unix.SOL_NETLINK, joinLeave, group, )   // Joining and leaving groups
recvfrom()       // listen for messages

// attributes
4 byte boundary
LTV (length, type, value) format
- Length (16 bits)   // length of the entire attribute, including length, type and value fields
- Type (16 bits)     // the type of an attribute
- Value (variable bytes)  // raw payload


// --------------------------------
//    mdlayher / netlink
// --------------------------------
unix.Socket(unix.AF_NETLIN, unix.SOCK_RAW|socketFlag, unix.NETLINK_NETFILTE)

// nfqueue
func (nfqueue *Nfqueue) SetVerdict(id uint32, verdict int) error {}
func (nfqueue *Nfqueue) SetVerdictBatch(id uint32, verdict int) error {}
func (nfqueue *Nfqueue) SetVerdictWithMark(id uint32, verdict, mark int) error {}
func (nfqueue *Nfqueue) SetVerdictModPacket(id uint32, verdict int, packet []byte) error {}
func (nfqueue *Nfqueue) SetVerdictModPacketWithMark(id uint32, verdict, mark int, packet []byte) error {}

// nfqueue.Open()
func Open(config *Config) (*Nfqueue, error) {  // nfqueue.Nfqueue 
	con, err := netlink.Dial(unix.NETLINK_NETFILTER, &netlink.Config{NetNS: config.NetNS})
}
// netlink.Dial()
func Dial(family int, config *Config) (*Conn, error) {  // netlink.Conn
	c, pid, err := dial(family, config)
	return NewConn(c, pid), nil
}
// netlink.dial()
func dial(family int, config *Config) (*conn, uint32, error) {  // netlink.conn
	s, err := socket.Socket(unix.AF_NETLINK, unix.SOCK_RAW, family, "netlink", &socket.Config{NetNS: config.NetNS})  // const socketFlags = unix.SOCK_CLOEXEC | unix.SOCK_NONBLOCK
	return newConn(fd, name)  // netlink.Conn
}
// socket.Socket()
func Socket(domain, typ, proto int, name string, cfg *Config) (*Conn, error) {  // socket.Conn
	return withNetNS(cfg.NetNS, func() (*Conn, error) {  // Linux only: create Conn in the specified network namespace.
		return socket(domain, typ, proto, name)
	})
}
// socket.socket()
func socket(domain, typ, proto int, name string) (*Conn, error) {  // socket.Conn
	for {
		fd, err = unix.Socket(domain, typ|socketFlags, proto) // unix.AF_NETLIN, unix.SOCK_RAW|socketFlag, unix.NETLINK_NETFILTE
		return newConn(fd, name)  // netlink.conn
	}
}
// socket.newConn()
func newConn(fd int, name string) (*Conn, error) {  // socket.Conn
	f := os.NewFile(uintptr(fd), name)
	rc, err := f.SyscallConn()
	return &Conn{  // socket.Conn
		name: name,
		fd:   f,
		rc:   rc,
	}, nil
}
// nfqueue.Nfqueue
type Nfqueue struct {
	Con    *netlink.Conn  // Con is the pure representation of a netlink socket
	logger *log.Logger
	wg      sync.WaitGroup
	flags        []byte   // uint32
	maxPacketLen []byte   // uint32
	family       uint8
	queue        uint16
	maxQueueLen  []byte   // uint32
	copymode     uint8
	setWriteTimeout func() error
}
// netlink.Conn
type Conn struct {
	seq  uint32        // seq is an atomically incremented integer used to provide sequence numbers when Conn.Send is called.
	mu   sync.RWMutex  // mu serializes access to the netlink socket for the request/response transaction within Execute.
	sock Socket        // sock is the operating system-specific implementation of a netlink sockets connection.
	pid  uint32        // pid is the PID assigned by netlink.
	d   *debugger      // d provides debugging capabilities for a Conn if not nil.
}
// netlink.conn
type conn struct {
	s *socket.Conn
}
// socket.Conn
type Conn struct {
	closed uint32     // Indicates whether or not Conn.Close has been called. Must be accessed atomically.
	name   string     // A unique name for the Conn which is also associated with derived file descriptors such as those created by accept(2).
	fd    *os.File    // Provides access to the underlying file registered with the runtime network poller, and arbitrary raw I/O calls.
	rc     syscall.RawConn
}
// nfqueue.Attribute
type Attribute struct {
	PacketID   *uint32
	Hook       *uint8
	Timestamp  *time.Time
	Mark       *uint32
	InDev      *uint32
	PhysInDev  *uint32
	OutDev     *uint32
	PhysOutDev *uint32
	Payload    *[]byte
	CapLen     *uint32
	UID        *uint32
	GID        *uint32
	SecCtx     *string
	L2Hdr      *[]byte
	HwAddr     *[]byte
	HwProtocol *uint16
	Ct         *[]byte
	CtInfo     *uint32
	SkbInfo    *[]byte
	Exp        *[]byte
}
//
func (nfqueue *Nfqueue) RegisterWithErrorFunc(ctx context.Context, fn HookFunc, errfn ErrorFunc) error {}
func (nfqueue *Nfqueue) setConfig(afFamily uint8, oseq uint32, resid uint16, attrs []netlink.Attribute) (uint32, error) {}
