
// libnetfilter_queue-1.0.5/src/libnetfilter_queue.c

// set the amount of packet data that nfqueue copies to userspace
// NFQNL_COPY_NONE   - 0 noop, do not use it
// NFQNL_COPY_META   - 1 copy only packet metadata
// NFQNL_COPY_PACKET - 2 copy entire packet
int nfq_set_mode(struct nfq_q_handle *qh,  uint8_t mode,  uint32_t range){}  // C.nfq_set_mode(nfq.qh, C.u_int8_t(2), C.uint(packetSize))

// ----------------------------
)
0 Gui774ume     / etrace                (syscall tracing)
0 Gui774ume     / utrace                (trace user space and kernel space functions)
0 Gui774ume     / nfprobe            Go  cilium/ebpf + DataDog/ebpf-manager      NetFilter event tracing
0 Gui774ume     / fsprobe               (fs events notifier)
0 Gui774ume     / krie                  (vulnerable kernel)       
0 Gui774ume     / tcprobe               (traffic control)    vishvananda/netlink
0_aporeto-inc   / netlink-go         Go  NFQUEUE                                 nflog, conntrack, packet lib
0_aquasecurity  / btfhub             Go  aquasecurity/libbpfgo
0_aquasecurity  / libbpfgo           Go
0_aquasecurity  / tracee             Go                      [bpf]
0_bol-van       / zapret             C   NFQUEUE
0_bol-van       / nfqueue_c2         C   NFQUEUE             simple
0_bol-van       / fingerprint        C   NFQUEUE             simple
0 florianl      / go-conntrack       Go  mdlayher/netlink    go-nfqueue.Attributes, TCP, DCCP, SCTP, Nat, CPU
0 florianl      / go-nfqueue         Go  mdlayher/netlink    go-nfqueue.Attribute
0 florianl      / go-tc
0_safing        / portmaster         Go  https://docs.safing.io/portmaster/architecture/os-integration#linux
0 yuuki         / go-conntracer-bpf  (TCP/UDP) events (connect, accept, sendto, recvfrom)  <- не разобрался
0 yuuki         / shawk              Go                                           process tracer
                / L4Wall             Go  cilium/ebpf                        [xdp]
  SYNwall       / SYNwall            C   linux/netfilter IN&OUT + PF_INET         IoT devices
  isgasho       / SailFirewall       Go  dropbox/goebpf                     [xdp] ip4,tcp
  mmat11        / beewall            Go  cilium/ebpf                        [xdp] ip46,tcp46,udp46    c->[]byte
  lebauce       / ebpfscene          Go  cilium/ebpf + DataDog/ebpf-manager [bpf] kprobe/do_vfs_ioctl
  harporoeder   / ebpfsnitch        *C++ NFQUEUE(in,out) + ebpf + proc      [bpf] dns
  shirou        / gopsutil          *Go                                           cpu, disk, docker, host, mem, net, process
 +AkihiroSuda   / go-netfilter-queue Go  linux/netfilter                    [nfq] ip46
 +r3boot        / go-snitch         *Go  NFQUEUE(out) + ftrace + proc + DBUS
  hackerschoice / gsocket            Go
  themighty1    / lpfw               C++
  massoudasadi  / packiffer          Go  dropbox/goebpf                [pcap xdp] sniff/analyze/inject/filter packets
  weaveworks    / tcptracer-bpf     *Go  iovisor/gobpf + proc               [bpf] TCP events
  acassen       / xdp-fw             C                                   [xdp-ПП] icmp6,VLAN(Q-in-Q)
  gamemann      / XDP-Firewall       C                                      [xdp] ip46, tcp, udp, icmp | src, dst, ttl, packet_length, pps, bps, tos | tcp_urg, _ack, _rst, _psh, _syn, _fin, icmp_code, _type
  gamemann      / xdp-tcp-header     C                                      [xdp] TCP Header Opts
  xdp-project   / xdp-tools          C                                      [xdp] ip46,tcp,udp

 +florianl      / go-nflog           Go  iptables -I OUTPUT -p icmp -j NFLOG --nflog-group 100
 +x-way         / iptables-tracer    Go  пример использования   [go-nflog.Attribute]
 +akerouanton   / iptables-tracer    Go  + vishvananda/netn

 +armon         / go-socks5          Go lib
 +serjs         / socks5-server      Go
  txthinking    / socks5             Go lib
  socks5        / sniproxy           Go socks5 + http server
  elazarl       / goproxy            Go HTTP Proxy

// Example
dropbox/goebpf -> https://github.com/dropbox/goebpf/tree/master/examples/xdp/basic_firewall

gobpf   - iovisor/gobpf
netlink - vishvananda/netlink

// -------------------
// SYNwall
linux/netfilter.h  net/netfilter/nf_conntrack.h>  net/ip.h  net/tcp.h  net/udp.h  linux/types.h
static unsigned int incoming_pkt(void *priv, struct sk_buff *skb, const struct nf_hook_state *state)
  if (!skb) { goto exit_accept; }
  IPPROTO_ICMP + ICMP_ECHO -> goto exit_drop
  LOCALHOST                -> goto exit_accept
  IPPROTO_TCP 
    !tcp_hdr(skb)          -> goto exit_drop
    syn && !ack            -> goto exit_drop   // SYN+ACK accept
    !process_tcp_in()      -> goto exit_drop
  IPPROTO_UDP
    !nf_ct_get()           -> goto exit_drop
    !process_udp_in()      -> goto exit_drop
nfho_in = (struct nf_hook_ops *)kcalloc(1, sizeof(struct nf_hook_ops), GFP_KERNEL);
nfho_in->hook = (nf_hookfn *)incoming_pkt;   // hook function
nfho_in->hooknum  = NF_INET_PRE_ROUTING;
nfho_in->pf       = PF_INET;                 // IPv4
nfho_in->priority = NF_IP_PRI_CONNTRACK + 1; // Place the hook just
nf_register_net_hook(&init_net, nfho_in);

// -------------------
// Linux networking
https://linux-kernel-labs.github.io/refs/heads/master/labs/networking.html
https://thermalcircle.de/doku.php?id=blog:linux:nftables_packet_flow_netfilter_hooks_detail
http://vger.kernel.org/~davem/skb_data.html            // skb work
https://habr.com/ru/companies/ruvds/articles/516266/   // skb work

// -------------------
// process list
https://github.com/shirou/gopsutil/tree/master/process

// -------------------
// DPI
https://github.com/basil00/reqrypt
https://github.com/ValdikSS/GoodbyeDPI

// -------------------
// harporoeder/ebpfsnitch -> probes.c
SEC("kprobe/tcp_v4_connect")    int kprobe_tcp_v4_connect(const struct pt_regs *const p_context)      pid
SEC("kretprobe/tcp_v4_connect") int kretprobe_tcp_v4_connect(const struct pt_regs *const p_context)   pid, uid

SEC("kprobe/tcp_v6_connect")    int kprobe_tcp_v6_connect(const struct pt_regs *const p_context)      pid
SEC("kretprobe/tcp_v6_connect") int kretprobe_tcp_v6_connect(const struct pt_regs *const p_context)   pid, uid

SEC("kprobe/security_socket_sendmsg")    int kprobe_security_socket_send_msg(const struct pt_regs *const p_context)            pid
SEC("kretprobe/security_socket_sendmsg") int kretprobe_security_socket_send_msg(const struct pt_regs *const p_context_ignore)  pid, uid

const uint64_t l_id  = bpf_get_current_pid_tgid();
const uint32_t l_pid = l_id >> 32;
struct ebpf_event_t *const l_event = bpf_ringbuf_reserve(&g_probe_ipv4_events, sizeof(struct ebpf_event_t), 0);
l_event->m_process_id = l_pid;
bpf_ringbuf_submit(l_event, BPF_RB_FORCE_WAKEUP);

// -------------------
// weaveworks/tcptracer-bpf -> tcptracer-bpf.c
struct bpf_map_def SEC("maps/tcp_event_ipv4") tcp_event_ipv4 = {}       k=cpu, v=fd
struct bpf_map_def SEC("maps/tcp_event_ipv6") tcp_event_ipv6 = {}       k=cpu, v=fd
struct bpf_map_def SEC("maps/connectsock_ipv4") connectsock_ipv4 = {}   k=pid, v=sock
struct bpf_map_def SEC("maps/connectsock_ipv6") connectsock_ipv6 = {}   k=pid, v=sock
struct bpf_map_def SEC("maps/tuplepid_ipv4")  tuplepid_ipv4 = {}        k=ipv4_tuple_t, v=pid_comm_t
struct bpf_map_def SEC("maps/tuplepid_ipv6")  tuplepid_ipv6 = {}        k=ipv6_tuple_t, v=pid_comm_t
struct bpf_map_def SEC("maps/fdinstall_ret")  fdinstall_ret = {}        k=pid, v=fd
struct bpf_map_def SEC("maps/fdinstall_pids") fdinstall_pids = {}       k=pid, v=bool

SEC("kprobe/tcp_v4_connect")    int kprobe__tcp_v4_connect(struct pt_regs *ctx)        pid
SEC("kretprobe/tcp_v4_connect") int kretprobe__tcp_v4_connect(struct pt_regs *ctx)     pid

SEC("kprobe/tcp_v6_connect")    int kprobe__tcp_v6_connect(struct pt_regs *ctx)        pid
SEC("kretprobe/tcp_v6_connect") int kretprobe__tcp_v6_connect(struct pt_regs *ctx)     pid

SEC("kprobe/tcp_set_state")      int kprobe__tcp_set_state(struct pt_regs *ctx)        cpu
SEC("kprobe/tcp_close")          int kprobe__tcp_close(struct pt_regs *ctx)            pid, cpu
SEC("kretprobe/inet_csk_accept") int kretprobe__inet_csk_accept(struct pt_regs *ctx)   pid, cpu

SEC("kprobe/fd_install")    int kprobe__fd_install(struct pt_regs *ctx)                pid
SEC("kretprobe/fd_install") int kretprobe__fd_install(struct pt_regs *ctx)             pid, cpu

// -------------------
// Gui774ume/nfprobe
struct bpf_map_def SEC("maps/hook_filters") hook_filters
struct bpf_map_def SEC("maps/proto_filters") proto_filters
struct bpf_map_def SEC("maps/packet_type_filters") packet_type_filters
struct bpf_map_def SEC("maps/verdict_filters") verdict_filters
struct bpf_map_def SEC("maps/netns_filters") netns_filters
struct bpf_map_def SEC("maps/table_filters") table_filters
struct bpf_map_def SEC("maps/in_ifindex_filters") in_ifindex_filters
struct bpf_map_def SEC("maps/in_name_filters") in_name_filters
struct bpf_map_def SEC("maps/out_ifindex_filters") out_ifindex_filters
struct bpf_map_def SEC("maps/out_name_filters") out_name_filters

SEC("kprobe/ipt_do_table")  int kprobe_ipt_do_table(struct pt_regs *ctx)
SEC("kprobe/ip6t_do_table") int kprobe_ip6t_do_table(struct pt_regs *ctx)

SEC("kretprobe/ipt_do_table")  int kretprobe_ipt_do_table(struct pt_regs *ctx) 
SEC("kretprobe/ip6t_do_table") int kretprobe_ip6t_do_table(struct pt_regs *ctx)

// -------------------
// aquasecurity/tracee -> tracee.bpf.c
SEC("tc") int tc_egress(struct __sk_buff *skb)    // ...
SEC("tc") int tc_ingress(struct __sk_buff *skb)   // ETH_P_IP, ETH_P_IPV6 | IPPROTO_TCP, IPPROTO_UDP, IPPROTO_ICMP, IPPROTO_ICMPV6

SEC("raw_tracepoint/inet_sock_set_state")  // TCP_LISTEN, TCP_CLOSE
SEC("raw_tracepoint/sys_execve")       int syscall__execve(void *ctx)
SEC("raw_tracepoint/sys_execveat")     int syscall__execveat(void *ctx)
SEC("raw_tracepoint/syscall__accept4") int syscall__accept4(void *ctx)  // AF_INET, AF_INET6, AF_UNIX

SEC("kprobe/do_exit")          int BPF_KPROBE(trace_do_exit)
SEC("kprobe/proc_create")      int BPF_KPROBE(trace_proc_create)
SEC("kprobe/security_bpf")     int BPF_KPROBE(trace_security_bpf)
SEC("kprobe/security_bpf_map") int BPF_KPROBE(trace_security_bpf_map)

SEC("kprobe/security_socket_bind")      // AF_INET, AF_INET6, AF_UNIX
SEC("kprobe/security_socket_create")    // family, type, protocol, kern
SEC("kprobe/security_socket_connect")   //
SEC("kprobe/security_socket_listen")    //
SEC("kprobe/security_socket_accept")    //

SEC("kprobe/security_file_open")        int BPF_KPROBE(trace_security_file_open)
SEC("kprobe/security_kernel_read_file") int BPF_KPROBE(trace_security_kernel_read_file)

SEC("kprobe/udp_sendmsg")      int BPF_KPROBE(trace_udp_sendmsg)
SEC("kprobe/__udp_disconnect") int BPF_KPROBE(trace_udp_disconnect)
SEC("kprobe/udp_destroy_sock") int BPF_KPROBE(trace_udp_destroy_sock)

SEC("kprobe/tcp_connect") int BPF_KPROBE(trace_tcp_connect)   // AF_INET, AF_INET6

SEC("kprobe/icmp_send") int BPF_KPROBE(trace_icmp_send)
SEC("kprobe/icmp_rcv")  int BPF_KPROBE(trace_icmp_rcv)

SEC("kprobe/ping_v4_sendmsg") int BPF_KPROBE(trace_ping_v4_sendmsg)

SEC("kprobe/send_bin")   int BPF_KPROBE(send_bin)
SEC("kprobe/device_add") int BPF_KPROBE(trace_device_add)

// -------------------
// lebauce/ebpfscene -> fire.c
SEC("kprobe/do_vfs_ioctl") int kprobe_do_vfs_ioctl(struct pt_regs *ctx)

// -------------------
// acassen/xdp-fw -> xdp_fw.c
SEC("xdp_fw") int xdp_drop(struct xdp_md *ctx)

// -------------------
// gamemann/XDP-Firewall -> xdpfw_kern.c
SEC("xdp_prog") int xdp_prog_main(struct xdp_md *ctx)

