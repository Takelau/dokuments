
// probes.c
SEC("kprobe/tcp_v4_connect")    int kprobe_tcp_v4_connect(const struct pt_regs *const p_context)
SEC("kretprobe/tcp_v4_connect") int kretprobe_tcp_v4_connect(const struct pt_regs *const p_context)

SEC("kprobe/security_socket_sendmsg")    int kprobe_security_socket_send_msg(const struct pt_regs *const p_context)
SEC("kretprobe/security_socket_sendmsg") int kretprobe_security_socket_send_msg(const struct pt_regs *const p_context_ignore)

SEC("kprobe/tcp_v6_connect")    int kprobe_tcp_v6_connect(const struct pt_regs *const p_context)
SEC("kretprobe/tcp_v6_connect") int kretprobe_tcp_v6_connect(const struct pt_regs *const p_context)


SEC("kretprobe/tcp_v6_connect") int kretprobe_tcp_v6_connect(const struct pt_regs *const p_context) {
	const uint64_t l_id  = bpf_get_current_pid_tgid();
	const uint32_t l_pid = l_id >> 32;
	...
	struct ebpf_event_t *const l_event = bpf_ringbuf_reserve(&g_probe_ipv4_events, sizeof(struct ebpf_event_t), 0);
	l_event->m_process_id = l_pid;
	...
	bpf_ringbuf_submit(l_event, BPF_RB_FORCE_WAKEUP);
	return 0;
}

// ebpf_event.hpp
struct ebpf_event_t {
    bool        m_v6;
    void *      m_handle;
    bool        m_remove;
    uint32_t    m_user_id;
    uint32_t    m_process_id;
    uint32_t    m_source_address;
    __uint128_t m_source_address_v6;
    uint16_t    m_source_port;
    uint32_t    m_destination_address;
    __uint128_t m_destination_address_v6;
    uint16_t    m_destination_port;
    uint64_t    m_timestamp;
    uint8_t     m_protocol;
} __attribute__((packed));

// ebpfsnitch_daemon.cpp
void ebpfsnitch_daemon::bpf_reader(void *const p_data, const int p_data_size) {
	assert(p_data);
	assert(p_data_size == sizeof(ebpf_event_t));
	const struct ebpf_event_t *const l_info = static_cast<ebpf_event_t *>(p_data);  // bpf data
	const std::shared_ptr<const process_info_t> l_process_info = m_process_manager.lookup_process_info(l_info->m_process_id);  // process_info
	...
}

// nfq_event.h
struct nfq_event_t {
    bool          m_v6;
    uint32_t      m_user_id;
    uint32_t      m_group_id;
    uint32_t      m_source_address;
    __uint128_t   m_source_address_v6;
    uint16_t      m_source_port;
    uint32_t      m_destination_address;
    __uint128_t   m_destination_address_v6;
    uint16_t      m_destination_port;
    uint32_t      m_nfq_id;
    uint64_t      m_timestamp;
    ip_protocol_t m_protocol;
    nfq_wrapper * m_queue;
};

// ------------------

ebpfsnitch_daemon::ebpfsnitch_daemon(
    std::shared_ptr<spdlog::logger> p_log,
    std::optional<std::string>      p_group,
    std::optional<std::string>      p_rules_path
):
    m_rule_engine(p_rules_path.value_or("rules.json")),
    m_log(p_log),
    m_group(p_group),
    m_process_manager(p_log),
    m_bpf_wrapper(p_log, std::string(reinterpret_cast<char*>(probes_c_o), sizeof(probes_c_o)))
{
    m_bpf_wrapper.attach_kprobe("kprobe_security_socket_send_msg",    "security_socket_sendmsg", false);
    m_bpf_wrapper.attach_kprobe("kretprobe_security_socket_send_msg", "security_socket_sendmsg", true);
    m_bpf_wrapper.attach_kprobe("kprobe_tcp_v4_connect",    "tcp_v4_connect", false);
    m_bpf_wrapper.attach_kprobe("kretprobe_tcp_v4_connect", "tcp_v4_connect", true);
    m_bpf_wrapper.attach_kprobe("kprobe_tcp_v6_connect",    "tcp_v6_connect", false);
    m_bpf_wrapper.attach_kprobe("kretprobe_tcp_v6_connect", "tcp_v6_connect", true);

    // m_ring_buffer -> bpf_reader | g_probe_ipv4_events
    m_ring_buffer = std::make_shared<bpf_wrapper_ring>(
        m_bpf_wrapper.lookup_map_fd_by_name("g_probe_ipv4_events"),
        ::std::bind(&ebpfsnitch_daemon::bpf_reader, this, std::placeholders::_1, std::placeholders::_2)
    );

    // m_nfq -> nfq_handler
    m_nfq = std::make_shared<nfq_wrapper>(0, ::std::bind(&ebpfsnitch_daemon::nfq_handler, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3 ), address_family_t::INET);
    // m_nfq_incoming -> nfq_handler_incoming
    m_nfq_incoming = std::make_shared<nfq_wrapper>(1, ::std::bind(&ebpfsnitch_daemon::nfq_handler_incoming, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3), address_family_t::INET);

    m_thread_group.push_back(::std::thread(&ebpfsnitch_daemon::filter_thread, this, m_nfq));
    m_thread_group.push_back(::std::thread(&ebpfsnitch_daemon::filter_thread, this, m_nfq_incoming));
    m_thread_group.push_back(::std::thread(&ebpfsnitch_daemon::probe_thread,  this));
}
// bpf_reader
void ebpfsnitch_daemon::bpf_reader(void *const p_data, const int p_data_size){
    assert(p_data);
    assert(p_data_size == sizeof(ebpf_event_t));
    // ebpf event
    const struct ebpf_event_t *const l_info = static_cast<ebpf_event_t *>(p_data);  
    // process info
    const std::shared_ptr<const process_info_t> l_process_info = m_process_manager.lookup_process_info(l_info->m_process_id);  
    // 
    struct ebpf_event_t l_info2;
    memcpy(&l_info2, l_info, sizeof(ebpf_event_t));
    l_info2.m_destination_port = ntohs(l_info->m_destination_port);  // dst port
    m_connection_manager.add_connection_info(l_info2, l_process_info);
}
// nfq_handler
nfq_cb_result_t ebpfsnitch_daemon::nfq_handler(nfq_wrapper *const p_queue,  const uint32_t  p_packet_id,  const std::span<const std::byte> &p_packet) {
    assert(p_queue);
    const uint16_t    l_payload_length = p_packet.size();
    const char *const l_data           = (char *)p_packet.data();
    // unknown dropping
    if (l_payload_length < 24) {
        p_queue->send_verdict(p_packet_id, nfq_verdict_t::DROP);
        return nfq_cb_result_t::OK;
    }
    const uint8_t l_ip_version = (*l_data & 0b11110000) >> 4;
    // unknown ip protocol version {}
    if (l_ip_version != 4 && l_ip_version != 6) {
        p_queue->send_verdict(p_packet_id, nfq_verdict_t::DROP);
        return nfq_cb_result_t::OK;
    }

    struct nfq_event_t l_nfq_event = {
        .m_v6        = l_ip_version == 6,
        .m_user_id   = 0,
        .m_group_id  = 0,
        .m_nfq_id    = p_packet_id,
        .m_timestamp = nanoseconds(),
        .m_queue     = p_queue
    };
    // src + dst adr
    if (l_ip_version == 4) { ... } else { ... }
    // src + dst port
    if (l_nfq_event.m_protocol == ip_protocol_t::TCP || l_nfq_event.m_protocol == ip_protocol_t::UDP) {...} else {...}
    process_nfq_event(l_nfq_event, true);
    return nfq_cb_result_t::OK;
}
// nfq_handler_incoming
nfq_cb_result_t ebpfsnitch_daemon::nfq_handler_incoming(nfq_wrapper *const p_queue,  const uint32_t p_packet_id,  const std::span<const std::byte> &p_packet) {
    assert(p_queue);
    const uint16_t    l_payload_length = p_packet.size();
    const char *const l_data           = (char *)p_packet.data();
    // unknown dropping
    if (l_payload_length < 24) {
        p_queue->send_verdict(p_packet_id, nfq_verdict_t::DROP);
        return nfq_cb_result_t::OK;
    }
    const ip_protocol_t l_proto = l_ip_version == 6
        ? static_cast<ip_protocol_t>(*((uint8_t*) (l_data + 6)))
        : static_cast<ip_protocol_t>(*((uint8_t*) (l_data + 9)));
    // UDP
    if (l_proto == ip_protocol_t::UDP) {...}
    p_queue->send_verdict(p_packet_id, nfq_verdict_t::ACCEPT);
    return nfq_cb_result_t::OK;
}
// process_associated_event
bool ebpfsnitch_daemon::process_associated_event(const struct nfq_event_t &l_nfq_event,  const struct process_info_t &l_info) {
    const std::optional<bool> l_verdict = m_rule_engine.get_verdict(l_nfq_event, l_info);
    if (l_verdict) {
        if (l_verdict.value()) {
            l_nfq_event.m_queue->send_verdict(
                l_nfq_event.m_nfq_id,
                nfq_verdict_t::ACCEPT
            );
            return true;
        } else {
            l_nfq_event.m_queue->send_verdict(
                l_nfq_event.m_nfq_id,
                nfq_verdict_t::DROP
            );
            return true;
        }
    }
    return false;
}