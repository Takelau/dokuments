
// 1
func Ints(x []int)
func Float64s(x []float64)
func Strings(x []string)
// 2
func IsSorted(data Interface) bool
func SliceStable(x interface{}, less func(i, j int) bool)
func SearchStrings(a []string, x string) int
// 3
type Interface interface {
	Len() int
	Less(i, j int) bool
	Swap(i, j int)
}
// 
func Reverse(data Interface) Interface

// --------------------------------
// 1
s := []int{4, 2, 3, 1}
sort.Ints(s)  // [1 2 3 4]
sort.Sort(sort.Reverse(sort.IntSlice(s)))  // [4 3 2 1]

s := []string{"Go", "Bravo", "Gopher", "Alpha", "Grin", "Delta"}
sort.Strings(s)

// --------------------------------
// 2
people := []struct {
	Name  string
	Age   int
}{ {"Gopher",7},{"Alice",55},{"Vera",24},{"Bob",75}, }

sort.SliceStable(people, func(i, j int) bool { return people[i].Age < people[j].Age }

// --------------------------------
// 3
type Person struct {
	Name  string
	Age   int
}
type ByAge []Person
func (a ByAge) Len() int           { return len(a) }
func (a ByAge) Less(i, j int) bool { return a[i].Age < a[j].Age }
func (a ByAge) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }

family := []Person{ {"Alice",23}, {"Eve",2}, {"Bob",25}, }
sort.Sort(ByAge(family))

// --------------------------------
// 4 
m := map[string]int{"Alice": 2, "Cecil": 1, "Bob": 3}

keys := make([]string, 0, len(m))
for k := range m {
	keys = append(keys, k)
}
sort.Strings(keys)
for _, k := range keys {
	fmt.Println(k, m[k])
}

// --------------------------------
// --------------------------------
