
// --------------------------------
type LEVEL uint8
const LOG LEVEL = iota
func (l LEVEL) String() string {
	switch l {
	case LOG:
		return "LOG"
}

// --------------------------------
// статистика файла по таймеру - https://github.com/arthurkiller/rollingwriter/blob/master/manager.go
wg.Add(1)
go func() {
	timer := time.Tick(time.Duration(Precision) * time.Second)
	var file *os.File
	var err error
	wg.Done()

	for {
		select {
			case <-m.context:
				return
			case <-timer:
				if file, err = os.Open(filepath); err != nil {
					continue
				}
				if info, err := file.Stat(); err == nil && info.Size() > m.thresholdSize {
					m.fire <- m.GenLogFileName(c)
				}
				file.Close()
		}
	}
}

// --------------------------------
// sync.Pool GLG - // https://github.com/kpango/glg/blob/master/glg.go
type Glg struct {
	bs      *uint64
	buffer  sync.Pool
	writer  io.Writer
}

func New() *Glg {
	g := &Glg{}
	g.bs = new(uint64)
	atomic.StoreUint64(g.bs, uint64(len("2006-01-02 15:04:05")))
	g.buffer = sync.Pool{
		New: func() interface{} {
			return bytes.NewBuffer(make([]byte, 0, int(atomic.LoadUint64(g.bs))))
		},
	}
	...
}

func (g *Glg) out(format string, val ...interface{}) error {
	var buf []byte
	var b = g.buffer.Get().(*bytes.Buffer)
	buf = b.Bytes()

	_, err := fmt.Fprintf(g.writer, *(*string)(unsafe.Pointer(&buf)), val...)   // func Fprintf(w io.Writer, format string, a ...interface{}) (n int, err error)

	bl := uint64(len(buf))
	if atomic.LoadUint64(g.bs) < bl {
		atomic.StoreUint64(g.bs, bl)
	}

	b.Reset()
	g.buffer.Put(b)
}

// --------------------------------
// log file (sync.Pool + Mutex) - https://github.com/siddontang/go-log/blob/master/log/logger.go
type Logger struct {
	loggers.Advanced
	flag    int        // Ltime|Lfile|Llevel
	hLock   sync.Mutex
	handler Handler
	bufs    sync.Pool
}

type Handler interface {
	Write(p []byte) (n int, err error)
	Close() error
}

type FileHandler struct {
	fd *os.File
}

type StreamHandler struct {
	w io.Writer
}

func NewFileHandler(fileName string, flag int) (*FileHandler, error) {
	f, err := os.OpenFile(fileName, flag, 0755);  if err != nil { return nil, err; }
	h := new(FileHandler)
	h.fd = f
	return h, nil
}

func NewStreamHandler(w io.Writer) (*StreamHandler, error) {
	h := new(StreamHandler)
	h.w = w
	return h, nil
}

func New(handler Handler, flag int) *Logger {
	var l = new(Logger)
	l.level   = LevelInfo
	l.handler = handler
	l.flag    = flag
	l.bufs    = sync.Pool{
		New: func() interface{} {
			return make([]byte, 0, 1024)
		},
	}
	return l
}

func NewDefault(handler Handler) *Logger {
	return New(handler, Ltime|Lfile|Llevel)
}

func (l *Logger) Output(callDepth int, level Level, msg string) {
	buf := l.bufs.Get().([]byte)
	buf = buf[0:0]
	defer l.bufs.Put(buf)
	
	buf = append(buf, msg...)
	if len(msg) == 0 || msg[len(msg)-1] != '\n' {
		buf = append(buf, '\n')
	}

	l.hLock.Lock()
	l.handler.Write(buf)
	l.hLock.Unlock()
}

func (l *Logger) OutputJson(callDepth int, level Level, body interface{}) {
	buf := l.bufs.Get().([]byte)
	buf = buf[0:0]
	defer l.bufs.Put(buf)

	msg, _ := json.Marshal(body)
	msg = append(msg, '\n')

	l.hLock.Lock()
	l.handler.Write(msg)
	l.hLock.Unlock()
}

// -------------------------------
// Reopen log file - https://github.com/arthurkiller/rollingwriter
func (w *Writer) Reopen(file string) error {
	newfile, err := os.OpenFile(w.absPath, DefaultFileFlag, DefaultFileMode)
	oldfile := atomic.SwapPointer((*unsafe.Pointer)(unsafe.Pointer(&w.file)), unsafe.Pointer(newfile))
	go func() {
		defer (*os.File)(oldfile).Close()
		... Compress()
	}
}

func (w *Writer) Write(b []byte) (int, error) {
	fp := atomic.LoadPointer((*unsafe.Pointer)(unsafe.Pointer(&w.file)))
	file := (*os.File)(fp)
	return file.Write(b)
}

func (w *Writer) Close() error {
	return (*os.File)(atomic.LoadPointer((*unsafe.Pointer)(unsafe.Pointer(&w.file)))).Close()
}
