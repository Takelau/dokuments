
// --------------------------------
//    Net
// --------------------------------
func ParseIP(ip string) IP         // IP{} || nil
func LookupIP(host string) ([]IP, error)
func LookupHost(host string) (ip []string, err error)
func LookupAddr(ip string) (names []string, err error)
func SplitHostPort(hostport string) (host, port string, err error)
func ResolveIPAddr(network, address string) (*IPAddr, error)

type Addr interface {
	Network() string  // "tcp", "udp"
	String()  string  // "192.0.2.1:25", "[2001:db8::1]:80"
}
func InterfaceAddrs() ([]Addr, error)

type Interface struct {
	Index        int          // positive integer that starts at one, zero is never used
	MTU          int          // maximum transmission unit
	Name         string       // "en0", "lo0", "eth0.100"
	HardwareAddr HardwareAddr // IEEE MAC-48, EUI-48 and EUI-64 form
	Flags        Flags        // FlagUp, FlagLoopback, FlagMulticast
}
func Interfaces() ([]Interface, error)

// --------------------------------
// Interfaces
interfaces,_ := net.Interfaces()
for _,i := range interfaces {
	fmt.Println( i.Name )            // lo0
	fmt.Println( i.Flags.String() )  // up|loopback|multicast
	fmt.Println( i.MTU )             // 16384
	fmt.Println( i.HardwareAddr )    // b8:e8:56:34:a1:c8
	byName,_ := net.InterfaceByName(i.Name)
	addresses, err := byName.Addrs() // lo0
	for k, v := range addresses {
		fmt.Println(k, v.String())     // 0 127.0.0.1/8
	}
}

// --------------------------------
// Dial
func Dial(network, address string) (Conn, error)
tcp, tcp4, tcp6, udp, udp4, udp6, ip, ip4, ip6, unix, unixgram, unixpacket
Dial("tcp", ":80")
Dial("tcp", "golang.org:http")
Dial("tcp", "192.0.2.1:http")
Dial("udp", "[fe80::1%lo0]:53")
Dial("ip4:1", "192.0.2.1")
Dial("ip6:ipv6-icmp", "2001:db8::1")

//	Dial("tcp", "golang.org:http")
//	Dial("tcp", "192.0.2.1:http")
//	Dial("tcp", "198.51.100.1:80")
//	Dial("udp", "[2001:db8::1]:domain")
//	Dial("udp", "[fe80::1%lo0]:53")
//	Dial("tcp", ":80")