
// --------------------------------
// api.proto
syntax = "proto3";
package message_service;
message Request {
	string text = 1;
	string subtext = 2;
}
message Response {
	string text = 1;
	string subtext = 2;
}
service MessageService {
	rpc SayIt (Request) returns (Response);
}

protoc -I .  --go_out=plugins=grpc:. api.proto

// Client
package main
import (
	"fmt"
p "github.com/mactsouk/protobuf"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
)
var port = ":8080"

func AboutToSayIt(ctx context.Context, m p.MessageServiceClient, text string) (*p.Response, error) {
	request := &p.Request{
		Text: text,
		Subtext: "New Message!",
	}
	r, err := m.SayIt(ctx, request)
	if err != nil { return nil, err; }
	return r, nil
}

func main() {
	conn, err := grpc.Dial(port, grpc.WithInsecure())
	if err != nil { fmt.Println("Dial:", err);  return; }

	client := p.NewMessageServiceClient(conn)  // New...Client
	r, err := AboutToSayIt(context.Background(), client, "My Message!")
	if err != nil { fmt.Println(err); }

	fmt.Println("Response Text:", r.Text)
	fmt.Println("Response SubText:", r.Subtext)
}

// Server
package main
import (
	"fmt"
p "github.com/mactsouk/protobuf"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"net"
)

var port = ":8080"
type MessageServer struct {}

func (MessageServer) SayIt(ctx context.Context, r *p.Request) (*p.Response, error) {
	fmt.Println("Request Text:", r.Text)
	fmt.Println("Request SubText:", r.Subtext)
	response := &p.Response{
		Text: r.Text,
		Subtext: "Got it!",
	}
	return response, nil
}

func main() {
	server := grpc.NewServer()
	var messageServer MessageServer
	p.RegisterMessageServiceServer(server, messageServer)   // Register...Server
	listen, err := net.Listen("tcp", port)
	if err != nil { fmt.Println(err); return; }

	fmt.Println("Serving requests...")
	server.Serve(listen)
}


// --------------------------------
//    Client Deadline
// --------------------------------
conn, err := grpc.Dial(address, grpc.WithInsecure());  if err != nil { ... }
defer conn.Close()

client := pb.NewOrderManagementClient(conn)
clientDeadline := time.Now().Add(time.Duration(2 * time.Second))
ctx, cancel := context.WithDeadline(context.Background(), clientDeadline)
defer cancel()

order1 := pb.Order{Id: "101", Items:[]string{"iPhone XS", "Mac Book Pro"}, Destination:"San Jose, CA", Price:2300.00}
res, addErr := client.AddOrder(ctx, &order1)
if addErr != nil {
	got := status.Code(addErr)   // Определяем код ошибки с помощью пакета status
	log.Printf("Error Occured -> addOrder : , %v:", got)  // ошибка типа DEADLINE_EXCEEDED 
} else {
	log.Print("AddOrder Response -> ", res.Value)
}

// на стороне сервера выполняем проверку
ctx.Err() == context.DeadlineExceeded


// --------------------------------
//    Client WithTimeout
// --------------------------------
ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
streamProcOrder, _ := client.ProcessOrders(ctx)
_ = streamProcOrder.Send(&wrapper.StringValue{Value:"102"})
_ = streamProcOrder.Send(&wrapper.StringValue{Value:"103"})
_ = streamProcOrder.Send(&wrapper.StringValue{Value:"104"})
channel := make(chan bool, 1)
go asncClientBidirectionalRPC(streamProcOrder, channel)

time.Sleep(time.Millisecond * 1000)
cancel()
log.Printf("RPC Status : %s", ctx.Err())

_ = streamProcOrder.Send(&wrapper.StringValue{Value:"101"})
_ = streamProcOrder.CloseSend()
<- channel

func asncClientBidirectionalRPC (streamProcOrder pb.OrderManagement_ProcessOrdersClient, c chan bool) {
	...
	combinedShipment, errProcOrder := streamProcOrder.Recv()
	if errProcOrder != nil { log.Printf("Error Receiving messages %v", errProcOrder); }
	...
}

// на стороне сервера выполняем проверку
stream.Context().Err() == context.Canceled


// --------------------------------
//    Серверный унарный перехватчик
// --------------------------------
func orderUnaryServerInterceptor(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
	log.Println("[Server Interceptor] ", info.FullMethod)
	m, err := handler(ctx, req)
	log.Printf(" Post Proc Message : %s", m)  // выполнение унарного RPC-вызова
	return m, err
}

func main() {
	s := grpc.NewServer(grpc.UnaryInterceptor(orderUnaryServerInterceptor))
}


// --------------------------------
//    Серверные потоковые перехватчики
// --------------------------------
type wrappedStream struct {
	grpc.ServerStream
}

func (w *wrappedStream) RecvMsg(m interface{}) error {
	log.Printf("[Server Stream Interceptor Wrapper] " + "Receive a message (Type: %T) at %s", m, time.Now().Format(time.RFC3339))
	return w.ServerStream.RecvMsg(m)
}

func (w *wrappedStream) SendMsg(m interface{}) error {
	log.Printf("[Server Stream Interceptor Wrapper] " + "Send a message (Type: %T) at %v", m, time.Now().Format(time.RFC3339))
	return w.ServerStream.SendMsg(m)
}

func newWrappedStream(s grpc.ServerStream) grpc.ServerStream {
	return &wrappedStream{s}
}

func orderServerStreamInterceptor(srv interface{}, ss grpc.ServerStream, info *grpc.StreamServerInfo, handler grpc.StreamHandler) error {
	log.Println("[Server Stream Interceptor] ", info.FullMethod)
	err := handler(srv, newWrappedStream(ss))
	if err != nil { log.Printf("RPC failed with error %v", err); }
	return err
}

s := grpc.NewServer( grpc.StreamInterceptor(orderServerStreamInterceptor) )


// --------------------------------
//    Клиентский унарный перехватчик
// --------------------------------
func orderUnaryClientInterceptor(ctx context.Context, method string, req, reply interface{}, cc *grpc.ClientConn,
	invoker grpc.UnaryInvoker, opts ...grpc.CallOption) error {
	// этап предобработки
	log.Println("Method : " + method)
	// вызов удаленного метода
	err := invoker(ctx, method, req, reply, cc, opts...)  // вызов удаленного метода
	// этап постобработки
	log.Println(reply)
	return err
}

func main() {
	conn, err := grpc.Dial(address, grpc.WithInsecure(), grpc.WithUnaryInterceptor(orderUnaryClientInterceptor))
}


// --------------------------------
//    Errors
// --------------------------------
0 OK                - Успех
1 CANCELLED         - Операция была отменена (вызывающей стороной)
2 UNKNOWN           - Неизвестная ошибка
3 INVALID_ARGUMENT  - Клиент указал недопустимый аргумент
4 DEADLINE_EXCEEDED - Крайний срок истек до завершения операции
5 NOT_FOUND         - Не удалось найти запрошенный элемент
6 ALREADY_EXISTS    - Элемент, который клиент пытался создать, уже существует
7 PERMISSION_DENIED - У вызывающей стороны нет права выполнять указанную операцию
8 RESOURCE_EXHAUSTED  - Исчерпан какой-то ресурс
9 FAILED_PRECONDITION - Операция была отклонена, поскольку система не находится в состоянии, необходимом для ее выполнения
10 ABORTED          - Операция была прервана
11 OUT_OF_RANGE     - Попытка выполнения операции за пределами допустимого диапазона
12 UNIMPLEMENTED    - Операция не реализована, не поддерживается или не включена в этом сервисе
13 INTERNAL         - Внутренние ошибки
14 UNAVAILABLE      - В данный момент сервис недоступен
15 DATA_LOSS        - Потеря или повреждение данных без возможности восстановления
16 UNAUTHENTICATED  - Запрос не содержит аутентификационных данных, необходимых для выполнения операции


// описание ошибки на сервере
if orderReq.Id == "-1" {
	// новое состояние с кодом ошибки InvalidArgument (пакет grpc.status)
	errorStatus := status.New(codes.InvalidArgument, "Invalid information received")
	ds, err := errorStatus.WithDetails(
		// Описываем произошедшее с помощью типа ошибки BadRequest_FieldViolation из google.golang.org/genproto/googleapis/rpc/errdetails
		&epb.BadRequest_FieldViolation{
			Field:"ID", Description: fmt.Sprintf("Order ID received is not valid %s : %s", orderReq.Id, orderReq.Description),
		},
	)
	if err != nil { return nil, errorStatus.Err() }
	return nil, ds.Err()
}

// обработка ошибки на клиене
order1 := pb.Order{Id: "-1", ...}
res, addOrderError := client.AddOrder(ctx, &order1)

if addOrderError != nil {
	errorCode := status.Code(addOrderError)
	if errorCode == codes.InvalidArgument {
		errorStatus := status.Convert(addOrderError)
		for _, d := range errorStatus.Details() {
			switch info := d.(type) {
				case *epb.BadRequest_FieldViolation:
					log.Printf("Request Field Invalid: %s", info)
				default:
					log.Printf("Unexpected error type: %s", info)
			}
		}
	} else { log.Printf("Unhandled error : %s ", errorCode) }
} else { log.Print("AddOrder Response -> ", res.Value) }