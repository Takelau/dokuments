
// --------------------------------
//    GitHub
// --------------------------------
git clone git@github.com:mactsouk/go-kafka.git
git status
git diff    // различия между изменениями и рабочим репозиторием, веткой и тп
git pull    // для получения обновлений из удаленного репозитория
git commit  // для записи изменений в репозиторий
git push    // перенести локальные изменения в репозиторий GitHub
// --------------------------------
git add a_file.go  // перенос локальных изменений в репозиторий GitHub
git commit -a -m "Commit message"
git push
// --------------------------------
git checkout -b new_branch  // новая ветка на локальном компе с именем new_branch
git push --set-upstream origin new_branch  // подключить ветку к GitHub
git checkout master         // переход с текущей ветки на 'master'
git --no-pager branch -a    //
git branch -D new_branch    // удалить текущую локальную ветку
// --------------------------------
git tag c7.0
git --no-pager show v1.0.0  // информация о tag = v1.0.0
git --no-pager tag          // список всех доступных тегов
git tag -d c7.0             // удаление тега с локального компьютера
git push origin :refs/tags/c7.0  // удаление тега с сервера GitHub
// --------------------------------
rm a_file.go
git rm a_file.go
...
git commit -a -m "Deleting a_file.go"
git push
// --------------------------------
git cherry-pick 4226f2c4    // вносит в текущую ветвь фиксацию номер 4226f2c4
git cherry-pick 4226f2c4..0d820a87  // все фиксации с 4226f2c4 по 0d820a87
// --------------------------------
.gitignore  <- список файлов и каталогов, которые следует игнорировать при записи изменений на GitHub


// --------------------------------
//    Отладка Delve
// --------------------------------
github.com/go-delve/delve 
~/go/bin/dlv version
dlv test   // для go-test
dlv debug  // компилирует пакет main в текущем рабочем каталоге и начинает его отладку
dlv debug -- arg1 arg2 arg3
c   // go run
r   // restart
next
print i  // выводит на экран значение переменной i
// --------------------------------
break main.main
break fName
