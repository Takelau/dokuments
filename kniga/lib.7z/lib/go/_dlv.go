
go build -gcflags="all=-N -l" -o bin/app
dlv --listen=192.168.1.200:30003 --headless=true --api-version=2 --accept-multiclient exec app

dlv debug --listen=192.168.1.200:30003 --headless --api-version=2 --log 
dlv debug --listen=192.168.1.200:30003 --headless=true --accept-multiclient --api-version=2 --log=true  
dlv debug --listen=192.168.1.200:30003 --headless=true --accept-multiclient --api-version=2 --log=true --log-output=debugger,debuglineerr,gdbwire,lldbout,rpc 

dlv debug --listen=192.168.1.200:30003 --headless --accept-multiclient --allow-non-terminal-interactive --api-version=2 --log

nano launch.json
{
	"name": "Launch remote",
	"type": "go",
	"request": "launch",
	"mode": "remote",
	"remotePath": "/vlm/work/src/fw",
	"host": "192.168.1.200",
	"port": 30003,
	"program": "/vlm/fw/fw_go17/src/fw",
	"logOutput": "debugger,debuglineerr,gdbwire,lldbout,rpc",
	"env": {}
},
{
	"name": "Firewall Attach",
	"type": "go",
	"request": "attach",
	"mode": "remote",
	"remotePath": "",
	"port": 30003,
	"host": "192.168.1.200",
	"showLog": true,
	"trace": "log",
	"logOutput": "rpc"
}
// описание полей
{
	"name": "Launch remote",
	"type": "go",
	"request": "launch",
	"mode": "remote",
	"remotePath": "absolute-path-to-the-file-being-debugged-on-the-remote-machine",
	"port": 2345,
	"host": "127.0.0.1",
	"program": "absolute-path-to-the-file-on-the-local-machine",
	"env": {}
}
