
// --------------------------------
google.protobuf.
  BoolValue, 
  DoubleValue, FloatValue, Int64Value, Int32Value
  StringValue, BytesValue

google.protobuf.Struct - представление объекта JSON, дает преимущества динамической типизации для protobuf
google.protobuf.Any    - встраивает двоичный сериализованный protobuf вместе с информацией о типе в поле другого protobuf

// --------------------------------
// Enum
message SearchRequest {
	string query = 1;
	enum Corpus {
		UNIVERSAL = 0;
		WEB = 1;
		IMAGES = 2;
	}
	Corpus corpus = 2;
}

// repeated
message SearchResponse {
  repeated Result results = 1;
}

message Result {
  string url = 1;
  string title = 2;
  repeated string snippets = 3;
}


// --------------------------------
// string
service OrderManagement {
	rpc searchOrders(google.protobuf.StringValue) returns (stream Order);
}

func (s *server) SearchOrders(searchQuery *wrappers.StringValue, stream pb.OrderManagement_SearchOrdersServer) error { ... }

// --------------------------------
// URL
message UpdateAwesomeNameRequest {
	AwesomeName awesome_name = 1;
}
service AwesomeService {
	rpc UpdateAppointment (UpdateAwesomeNameRequest) returns (AwesomeName) {
		option (google.api.http) = {
			put: "/v1/awesome-name/{awesome_name.id}"
			body: "awesome_name"
		};
	};
}

// --------------------------------
service OrderManagement {
	rpc getOrder(google.protobuf.StringValue) returns (Order);
}
order, err := client.GetOrder(ctx, &wrapper.StringValue{Value: "106"}){...}
func (s *server) GetOrder(ctx context.Context, orderId *wrapper.StringValue) (*pb.Order, error){...}

// --------------------------------
service ProductInfo {
	rpc getProduct(ProductID) returns (Product);
}
message ProductID {
	string value = 1;
}
product, err := client.GetProduct(ctx, &pb.ProductID{Value: "15"})


Value Types // https://developers.google.com/protocol-buffers/docs/proto3#scalar
------------------------------
.proto   Go       PHP
------------------------------
double   float64  float
float    float32  float
int32    int32    integer          // Неэффективен для кодирования отрицательных чисел 
int64    int64    integer/string   //                                        (–9 223 372 036 854 775 808 до 9 223 372 036 854 775 807)
uint32   uint32   integer          // Использует кодировку переменной длины  (0 до 4 294 967 295)
uint64   uint64   integer/string   //                                        (0 до 18 446 744 073 709 551 615)
sint32   int32    integer          // Знаковое значение int                  (–2 147 483 648 до 2 147 483 647)
sint64   int64    integer/string   //                                        (–9 223 372 036 854 775 808 до 9 223 372 036 854 775 807)
fixed32  uint32   integer
fixed64  uint64   integer/string
sfixed32 int32    integer          // Всегда четыре байта
sfixed64 int64    integer/string   // Всегда восемь байтов
bool     bool     boolean
string   string   string           // текст в кодировке UTF-8 или 7-битный текст ASCII
bytes    []byte   string


Транспортные типы // https://developers.google.com/protocol-buffers/docs/encoding
----------------------------------------------------------------------------
   Категория         Типы полей
----------------------------------------------------------------------------
0	 Varint	           int32, int64, uint32, uint64, sint32, sint64, bool, enum
1	 64-bit	           fixed64, sfixed64, double
2	 Length-delimited  string, bytes, embedded messages, packed repeated fields
3	 Start group       groups (deprecated)
4	 End group         groups (deprecated)
5  32-bit	           fixed32, sfixed32, float

Транспортные механизмы
HTTP2       // https://github.com/grpc/grpc/tree/master/src/core/ext/transport/chttp2
Cronet      // https://github.com/grpc/grpc/tree/master/src/core/ext/transport/cronet
in-process  // https://github.com/grpc/grpc/tree/master/src/core/ext/transport/inproc


// HTTP2 Request
HEADERS (flags = END_HEADERS)
:method = POST                    // CONST - HTTP-метод
:scheme = http                    // https (TLS)
:path = /ProductInfo/getProduct
:authority = abc.com
te = trailers                     // CONST - способ обнаружения несовместимых прокси-серверов
grpc-timeout = 1S
content-type = application/grpc   // CONST
grpc-encoding = gzip              // способ сжатия сообщения: identity, gzip, deflate, snappy и {custom}
authorization = Bearer xxxxxx     // необязательные метаданные
                                  // Названия заголовков, в которых передаются эти метаданные, должны начинаться с grpc-
DATA (flags = END_STREAM)
<Length-Prefixed Message>

// HTTP2 Response
HEADERS (flags = END_HEADERS)
:status = 200
grpc-encoding = gzip
content-type = application/grpc+proto

DATA
<Length-Prefixed Message>

HEADERS (flags = END_STREAM, END_HEADERS)
:status
content-type 
grpc-status = 0 # OK                 // коды состояния https://github.com/grpc/grpc/blob/master/doc/statuscodes.md
grpc-message                         // Status-Message
trace-proto-bin = jher831yy13JHy3hc  // описание ошибки
