s := []string{"a", "b", "c"}
reflect.ValueOf(s).Kind()           // reflect.Slice
reflect.ValueOf(s).Len()            // 3
reflect.ValueOf(s).Index(IDX)       // "a"
reflect.ValueOf(s).Index(IDX).Interface()

s := map[int]string{1:"a", 2:"b", 3:"c"}
reflect.TypeOf(s).Key().Kind()      // reflect.Int
reflect.TypeOf(s).Elem().Kind()     // reflect.String

// --------------------------------
// поиск элемента слайса
s := [3]string{"a", "b", "c"}
itemExists(s, "a")  // true
itemExists(s, "x")  // false

func itemExists(slice interface{}, item interface{}) bool {
	s := reflect.ValueOf(slice)
	if s.Kind() != reflect.Slice { panic("Invalid data-type"); }

	for i := 0; i < s.Len(); i++ {
		if s.Index(i).Interface() == item {
			return true
		}
	}

	return false
}

// --------------------------------
package main
import (
	"fmt"
	"reflect"
)

func main() {
	swap := func(in []reflect.Value) []reflect.Value {
		return []reflect.Value{in[1], in[0]}
	}

	makeSwap := func(fptr interface{}) {
		fn := reflect.ValueOf(fptr).Elem()
		v := reflect.MakeFunc(fn.T, swap)
		fn.Set(v)
	}

	var intSwap func(int, int) (int, int)
	makeSwap(&intSwap)
	fmt.Println(intSwap(0, 1))

	var floatSwap func(float64, float64) (float64, float64)
	makeSwap(&floatSwap)
	fmt.Println(floatSwap(2.72, 3.14))
}
