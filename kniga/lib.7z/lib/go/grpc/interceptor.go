
// --------------------------------
// Proto Buf
// --------------------------------
var _OrderManagement_serviceDesc = grpc.ServiceDesc{  ServiceName:"ecommerce.OrderManagement",  HandlerType:(*OrderManagementServer)(nil),
	Methods: []grpc.MethodDesc{
		{ MethodName:"addOrder",  Handler:_OrderManagement_AddOrder_Handler, },  // Unary
	},
	Streams: []grpc.StreamDesc{
		{ StreamName:"searchOrders",   Handler:_OrderManagement_SearchOrders_Handler,   ServerStreams:true, },  // Stream Server
		{ StreamName:"updateOrders",   Handler:_OrderManagement_UpdateOrders_Handler,   ClientStreams:true, },  // Stream Client
		{ StreamName:"processOrders",  Handler:_OrderManagement_ProcessOrders_Handler,  ServerStreams:true,  ClientStreams:true, },
	},
	Metadata: "order_management.proto",
}

// Unary Handler
func _OrderManagement_AddOrder_Handler(srv interface{}, ctx context.Context, dec func(interface{}) error, interceptor grpc.UnaryServerInterceptor) (interface{}, error) {
	in := new(Order)
	if err := dec(in); err != nil { return nil, err; }
	if interceptor == nil {
		return srv.(OrderManagementServer).AddOrder(ctx, in)
	}
	info := &grpc.UnaryServerInfo{ Server:srv, FullMethod:"/ecommerce.OrderManagement/AddOrder", }
	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return srv.(OrderManagementServer).AddOrder(ctx, req.(*Order))
	}
	return interceptor(ctx, in, info, handler)
}

// Stream Server Handler
func _OrderManagement_SearchOrders_Handler(srv interface{}, stream grpc.ServerStream) error {
	m := new(wrappers.StringValue)
	if err := stream.RecvMsg(m); err != nil {
		return err
	}
	return srv.(OrderManagementServer).SearchOrders(m, &orderManagementSearchOrdersServer{stream})
}

// Stream Client Handler
func _OrderManagement_UpdateOrders_Handler(srv interface{}, stream grpc.ServerStream) error {
	return srv.(OrderManagementServer).UpdateOrders(&orderManagementUpdateOrdersServer{stream})
}

// Streem Dual Handler
func _OrderManagement_ProcessOrders_Handler(srv interface{}, stream grpc.ServerStream) error {
	return srv.(OrderManagementServer).ProcessOrders(&orderManagementProcessOrdersServer{stream})
}


// --------------------------------
// Server Interceptor
// --------------------------------
// Unary
func orderUnaryServerInterceptor(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
	// Pre-processing
	log.Printf("======= [Server Interceptor] method:%s message:%v \n", info.FullMethod, req)
	// handler
	m, err := handler(ctx, req)
	// Post-processing
	log.Printf(" Post Proc Message : %s \n", m)
	return m, err
}

// Stream
type wrappedStream struct { grpc.ServerStream; }
func (w *wrappedStream) RecvMsg(m interface{}) error { log.Printf("====== [Server Stream Interceptor Wrapper] Receive a message (Type: %T) at %s", m, time.Now().Format(time.RFC3339));  return w.ServerStream.RecvMsg(m); }
func (w *wrappedStream) SendMsg(m interface{}) error { log.Printf("====== [Server Stream Interceptor Wrapper] Send a message (Type: %T) at %v", m, time.Now().Format(time.RFC3339));     return w.ServerStream.SendMsg(m); }
func newWrappedStream(s grpc.ServerStream) grpc.ServerStream { return &wrappedStream{s}; }

func orderServerStreamInterceptor(srv interface{}, ss grpc.ServerStream, info *grpc.StreamServerInfo, handler grpc.StreamHandler) error {
	// Pre-processing
	log.Println("====== [Server Stream Interceptor] ", info.FullMethod)
	// handler
	err := handler(srv, newWrappedStream(ss))  // <- Stream Server Handler
	if err != nil {...}
	// Post-processing
	return err
}

func main() {
	...
	s := grpc.NewServer(
		grpc.UnaryInterceptor(orderUnaryServerInterceptor),
		grpc.StreamInterceptor(orderServerStreamInterceptor),
	)
	pb.RegisterOrderManagementServer(s, &server{})   // pb.Register ... Server()
}


// --------------------------------
// Client Interceptor
// --------------------------------
// Unary
func orderUnaryClientInterceptor(ctx context.Context, method string, req, reply interface{}, cc *grpc.ClientConn, invoker grpc.UnaryInvoker, opts ...grpc.CallOption) error {
	// Pre-processor
	log.Println("Method : " + method)
	// invoker
	err := invoker(ctx, method, req, reply, cc, opts...)
	// Post-processor
	log.Println(reply)
	return err
}

// Stream
type wrappedStream struct { grpc.ClientStream; }
func (w *wrappedStream) RecvMsg(m interface{}) error { log.Printf("====== [Client Stream Interceptor] Receive a message (Type: %T) at %v", m, time.Now().Format(time.RFC3339));  return w.ClientStream.RecvMsg(m); }
func (w *wrappedStream) SendMsg(m interface{}) error { log.Printf("====== [Client Stream Interceptor] Send a message (Type: %T) at %v",    m, time.Now().Format(time.RFC3339));  return w.ClientStream.SendMsg(m); }
func newWrappedStream(s grpc.ClientStream) grpc.ClientStream { return &wrappedStream{s}; }

func clientStreamInterceptor(ctx context.Context, desc *grpc.StreamDesc, cc *grpc.ClientConn, method string, streamer grpc.Streamer, opts ...grpc.CallOption) (grpc.ClientStream, error) {
	log.Println("======= [Client Interceptor] ", method)
	s, err := streamer(ctx, desc, cc, method, opts...)
	if err != nil {
		return nil, err
	}
	return newWrappedStream(s), nil
}

func main() {
	conn, err := grpc.Dial(address, grpc.WithInsecure(),
		grpc.WithUnaryInterceptor(orderUnaryClientInterceptor),
		grpc.WithStreamInterceptor(clientStreamInterceptor),
	)
	defer conn.Close()

	c := pb.NewOrderManagementClient(conn)  // pb.New...Client()
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*5)
	defer cancel()
	...
}