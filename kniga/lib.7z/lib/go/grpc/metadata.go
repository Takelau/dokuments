
lib - google.golang.org/grpc/metadata
doc - pkg.go.dev/google.golang.org/grpc/metadata

// --------------------------------
метаданные передаются в HEADERS (не DATA) => 
HEADERS может быть как первым, так и последним блоком, сигнализирующим о прекращении передачи DATA

type MD map[string][]string

func New(m map[string]string) MD
func Pairs(kv ...string) MD
func Join(mds ...MD) MD

func (md MD) Append(k string, vals ...string)
func (md MD) Copy() MD
func (md MD) Delete(k string)
func (md MD) Get(k string) []string
func (md MD) Set(k string, vals ...string)
func (md MD) Len() int

// Out
func NewOutgoingContext(ctx context.Context, md MD) context.Context              // return context.WithValue(ctx, mdOutgoingKey{}, rawMD{md: md})
func AppendToOutgoingContext(ctx context.Context, kv ...string) context.Context
// from-Out
func FromOutgoingContext(ctx context.Context) (MD, bool)
func FromOutgoingContextRaw(ctx context.Context) (MD, [][]string, bool)

// In
func NewIncomingContext(ctx context.Context, md MD) context.Context              // return context.WithValue(ctx, mdIncomingKey{}, md)
// from-In
func FromIncomingContext(ctx context.Context) (MD, bool)


// --------------------------------
// создание
md := metadata.New(map[string]string{"k1":"v1", "k2":"v2"})
md := metadata.Pairs(
	"key1", "val1.1",
	"key1", "val1.2", // у "key1" будет значение []string{"val1.1", "val1.2"}
	"key2", "val2",
)


// --------------------------------
//    Client
// --------------------------------
md := metadata.Pairs("timestamp", time.Now().Format(time.StampNano), "kn", "vn",)
mdCtx := metadata.NewOutgoingContext(context.Background(), md)
ctxA  := metadata.AppendToOutgoingContext(mdCtx, "k1", "v1", "k1", "v2", "k2", "v3")

conn, _ := grpc.Dial(address, grpc.WithInsecure())
client := pb.NewOrderManagementClient(conn)  // New...Client()

// Unari
var header, trailer metadata.MD
res, _ := client.AddOrder(ctxA, &pb.Order{Id:"101"}, grpc.Header(&header), grpc.Trailer(&trailer))
if t, ok := header["timestamp"]; ok {
	for i, e := range t {...}
}

// Stream
stream, _ := client.UpdateOrders(mdCtx)
_ = stream.Send(&pb.Order{Id:"102"})
res, _ := stream.CloseAndRecv()
header, err := stream.Header()    // извлекаем заголовок
trailer     := stream.Trailer()   // извлекаем заключительный блок


// --------------------------------
//    Server
// --------------------------------
// серверное чтение
func (s *server) SomeRPC(ctx context.Context, in *pb.someRequest) (*pb.someResponse, error) {  // унарное чтение
	md, ok := metadata.FromIncomingContext(ctx)
	if t, ok := md["timestamp"]; ok {
		for i, e := range t {...}
	}
}

func (s *server) SomeStreamingRPC(stream pb.Service_SomeStreamingRPCServer) error {  // потоковое чтение
	md, ok := metadata.FromIncomingContext(stream.Context())
}

// серверная отправка
func (s *server) SomeRPC(ctx context.Context, in *pb.someRequest) (*pb.someResponse, error) {
	// создаем и отправляем заголовок
	header := metadata.Pairs("header-key", "val")
	grpc.SendHeader(ctx, header)
	// создаем и отправляем заключительный блок
	trailer := metadata.Pairs("trailer-key", "val")
	grpc.SetTrailer(ctx, trailer)
}

func (s *server) SomeStreamingRPC(stream pb.Service_SomeStreamingRPCServer) error {
	// создаем и отправляем заголовок
	header := metadata.Pairs("header-key", "val")
	stream.SendHeader(header)
	// создаем и отправляем заключительный блок
	trailer := metadata.Pairs("trailer-key", "val")
	stream.SetTrailer(trailer)
}