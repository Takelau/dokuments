
// -------------
// gRPC - public key/certificate | (no CA)
// -------------
// github.com/grpc-up-and-running/samples/tree/master/ch06/secure-channel/certs
1.1
openssl genrsa -out server.key 2048                                        // gRPC server {server.crt + server.key}
openssl req -new -x509 -sha256 -key server.key -out server.crt -days 3650  // grpc client {server.cr}

1.2 // for java application | Convert server/client keys to pem format
$ openssl pkcs8 -topk8 -inform pem -in server.key -outform pem -nocrypt -out server.pem
$ openssl pkcs8 -topk8 -inform pem -in client.key -outform pem -nocrypt -out client.pem