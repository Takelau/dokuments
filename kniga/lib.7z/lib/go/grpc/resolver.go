
lib - google.golang.org/grpc/resolver
doc - pkg.go.dev/google.golang.org/grpc/resolver

// --------------------------------
var defaultScheme = "passthrough"
var m = make(map[string]Builder)

type Builder interface {
	Build(target Target, cc ClientConn, opts BuildOptions) (Resolver, error)
	Scheme() string  // https://github.com/grpc/grpc/blob/master/doc/naming.md
}

type Target struct {
	Scheme    string  // Deprecated: use URL.Scheme instead.
	Authority string  // Deprecated: use URL.Host instead.
	Endpoint  string  // Deprecated: use URL.Path or URL.Opaque instead
	URL       url.URL
}

type Resolver interface {
	ResolveNow(ResolveNowOptions)
	Close()
}

type State struct {
	Addresses     []Address
	ServiceConfig *serviceconfig.ParseResult
	Attributes    *attributes.Attributes
}

type Address struct {
	Addr        string  // Addr is the server address on which a connection will be established.
	ServerName  string
	Attributes         *attributes.Attributes
	BalancerAttributes *attributes.Attributes
	Type     AddressType  // Deprecated: use Attributes instead.
	Metadata interface{}  // Deprecated: use Attributes instead.
}

func Register(b Builder)              // m[b.Scheme()] = b
func Get(scheme string) Builder
func SetDefaultScheme(scheme string)  // defaultScheme = scheme
func GetDefaultScheme() string

// --------------------------------
Target{URL.Scheme:"dns", URL.Host:"some_authority", URL.Path:"foo.bar"}  // dns://some_authority/foo.bar
Target{URL.Scheme:resolver.GetDefaultScheme(), URL.Path: "foo.bar"}      // foo.bar


// --------------------------------
//    New - github.com/grpc/grpc-go/tree/master/examples/features/load_balancing
// --------------------------------
//  Server
import(
	"google.golang.org/grpc"
)
var addrs = []string{":50051", ":50052"}

type ecServer struct {
	pb.UnimplementedEchoServer
	addr string
}
func (s *ecServer) UnaryEcho(ctx context.Context, req *pb.EchoRequest) (*pb.EchoResponse, error) {
	return &pb.EchoResponse{Message: fmt.Sprintf("%s (from %s)", req.Message, s.addr)}, nil
}

func startServer(addr string) {
	lis, _ := net.Listen("tcp", addr)
	s := grpc.NewServer()
	pb.RegisterEchoServer(s, &ecServer{addr: addr})  // Register...Server()
	if err := s.Serve(lis); err != nil {...}
}

func main() {
	for _, addr := range addrs {
		go func(addr string) {
			startServer(addr)
		}(addr)
	}
}

//  Client
import(
	"google.golang.org/grpc"
	"google.golang.org/grpc/resolver"
	"google.golang.org/grpc/credentials/insecure"
)
var addrs = []string{"localhost:50051", "localhost:50052"}

func init() {
	resolver.Register(&eBuilder{}) // <-- 1
}

func main() {
	conn, _ := grpc.Dial(
		"example:///lb.example.grpc.io",
		grpc.WithDefaultServiceConfig(`{"loadBalancingConfig": [{"round_robin":{}}]}`),
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	defer conn.Close()
	makeRPCs(conn, 10)
}

func makeRPCs(cc *grpc.ClientConn, n int) {
	c := pb.NewEchoClient(cc)  // New...Client()
	for i := 0; i < n; i++ {
		// callUnaryEcho(hwc, "this is examples/load_balancing")
		ctx, cancel := context.WithTimeout(context.Background(), time.Second);  defer cancel();
		r, _ := c.UnaryEcho(ctx, &pb.EchoRequest{Message: message})
		fmt.Println(r.Message)	
	}
}

type eBuilder struct{}  // type Builder interface {}

func (*eBuilder) Build(target resolver.Target, cc resolver.ClientConn, opts resolver.BuildOptions) (resolver.Resolver, error) {
	r := &exampleResolver{
		target: target,
		cc:     cc,
		addrsStore: map[string][]string{
			"lb.example.grpc.io": addrs,  // "lb.example.grpc.io": []{"localhost:50051", "localhost:50052"}
		},
	}
	r.start()
	return r, nil
}
func (*eBuilder) Scheme() string { return "example"; }

type eResolver struct {   // type Resolver interface {}
	target     resolver.Target
	cc         resolver.ClientConn
	addrsStore map[string][]string
}

func (r *eResolver) start() {
	addrStrs := r.addrsStore[r.target.Endpoint]  // -> r.target.URL.Path
	addrs := make([]resolver.Address, len(addrStrs))
	for i, s := range addrStrs {
		addrs[i] = resolver.Address{Addr: s}
	}
	r.cc.UpdateState(resolver.State{Addresses: addrs})
}
func (*eResolver) ResolveNow(o resolver.ResolveNowOptions) {}
func (*eResolver) Close() {}


// --------------------------------
//    Old
// --------------------------------
//  Server
import(
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	pb "..."
)

var addrs = []string{":50051", ":50052"}
type ecServer struct {
	addr string
}

func main() {
	for _,addr := range addrs {
		go func(addr string) {
			startServer(addr)
		}(addr)
	}
}

func startServer(addr string) {
	lis,_ := net.Listen("tcp", addr)
	s := grpc.NewServer()
	pb.RegisterEchoServer(s, &ecServer{addr: addr})  // Register...Server()
	if err := s.Serve(lis); err != nil {...}
}

//  Client
import (
	"google.golang.org/grpc"
	"google.golang.org/grpc/resolver"
)

var addrs = []string{"localhost:50051", "localhost:50052"}

func init() {
	resolver.Register(&eBuilder{})  // <-- 1
}

func main() {
	conn, _ := grpc.Dial(
		"example:///lb.example.grpc.io",
		grpc.WithBalancerName("round_robin"),  // -> WithDefaultServiceConfig(s string) DialOption
		grpc.WithInsecure(),                   // -> grpc.WithTransportCredentials(insecure.NewCredentials())
	)
	defer conn.Close()
	makeRPCs(conn, 10)
}

func makeRPCs(cc *grpc.ClientConn, n int) {
	hwc := pb.NewEchoClient(cc)  // New...Client()
	for i := 0; i < n; i++ {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second);  defer cancel();
		r, _ := c.UnaryEcho(ctx, &pb.EchoRequest{Message:"load_balancing"})
		fmt.Println(r.Message)
	}
}

type eBuilder struct{}   // type Builder interface {}

func (*eBuilder) Build(target resolver.Target, cc resolver.ClientConn, opts resolver.BuildOption) (resolver.Resolver, error) {
	r := &eResolver{
		target: target,
		cc:     cc,
		addrsStore: map[string][]string{
			"lb.example.grpc.io": addrs,   // "lb.example.grpc.io": "localhost:50051", "localhost:50052"
		},
	}
	r.start()
	return r, nil
}
func (*eBuilder) Scheme() string { return "example"; }

type eResolver struct {   // type Resolver interface {}
	target     resolver.Target
	cc         resolver.ClientConn
	addrsStore map[string][]string
}

func (r *eResolver) start() {
	addrStrs := r.addrsStore[r.target.URL.Path]
	addrs := make([]resolver.Address, len(addrStrs))
	for i, s := range addrStrs {
		addrs[i] = resolver.Address{Addr: s}
	}
	r.cc.UpdateState(resolver.State{Addresses: addrs})
}
func (*eResolver) ResolveNow(o resolver.ResolveNowOption) {}
func (*eResolver) Close() {}


