
// --------------------------------
//    Test
// --------------------------------


// --------------------------------
//    GoMock
// --------------------------------
// product_info.proto
syntax = "proto3";
import "google/protobuf/wrappers.proto";
package ecommerce;
service ProductInfo {
    rpc addProduct(Product) returns (google.protobuf.StringValue);
    rpc getProduct(google.protobuf.StringValue) returns (Product);
}
message Product {
    string id = 1;
    string name = 2;
    string description = 3;
    float price = 4;
}

// product_info.pb.go
type ProductInfoClient interface {
	AddProduct(ctx context.Context, in *Product, opts ...grpc.CallOption) (*wrappers.StringValue, error)
	GetProduct(ctx context.Context, in *wrappers.StringValue, opts ...grpc.CallOption) (*Product, error)
}
//      proto                    interface{}                                  
mockgen github.com/project/proto ProductInfoClient > mock_prodinfo/prodinfo_mock.go


// --------------------------------
//    bufconn
// --------------------------------
bufconn - предоставляет реализацию net.Conn на основе буфера и сопутствующие возможности, связанные с отправкой и приемом сообщений

import (
	"google.golang.org/grpc/test/bufconn"
)
const bufSize = 1024 * 1024

func initGRPCServerBuffConn() (*grpc.Server) {
	s := grpc.NewServer()
	pb.RegisterProductInfoServer(s, &server{})

	reflection.Register(s)

	listener = bufconn.Listen(bufSize)
	go func() {
		if err := s.Serve(listener); err != nil { log.Fatalf("failed to serve: %v", err); }
	}()

	return s
}

func main() {
	srv := initGRPCServerBuffConn()
	...
	srv.Close()
}

// --------------------------------
