// библиотека
// https://github.com/grpc-ecosystem/awesome-grpc#lang-go

// doc 
// metadata, compressor - https://github.com/grpc/grpc-go/tree/master/Documentation
// unit_testing         - https://github.com/grpc/grpc/tree/master/doc 

// codec
// ugorji / go - https://github.com/ugorji/go/tree/master/codec


// --------------------------------
//    Client & Server
// --------------------------------
import "google.golang.org/grpc/backoff"
type Config struct {
	BaseDelay  time.Duration // время задержки после первого сбоя
	Multiplier float64       // это коэффициент, на который умножаются отсрочки после неудачной повторной попытки. В идеале должно быть больше 1.
	Jitter     float64       // это фактор, с помощью которого случайным образом рандомизируются отсрочки
	MaxDelay time.Duration   // верхняя граница задержки отсрочки
}

import "google.golang.org/grpc"
// Connect Params
type ConnectParams struct {  // EXPERIMENTAL
	Backoff           backoff.Config
	MinConnectTimeout time.Duration
}

// Dial Option
type DialOption interface {}
func WithConnectParams(p ConnectParams) DialOption  // EXPERIMENTAL
func WithContextDialer(f func(context.Context, string) (net.Conn, error)) DialOption
func WithAuthority(a string) DialOption  // :authority pseudo-header | имя сервера для рукопожатия
func WithBlock() DialOption              // бликирует Dial до завершения устновки соединения, в противном случае - в фоне
func WithKeepaliveParams(kp keepalive.ClientParameters) DialOption
func WithInitialWindowSize(s int32) DialOption  // sets the value for initial window size on a stream
func WithReadBufferSize(s int) DialOption       // default 32KB
func WithWriteBufferSize(s int) DialOption      // default 32KB
func WithReturnConnectionError() DialOption     // использовать совместно с WithBlock()
func WithUserAgent(s string) DialOption
func WithUnaryInterceptor(f UnaryClientInterceptor)   DialOption  <-- Unary  Client Interceptor
func WithStreamInterceptor(f StreamClientInterceptor) DialOption  <-- Stream Client Interceptor
func WithChainUnaryInterceptor(interceptors  ...UnaryClientInterceptor)  DialOption  <-- Unary Client Interceptor
func WithChainStreamInterceptor(interceptors ...StreamClientInterceptor) DialOption  <-- Chain Stream Interceptor

func WithInsecure() DialOption --> grpc.WithTransportCredentials(insecure.NewCredentials())  // "google.golang.org/grpc/credentials/insecure"

// CallOption
type CallOption interface {}
func Header(md *metadata.MD) CallOption          // извлекает метаданные заголовка для унарного RPC
func MaxCallRecvMsgSize(bytes int) CallOption    // устанавливает максимальный размер сообщения в байтах, который может получить клиент
func MaxCallSendMsgSize(bytes int) CallOption    // устанавливает максимальный размер сообщения в байтах, который может отправить клиент
func MaxRetryRPCBufferSize(bytes int) CallOption // ограничивает объем памяти, используемый для буферизации запросов этого RPC для повторных попыток
func Peer(p *peer.Peer) CallOption
func Trailer(md *metadata.MD) CallOption         // извлекает метаданные трейлера для унарного RPC
func WaitForReady(waitForReady bool) CallOption  // TRANSIENT_FAILURE | By default, RPCs don't "wait for ready"

// Client
type ClientConn struct { }
func Dial(target string, opts ...DialOption) (*ClientConn, error)
func DialContext(ctx context.Context, target string, opts ...DialOption) (conn *ClientConn, err error)
func (cc *ClientConn) Close() error
func (cc *ClientConn) Connect()
func (cc *ClientConn) NewStream(ctx context.Context, desc *StreamDesc, method string, opts ...CallOption) (ClientStream, error)
func (cc *ClientConn) GetState() connectivity.State  // {Idle, Connecting, Ready, TransientFailure, Shutdown}
func (cc *ClientConn) WaitForStateChange(ctx context.Context, sourceState connectivity.State) bool

// Client Stream
type ClientStream interface {
	Header() (metadata.MD, error) // мета от сервера | блокируется, если мета еще не могут быть прочитаны
	Trailer() metadata.MD         // мета от сервера | только после stream.CloseAndRecv() или stream.Recv() с err != nil
	CloseSend() error             // не запускать в разных горутинах c SendMsg()
	Context() context.Context
	SendMsg(m interface{}) error  // безопасно, если SendMsg() && RecvMsg() вызываются в разных go(), но в одном потоке
	RecvMsg(m interface{}) error  // не безопасно вызывать RecvMsg() || SendMsg() в одном потоке, но в разных go()
}
func NewClientStream(ctx context.Context, desc *StreamDesc, cc *ClientConn, method string, opts ...CallOption) (ClientStream, error)

// Server Option
type ServerOption interface {}
func ConnectionTimeout(d time.Duration) ServerOption         // default 120 seconds
func Creds(c credentials.TransportCredentials) ServerOption  // TLS, SSL
func HeaderTableSize(s uint32) ServerOption  // Experimental
func ReadBufferSize(s int) ServerOption      // 32KB
func WriteBufferSize(s int) ServerOption     // 32KB
func NumStreamWorkers(numServerWorkers uint32) ServerOption  // def 0 - disable workers and spawn a new goroutine for each stream
func MaxConcurrentStreams(n uint32) ServerOption   // max конкурентных потоков для каждого ServerTransport
func MaxHeaderListSize(s uint32) ServerOption      // uncompressed
func MaxRecvMsgSize(m int) ServerOption            // def 4MB
func MaxSendMsgSize(m int) ServerOption            // def math.MaxInt32
func InitialConnWindowSize(s int32) ServerOption // window size on a connection
func InitialWindowSize(s int32) ServerOption     // sets window size for stream
func StreamInterceptor(i StreamServerInterceptor) ServerOption  <-- Stream Server Interceptor
func UnaryInterceptor(i UnaryServerInterceptor)   ServerOption  <-- Unary  Server Interceptor
func ChainUnaryInterceptor(interceptors  ...UnaryServerInterceptor)  ServerOption  <-- Unary  Server Interceptor
func ChainStreamInterceptor(interceptors ...StreamServerInterceptor) ServerOption  <-- Stream Server Interceptor

// server
type Server struct {}
func NewServer(opt ...ServerOption) *Server
func (s *Server) GetServiceInfo() map[string]ServiceInfo
func (s *Server) RegisterService(sd *ServiceDesc, ss interface{})  // вызывается до Serve()
func (s *Server) Serve(lis net.Listener) error
func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request)  // Experimental
func (s *Server) GracefulStop()  // прекращение получения новых сообщений и ожидание завершения текущих
func (s *Server) Stop()          // немедленно завершает все 'connections' и 'listeners'

// Transport Credentials
type TransportCredentials interface {
	ClientHandshake(context.Context, string, net.Conn) (net.Conn, AuthInfo, error)
	ServerHandshake(net.Conn) (net.Conn, AuthInfo, error)
	Info() ProtocolInfo
	Clone() TransportCredentials
	OverrideServerName(string) error
}
func NewTLS(c *tls.Config) TransportCredentials
func NewClientTLSFromCert(cp *x509.CertPool, serverNameOverride string) TransportCredentials  // client
func NewClientTLSFromFile(certFile, serverNameOverride string) (TransportCredentials, error)  // client
func NewServerTLSFromCert(cert *tls.Certificate) TransportCredentials                         // server
func NewServerTLSFromFile(certFile, keyFile string) (TransportCredentials, error)             // server

// Server Stream
type ServerStream interface {
	SetHeader(metadata.MD) error    // sets the header metadata
	SendHeader(metadata.MD) error
	SetTrailer(metadata.MD)         // metadata, возвращаемые вместе с 'RPC status
	Context() context.Context
	SendMsg(m interface{}) error
	RecvMsg(m interface{}) error
}

// Server Transport Stream
type ServerTransportStream interface {  // Experimental
	Method() string
	SetHeader(md metadata.MD) error
	SendHeader(md metadata.MD) error
	SetTrailer(md metadata.MD) error
}
func ServerTransportStreamFromContext(ctx context.Context) ServerTransportStream


// --------------------------------
//    Перехватчики (Interceptor)
// --------------------------------
1. Унарные
// server
type UnaryServerInfo struct {
	Server     interface{}  // service implementation the user provides. This is read-only
	FullMethod string       // full RPC method string, i.e., /package.service/method
}
type UnaryHandler func(ctx context.Context, req interface{}) (interface{}, error)   // called to complete RPCs
type UnaryServerInterceptor func(ctx context.Context, req interface{}, info *UnaryServerInfo, handler UnaryHandler) (resp interface{}, err error)

func UnaryInterceptor(i UnaryServerInterceptor) ServerOption                     // o.streamInt = i
func ChainUnaryInterceptor(interceptors ...UnaryServerInterceptor) ServerOption  // o.chainUnaryInts = append(o.chainUnaryInts, interceptors...)

// client
type UnaryInvoker func(ctx context.Context, method string, req, reply interface{}, cc *ClientConn, opts ...CallOption) error   // called to complete RPCs
type UnaryClientInterceptor func(ctx context.Context, method string, req, reply interface{}, cc *ClientConn, invoker UnaryInvoker, opts ...CallOption) error

func WithUnaryInterceptor(f UnaryClientInterceptor) DialOption                     <-- Unary Client Interceptor
func WithChainUnaryInterceptor(interceptors ...UnaryClientInterceptor) DialOption  <-- Unary Client Interceptor


2. Потоковые
// server
type StreamServerInfo struct {
	FullMethod     string  // full RPC method string, i.e., /package.service/method
	IsClientStream bool    // indicates whether the RPC is a client streaming RPC
	IsServerStream bool    // indicates whether the RPC is a server streaming RPC
}
type StreamHandler func(srv interface{}, stream ServerStream) error
type StreamServerInterceptor func(srv interface{}, ss ServerStream, info *StreamServerInfo, handler StreamHandler) error

func StreamInterceptor(i StreamServerInterceptor) ServerOption                     // o.streamInt = i
func ChainStreamInterceptor(interceptors ...StreamServerInterceptor) ServerOption  // o.chainStreamInts = append(o.chainStreamInts, interceptors...)

// client
type StreamDesc struct {   // StreamName and Handler are only used when registering handlers on a server
	StreamName string        // the name of the method excluding the service
	Handler    StreamHandler // the handler called for the method
	ServerStreams bool       // indicates the server can perform streaming sends
	ClientStreams bool       // indicates the client can perform streaming sends
}
type Streamer func(ctx context.Context, desc *StreamDesc, cc *ClientConn, method string, opts ...CallOption) (ClientStream, error)
type StreamClientInterceptor func(ctx context.Context, desc *StreamDesc, cc *ClientConn, method string, streamer Streamer, opts ...CallOption) (ClientStream, error)

func WithStreamInterceptor(f StreamClientInterceptor) DialOption                     <-- Stream Client Intercepto
func WithChainStreamInterceptor(interceptors ...StreamClientInterceptor) DialOption  <-- Chain  Stream Interceptor


// --------------------------------
//    uuid
// --------------------------------
import (
	"github.com/gofrs/uuid"
)
out, err := uuid.NewV4()


// --------------------------------
//    Error
// --------------------------------
import (
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	epb "google.golang.org/genproto/googleapis/rpc/errdetails"
)
1. status.New(codes.OK, "").Err()
2. status.Errorf(codes.NotFound, "Product does not exist", in.Value)
3.
ds,err := status.New(codes.InvalidArgument, "Invalid information received").WithDetails(
	&epb.BadRequest_FieldViolation{
		Field: "ID",
		Description: fmt.Sprintf("Order ID received is not valid %s : %s", orderReq.Id, orderReq.Description),
	},
)
if err == nil {...}
ds.Err()


codes.OK       = 0  // выполнено успашно
codes.Canceled = 1  // Операция была отменена (вызывающей стороной
codes.Unknown  = 2  // неизвестная ошибка
codes.InvalidArgument    = 3  // Клиент указал недопустимый аргумент (не создается gRPC)
codes.DeadlineExceeded   = 4  // operation expired before completion
codes.NotFound           = 5  // Не удалось найти запрошенный элемент
codes.AlreadyExists      = 6  // Элемент, который клиент пытался создать, уже существует
codes.PermissionDenied   = 7  // 
codes.ResourceExhausted  = 8  // Исчерпан какой-то ресурс (out-of-memory and server overload situations)
codes.FailedPrecondition = 9  // Операция была отклонена (не создается gRPC)
codes.Aborted            = 10 // Операция была прервана (не создается gRPC - operation was aborted | concurrency issue like sequencer check failures | transaction aborts)
codes.OutOfRange         = 11 // Попытка выполнения операции за пределами допустимого диапазона (не создается gRPC)
codes.Unimplemented      = 12 // Операция не реализована / error code when a method implementation is missing on the server
codes.Internal           = 13 // Внутренние ошибки
codes.Unavailable        = 14 // Сервис временно не доступен
codes.DataLoss           = 15 // Потеря или повреждение данных (не создается gRPC)
codes.Unauthenticate     = 16 // Запрос не содержит аутентификационных данных / this error code when the authentication metadata is invalid or a Credentials callback fails


// --------------------------------
//    Install
// --------------------------------
go get -u google.golang.org/grpc
go get -u google.golang.org/protobuf/{proto,protoc-gen-go}
go install google.golang.org/protobuf/cmd/protoc-gen-go@latest  // > go 1.16
go install google.golang.org/grpc/cmd/protoc-gen-go-grpc@latest

// protoc - https://github.com/protocolbuffers/protobuf/releases
unzip protoc-3.19.4-linux-x86_64.zip -d $HOME/.local
export PATH="$PATH:$HOME/.local/bin"

// plugins
go install google.golang.org/grpc/cmd/protoc-gen-go-grpc
export PATH="$PATH:$(go env GOPATH)/bin"
import "google.golang.org/grpc"

// turn on logging
export GRPC_GO_LOG_VERBOSITY_LEVEL=99
export GRPC_GO_LOG_SEVERITY_LEVEL=info

// Go module support
go mod edit -replace=google.golang.org/grpc=github.com/grpc/grpc-go@latest
go mod tidy
go mod vendor
go build -mod=vendor
