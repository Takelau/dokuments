
// --------------------------------
//    TLS
// --------------------------------

1. Однонаправленное защищенное соединение; задействуется CA (certificate authority)

OpenSSL, mkcert, certstrap
server.key            // закрытый RSA-ключ, с помощью которого подписывается и аутентифицируется открытый ключ
server.pem/server.crt // самоподписанные открытые X.509-ключи для публичного распространения

// github.com/grpc-up-and-running/samples/tree/master/ch06/secure-channel/go

// Server
import (
	"crypto/tls"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	...
)

const (
	port = ":50051"
	crtFile = filepath.Join("certs", "server.crt")
	keyFile = filepath.Join("certs", "server.key")
)

type server struct {
	productMap map[string]*pb.Product
}
func (s *server) AddProduct(ctx context.Context, in *pb.Product) (*wrapper.StringValue, error) {...}

func main() {
	cert, err := tls.LoadX509KeyPair(crtFile, keyFile);   if err != nil {...}
	opts := []grpc.ServerOption{
		grpc.Creds(credentials.NewServerTLSFromCert(&cert)),
	}

	s := grpc.NewServer(opts...)
	pb.RegisterProductInfoServer(s, &server{})  // Register...Server()

	lis, err := net.Listen("tcp", port);  if err != nil {...}
	err = s.Serve(lis);                   if err != nil {...}
}

// Client
import (
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

const (
	address = "localhost:50051"
	hostname = "localhost"
	crtFile = filepath.Join("certs", "server.crt")  // путь к сертификату
)

func main() {
	creds, _ := credentials.NewClientTLSFromFile(crtFile, hostname)
	opts := []grpc.DialOption{
		grpc.WithTransportCredentials(creds),
	}

	conn, _ := grpc.Dial(address, opts...);   defer conn.Close();
	c := pb.NewProductInfoClient(conn)  // New...Client()

	ctx, cancel := context.WithTimeout(context.Background(), time.Second);  defer cancel();
	r, err := c.AddProduct(ctx, &pb.Product{Name:"test"})
	...
}


2. Двусторонняя аутентификация mTLS

server.key - закрытый RSA-ключ сервера
server.crt - публичный сертификат сервера
client.key - закрытый RSA-ключ клиента
client.crt - публичный сертификат клиента
ca.crt     - публичный сертификат удостоверяющего центра, с помощью которого подписываются все публичные сертификаты

// Server
import (
	"crypto/tls"
	"crypto/x509"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

var (
	port = ":50051"
	crtFile = filepath.Join("ch06", "mutual-tls-channel", "certs", "server.crt")
	keyFile = filepath.Join("ch06", "mutual-tls-channel", "certs", "server.key")
	caFile  = filepath.Join("ch06", "mutual-tls-channel", "certs", "ca.crt")
)

type server struct {
	productMap map[string]*pb.Product
}
func (s *server) AddProduct(ctx context.Context, in *pb.Product) (*wrapper.StringValue, error) {...}

func main() {
	certificate, _ := tls.LoadX509KeyPair(crtFile, keyFile)
	certPool := x509.NewCertPool()
	ca, _ := ioutil.ReadFile(caFile)

	if ok := certPool.AppendCertsFromPEM(ca); !ok { log.Fatalf(...); }

	opts := []grpc.ServerOption{
		grpc.Creds(    // Create the TLS credentials
			credentials.NewTLS(&tls.Config {
				ClientAuth:   tls.RequireAndVerifyClientCert,
				Certificates: []tls.Certificate{certificate},
				ClientCAs:    certPool,
			},
		)),
	}

	s := grpc.NewServer(opts...)
	pb.RegisterProductInfoServer(s, &server{})

	lis, _ := net.Listen("tcp", port)
	if err := s.Serve(lis); err != nil {...}
}

// Client
import (
	"crypto/tls"
	"crypto/x509"
	"google.golang.org/grpc/credentials"
)

var (
	address  = "localhost:50051"
	hostname = "localhost"
	crtFile = filepath.Join("ch06", "mutual-tls-channel", "certs", "client.crt")
	keyFile = filepath.Join("ch06", "mutual-tls-channel", "certs", "client.key")
	caFile  = filepath.Join("ch06", "mutual-tls-channel", "certs", "ca.crt")
)

func main() {
	certificate, _ := tls.LoadX509KeyPair(crtFile, keyFile)
	certPool := x509.NewCertPool()
	ca, _ := ioutil.ReadFile(caFile)

	if ok := certPool.AppendCertsFromPEM(ca); !ok {...}

	opts := []grpc.DialOption{
		grpc.WithTransportCredentials( credentials.NewTLS(&tls.Config{
			ServerName:   hostname,   // NOTE: this is required!
			Certificates: []tls.Certificate{certificate},
			RootCAs:      certPool,
		})),
	}

	conn, _ := grpc.Dial(address, opts...);  defer conn.Close();
	c := pb.NewProductInfoClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second);  defer cancel();
	r, _ := c.AddProduct(ctx, &pb.Product{Name:"test"})

	product, err := c.GetProduct(ctx, &wrapper.StringValue{Value: r.Value})
}

