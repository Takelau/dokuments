
// --------------------------------
// DeadLine
// --------------------------------

DEADLINE_EXCEEDED

if ctx.Err() == context.DeadlineExceeded { return nil, ctx.Err(); }

// --------------------------------
1. Unary
// Client
func main() {
	conn, _ := grpc.Dial(address, grpc.WithInsecure()); defer conn.Close();
	c := pb.NewOrderManagementClient(conn)  // New...Client()

	ctx, cancel := context.WithDeadline(context.Background(), time.Now().Add(time.Duration(2 * time.Second)));  defer cancel();
	res, err := c.AddOrder(ctx, &pb.Order{Id:"101"})
	if err != nil {
		log.Printf("Error Occured -> addOrder : , %v:", status.Code(addErr))
	}
}

// Server
func (s *server) AddOrder(ctx context.Context, orderReq *pb.Order) (*wrappers.StringValue, error) {
	if ctx.Err() == context.DeadlineExceeded {
		return nil, ctx.Err()
	}
	...
}

// --------------------------------
2. Server Stream
// CLient
func main() {
	...
	stream, _ := client.SearchOrders(ctx, &wrapper.StringValue{Value: "Google"})
	for {
		searchOrder, err := searchStream.Recv()
		if err == io.EOF { break; }
		if err == nil {...}
	}
}

// Server
func (s *server) SearchOrders(searchQuery *wrappers.StringValue, stream pb.OrderManagement_SearchOrdersServer) error {
	for key, order := range orderMap {
		for _, itemStr := range order.Items {
			if strings.Contains(itemStr, searchQuery.Value) {
				err := stream.Send(&order)
				break
			}
		}
	}
	return nil
}

// --------------------------------
3. Client Stream
// Client
func main() {
	...
	csu, _ := client.UpdateOrders(ctx)
	_ = csu.Send(&pb.Order{Id:"102"})
	res, _ := csu.CloseAndRecv()
	log.Printf("Update Orders Res : ", res)
}

// Server
func (s *server) UpdateOrders(stream pb.OrderManagement_UpdateOrdersServer) error {
	ordersStr := "Updated Order IDs : "
	for {
		order, err := stream.Recv()
		if err == io.EOF {
			return stream.SendAndClose(&wrapper.StringValue{Value: "Orders processed " + ordersStr})
		}
		orderMap[order.Id] = *order
		ordersStr += order.Id + ", "
	}
}

// --------------------------------
4. Dual Stream
// Client
func main() {
	...
	csp, _ := client.ProcessOrders(ctx)
	_ = csp.Send(&wrapper.StringValue{Value:"102"})  // ...
	channel := make(chan bool, 1)
	go asncClientBidirectionalRPC(csp, channel)
	time.Sleep(time.Millisecond * 1000)

	_ = csp.CloseSend()
	<- channel
}

func asncClientBidirectionalRPC (csp pb.OrderManagement_ProcessOrdersClient, c chan bool) {
	for {
		res, err := csp.Recv()
		if err == io.EOF { break; }
		log.Printf("Combined shipment : ", res.OrdersList)
	}
	c <- true
}

// Server
func (s *server) ProcessOrders(stream pb.OrderManagement_ProcessOrdersServer) error {
	batchMarker := 1  // отправка по частям
	combinedShipmentMap := make(map[string]pb.CombinedShipment)
	for {
		orderId, err := stream.Recv()
		if err == io.EOF {
			err = stream.Send(...); if err != nil { ... }
			return nil
		}
		if err != nil { return err; }
		... batch algritm ... // github.com/grpc-up-and-running/samples/blob/master/ch05/deadlines/order-service/go/server/main.go
	}
}


// --------------------------------
// Error
// --------------------------------

// Server Unary
import (
	"google.golang.org/grpc/status"
	"google.golang.org/grpc/codes"
	epb "google.golang.org/genproto/googleapis/rpc/errdetails"
)

func (s *server) AddOrder(ctx context.Context, orderReq *pb.Order) (*wrappers.StringValue, error) {
	if orderReq.Id == "-1" {
		// формирование ошибки
		errStatus := status.New(codes.InvalidArgument, "Invalid information received")
		ds, err := errStatus.WithDetails(
			&epb.BadRequest_FieldViolation{
				Field:"ID",
				Description: fmt.Sprintf("Order ID received is not valid %s : %s", orderReq.Id, orderReq.Description),
			},
		)
		if err != nil { return nil, errStatus.Err(); }
		return nil, ds.Err()

	} else {
		orderMap[orderReq.Id] = *orderReq
		log.Println("Order : ", orderReq.Id, " -> Added")
		return &wrapper.StringValue{Value: "Order Added: " + orderReq.Id}, nil
	}
}

// Client Unary
func main() {
	conn, _ := grpc.Dial(address, grpc.WithInsecure());  defer conn.Close();
	client := pb.NewOrderManagementClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second * 5);  defer cancel();
	res, addErr := client.AddOrder(ctx, &pb.Order{Id:"-1"})
	// обработка ошибки
	if addErr != nil {
		errCode := status.Code(addErr)
		if errCode == codes.InvalidArgument {
			errStatus := status.Convert(addErr)
			for _, d := range errStatus.Details() {
				switch info := d.(type) {
				case *epb.BadRequest_FieldViolation:
					log.Printf("Request Field Invalid: %s", info)
				default:
					log.Printf("Unexpected error type: %s", info)
				}
			}
		} else { log.Printf("Unhandled error : %s ", errCode); }
	} else { log.Print("AddOrder Response -> ", res.Value); }
}


