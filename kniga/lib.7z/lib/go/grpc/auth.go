
// --------------------------------
//    Auth
// --------------------------------

1. base:   Authorization: Basic YWRtaW46YWRtaW4=
2. token:  JSON Web Tokens (JWTs), ...


1. base

godoc.org/google.golang.org/grpc/metadata#New
pkg.go.dev/google.golang.org/grpc/credentials

type PerRPCCredentials interface {
	GetRequestMetadata(ctx context.Context, uri ...string) (map[string]string, error)
	RequireTransportSecurity() bool
}

// Server
import (
	"strings"
	"encoding/base64"
	"crypto/tls"
	"encoding/base64"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"  <-- PerRPCCredentials{}
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
)

var (
	port = ":50051"
	errMissingMetadata = status.Errorf(codes.InvalidArgument, "missing metadata")
	errInvalidToken    = status.Errorf(codes.Unauthenticated, "invalid credentials")
)

func (s *server) AddProduct(ctx context.Context, in *pb.Product) (*wrapper.StringValue, error) {...}

func main() {
	cert, _ := tls.LoadX509KeyPair(filepath.Join("certs","server.crt"), filepath.Join("certs","server.key"))
	opts := []grpc.ServerOption{
		grpc.Creds(credentials.NewServerTLSFromCert(&cert)),
		grpc.UnaryInterceptor(ensureValidBasicCredentials),
	}

	s := grpc.NewServer(opts...)
	pb.RegisterProductInfoServer(s, &server{})  // Register...Server()

	lis, _ := net.Listen("tcp", port)
	if err := s.Serve(lis); err != nil {...}
}

func ensureValidBasicCredentials(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok { return nil, errMissingMetadata; }
	// The keys within metadata.MD are normalized to lowercase.
	// https://godoc.org/google.golang.org/grpc/metadata#New
	if !valid(md["authorization"]) {
		return nil, errInvalidToken
	}
	return handler(ctx, req)
}

func valid(authorization []string) bool {
	if len(authorization) < 1 { return false; }
	token := strings.TrimPrefix(authorization[0], "Basic ")
	return token == base64.StdEncoding.EncodeToString([]byte("admin:admin"))
}


// Client
import (
	"encoding/base64"
	"google.golang.org/grpc/credentials"
)

const address = "localhost:50051"

func main() {
	creds, _ := credentials.NewClientTLSFromFile(filepath.Join("certs", "server.crt"), "localhost")
	auth := basicAuth{ username:"admin", password:"admin", }
	opts := []grpc.DialOption{
		grpc.WithPerRPCCredentials(auth),
		grpc.WithTransportCredentials(creds),
	}

	conn, _ := grpc.Dial(address, opts...);  defer conn.Close();
	c := pb.NewProductInfoClient(conn)   // New...Client

	ctx, cancel := context.WithTimeout(context.Background(), time.Second);  defer cancel();
	r, _ := c.AddProduct(ctx, &pb.Product{Name:"test"})
}

type basicAuth struct {  // type PerRPCCredentials interface {}
	username string
	password string
}

func (b basicAuth) GetRequestMetadata(ctx context.Context, in ...string) (map[string]string, error) {
	auth := b.username + ":" + b.password
	enc := base64.StdEncoding.EncodeToString([]byte(auth))
	return map[string]string{"authorization": "Basic "+enc}, nil
}

func (b basicAuth) RequireTransportSecurity() bool {
	return true
}


2. token

pkg.go.dev/golang.org/x/oauth2

type Token struct {
	AccessToken  string    `json:"access_token"`
	TokenType    string    `json:"token_type,omitempty"`
	RefreshToken string    `json:"refresh_token,omitempty"`
	Expiry       time.Time `json:"expiry,omitempty"`
	raw interface{}
}
func (t *Token) SetAuthHeader(r *http.Request)
func (t *Token) Valid() bool
func (t *Token) Extra(key string) interface{}
func (t *Token) WithExtra(extra interface{}) *Token


// Server
import(
	"crypto/tls"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
)

var (
	port               = ":50051"
	crtFile            = filepath.Join("certs", "server.crt")
	keyFile            = filepath.Join("certs", "server.key")
	errMissingMetadata = status.Errorf(codes.InvalidArgument, "missing metadata")
	errInvalidToken    = status.Errorf(codes.Unauthenticated, "invalid token")
)

func (s *server) AddProduct(ctx context.Context, in *pb.Product) (*pb.ProductID, error) {...}

func main() {
	cert, _ := tls.LoadX509KeyPair(crtFile, keyFile)
	opts := []grpc.ServerOption{
		grpc.Creds(credentials.NewServerTLSFromCert(&cert)),
		grpc.UnaryInterceptor(ensureValidToken),
	}

	s := grpc.NewServer(opts...)
	pb.RegisterProductInfoServer(s, &server{})  // register...Server()

	lis, _ := net.Listen("tcp", port)
	if err := s.Serve(lis); err != nil {...}
}

func ensureValidToken(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok { return nil, errMissingMetadata; }
	if !valid(md["authorization"]) {
		return nil, errInvalidToken
	}
	return handler(ctx, req)
}

func valid(authorization []string) bool {
	if len(authorization) < 1 { return false; }
	token := strings.TrimPrefix(authorization[0], "Bearer ")
	return token == "some-secret-token"
}


// Client
import (
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/credentials/oauth"
	"golang.org/x/oauth2"
)

const (
	address  = "localhost:50051"
	hostname = "localhost"
)

func main() {
	perRPC := oauth.NewOauthAccess(fetchToken())
	crtFile := filepath.Join("certs", "server.crt")
	creds, _ := credentials.NewClientTLSFromFile(crtFile, hostname)

	opts := []grpc.DialOption{
		grpc.WithPerRPCCredentials(perRPC),
		grpc.WithTransportCredentials(creds),
	}

	conn, _ := grpc.Dial(address, opts...);  defer conn.Close();
	c := pb.NewProductInfoClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second);  defer cancel();
	r, _ := c.AddProduct(ctx, &pb.Product{Name:"test"})
}

func fetchToken() *oauth2.Token {
	return &oauth2.Token{
		AccessToken: "some-secret-token",
	}
}
