

// --------------------------------
// Proto Buf
// --------------------------------
var _OrderManagement_serviceDesc = grpc.ServiceDesc{  ServiceName:"ecommerce.OrderManagement",  HandlerType:(*OrderManagementServer)(nil),
	Methods: []grpc.MethodDesc{
		{ MethodName:"addOrder",  Handler:_OrderManagement_AddOrder_Handler, },  // Unary
	},
	Streams: []grpc.StreamDesc{
		{ StreamName:"searchOrders",   Handler:_OrderManagement_SearchOrders_Handler,   ServerStreams:true, },  // Stream Server
		{ StreamName:"updateOrders",   Handler:_OrderManagement_UpdateOrders_Handler,   ClientStreams:true, },  // Stream Client
		{ StreamName:"processOrders",  Handler:_OrderManagement_ProcessOrders_Handler,  ServerStreams:true,  ClientStreams:true, },
	},
	Metadata: "order_management.proto",
}

// Unary
func _OrderManagement_AddOrder_Handler(srv interface{}, ctx context.Context, dec func(interface{}) error, interceptor grpc.UnaryServerInterceptor) (interface{}, error) {
	in := new(Order)
	if err := dec(in); err != nil { return nil, err; }
	if interceptor == nil {
		return srv.(OrderManagementServer).AddOrder(ctx, in)
	}
	info := &grpc.UnaryServerInfo{ Server:srv, FullMethod:"/ecommerce.OrderManagement/AddOrder", }
	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return srv.(OrderManagementServer).AddOrder(ctx, req.(*Order))
	}
	return interceptor(ctx, in, info, handler)
}

// Stream Server
func _OrderManagement_SearchOrders_Handler(srv interface{}, stream grpc.ServerStream) error {
	m := new(wrappers.StringValue)
	if err := stream.RecvMsg(m); err != nil {
		return err
	}
	return srv.(OrderManagementServer).SearchOrders(m, &orderManagementSearchOrdersServer{stream})
}

// Stream Client
func _OrderManagement_UpdateOrders_Handler(srv interface{}, stream grpc.ServerStream) error {
	return srv.(OrderManagementServer).UpdateOrders(&orderManagementUpdateOrdersServer{stream})
}

// Streem Dual
func _OrderManagement_ProcessOrders_Handler(srv interface{}, stream grpc.ServerStream) error {
	return srv.(OrderManagementServer).ProcessOrders(&orderManagementProcessOrdersServer{stream})
}


// --------------------------------
// Unari
// --------------------------------
// proto
syntax = "proto3";
package ecommerce;
message Product {
	string id = 1;
	string name = 2;
}
message ProductID {
	string value = 1;
}
service ProductInfo {
	rpc addProduct(Product) returns (ProductID);
	rpc getProduct(ProductID) returns (Product);
}

// server
type productInfo struct {
	productMap map[string]*pb.Product
}
func (s *server) AddProduct(ctx context.Context, in *pb.Product)   (*pb.ProductID, error) {...}
func (s *server) GetProduct(ctx context.Context, in *pb.ProductID) (*pb.Product,   error) {...}

func main() {
	lis, _ := net.Listen("tcp", ":3000")
	s := grpc.NewServer()
	pb.RegisterProductInfoServer(s, &productInfo{})  // pb.Register...Server()
	if err := s.Serve(lis); err != nil {...}
}

// client
func main() {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	conn, err := grpc.Dial(":3000", grpc.WithInsecure());   if err != nil {...}
	defer conn.Close()

	c := pb.NewProductInfoClient(conn)  // pb.New...Client()
	r, err := c.AddProduct(ctx, &pb.Product{Name: name, Description: description, Price: price});   if err != nil {...}
}


// --------------------------------
// Streem Server
// --------------------------------
// proto
service OrderManagement {
	rpc searchOrders(google.protobuf.StringValue) returns (stream Order);
}
message Order {
	string id = 1;
}

// .pb.go
type Order struct {  Id string `protobuf:"bytes,1,opt,name=id,proto3" json:"id,omitempty"`;  }
type OrderManagementClient interface {  SearchOrders(ctx context.Context, in *wrappers.StringValue, opts ...grpc.CallOption) (OrderManagement_SearchOrdersClient, error);  }
type OrderManagementServer interface {  SearchOrders(*wrappers.StringValue, OrderManagement_SearchOrdersServer) error;  }
type OrderManagement_SearchOrdersClient interface {  Recv() (*Order, error);  grpc.ClientStream;  }
type OrderManagement_SearchOrdersServer interface {  Send(*Order) error;      grpc.ServerStream;  }

// server
var orderMap = make(map[string]pb.Order)
type server struct {
	orderMap map[string]*pb.Order
}

func (s *server) SearchOrders(searchQuery *wrappers.StringValue, stream pb.OrderManagement_SearchOrdersServer) error {
	for key, order := range orderMap {
		for _, itemStr := range order.Items {
			if strings.Contains(itemStr, searchQuery.Value) {
				err := stream.Send(&order)
				break
			}
		}
	}
	return nil
}

// client
func main() {
	conn, err := grpc.Dial(address, grpc.WithInsecure());  	defer conn.Close();
	client := pb.NewOrderManagementClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*5);  defer cancel();

	searchStream, _ := client.SearchOrders(ctx, &wrapper.StringValue{ Value:"Google" })
	for {
		searchOrder, err := searchStream.Recv()
		if err == io.EOF { break; }
		if err == nil { ... }
	}
}


// --------------------------------
// Streem Client
// --------------------------------
// proto
service OrderManagement {
	rpc updateOrders(stream Order) returns (google.protobuf.StringValue);
}
message Order {
	string id = 1;
}

// .pb.go
type OrderManagementClient interface { UpdateOrders(ctx context.Context, opts ...grpc.CallOption) (OrderManagement_UpdateOrdersClient, error); }
type OrderManagementServer interface { UpdateOrders(OrderManagement_UpdateOrdersServer) error; }
type OrderManagement_UpdateOrdersClient interface { Send(*Order) error;      CloseAndRecv() (*wrappers.StringValue, error);  grpc.ClientStream; }
type OrderManagement_UpdateOrdersServer interface { Recv() (*Order, error);  SendAndClose(*wrappers.StringValue) error;      grpc.ServerStream; }

// server
func (s *server) UpdateOrders(stream pb.OrderManagement_UpdateOrdersServer) error {
	for {
		order, err := stream.Recv()
		if err == io.EOF {
			return stream.SendAndClose(&wrapper.StringValue{ Value:"Orders processed" })
		}
	}
}

// client
stream, err := client.UpdateOrders(ctx)
for _, order := range orderList{
	if err := stream.Send(&order); err != nil { ... }
}
res, err := stream.CloseAndRecv()


// --------------------------------
// Streem Dual
// --------------------------------
// proto
service OrderManagement {
	rpc processOrders(stream google.protobuf.StringValue) returns (stream CombinedShipment);
}
message Order {
	string id = 1;
}

// .pb.go
type OrderManagementClient interface { ProcessOrders(ctx context.Context, opts ...grpc.CallOption) (OrderManagement_ProcessOrdersClient, error); }
type OrderManagementServer interface { ProcessOrders(OrderManagement_ProcessOrdersServer) error; }
type OrderManagement_ProcessOrdersClient interface { Send(*wrappers.StringValue) error;  Recv() (*CombinedShipment, error);      grpc.ClientStream; }
type OrderManagement_ProcessOrdersServer interface { Send(*CombinedShipment) error;      Recv() (*wrappers.StringValue, error);  grpc.ServerStream; }

// server
func (s *server) ProcessOrders(stream pb.OrderManagement_ProcessOrdersServer) error {
	batchMarker := 1  // отправка по частям
	combinedShipmentMap := make(map[string]pb.CombinedShipment)
	for {
		orderId, err := stream.Recv()
		if err == io.EOF {
			err = stream.Send(...); if err != nil { ... }
			return nil
		}
		if err != nil { return err; }
		... batch algritm ... // github.com/grpc-up-and-running/samples/blob/master/ch05/deadlines/order-service/go/server/main.go
	}
}

// client
stream, err := client.ProcessOrders(ctx)
if err := stream.Send(&wrapper.StringValue{Value:"102"}); err != nil { ... }
c := make(chan struct{})
go func(stream, c) {
	for {
		val, err := stream.Recv()
		if err == io.EOF { break; }
	}
	close(c)
}(stream, c)

<-c
if err := stream.CloseSend(); err != nil {...}
