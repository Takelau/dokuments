
// --------------------------------
//    OpenCensus
// --------------------------------
// Doc
pkg.go.dev/go.opencensus.io

go get -u -v go.opencensus.io/...                          // OpenCensus
go get -u -v contrib.go.opencensus.io/exporter/prometheus  // Prometheus exporter

localhost:8081/debug/rpcz
localhost:8081/debug/tracez


// --------------------------------
//    Prometheus Exporter
// --------------------------------
pkg.go.dev/contrib.go.opencensus.io/exporter/prometheus
go get -u contrib.go.opencensus.io/exporter/prometheus

type Exporter struct {}
func NewExporter(o Options) (*Exporter, error)
func (e *Exporter) ServeHTTP(w http.ResponseWriter, r *http.Request)
type Options struct {
	Namespace   string
	Registry    *prometheus.Registry
	Registerer  prometheus.Registerer
	Gatherer    prometheus.Gatherer
	OnError     func(err error)
	ConstLabels prometheus.Labels // ConstLabels will be set as labels on all views.
}

1.
import (
	"log"
	"net/http"
	"contrib.go.opencensus.io/exporter/prometheus"
)

func main() {
	exporter, err := prometheus.NewExporter(prometheus.Options{});   if err != nil { log.Fatal(err); }
	http.Handle("/metrics", exporter)
	log.Fatal(http.ListenAndServe(":9999", nil))
}

2.
