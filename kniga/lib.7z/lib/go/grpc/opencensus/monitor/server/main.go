package main

import (
	"context"
	"errors"
	"log"
	"net"
	"net/http"

	"github.com/google/uuid"

	"google.golang.org/grpc"
	wrapper "github.com/golang/protobuf/ptypes/wrappers"
	pb "github.com/grpc-up-and-running/samples/ch07/grpc-prometheus/go/proto"
	
	"go.opencensus.io/plugin/ocgrpc"
	"go.opencensus.io/stats/view"
	"go.opencensus.io/zpages"
	"go.opencensus.io/examples/exporter"
)

const (
	port = ":50051"
)

// server is used to implement ecommerce/product_info.
type server struct {
	productMap map[string]*pb.Product
}

// AddProduct implements ecommerce.AddProduct
func (s *server) AddProduct(ctx context.Context, in *pb.Product) (*wrapper.StringValue, error) {
	out, err := uuid.NewUUID()
	if err != nil {
		log.Fatal(err)
	}
	in.Id = out.String()
	if s.productMap == nil {
		s.productMap = make(map[string]*pb.Product)
	}
	s.productMap[in.Id] = in
	return &wrapper.StringValue{Value: in.Id}, nil
}

// GetProduct implements ecommerce.GetProduct
func (s *server) GetProduct(ctx context.Context, in *wrapper.StringValue) (*pb.Product, error) {
	value, exists := s.productMap[in.Value]
	if exists {
		return value, nil
	}
	return nil, errors.New("Product does not exist for the ID" + in.Value)
}

func main() {
	// Запускаем сервер z-Pages
	// Для визуализации метрик служит HTTP-путь на порте 8081, начинающийся с /debug
	go func() {
		mux := http.NewServeMux()
		zpages.Handle(mux, "/debug")
		log.Fatal(http.ListenAndServe("127.0.0.1:8081", mux))
	}()

	// Регистрируем средства экспорта собираемых данных
	// PrintExporter экспортирует данные в консоль / (не обязательно)
	view.RegisterExporter(&exporter.PrintExporter{})

	// Регистрируем представления для сбора количества запросов к серверу
	if err := view.Register(ocgrpc.DefaultServerViews...); err != nil {
		log.Fatal(err)
	}

	// Создаем gRPC-сервер с обработчиком статистики
	grpcServer := grpc.NewServer(grpc.StatsHandler(&ocgrpc.ServerHandler{}))
	pb.RegisterProductInfoServer(grpcServer, &server{})

	lis, err := net.Listen("tcp", port)
	if err != nil { log.Fatalf("Failed to listen: %v", err); }

	if err := grpcServer.Serve(lis); err != nil { log.Fatalf("failed to serve: %v", err); }
}