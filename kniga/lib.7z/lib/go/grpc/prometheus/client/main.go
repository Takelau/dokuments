package main

import (
	"context"
	"fmt"
	"log"
	"time"
	"net/http"

	"github.com/grpc-ecosystem/go-grpc-prometheus"
	wrapper "github.com/golang/protobuf/ptypes/wrappers"
	pb "github.com/grpc-up-and-running/samples/ch07/grpc-prometheus/go/proto"
	"google.golang.org/grpc"
	"github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
)

const (
	address = "localhost:50051"
)

func main() {
	reg := prometheus.NewRegistry()                    // Create a metrics registry
	grpcMetrics := grpc_prometheus.NewClientMetrics()  // Create some standard client metrics
	reg.MustRegister(grpcMetrics)                      // Register client metrics to registry

	// Set up a connection to the server
	conn, err := grpc.Dial(address,
		grpc.WithUnaryInterceptor(grpcMetrics.UnaryClientInterceptor()),
		grpc.WithInsecure(),
	)
	if err != nil { log.Fatalf("did not connect: %v", err); }
	defer conn.Close()

	// Create a HTTP server for prometheus
	// http://localhost:9094/metrics
	httpServer := &http.Server{Handler: promhttp.HandlerFor(reg, promhttp.HandlerOpts{}), Addr: fmt.Sprintf("0.0.0.0:%d", 9094)}

	// Start your http server for prometheus.
	go func() {
		if err := httpServer.ListenAndServe(); err != nil {
			log.Fatal("Unable to start a http server.")
		}
	}()

	c := pb.NewProductInfoClient(conn)  // New...Client()

	for {
		// Contact the server and print out its response.
		name := "Sumsung S10"
		description := "Samsung Galaxy S10 is the latest smart phone, launched in February 2019"
		price := float32(700.0)
		
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()

		r, err := c.AddProduct(ctx, &pb.Product{Name: name, Description: description, Price: price})
		if err != nil { log.Fatalf("Could not add product: %v", err); }
		log.Printf("Product ID: %s added successfully", r.Value)

		product, err := c.GetProduct(ctx, &wrapper.StringValue{Value: r.Value})
		if err != nil { log.Fatalf("Could not get product: %v", err); }
		log.Printf("Product: ", product.String())
		
		time.Sleep(3 * time.Second)
	}
}
