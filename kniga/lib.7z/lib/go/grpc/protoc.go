
option go_package = "github.com/project/name";
option optimize_for = CODE_SIZE;   // SPEED | CODE_SIZE | LITE_RUNTIME

// --------------------------------
// Определение
// nano ProductInfo.proto
syntax = "proto3";        // версия
package ecommerce;        // имя пакета
service ProductInfo {     // определение интерфейса gRPC-сервиса - набор методов, вызываемых удаленнно
	rpc addProduct(Product) returns (ProductID);  // удаленный метод добавления товара, возвращающий ID этого товара в качестве ответа
	rpc getProduct(ProductID) returns (Product);  // удаленный метод для получения товара по его ID
}
message Product {          // определение формата/типа сообщений Product 
	string id          = 1;  // уникальный номер служит идентификатором в двоичном формате сообщений
	string name        = 2;
	string description = 3;
  enum Corpus {     // нумерованный список
    UNIVERSAL = 0;  // должент быть 0 для совместимости с proto2
    WEB       = 1;
    IMAGES    = 2;
  }
  Corpus corpus = 4;
  repeated int32 d = 5 [packed=true];  // пустые поля не будут присутствовать в байткоде сообщения
  reserved 15, 9 to 11;   // резервирование номера
  reserved "foo", "bar";  // резервирование имени
}
message ProductID {
	string value = 1;
}

// вложенные типы
message SearchResponse {
  message Result {
    string url = 1;
    string title = 2;
    repeated string snippets = 3;   // OBSOLETE_snippets - признак устаревшего поля
  }
  repeated Result results = 1;
}
message SomeOtherMessage {
  SearchResponse.Result result = 1;  // _Parent_._Type_
}

// map
map<string, Project> projects = 3;  // не может быть 'repeated'
message MapFieldEntry {             // proto2 & proto3 - реализация обратной совместимости
  key_type   key   = 1;
  value_type value = 2;
}
repeated MapFieldEntry map_field = N;

// Any
import "google/protobuf/any.proto";
message ErrorStatus {
  string message = 1;
  repeated google.protobuf.Any details = 2;  // []bytes
}

// JSON
import "google/protobuf/wrappers.proto";
service OrderManagement {
  rpc getOrder(google.protobuf.StringValue) returns (Order);
}
// server
func (s *server) GetOrder(ctx context.Context, orderId *wrapper.StringValue) (*pb.Order, error) {...}
// client 
ord := pb.NewOrderManagementClient(conn)
order, err := ord.GetOrder(ctx, &wrapper.StringValue{Value: "106"})


// --------------------------------
// package | option go_package
package foo.bar;
message Open { ... }

message Foo {
  foo.bar.Open open = 1;
}


// --------------------------------
// import
// nano old.proto
import public "new.proto";
import        "other.proto";
// nano client.proto
import        "old.proto";  // <- old.proto + new.proto, но не из other.proto


// --------------------------------
//    Wrapper
// --------------------------------
Документация - pkg.go.dev/google.golang.org/protobuf

// wrappers.proto
import "google/protobuf/wrappers.proto";
service OrderManagement {
  rpc addOrder(Order) returns (google.protobuf.StringValue);
}
// go
wrapper "github.com/golang/protobuf/ptypes/wrappers"
func (s *server) AddOrder(ctx context.Context, orderReq *pb.Order) (*wrapper.StringValue, error) { return &wrapper.StringValue{Value:"text"}, nil; }
func (s *server) GetOrder(ctx context.Context, orderId *wrapper.StringValue) (*pb.Order, error) { fmt.Println(orderId.Value); }


// --- wrappers ---
"github.com/golang/protobuf/ptypes/wrappers"
func (x *BoolValue)   GetValue() bool
func (x *BytesValue)  GetValue() []byte
func (x *DoubleValue) GetValue() float64
func (x *FloatValue)  GetValue() float32
func (x *Int32Value)  GetValue() int32
func (x *Int64Value)  GetValue() int64
func (x *StringValue) GetValue() string
func (x *UInt32Value) GetValue() uint32
func (x *UInt64Value) GetValue() uint64


// --- any ---
"github.com/golang/protobuf/ptypes/any"
func New(src proto.Message) (*Any, error)
func (x *Any) GetValue() []byte
func (x *Any) MarshalFrom(m proto.Message) error
func (x *Any) UnmarshalNew() (proto.Message, error)
func (x *Any) UnmarshalTo(m proto.Message) error
func (x *Any) MessageIs(m proto.Message) bool
// Constructing
any, err := anypb.New(m); if err != nil { ... }
// Unmarshaling
1  m := new(foopb.MyMessage);  if err := any.UnmarshalTo(m)
2  m, err := any.UnmarshalNew()
3
switch m := m.(type) {
  case *foopb.MyMessage:     ... // make use of m as a *foopb.MyMessage
  case *barpb.OtherMessage:  ... // make use of m as a *barpb.OtherMessage
}
// Type checking
if any.MessageIs((*foopb.MyMessage)(nil)) { ... }


// --- timestamp ---
"github.com/golang/protobuf/ptypes/timestamp"
// Conversion to a Go Time
1  t := ts.AsTime()
2  if err := ts.CheckValid(); err != nil { ... }
// Conversion from a Go Time
1  ts := timestamppb.New(t)  // construct a Timestamp message <- time.Time
2  ts := timestamppb.Now()


// --- duration ---
"github.com/golang/protobuf/ptypes/duration"
func New(d time.Duration) *Duration
func (x *Duration) AsDuration() time.Duration
func (x *Duration) CheckValid() error
func (x *Duration) GetNanos() int32
func (x *Duration) GetSeconds() int64
func (x *Duration) IsValid() bool
// Conversion to a Go Duration
1  d := dur.AsDuration()  // convert a Duration message -> time.Duration
2  if err := dur.CheckValid(); err != nil { ... }
// Conversion from a Go Duration
dur := durationpb.New(d)

// --- empty ---
"github.com/golang/protobuf/ptypes/empty"

// --- struct ---
"github.com/golang/protobuf/ptypes/struct"


// --------------------------------
//    Типы
// --------------------------------
.proto     Go        C++
bytes      []byte    string
double     float64   double
float      float32   float
int(32)    int(32)   int(32)
uint(32)   uint(32)  uint(32)
sint(32)   int(32)   int(32)
fixed(32)  uint(32)  uint(32)
bool       bool      bool
string     string    string

import "google/protobuf/wrappers.proto"
Int64Value,  UInt64Value  // JSON number
Int32Value,  UInt32Value  // JSON number
DoubleValue, FloatValue   // JSON number
StringValue, BytesValue   // JSON string
BoolValue                 // JSON `true` and `false`


// --------------------------------
//    Protoc
// --------------------------------
// https://developers.google.com/protocol-buffers/docs/reference/go-generated
protoc -I=$SRC_DIR --go_out=$DST_DIR  $SRC_DIR/name.proto
  --proto_path  или  -I
  --go_opt=module=$PREFIX         //
  --go_opt=paths=import           // default
  --go_opt=paths=source_relative  //
  --go-grpc_opt=paths=source_relative
  --go-grpc_out=require_unimplemented_servers=false

// --go-grpc_opt
protoc -I proto/  --go_out=server/pb --go_opt=paths=source_relative  --go-grpc_out=server/pb --go-grpc_opt=require_unimplemented_servers=false,paths=source_relative  order.proto
  
// --go_opt=paths=source_relative
protoc --proto_path=src  --go_out=out  --go_opt=paths=source_relative  foo.proto  bar/baz.proto  // src/foo.proto + src/bar/baz.proto -> out/foo.pb.go + out/bar/baz.pb.go
  
protoc --go_out=. --go_opt=paths=source_relative \       // helloworld/helloworld.pb.go
	--go-grpc_out=. --go-grpc_opt=paths=source_relative \  // helloworld/helloworld_grpc.pb.go
	helloworld/helloworld.proto

// option
// M${PROTO_FILE}=${GO_IMPORT_PATH}
option go_package = "example.com/project/protos/fizz";
protoc --proto_path=src \
  --go_opt=Mprotos/buzz.proto=example.com/project/protos/fizz \
  --go_opt=Mprotos/bar.proto=example.com/project/protos/foo \
  protos/buzz.proto protos/bar.proto


// --------------------------------
//    Protocol Buffers
// --------------------------------
https://developers.google.com/protocol-buffers/docs/encoding

// транспортные механизмы - https://github.com/grpc/grpc/tree/master/src/core/ext/transport
1 chttp2     - HTTP2 based transport
2 Cronet     - client/secure
3 in-process - 
4 binder     - cross process IPC on Android

// gRPC over HTTP2  - https://github.com/grpc/grpc/blob/master/doc/PROTOCOL-HTTP2.md
1.Request
HEADERS (flags = END_HEADERS)
:method = POST 
:scheme = http
:path = /ProductInfo/getProduct    // путь конечной точки
:authority = abc.com               // доменное имя в URI-адресе
te = trailers                      // способ обнаружения несовместимых прокси-серверов
grpc-timeout = 1S                  // время ожидания вызов: H(Hour), M(Minute), S(Second), m(Millisecond), u(Microsecond), n(Nanosecond)
content-type = application/grpc    // тип содержимого: "application/grpc" [("+proto" / "+json" / {custom})]
grpc-encoding = gzip               // сжатие: identity, gzip, deflate, snappy и {custom}
authorization = Bearer xxxxxx

DATA (flags = END_STREAM)

2.Response
HEADERS (flags = END_HEADERS)
:status = 200                      // код состояния HTTP-ответа
grpc-encoding = gzip               // способ сжатия сообщения
content-type = application/grpc    // тип содержимого

DATA
<Length-Prefixed Message>

HEADERS (flags = END_STREAM, END_HEADERS)
grpc-status = 0                    // код состояния - https://github.com/grpc/grpc/blob/master/doc/statuscodes.md
grpc-message = xxxxxx              // описание ошибки
trace-proto-bin = jher831yy13JHy3

// Status codes - https://github.com/grpc/grpc/blob/master/doc/statuscodes.md
Code            Number  Description
OK                  0   Not an error; returned on success.
CANCELLED           1   The operation was cancelled, typically by the caller.
UNKNOWN             2   Unknown error. For example, this error may be returned when a Status value received from another address space belongs to an error space that is not known in this address space. Also errors raised by APIs that do not return enough error information may be converted to this error.
INVALID_ARGUMENT    3   The client specified an invalid argument. Note that this differs from FAILED_PRECONDITION. INVALID_ARGUMENT indicates arguments that are problematic regardless of the state of the system (e.g., a malformed file name).
DEADLINE_EXCEEDED   4   The deadline expired before the operation could complete. For operations that change the state of the system, this error may be returned even if the operation has completed successfully. For example, a successful response from a server could have been delayed long
NOT_FOUND           5   Some requested entity (e.g., file or directory) was not found. Note to server developers: if a request is denied for an entire class of users, such as gradual feature rollout or undocumented allowlist, NOT_FOUND may be used. If a request is denied for some users within a class of users, such as user-based access control, PERMISSION_DENIED must be used.
ALREADY_EXISTS      6   The entity that a client attempted to create (e.g., file or directory) already exists.
PERMISSION_DENIED   7   The caller does not have permission to execute the specified operation. PERMISSION_DENIED must not be used for rejections caused by exhausting some resource (use RESOURCE_EXHAUSTED instead for those errors). PERMISSION_DENIED must not be used if the caller can not be identified (use UNAUTHENTICATED instead for those errors). This error code does not imply the request is valid or the requested entity exists or satisfies other pre-conditions.
RESOURCE_EXHAUSTED  8   Some resource has been exhausted, perhaps a per-user quota, or perhaps the entire file system is out of space.
FAILED_PRECONDITION 9   The operation was rejected because the system is not in a state required for the operation's execution. For example, the directory to be deleted is non-empty, an rmdir operation is applied to a non-directory, etc. Service implementors can use the following guidelines to decide between FAILED_PRECONDITION, ABORTED, and UNAVAILABLE: (a) Use UNAVAILABLE if the client can retry just the failing call. (b) Use ABORTED if the client should retry at a higher level (e.g., when a client-specified test-and-set fails, indicating the client should restart a read-modify-write sequence). (c) Use FAILED_PRECONDITION if the client should not retry until the system state has been explicitly fixed. E.g., if an "rmdir" fails because the directory is non-empty, FAILED_PRECONDITION should be returned since the client should not retry unless the files are deleted from the directory.
ABORTED             10  The operation was aborted, typically due to a concurrency issue such as a sequencer check failure or transaction abort. See the guidelines above for deciding between FAILED_PRECONDITION, ABORTED, and UNAVAILABLE.
OUT_OF_RANGE        11  The operation was attempted past the valid range. E.g., seeking or reading past end-of-file. Unlike INVALID_ARGUMENT, this error indicates a problem that may be fixed if the system state changes. For example, a 32-bit file system will generate INVALID_ARGUMENT if asked to read at an offset that is not in the range [0,2^32-1], but it will generate OUT_OF_RANGE if asked to read from an offset past the current file size. There is a fair bit of overlap between FAILED_PRECONDITION and OUT_OF_RANGE. We recommend using OUT_OF_RANGE (the more specific error) when it applies so that callers who are iterating through a space can easily look for an OUT_OF_RANGE error to detect when they are done.
UNIMPLEMENTED       12  The operation is not implemented or is not supported/enabled in this service.
INTERNAL            13  Internal errors. This means that some invariants expected by the underlying system have been broken. This error code is reserved for serious errors.
UNAVAILABLE         14  The service is currently unavailable. This is most likely a transient condition, which can be corrected by retrying with a backoff. Note that it is not always safe to retry non-idempotent operations.
DATA_LOSS           15  Unrecoverable data loss or corruption.
UNAUTHENTICATED     16  The request does not have valid authentication credentials for the operation.