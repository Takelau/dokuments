
club155.ru
go clean -i -x golang.org/tools/godoc     // i-установленные архивы и бинарники, r-все зависимости, x-принт
go clean -cache && go clean -modcache && go clean -testcache

// --------------------------------
//    Man
// --------------------------------
go get golang.org/x/tools/cmd/godoc
go doc fmt.Printf
godoc -http=:8001   // <-- http://localhost:8001/pkg/


// --------------------------------
//    IO
// --------------------------------
args := os.Args
// --------------------------------
flag.Parse()
for _,a := range flag.Args() { ... }
// --------------------------------
bufio func NewReadWriter(r *Reader, w *Writer) *ReadWriter
bufio func NewReader(r io.Reader) *Reader                  // NewReaderSize(rd, defaultBufSize)
bufio func NewReaderSize(r io.Reader, size int) *Reader    // defaultBufSize = 4096
bufio func (b *Reader) Read(p []byte) (n int, err error)   // 
bufio func (b *Reader) ReadBytes(delim byte) ([]byte, error)
bufio func (b *Reader) ReadString(delim byte) (string, error)
bufio func (b *Reader) ReadRune() (r rune, size int, err error)
bufio func (b *Reader) ReadLine() (line []byte, isPrefix bool, err error)  // low-level
bufio func (b *Reader) WriteTo(w io.Writer) (n int64, err error)
bufio func NewWriter(w io.Writer) *Writer
bufio func NewWriterSize(w io.Writer, size int) *Writer
bufio func (b *Writer) Write(p []byte) (nn int, err error)
bufio func (b *Writer) WriteByte(c byte) error
bufio func (b *Writer) WriteString(s string) (int, error)
bufio func (b *Writer) WriteRune(r rune) (size int, err error)
bufio func (b *Writer) ReadFrom(r io.Reader) (n int64, err error)
bufio func (b *Writer) Flush() error
bufio func (b R|W) Buffered() int   // кол-во байт которое может быть прочитано
bufio func (b R|W) Size() int       // размер низлежащего буфера в байтах | return len(b.buf)
bufio func (b R|W) Reset(R|W)       // reset discards any buffered data ...

bufio func NewScanner(r io.Reader) *Scanner
bufio func (s *Scanner) Scan() bool   // for s.Scan() { s.Text() }
bufio func (s *Scanner) Text() string
bufio func (s *Scanner) Bytes() []byte

io func ReadAll(r Reader) ([]byte, error)                         // make([]byte, 0, 512) + for {...}
io func ReadFull(r Reader, buf []byte) (n int, err error)         // ReadAtLeast(r, buf, len(buf))
io func ReadAtLeast(r Reader, buf []byte, min int) (n int, err error)
io func LimitReader(r Reader, n int64) Reader                     // LimitReader(strings.NewReader("text"), 10)
io func WriteString(w Writer, s string) (n int, err error)
io func Copy(dst Writer, src Reader) (written int64, err error)   // copyBuffer(dst, src, nil)
io func CopyBuffer(dst Writer, src Reader, buf []byte) (written int64, err error)  // make([]byte, 32 * 1024)

io func Pipe() (*PipeReader, *PipeWriter)
io (r *PipeReader) Read(data []byte) (n int, err error)
io (w *PipeWriter) Write(data []byte) (n int, err error)

io/ioutil func ReadAll(r io.Reader) ([]byte, error)   // = io.ReadFull()
io/ioutil func ReadDir(dirname string) ([]os.FileInfo, error)
io/ioutil func ReadFile(filename string) ([]byte, error)
io/ioutil func WriteFile(filename string, data []byte, perm os.FileMode) error  // вызавает os.WriteFile()

strings func NewReader(s string) *Reader
strings func (r *Reader) Read(b []byte) (n int, err error)
strings func (r *Reader) WriteTo(w io.Writer) (n int64, err error)
strings func (r *Reader) Len() int     // кол-во байт не прочитанной части стоки
strings func (r *Reader) Size() int64  // исходная длина базовой строки
strings func (r *Reader) Reset(s string)

bytes func NewBuffer(buf []byte) *Buffer     // return &Buffer{buf: buf}
bytes func NewBufferString(s string) *Buffer
bytes func (b *Buffer) ReadFrom(r io.Reader) (n int64, err error)
bytes func (b *Buffer) WriteTo(w io.Writer) (n int64, err error)
bytes func (b *Buffer) ReadString(delim byte) (line string, err error)
bytes func (b *Buffer) Read(p []byte) (n int, err error)
bytes func (b *Buffer) Write(p []byte) (n int, err error)
bytes func (b *Buffer) String() string
bytes func (b *Buffer) Bytes() []byte
bytes func (b *Buffer) Len() int
bytes func (b *Buffer) Cap() int
bytes func (b *Buffer) Reset()    // = b.Truncate(0)
bytes func NewReader(b []byte) *Reader
bytes func (r *Reader) Read(b []byte) (n int, err error)
bytes func (r *Reader) ReadAt(b []byte, off int64) (n int, err error)
bytes func (r *Reader) WriteTo(w io.Writer) (n int64, err error)
bytes func (r *Reader) Len() int
bytes func (r *Reader) Size() int64

binary func Read(r io.Reader, order ByteOrder, data interface{}) error   // order -> binary.LittleEndian
binary func Write(w io.Writer, order ByteOrder, data interface{}) error
binary func Size(v interface{}) int   // 

os func Pipe() (r *File, w *File, err error)
os func Create(name string) (*File, error)    // = OpenFile(filename, O_RDWR|O_CREATE|O_TRUNC, 0666)
os func WriteFile(filename string, data []byte, perm FileMode) error
os func (f *File) Read(b []byte) (n int, err error)
os func (f *File) ReadAt(b []byte, off int64) (n int, err error)
os func (f *File) ReadFrom(r io.Reader) (n int64, err error)
os func (f *File) Write(b []byte) (n int, err error)
os func (f *File) WriteAt(b []byte, off int64) (n int, err error)
os func (f *File) WriteString(s string) (n int, err error)
os func (f *File) SetDeadline(t time.Time) error     // ErrNoDeadline
os func (f *File) Truncate(size int64) error
os func (f *File) Fd() uintptr
os func (f *File) Sync() error  // сброс на диск
os func (f *File) Stat() (FileInfo, error)

type FileInfo interface {
	Size() int64         // length in bytes for regular files; system-dependent for others
	Mode() FileMode      // file mode bits
	ModTime() time.Time  // modification time
	IsDir() bool         // abbreviation for Mode().IsDir()
}
// --------------------------------
var f *os.File = os.Stdin;  defer f.Close()
s := bufio.NewScanner(f)    // буферизируемое сканирование
for s.Scan() {
	fmt.Println(">",s.Text())
}

l, err := net.Listen("tcp4", ":3000");  defer l.Close()
c, err := l.Accept()
s := bufio.NewReader(c)     // буферизируемое сетевое чтение
// --------------------------------
f,_ := os.Open("/dev/random");  defer f.Close();  // "encoding/binary"
binary.Read(f, binary.LittleEndian, &seed)        // LittleEndian - прямой | BigEndian - обратный порядок байт
// --------------------------------
f,_ := os.Open(fname);  defer f.Close();
st,_ := f.Stat();  size := st.Size()        // размер файла в байтах (int64) | type FileInfo interface { ... }
1:  // удаляет '\n'
  s := bufio.NewScanner(f)                  // + s.Split(bufio.ScanLines)
  for s.Scan() {
  	io.WriteString(os.Stdout, s.Text())     // вывод на экран
  }
2:  // не удаляет '\n'
	r := bufio.NewReader(f) // c net.Conn
	for {
		line, err := r.ReadString('\n')
		if err == io.EOF { break; } else if err != nil { break; }
	}
3:
	var b bytes.Buffer;  defer b.Reset();
	n,_ := b.ReadFrom(f)
	return b.String() || b.Bytes()
4:
	func readSize(f *os.File, size int) []byte {
		buffer := make([]byte, size)
		n,_ := f.Read(buffer)
		return buffer[0:n]
	}
	for {
		data := readSize(f, size)
		if data != nil { string(data); } else { break; }
	}
5:
	b,_ := ioutil.ReadFile("test.txt")  // []byte, error
6:
	b,_ := ioutil.ReadAll(f)            // []byte, error
// --------------------------------
io.WriteString(os.Stderr, "text")
os.Stdout.Write(...)
// --------------------------------
s := []byte("text")
f,_ := os.Create("f.txt");  defer f.Close();
1: fmt.Fprintf(f, string(s))            // форматированная запись
2: n,_ := f.Write(s)                    // полная запись
3: n,_ := f.WriteString( string(s) )    // построчная запись
4: n,_ := io.WriteString(f, string(s))  // не буферизируемая запись
5: w   := bufio.NewWriter(f)            // буферизируемая запись
   n,_ := w.WriteString( string(s) )
   w.Flush()
6: err := ioutil.WriteFile("name.txt", s, 0644)  // вызывает os.WriteFile()
   err := os.WriteFile("name.txt", s, 0644)      // os.OpenFile() + f.Write(data)
// --------------------------------
"encoding/gob"   // gob сериализация
err   := os.Remove(fname)
f,err := os.Create(fname);  defer f.Close()
enc := gob.NewEncoder(f)    // сохранить
err  = enc.Encode(DATA)
dec := gob.NewDecoder(f)    // загрузить
dec.Decode(&DATA)


// --------------------------------
//    Указатели
// --------------------------------
var a  int = 10
var p *int = &a


// --------------------------------
//    Slice
// --------------------------------
s := new([10]int)[0:3]  // len:3  cap:10  s:{0,0,0}
s := make([]int, 0, 5)  // len:0  cap:5   s:{}
s := make([]int,0)      // len:0  cap:0   s:{}
s := []int{2, 3, 5, 7, 11, 13}
s[1:4] --> [3 5 7]
s[:3]  --> [2 3 5]
s[4:]  --> [11 13]
s = s[:0]        // обнуление
s1 := a1[:]      // срез для массива a1 := [3]int{1,2,3}
copy(dst, src)   // копия среза <- минимум из len(dst) и len(src)
copy(s1, a1[:])  // копия массива в срез
s = append(s, a1[:]...)   // добавление массива в срез / (...) разбивает массив на элементы
s = append(s, s...)       // добавление среза в срез
s = append(s,"")[:len(s)] // увеличит емкость среза, если len(s) == cap(s)
// --------------------------------
var b [9]int
b = [...]int{0:5, 2:4, 4:3, 8:0}  // [9]int{5, 0, 4, 0, 3, 0, 0, 0, 0}
// --------------------------------
sl := []int{1,2,3}
sla(&sl, 4)   // [1 2 3 4]
slp(&sl)      // [1 2 3]
func sla(sl *[]int, n int) {
	*sl = append(*sl, n)
}
func slp(sl *[]int) {
	vl := *sl
	*sl = vl[0:len(*sl)-1]
}


// --------------------------------
//    Map
// --------------------------------
m := map[string]int{"a":1, "b":2, "c":3}
m := make(map[string]int,3){"a":1, "b":2, "c":3}  <-- в 3 раза быстрее
for k,v := range m {
  delete(m, k)
}
v,ok = m[k]
// --------------------------------
type Gopher struct {
  Name string `json:name`
  Pswd string `json:pswd`
  Age  int    `json:age`
}
func (g Gopher) Map() map[string]interface{} {
  return map[string]interface{"name":g.Name, "pswd":g.Pswd, "age":14}
}
// --------------------------------
sort.Slice(sl, func(i, j int) bool {
	return sl[i].Age < sl[j].Age
})
// --------------------------------
a := []string{"a", "b", "c"}
b,_ := json.Marshal(a)
// --------------------------------
a := map[string]int{"a":5, "b":7}
b,_ := json.Marshal(a)


// --------------------------------
//    Struct
// --------------------------------
sl := new([]s)      // возврат указателя
*sl = make([]s, 0)  // new требует инициализацию
// --------------------------------
type User struct {
	Name     string `form:"name" json:"name" binding:"required"`
	Password string `form:"pass" json:"pass" binding:"required"`
}
var list []User
list = append(list, User{"n1","p1"})
// --------------------------------
type Friend struct {
  Fname string
}
type Person struct {
  UserName string
  Emails   []string
  Friends  []*Friend
}
f1 := Friend{Fname: "t1"}
f2 := Friend{Fname: "t2"}
p := Person{
  UserName: "un",
  Emails:  []string{"a", "b"},
  Friends: []*Friend{&f1, &f2}
}
t.Execute(os.Stdout, p)
// --------------------------------
// сортировка слайса структур
sl := make([]st, 0)
sl = append(sl, st{Age:1})  // ... 
sort.Slice(sl, func(i, j int) bool {  
  return sl[i].Age < sl[j].Age
}


// --------------------------------
//    Interface
// --------------------------------
var myInt interface{} = 123
v,ok := myInt.(int)  // 123,true
// --------------------------------
switch v := myInt.(type) {
	case int: ...
	case nil: ...
	default:
}
// --------------------------------
type Shape interface {  // 336
	Area()      float64
	Perimeter() float64
}


// --------------------------------
//    iota
// --------------------------------
const (
  A Digit = iota   // A = 0
  B                // B = 1
}
const (
	A int = 1 << iota  // 2^0
  _                  // 2^1
  C                  // 2^2
}


// --------------------------------
//    Fmt
// --------------------------------
err := fmt.Sscanf(line, "%d\t%d\t%s", &s.A, &s.B, &s.C);


// --------------------------------
//    JSON
// --------------------------------
type Person struct {
	Comment  string    `json:"comment"`
	Text1    string    `json:",omitempty"`        // пропуск, если не инициализирован
	Text2    string    `json:"-"`                 // пропуск, всегда
}
// Decode from (to) file
func loadJSON(fname string, k interface{}) error {   // <-- loadJSON("...", &myStruct)
1: // чтение
	f,err := os.Open(fname);             if err != nil { return err; };  defer f.Close();
	err = json.NewDecoder(f).Decode(k);  if err != nil { return err; }
2:
	f,err := ioutil.ReadFile(fname);     if err != nil { return err; }
	err   := json.Unmarshal([]byte(f), k)
	return nil
}
//
func saveJSON(f *os.File, k interface{}) {
	err := json.NewEncoder(f).Encode(k);  if err != nil { return; }   // sync.Pool
	return
}
// --------------------------------
rec,err := json.Marshal(&k)         // []byte, err
err     := json.Unmarshal(rec, &k)  // err


// --------------------------------
//    XML
// --------------------------------
const xml.Header = `<?xml version="1.0" encoding="UTF-8"?>`+"\n"
type Person struct {
	XMLName  xml.Name  `xml:"pers"`
	Comment  string    `xml:",comment"`          // <!-- ... -->
	Id       int       `xml:"id,attr"`           // <pers id="0">
	Name     string    `xml:"name>first"`        // <name><first>Name</first></name>
	Age      int       `xml:"age"`               // <age>...</age>
	Text3    string    `xml:",innerxml"`         // <test>...</test>
	Text4    string    `xml:",omitempty"`        // пропуск, если не инициализирован
	Text5    string    `xml:"-"`                 // пропуск, всегда
}
// --------------------------------
// создание XML из структуры
xmlData, _ := xml.MarshalIndent(k,""," ")      // []byte, error
xmlData = []byte(xml.Header + string(xmlData))
// --------------------------------
// структура из XML
k := &Person{}
err := xml.Unmarshal(xmlData, k)
// --------------------------------
// создание XML из файла
f,_ := os.Open(fname)
err := xml.NewDecoder(f).Decode(k);  if err != nil {...};  defer f.Close();


// --------------------------------
//    Validate
// --------------------------------
Usage: -       // Skip Field
Usage: a,b|c
Usage: required
Usage: len=10
Usage: max=10
Usage: min=10
Usage: lt=10   //Less Than
// --------------------------------
t := net.ParseIP(ip)
if t.To4() == nil { continue; }


// --------------------------------
//    Regexp
// --------------------------------
r := regexp.MustCompile(`...`)
if r.MatchString(line) {
	match := r.FindStringSubmatch(line)  // []
}
// --------------------------------
r := regexp.MustCompile(`...`)
str := r.FindString(line)  // string
// --------------------------------
`.*\[(\d\d\/\w+/\d\d\d\d:\d\d:\d\d:\d\d.*)\] .*`  <--  [21/Nov/2017:19:28:09+0200]
`.*\[(\w+\-\d\d-\d\d:\d\d:\d\d:\d\d.*)\] .*`      <--  [Jun-21-17:19:28:09+0200]
ip := "(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])";  wan := ip+"\\."+ip+"\\."+ip+"\\."+ip


// --------------------------------
//    Time
// --------------------------------
golang.org/src/time/format.go
Mon Jan 2 15:04:05 MST 2006
// --------------------------------
start   := time.Now()
stop    := time.Now()
latency := stop.Sub(start)
fmt.Printf("struct: %13v \n", latency)


// --------------------------------
//    Basic types
// --------------------------------
uint8    0 - 255
uint16   0 - 65535                    smallserial    1 to 32767
uint32   0 - 4294967295               serial         1 to 2147483647
uint64   0 - 18446744073709551615     bigserial      1 to 9223372036854775807

int8    -128 to 127
int16   -32768 to 32767                              smallint  -32768 to +32767
int32   -2147483648 to 2147483647                    integer   -2147483648 to +2147483647
int64   -9223372036854775808 to 9223372036854775807  bigint    -9223372036854775808 to +9223372036854775807

float32
float64
complex64
complex128

byte   alias for uint8
rune   alias for int32 (represents a Unicode code point)

// Postgre SQL
smallint          2 bytes   small-range integer         -32768 to +32767
integer           4 bytes   typical choice for integer  -2147483648 to +2147483647
bigint            8 bytes   large-range integer         -9223372036854775808 to +9223372036854775807
decimal   variable 	user-specified precision, exact 	up to 131072 digits before the decimal point; up to 16383 digits after the decimal point
numeric   variable 	user-specified precision, exact 	up to 131072 digits before the decimal point; up to 16383 digits after the decimal point
real              4 bytes   variable-precision, inexact     6 decimal digits precision
double precision  8 bytes   variable-precision, inexact    15 decimal digits precision
smallserial       2 bytes   small autoincrementing integer 	1 to 32767
serial            4 bytes   autoincrementing integer        1 to 2147483647
bigserial         8 bytes   large autoincrementing integer  1 to 9223372036854775807


// --------------------------------
//    Fmt
// --------------------------------
// pointer
%p
// type
%T  "abc" -> string | 100 -> int
// boolean
%t  the word true or false
// int && float
%b  base 2
%d  base 10
%o  base 8
%f  decimal point but no exponent, e.g. 123.456
%.2f
// String and slice of bytes
%c  character
%s  the uninterpreted bytes of the string or slice
%q  a double-quoted string safely escaped with Go syntax
%x  base 16, lower-case, two characters per byte
%X  base 16, upper-case, two characters per byte
%+v struct
// Unicode   <- https://unicode-table.com/en/042B/
s := "Ы"
fmt.Println([]byte(s))             // 208 171  UTF-8     dec (bytes)
fmt.Println([]rune(s))             // 1067     UTF-16BE  dec
fmt.Printf("x: % x\n", []byte(s))  // d0 ab    UTF-8     hex
fmt.Printf("U: %U\n",  []rune(s))  // U+042B   UTF-16BE  hex


// --------------------------------
//    Template
// --------------------------------
tFile := `{{ range . }} {{ printf "%d" .a}} and {{ printf "%d" .b}}`
var DATA []Struct
t := template.Must(template.ParseGlob(tFile))
t.Execute(os.Stdout, DATA)         // text/template
t.ExecuteTemplate(w, tFile, DATA)  // html/template
// --------------------------------
{{ range . }} ... {{ end }}
{{if .Name}} {{else}} {{end}}
{{if and .User .User.Admin}}  // type User struct { Admin bool }
{{if not .Authenticated}}
{{index names 2 1}}           // names[2][1]
{{ printf "%d" .Num}}
eq  a1 == a2
ne  a1 != a2
lt  a1 <  a2
le  a1 <= a2
gt  a1 >  a2
ge  a1 >= a2
{{ eq a1 a2 a3 a4 }}  // a1==a2 || a1==a3 || a1==a4
// https://curtisvermeeren.github.io/2017/09/14/Golang-Templates-Cheatsheet


// --------------------------------
//    Chan
// --------------------------------
// Буферизованные, Сигнальные, Нулевые (всегда блокирован)
c := make(chan int)
_,ok := <-c
// --------------------------------
//         запись           чтение
func f(out chan<- int64, in <-chan int64) {
	for x := range in {
		out <- x
	}
	close(out)
}
// --------------------------------
// выполнять f() каждую секунду
c := time.Tick(time.Second)
for n := range c {
	fmt.Printf("%v %s\n", n, f())  // n = времени запуска f()
}
// --------------------------------
// таймат ожидания '<-c'
select {
	case n,ok := <-c: ...
	case <-time.After(time.Second):   
		fmt.Println("timed out")
}
// --------------------------------
// ограничение по времени приема данных в канале 'с'
func f(c chan int) {
	t := time.NewTimer(time.Second)
	for {
		select {
			case n := <-c: ...
			case <-t.C:  
				c = nil
		}
	}
}


// --------------------------------
//    Sync
// --------------------------------
type Mutex struct {
	state int32
	sema  uint32
}

type RWMutex struct {
	w Mutex              // held if there are pending writers
	writerSem    uint32  // semaphore for writers to wait for completing readers
	readerSem    uint32  // semaphore for readers to wait for completing writers
	readerCount  int32   // number of pending readers
	readerWait   int32   // number of departing readers
}


// --------------------------------
//    Разное
// --------------------------------
switch t := r.(type) {
	case string: err = error.New(t)
	case error:  err = t
}
// --------------------------------
var f = func(s *SName) string { return "" }
// --------------------------------
func abc() func() int {    // 281
	i := 0
	return func() int {
		i++
		return i * i
	}
}
x := abc();  fmt.Println(x());  // 1 > 4 > 9
// --------------------------------
func abc(f func(int) int, v int) int { return f(v); }
func sum(i int) int { return i + i;  }
abc(sum, 1)  // 2
// --------------------------------
func abc(s ...string) { fmt.Println(s);  s[0] = "x"; }  // []string  <- 284
// --------------------------------
func abc(x, y int) (min, max int) {
	if x > y { min = y; max = x;
	} else {   min = x; max = y; }
	return
}
// --------------------------------
type buffer []byte
func (b *buffer) write(p []byte) {       *b = append(*b, p...); }
func (b *buffer) writeString(s string) { *b = append(*b, s...); }
func (b *buffer) writeByte(c byte) {     *b = append(*b, c);    }
// --------------------------------
// дженерики
func Print[T any](s []T) {
	for _, v := range s { fmt.Print(v); }
}
// --------------------------------
// comparable
func Equal[T comparable](a, b T) bool { return a == b; }
func main() { Equal("a","a"); }


// --------------------------------
//    Unsafe && Reflect
// --------------------------------
reflect.Value - используется для хранения значений любого типа
reflect.Type  - используется для представления типов Go
reflect.TypeOf(x) - тип
// --------------------------------
t := reflect.TypeOf(123)           // < Type : int  | func TypeOf(i interface{}) Type
r := reflect.ValueOf(&s)[.Elem()]  // reflect.Value | func ValueOf(i interface{}) Value
t := r.Type()                      // < Type : main.s / int / string
t.Kind()                           // < Kind : struct
for i := 0; i < r.NumField(); i++ {
	t.Field(i).Name          // < string  : A
	r.Field(i).Type()        // < Type    : int
	r.Field(i).Kind()        // < string  : int
	r.Field(i).Interface()   // значение  : 10
}
for j := 0; j < r.NumMethod(); j++ {
	t.Method(j).Name      // < string : NameFunc
	r.Method(j).Type()    // < Type   : func(os.FileMode) error
}
// --------------------------------
var x float64 = 3.4
p := reflect.ValueOf(&x)
p.Type()    // > *float64
p.CanSet()  // > false
v := p.Elem()
v.SetFloat(7.1)
// --------------------------------
// валидация типа
for _,v := range []interface{}{"hi", 42, func(){}} {
	switch v := reflect.ValueOf(v); v.Kind() {
		case reflect.String:
			fmt.Println(v.String())  // <- hi
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			fmt.Println(v.Int())     // <- 42
		default:
			fmt.Printf("unhandled kind %s", v.Kind())  // <- unhandled kind func
	}
}
// --------------------------------
func Float64bits(f float64) uint64 {
  return *(*uint64)(unsafe.Pointer(&f))
}
// --------------------------------
const size = unsafe.Sizeof(uint32(0))  // число байт типа uint32 = 4
// --------------------------------
position := uintptr(h.rawring) + uintptr(h.frameSize * h.offset)
return (*v1header)(unsafe.Pointer(position))


// --------------------------------
//    Syscall
// --------------------------------
env := os.Environ()
syscall.Exec("/bin/ls", []string{"ls", "-a", "-x"}, env)
pid, _, _ := syscall.Syscall(39, 0, 0, 0)  // инфо о процессе
// --------------------------------
Getpid() (pid int)
Chmod(path string, mode uint32) (err error)
Chown(path string, uid int, gid int) (err error)
Fchmod(fd int, mode uint32) (err error)
Fchown(fd int, uid int, gid int) (err error)
Clearenv()
Close(fd int) (err error)
Read(fd int, p []byte) (n int, err error)
Write(fd int, p []byte) (n int, err error)
Exit(code int)


// --------------------------------
//    Flag
// --------------------------------
обработка аргументов коммандной строки
flag.Arg(i int) string
flag.Args() []string
flag.Int("O", 1, "comment")
flag.Bool("k", true, "comment")
flag.String("o", "", "comment")
flag.Var(&s, "name", "comment")
flag.Set(name, value string) error
flag.Parse()
// для 'flag.Var()' требуется определить интерфейс Value
type Value interface {
	String()    string
	Set(string) error
}
// --------------------------------
for index,val := range flag.Args() { ... }


// --------------------------------
//    Cobra
// --------------------------------
cobra                // help
cobra init <name>
cd ~/go/src/<name>
cobra add <command>  // Add a command to a Cobra Application | ~/go/src/cli/cmd/<command>.go
go run main.go
cobra init aliases   // создание псевдонимов


// --------------------------------
//    Компиляция
// --------------------------------
go run -race          name.go
go build -gcflags "-m -m"
go tool compile       name.go   // > name.o                  объектный файл
go tool compile -pack name.go   // > name.a / ar t name.a    архив объектных файлов
go install aPackName            // оздание пакета ( ~/go/src/aPackName )
// --------------------------------
go get golang.org/dl/gotip
gotip run -gcflags=all=-d=checkptr name.go  // валидация unsafe.Pointer
// --------------------------------
env GOOS=linux GOARCH=amd64 go build name.go  // кросс-компиляция
                                              // golang.org/doc/install/source
GOSSAFUNC=main GOOS=linux GOARCH=amd64 go build -gcflags "-S" name.go  // машинный код


// --------------------------------
//    mod && plugin
// --------------------------------
go mod init
go build -buildmode plugin -o mod.so ./mod
for d in $(find . -maxdepth 1 -type d | grep -v '^.$'); do echo $d; done


// --------------------------------
//    bpfTrace
// --------------------------------
github.com/iovisor/bpftrace/blob/master/docs/reference_guide.md


// --------------------------------
//    container
// --------------------------------
container/heap - куча
container/list - двусвязный список
container/ring - кольцо


// --------------------------------
//    pprof && trace && test(quick)
// --------------------------------
 + runtime/pprof
 + net/http/pprof
go tool pprof -http=localhost:8080 file.out
go tool pprof file.out    // профилирование
  top
  top10 --cum             // время выполнения каждой функции
  list main.fname         // ... компонентов функции
// --------------------------------
 + github.com/pkg/profile
  defer profile.Start(profile.ProfilePath("/tmp")).Stop()  // процессор -> /tmp/cpu.pprof
  defer profile.Start(profile.MemProfile).Stop()           // память
// --------------------------------
 + runtime/trace
 + net/http/pprof
go tool trace file.out     // трассировка (использует веб-интерфейс)
// --------------------------------
go test f.go f_test.go -v  // тестирование
go test name* -v           // расширенный вывод отчета (RUN + PASS + FAIL)
go test name* -v -count=1  // запускать указанное кол-во раз | 'count=1' отключает кеширование
go test name* -v -run='F2' // только для имен функций соовт-х регулярному выражению
go test name* -v -timeout 15s

go test -cover                   // покрытие тестами
go test -coverprofile=<name>.out // 1.  создание отчета о покрытии кода
go tool cover -func=<name>.out   // 2.1 анализ файла отчета (консоль)
go tool cover -html=<name>.out   // 2.2 ... браузер
go tool cover -html=<name>.out -o output.html  // 2.3 ... в воде отчета

go test -trace            // генерация файла трассировки
go vet name               // поиск не допустимого кода
// --------------------------------
quick.Value()  // заполнение структуры случайными данными
quick.Check()  // проверка условия методом "черного ящика"
// --------------------------------
go test -benchmem -bench=. benchmark.go benchmark_test.go
Benchmark50fibo3-8 300000 4612 ns/op 2481 B/op 10 allocs/o
8           - количество горутин | GOMAXPROCS
300000      - сколько раз была выполнена соответствующая функция
4612 ns/op  - среднее время каждого выполнения функции
2481 B/op   - среднее количество памяти, которое выделялось при каждом выполнении функции тестирования
10 allocs/o - количество операций выделения памяти, применяемых для выделения количества памяти, указанного в четвертом столбце


// --------------------------------
//    Signal
// --------------------------------
              os.Signal
SIGKILL   9   syscall.SIGKILL & os.Kill
SIGSTOP       syscall.SIGTSTP
SIGTERM       syscall.SIGTERM | kill(1)
SIGINFO       не в linux
SIGINT        syscall.SIGINT & os.Interrupt   // Ctrl+C


// --------------------------------
//    Clean
// --------------------------------
go clean -cache && go clean -modcache && go clean -testcache


// --------------------------------
//    curl
// --------------------------------
httpie.io
http [flags] [METHOD] URL [ITEM [ITEM]]
http :2000/bar
http PUT pie.dev/put name='one'
http -j GET http://172.16.10.211:8010/
http -f POST pie.dev/post name='one'     // Forms
http pie.dev/headers  User-Agent:Bacon/1.0  'Cookie:sid=123;foo=bar'

// GET with JSON
curl -X GET -v http://hostname/resource
curl -X GET -i -H "Accept: application/json" -H "Content-Type: application/json" http://hostname/resource
// GET with XML
curl -X GET -H "Accept: application/xml" -H "Content-Type: application/xml" http://hostname/resource
// POST: For posting data:
curl -X POST --data "param1=value1&param2=value2" http://hostname/resource
// POST: For file upload:
curl -X POST --form "fileupload=@filename.txt" http://hostname/resource
// POST: RESTful HTTP Post:
curl -X POST -d @filename http://hostname/resource
curl -X POST -H "Content-Type: application/json" --data "{\"name\":\"john\",\"pass\":\"doe\"}" localhost:3000
curl -X POST -H "Content-Type: application/xml"  --data "<login><name>john</name><pass>doe</pass></login>" localhost:3000
curl -X POST -H "Content-Type: application/x-www-form-urlencoded" --data "name=john&pass=doe" localhost:3000
curl -X POST -F name=john -F pass=doe http://localhost:3000
curl -X POST "http://localhost:3000/?name=john&pass=doe"
curl -X POST -d user=john http://localhost:3000
// PUT
curl -X PUT -d "Text" -v http://hostname/resource
curl -X PUT -d "Text" --insecure -v https://hostname/resource


// --------------------------------
//    PATH
// --------------------------------
printenv
// .bash_profile
export GOOS=linux             # LiteIDE
export GOARCH=amd64           # LiteIDE
export LC_CTYPE=en_US.UTF-8   # docui
export TERM=xterm-256color    # docui
export GOROOT=/vlm/go/go117
export GOPATH=/vlm/work
# PATH=$PATH:$HOME/.local/bin:$GOROOT/bin:$GOPATH/bin
PATH=$PATH:$GOROOT/bin:$GOPATH/bin
export PATH


fmt.Printf("%2s %12s %12s %12s %12s %12s %12s \n", "i", "1<<i", "2<<i", "3<<i", "4<<i", "5<<i", "10<<i")
for i := 0; i < 31; i++ {
	fmt.Printf("%2d %12d %12d %12d %12d %12d %12d \n", i, 1<<i, 2<<i, 3<<i, 4<<i, 5<<i, 10<<i)
}
 i         1<<i         2<<i         3<<i         4<<i         5<<i        10<<i 
 0            1            2            3            4            5           10 
 1            2            4            6            8           10           20 
 2            4            8           12           16           20           40 
 3            8           16           24           32           40           80 
 4           16           32           48           64           80          160 
 5           32           64           96          128          160          320 
 6           64          128          192          256          320          640 
 7          128          256          384          512          640         1280 
 8          256          512          768         1024         1280         2560 
 9          512         1024         1536         2048         2560         5120 
10         1024         2048         3072         4096         5120        10240 
11         2048         4096         6144         8192        10240        20480 
12         4096         8192        12288        16384        20480        40960 
13         8192        16384        24576        32768        40960        81920 
14        16384        32768        49152        65536        81920       163840 
15        32768        65536        98304       131072       163840       327680 
16        65536       131072       196608       262144       327680       655360 
17       131072       262144       393216       524288       655360      1310720 
18       262144       524288       786432      1048576      1310720      2621440 
19       524288      1048576      1572864      2097152      2621440      5242880 
20      1048576      2097152      3145728      4194304      5242880     10485760 
21      2097152      4194304      6291456      8388608     10485760     20971520 
22      4194304      8388608     12582912     16777216     20971520     41943040 
23      8388608     16777216     25165824     33554432     41943040     83886080 
24     16777216     33554432     50331648     67108864     83886080    167772160 
25     33554432     67108864    100663296    134217728    167772160    335544320 
26     67108864    134217728    201326592    268435456    335544320    671088640 
27    134217728    268435456    402653184    536870912    671088640   1342177280 
28    268435456    536870912    805306368   1073741824   1342177280   2684354560 
29    536870912   1073741824   1610612736   2147483648   2684354560   5368709120 
30   1073741824   2147483648   3221225472   4294967296   5368709120  10737418240

0x3<<8      0x300  768
(0x3<<8)|2  0x302  770

0XNNNN
// base 16 / 0-9 A(10)-F(15)
0x7F24 == 32548
(7 x 16 3) = (7  x 512) = 28672
(F x 16 2) = (15 x 64)  = 3840
(2 x 16 1) = (2  x 16)  = 32
(4 x 16 0) = (4  x 1)   = 4
0X10 == 16

// base 8
0x754 == 492
(7 x 8 2) = 448
(5 x 8 1) = 40
(4 x 8 0) = 4

// Побитовые операторы     https://github.com/huin/mqtt
    A=0011 1100 | А=60
    B=0000 1101 | В=13
------------------------
(A&B)=0000 1100 | 12   оператор “И”     (AND) копирует бит в результат, если бит задан в обоих операндах
(A|B)=0011 1101 | 61   оператор “ИЛИ”   (OR)  копирует бит в результат, если бит задан в одном из операндов
(A^B)=0011 0001 | 49   оператор “X-ИЛИ” (XOR) копирует бит в результат, если бит задан в одном из операндов, но не в обоих
A<<2 =1111 0000 | 240  оператор смещения влево – перемещает бит влево на ко-во позиций, заданное в правом операнде
