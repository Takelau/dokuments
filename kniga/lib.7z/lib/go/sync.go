// --------------------------------
//    WaitGroup
// --------------------------------
package main
import (
	"time"
	"sync"
	"flag"
)

func main() {
	var n int;   flag.IntVar(&n, "n", 0, "number")  // -n=3
	flag.Parse()

	var wg sync.WaitGroup    // старт группы
	
	for k:=0; k<n; k++ {
		wg.Add(1)              // ++
		go b(k, &wg)
	}

	wg.Wait()                // стоп группы
}

func b(k int, wg *sync.WaitGroup) {
	defer wg.Done()          // --
	time.Sleep(10 * time.Millisecond)
}


// --------------------------------
//    управляющая горутина
// --------------------------------
package main
import (
	"fmt"
	"time"
	"sync"
)

var r = make(chan int)   // канал чтения управляющей горутины
var w = make(chan int)   // канал записи управляющей горутины

func monitor() {   // управляющая горутина
	var value int
	for {
		select {
			case n,ok := <-w:
				if ok {
					value = n
					fmt.Println("w", value)
				}
			case r <- value:
		}
	}
}

func set(n int) {
	w <- n
	time.Sleep(time.Second)
}

func get() int {
	time.Sleep(time.Second)
	return <-r
}

func main() {
	go monitor()
	var w sync.WaitGroup

	for i := 0; i < 10; i++ {
		w.Add(1)
		go func(n int) {
			defer w.Done()
			set(n)
		}(i)
	}

	for i := 0; i < 10; i++ {
		w.Add(1)
		go func(n int) {
			defer w.Done()
			fmt.Println("r", n, get())
		}(i)
	}

	w.Wait()
}


// --------------------------------
//    Mutex
// --------------------------------
var counter = struct{
	sync.RWMutex
	m map[string]int
}{m: make(map[string]int)}

// чтение
counter.RLock()
n := counter.m["some_key"]
counter.RUnlock()
fmt.Println("some_key:", n)

// запись
counter.Lock()
counter.m["some_key"]++
counter.Unlock()

// --------------------------------
package main
import (
	"fmt"
	"time"
	"sync"
	"strconv"
)

func main() {
	var wg sync.WaitGroup
	c := &Secret { pass:"pwd" }

	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			c.set(i)          // запись в c.pass
		}(i)
	}

	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			c.get(i)          // чтение из c.pass
		}(i)
	}

	wg.Wait()
}

type Secret struct {
	RWM   sync.RWMutex    // 'RWMutex' работет быстрее на чтение
	pass  string
}

func (c *Secret) set(i int) {
	defer c.RWM.Unlock()
	c.RWM.Lock()
	time.Sleep(time.Second)
	
	c.pass = "p" + strconv.Itoa(i)
	fmt.Println("w", i, c.pass)
}

func (c *Secret) get(i int) {
	defer c.RWM.RUnlock()
	c.RWM.RLock()
	time.Sleep(time.Second)
	
	fmt.Println("r", i, c.pass)
}


// --------------------------------
//    Atomic
// --------------------------------
package main
import (
	"fmt"
	"sync"
	"sync/atomic"
)

type atomCounter struct {
	val int64
}

func (c *atomCounter) Value() int64 {
	return atomic.LoadInt64(&c.val)
}
func main() {
	var waitGroup sync.WaitGroup
	counter := atomCounter{}
	X := 100
	Y := 200

	for i := 0; i < X; i++ {
		waitGroup.Add(1)
		go func(no int) {
			defer waitGroup.Done()
			for i := 0; i < Y; i++ {
				atomic.AddInt64(&counter.val, 1)
			}
		}(i)
	}

	waitGroup.Wait()
	fmt.Println(counter.Value())
}


// --------------------------------
//    Pool
// --------------------------------
package main
import (
	"bytes"
	"sync"
)

var pool = sync.Pool{
	New: func() interface{} { return &bytes.Buffer{} },
}

func main() {
	s := pool.Get().(*bytes.Buffer)
	s.Write([]byte("a"))
	pool.Put(s)

	s.Reset()
	pool.Put(s)

	s = pool.Get().(*bytes.Buffer)
	s.Write([]byte("b"))
	pool.Put(s)
}

// --------------------------------
func Fprintln(w io.Writer, a ...interface{}) (n int, err error) {
	p := newPrinter()
	p.doPrintln(format, a)
	n, err = w.Write(p.buf)
	p.free()
	return
}

var ppFree = sync.Pool {
	New: func() interface{} { return new(pp) },
}

func newPrinter() *pp {
	p := ppFree.Get().(*pp)
	// ...
	return p
}

type buffer []byte
func (b *buffer) write(p []byte) {       *b = append(*b, p...); }
func (b *buffer) writeString(s string) { *b = append(*b, s...); }
func (b *buffer) writeByte(c byte) {     *b = append(*b, c);    }

type pp struct {
	buf buffer
}

func (p *pp) Write(b []byte) (ret int, err error) {
	p.buf.write(b)
	return len(b), nil
}

func (p *pp) free() {
	if cap(p.buf) > 64<<10 { return; }
	p.buf = p.buf[:0]
	ppFree.Put(p)        // func (p *Pool) Put(x interface{}) { ... }
}

func (p *pp) doPrintln(a []interface{}) {
	for argNum, arg := range a {
		if argNum > 0 { p.buf.writeByte(' '); }
		p.printArg(arg, 'v')
	}
	p.buf.writeByte('\n')
}

// --------------------------------
//    Sync / ErrGroup
// --------------------------------
package main
import (
	"context"
	"fmt"
	"os"
	"golang.org/x/sync/errgroup"
)

var (
	Web   = fakeSearch("web")
	Image = fakeSearch("image")
	Video = fakeSearch("video")
)

type Result string
type Search func(ctx context.Context, query string) (Result, error)

func fakeSearch(kind string) Search {
	return func(_ context.Context, query string) (Result, error) {
		return Result(fmt.Sprintf("%s result for %q", kind, query)), nil
	}
}

func main() {
	Google := func(ctx context.Context, query string) ([]Result, error) {
		g, ctx := errgroup.WithContext(ctx)

		searches := []Search{Web, Image, Video}
		results := make([]Result, len(searches))
		for i, search := range searches {
			i, search := i, search // https://golang.org/doc/faq#closures_and_goroutines
			g.Go(func() error {
				result, err := search(ctx, query)
				if err == nil {
					results[i] = result
				}
				return err
			})
		}
		if err := g.Wait(); err != nil { return nil, errж }
		return results, nil
	}

	results, err := Google(context.Background(), "golang")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return
	}
	for _, result := range results {
		fmt.Println(result)
	}

	// web result for "golang"
	// image result for "golang"
	// video result for "golang"
}