
type User struct {
	Uid string       // Uid is the user ID
	Gid string       // Gid is the primary group ID
	Username string  // Username is the login name
	Name string      // Name is the user's real or display name
	HomeDir string
}

type Group struct {
	Gid  string
	Name string
}

func Current() (*User, error)
func Lookup(username string) (*User, error)
func LookupId(uid string) (*User, error)

func (u *User) GroupIds() ([]string, error)

func LookupGroup(name string) (*Group, error)
func LookupGroupId(gid string) (*Group, error)

// --------------------------------
package main
import (
	"fmt"
	"os"
	"os/user"
)

func main() {
	fmt.Println("User id:", os.Getuid())  // User id: 1000

	var u *user.User
	u, _ = user.Current()
	fmt.Print("Group ids: ")

	groupIDs, _ := u.GroupIds()
	for _, i := range groupIDs {
		fmt.Print(i, " ")              // Group ids: 1000 973
	}
}