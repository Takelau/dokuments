
https://github.com/uptrace/go-treemux-realworld-example-app
https://pkg.go.dev/github.com/go-redis/redis/v8#pkg-examples
https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/other_protocols/redis

RESP - REdis Serialization Protocol  // https://redis.io/topics/protocol

ctx, cancel := context.WithCancel(context.Background())

// Get & Set
err := rdb.Set(ctx,   "key", "value", time.Hour).Err()  // time.Hour || 0
err := rdb.SetEX(ctx, "key", "value", time.Hour).Err()
val, err := rdb.Do(ctx, "get", "key").Result()  // fmt.Println(val.(string))
val, err := rdb.Get(ctx, "key").Result()        // err == redis.Nil | err != nil
switch {
	case err == redis.Nil:  fmt.Println("key does not exist")
	case err != nil:        fmt.Println("Get failed", err)
	case val == "":         fmt.Println("value is empty")
}
get      := rdb.Get(ctx, "key")             // fmt.Println(get.Val(), get.Err())
s, err   := get.Text()
num, err := get.Int()
num, err := get.Int64()
num, err := get.Uint64()
num, err := get.Float32()
num, err := get.Float64()
flag, err := get.Bool()

result, err := rdb.Incr(ctx, "counter").Result()

// -------------------------------
// BLPop
err := rdb.RPush(ctx, "queue", "message").Err()
result, err := rdb.BLPop(ctx, 1*time.Second, "queue").Result()
fmt.Println(result[0], result[1])  // Output: queue message

// -------------------------------
// Scan
rdb.FlushDB(ctx)
for i := 0; i < 33; i++ {
	err := rdb.Set(ctx, fmt.Sprintf("key%d", i), "value", 0).Err()
}
var cursor uint64
var n int
for {
	var keys []string
	var err error
	keys, cursor, err = rdb.Scan(ctx, cursor, "key*", 10).Result();  if err != nil { panic(err) }
	n += len(keys)  // Output: found 33 keys
	if cursor == 0 { break }
}

// ScanType
rdb.FlushDB(ctx)
for i := 0; i < 33; i++ {
	err := rdb.Set(ctx, fmt.Sprintf("key%d", i), "value", 0).Err()
}
var cursor uint64
var n int
for {
	var keys []string
	var err error
	keys, cursor, err = rdb.ScanType(ctx, cursor, "key*", 10, "string").Result();  if err != nil { panic(err) }
	n += len(keys)  // Output: found 33 keys
	if cursor == 0 { break }
}

// -------------------------------
// HMSet + HGetAll && Scan into Struct
rdb.FlushDB(ctx)
err := rdb.HMSet(ctx, "map", "name", "hello", "count", 123, "correct", true).Err();  if err != nil {       panic(err) }
res := rdb.HGetAll(ctx, "map");                                                      if res.Err() != nil { panic(err) }

type data struct {
	Name    string `redis:"name"`
	Count   int    `redis:"count"`
	Correct bool   `redis:"correct"`
}

var d data
if err := res.Scan(&d); err != nil { panic(err) }
fmt.Println(d)  // Output: {hello 123 true}

// -------------------------------
// MSet + MGet && Scan into Struct
rdb.FlushDB(ctx)
err := rdb.MSet(ctx, "name", "hello", "count", 123, "correct", true).Err();   if err != nil {       panic(err) }
res := rdb.MGet(ctx, "name", "count", "empty", "correct");                    if res.Err() != nil { panic(err) }

type data struct {
	Name    string `redis:"name"`
	Count   int    `redis:"count"`
	Correct bool   `redis:"correct"`
}

var d data
if err := res.Scan(&d); err != nil { panic(err) }
fmt.Println(d)  // Output: {hello 123 true}

// -------------------------------
// PubSub
err := rdb.Publish(ctx, "mychannel1", "payload").Err();  if err != nil { panic(err) }
pubsub := rdb.Subscribe(ctx, "mychannel1")
ch := pubsub.Channel()
for msg := range ch { fmt.Println(msg.Channel, msg.Payload) }

// PubSub
pubsub := rdb.Subscribe(ctx, "mychannel1")
_, err := pubsub.Receive(ctx);  if err != nil { panic(err) }
ch := pubsub.Channel()
err = rdb.Publish(ctx, "mychannel1", "hello").Err();  if err != nil { panic(err) }
time.AfterFunc(time.Second, func() { _ = pubsub.Close() })
for msg := range ch {
	fmt.Println(msg.Channel, msg.Payload)  // Output: mychannel1 hello
}	

// PubSub Receive
pubsub := rdb.Subscribe(ctx, "mychannel2")
defer pubsub.Close()
for i := 0; i < 2; i++ {
	msgi, err := pubsub.ReceiveTimeout(ctx, time.Second);  if err != nil { break }

	switch msg := msgi.(type) {
		case *redis.Subscription:
			fmt.Println("subscribed to", msg.Channel)
			_, err := rdb.Publish(ctx, "mychannel2", "hello").Result();  if err != nil { panic(err) }
		case *redis.Message:
			fmt.Println("received", msg.Payload, "from", msg.Channel)
		default:
			panic("unreached")
	}
}

// -------------------------------
// Pipelined
var incr *redis.IntCmd
_,err := rdb.Pipelined(ctx, func(pipe redis.Pipeliner) error {
	incr = pipe.Incr(ctx, "pipelined_counter")
	pipe.Expire(ctx, "pipelined_counter", time.Hour)
	return nil
})
fmt.Println(incr.Val(), err)  // Output: 1 <nil>

// -------------------------------
// Pipeline (manual)
pipe := rdb.Pipeline()
incr := pipe.Incr(ctx, "pipeline_counter")
pipe.Expire(ctx, "pipeline_counter", time.Hour)
_, err := pipe.Exec(ctx)
fmt.Println(incr.Val(), err)  // Output: 1 <nil>

// -------------------------------
// TxPipeline | Set
pipe := db.Client.TxPipeline()
pipe.Set(Ctx, "language", "golang")
pipe.Set(Ctx, "year", 2009)
results, err := pipe.Exec()

// TxPipeline | ZScore & ZRank
pipe := db.Client.TxPipeline()
score := pipe.ZScore(Ctx, "key", "username")  // <- int(score.Val())
rank  := pipe.ZRank(Ctx, "key", "username")   // <- int(rank.Val())
_,err := pipe.Exec(Ctx)
if score == nil { return nil, ErrNil; }

// TxPipelined | ZAdd & ZRank
pipe := m.db.TxPipeline();  defer pipe.Close()
z := &redis.Z{ Member:"name", Score:float64(1024), }
pipe.ZAdd(ctx, "hackers", z)
rank := pipe.ZRank(Ctx, "hackers", z.Member.(string))
res, err := pipe.Exec(ctx)
if rank.Val() == 0 { fmt.Println("rank.Val()", rank.Val()) }

// TxPipelined && IntCmd
var incr *redis.IntCmd
_, err := rdb.TxPipelined(ctx, func(pipe redis.Pipeliner) error {
	incr = pipe.Incr(ctx, "tx_pipelined_counter")
	pipe.Expire(ctx, "tx_pipelined_counter", time.Hour)
	return nil
})
fmt.Println(incr.Val(), err)  // Output: 1 <nil>

// TxPipelined && IntCmd (manual)
pipe := rdb.TxPipeline()
incr := pipe.Incr(ctx, "tx_pipeline_counter")
pipe.Expire(ctx, "tx_pipeline_counter", time.Hour)
_, err := pipe.Exec(ctx)
fmt.Println(incr.Val(), err)  // Output: 1 <nil>

// -------------------------------
// Watch

// -------------------------------
// Command
v, err := rdb.Do(ctx, "get", "key_does_not_exist").Text()
fmt.Printf("%q %s", v, err)  // Output: "" redis: nil

// -------------------------------
// Client && Failover
rdb := redis.NewClient(&redis.Options{
	Addr:     "localhost:6379", // use default Addr
	Password: "",               // no password set
	DB:       0,                // use default DB
})
pong, err := rdb.Ping(ctx).Result()

rdb := redis.NewFailoverClient(&redis.FailoverOptions{
	MasterName:    "master",
	SentinelAddrs: []string{":26379"},
})
rdb.Ping(ctx)

// -------------------------------
// github.com/go-redis/cache
package rwe
import (
	"context"
	"sync"
	"time"
	"github.com/go-redis/cache/v8"
	"github.com/go-redis/redis/v8"
)

var (
	redisRingOnce sync.Once
	redisRing     *redis.Ring
)

func RedisRing() *redis.Ring {
	redisRingOnce.Do(func() {
		opt := Config.RedisCache.Options()
		redisRing = redis.NewRing(opt)

		_ = redisRing.ForEachShard(context.TODO(),
			func(ctx context.Context, shard *redis.Client) error {
				shard.AddHook(redisotel.TracingHook{})
				return nil
			})
	})
	return redisRing
}

var (
	redisCacheOnce sync.Once
	redisCache     *cache.Cache
)

func RedisCache() *cache.Cache {
	redisCacheOnce.Do(func() {
		redisCache = cache.New(&cache.Options{
			Redis:      RedisRing(),
			LocalCache: cache.NewTinyLFU(1000, time.Minute),
		})
	})
	return redisCache
}