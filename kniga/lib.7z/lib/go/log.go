
var std = New(os.Stderr, "", LstdFlags)

func New(out io.Writer, prefix string, flag int) *Logger {
	return &Logger{out: out, prefix: prefix, flag: flag}
}
// -----------------------
type Logger struct {
	mu     sync.Mutex // ensures atomic writes; protects the following fields
	prefix string     // prefix on each line to identify the logger (but see Lmsgprefix)
	flag   int        // properties
	out    io.Writer  // destination for output
	buf    []byte     // for accumulating text to write
}

func (l *Logger) Output(calldepth int, s string) error {
	now := time.Now() // get this early.
	var file string
	var line int
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.flag&(Lshortfile|Llongfile) != 0 {
		// Release lock while getting caller info - it's expensive.
		l.mu.Unlock()
		var ok bool
		_, file, line, ok = runtime.Caller(calldepth)
		if !ok {
			file = "???"
			line = 0
		}
		l.mu.Lock()
	}
	l.buf = l.buf[:0]
	l.formatHeader(&l.buf, now, file, line)
	l.buf = append(l.buf, s...)
	if len(s) == 0 || s[len(s)-1] != '\n' {
		l.buf = append(l.buf, '\n')
	}
	_, err := l.out.Write(l.buf)
	return err
}
// -----------------------
func Fatal(v ...interface{}) {
	std.Output(2, fmt.Sprint(v...))
	os.Exit(1)
}

func Fatalf(format string, v ...interface{}) {
	std.Output(2, fmt.Sprintf(format, v...))
	os.Exit(1)
}

func Fatalln(v ...interface{}) {
	std.Output(2, fmt.Sprintln(v...))
	os.Exit(1)
}
// -----------------------
func Panic(v ...interface{}) {
	s := fmt.Sprint(v...)
	std.Output(2, s)
	panic(s)
}

func Panicf(format string, v ...interface{}) {
	s := fmt.Sprintf(format, v...)
	std.Output(2, s)
	panic(s)
}
// -----------------------
func os.Exit(code int) {
	if code == 0 {
		if testlog.PanicOnExit0() {
			// We were told to panic on calls to os.Exit(0).
			// This is used to fail tests that make an early
			// unexpected call to os.Exit(0).
			panic("unexpected call to os.Exit(0) during test")
		}

		// Give race detector a chance to fail the program.
		// Racy programs do not have the right to finish successfully.
		runtime_beforeExit()
	}
	syscall.Exit(code)
}


// --------------------------------
//    Log File
// --------------------------------
f, err := os.OpenFile("text.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
if err != nil { log.Println(err); }
defer f.Close()
logger := log.New(f, "prefix", log.LstdFlags) // Ldate + Ltime
logger.Println("text to append")       // prefix: 2017/10/20 07:52:58 text to append
logger.Println("more text to append")  // prefix: 2017/10/20 07:52:58 more text to append
// -----------------------
var buf bytes.Buffer
logger := log.New(&buf, "logger: ", log.Lshortfile)
logger.Print("msg 1")  // logger: main.go:12: msg 1
logger.SetFlags(log.Lshortfile | log.Ltime)
logger.Print("msg 2")  // logger: 14:02:10 main.go:14: msg 2
fmt.Print(&buf)


// --------------------------------
//    SysLog
// --------------------------------
sl, err := syslog.New(syslog.LOG_INFO, msg)  // LOG_ALERT, LOG_ERR, LOG_WARNINGm, LOG_INFO, LOG_DEBUG
if err != nil { log.Fatal(err);
} else {        log.SetOutput(sl); }
log.Println("msg1")
