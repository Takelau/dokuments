
// io.Reader
type Reader interface {
	Read(p []byte) (n int, err error)
}
// io.Writer
type Writer interface {
	Write(p []byte) (n int, err error)
}
io.EOF
// io.Closer
type Closer interface {
	Close() error
}

type ReadCloser interface {
	Reader
	Closer
}
type WriteCloser interface {
	Writer
	Closer
}
type ReadWriteCloser interface {
	Reader
	Writer
	Closer
}

// --------------------------------
// io.Reader
package main
import (
	"fmt"
	"io"
)

type MyStringData struct {
	str   string
	index int
}

func (s *MyStringData) Read(p []byte) (n int, err error) {
	strBytes := []byte(s.str)
	if s.index >= len(strBytes) {
		return 0, io.EOF
	}

	nextIndex := s.index + len(p)

	if nextIndex >= len(strBytes) {
		nextIndex = len(strBytes)
		err = io.EOF
	}

	nextBytes := strBytes[s.index:nextIndex]
	n = len(nextBytes)
	copy(p, nextBytes)
	s.index = nextIndex
	return
}

func main() {
	src := MyStringData{str: "Hello Amazing World!"}
	p := make([]byte, 3)
	for {
		n, err := src.Read(p)
		fmt.Printf("%d bytes read: [%s]\n", n, p[:n])
		if err == io.EOF {
			fmt.Println("--end-of-file--")
			break
		} else if err != nil {
			break
		}
	}

}

// --------------------------------
// io.Writer
package main
import (
	"fmt"
	"io"
)

type SampleStore struct {
	data []byte
}

func (s *SampleStore) Write(p []byte) (n int, err error) {
	if len(s.data) == 10 { return 0, io.EOF; }
	remainingCap := 10 - len(s.data)

	writeLength := len(p)
	if remainingCap <= writeLength {
		writeLength = remainingCap
		err = io.EOF
	}

	s.data = append(s.data, p[:writeLength]...)
	n = writeLength
	return
}

func main() {
	s := SampleStore{}
	// v1
	n1, err1 := s.Write([]byte("Hello!"));    fmt.Printf("%d [%s] err:%v \n", n1, s.data, err1)  // 6 [Hello!] err:<nil>
	n2, err2 := s.Write([]byte(" Amazing"));  fmt.Printf("%d [%s] err:%v \n", n2, s.data, err2)  // 4 [Hello! Ama] err:EOF
	n3, err3 := s.Write([]byte(" World!"));   fmt.Printf("%d [%s] err:%v \n", n3, s.data, err3)  // 0 [Hello! Ama] err:EOF
	// v2
	n1, err1 := io.WriteString(s, "Hello!");    fmt.Printf("%d [%s] err:%v \n", n1, s.data, err1)  // 6 [Hello!] err:<nil> 
	n2, err2 := io.WriteString(s, " Amazing");  fmt.Printf("%d [%s] err:%v \n", n2, s.data, err2)  // 4 [Hello! Ama] err:EOF
	n3, err3 := io.WriteString(s, " World!");   fmt.Printf("%d [%s] err:%v \n", n3, s.data, err3)  // 0 [Hello! Ama] err:EOF
}

// --------------------------------
// io.WriteString
type StringWriter interface {
	WriteString(s string) (n int, err error)
}
func WriteString(w Writer, s string) (n int, err error)

io.WriteString(os.Stdout, "Hello World")

// --------------------------------
// io.ReadFull
func ReadFull(src Reader, buf []byte) (n int, err error)
if n < len(buf) && err == io.ErrUnexpectedEOF {  }
if n =0 && err == io.EOF {  }

buf := make([]byte, 14)
src := strings.NewReader("Hello Amazing World!")
n, err := io.ReadFull(src, buf )

// --------------------------------
// io.LimitReader
func LimitReader(r Reader, n int64) Reader

package main
import (
	"fmt"
	"io"
	"strings"
)

func main() {
	mainSrc := strings.NewReader("Hello Amazing World!")
	src := io.LimitReader(mainSrc, 10)
	p := make([]byte, 3)

	for {
		n, err := src.Read(p)
		fmt.Printf("%d data:[%s] err:[%v] \n", n, p[:n], err)
		if err == io.EOF {     break
		} else if err != nil { break }
	}
}

// --------------------------------
// io.Copy - перемещение всех данных в одной 'go' функции
func Copy(dst Writer, src Reader) (int64, error)
func CopyBuffer(dst Writer, src Reader, buf []byte) (written int64, err error)
func CopyN(dst Writer, src Reader, n int64) (written int64, err error)
io.EOF

package main
import (
	"io"
	"log"
	"os"
	"strings"
)

func main() {
	buf := make([]byte, 8)
	r1 := strings.NewReader("first reader\n")
	r2 := strings.NewReader("second reader\n")
	if _, err := io.CopyBuffer(os.Stdout, r1, buf); err != nil { log.Fatal(err) }
	if _, err := io.CopyBuffer(os.Stdout, r2, buf); err != nil { log.Fatal(err) }
}

// --------------------------------
// io.Pipe
func Pipe() (*PipeReader, *PipeWriter)
type PipeReader struct {}
type PipeWriter struct {}

func (r *PipeReader) Close() error
func (r *PipeReader) CloseWithError(err error) error
func (r *PipeReader) Read(data []byte) (n int, err error)

func (w *PipeWriter) Close() error
func (w *PipeWriter) CloseWithError(err error) error
func (w *PipeWriter) Write(data []byte) (n int, err error)

src, dst := io.Pipe()
