
nc -v    <ip> 22       // наличие открытого порта
nc -vnz  <ip> 20-24    // TCP сканер
nc -vnzu <ip> 550-560  // UDP сканер
echo -n "foo" | nc -u -w1 <ip> 550   // отправка UDP-пакета
nc -u <ip> 550                       // приём UDP-пакета
while true; do nc -u <ip> 550; done  // приём в цикле
nc -u <ip> 550 < name.txt     // отправка файла
nc -lvp 550 > /tmp/name.txt   // запись в файл

IP обеспечивает способ адресации для эффективной доставки пакета в точку назначения

// openssl genrsa -out server.key 2048
// openssl ecparam -genkey -name secp384r1 -out server.key
// openssl req -new -x509 -sha256 -key server.key -out server.crt -days 3650
// openssl req -x509 -nodes -newkey rsa:2048 -keyout client.key -out

type ProtocolError DEPRECATED


// --------------------------------
type Request struct {
	Method    string
	URL      *url.URL
	Proto     string        // "HTTP/1.0"
	Header    Header
	Body      io.ReadCloser
	ContentLength  int64    // {-1:'length is unknown', >=0:'read from Body'}
	Close     bool
	Cancel  <-chan struct{} // Deprecated
	Response *Response      // Go 1.7
	...
}
func NewRequest(method, url string, body io.Reader) (*Request, error)
func NewRequestWithContext(ctx context.Context, method, url string, body io.Reader) (*Request, error)

type Client struct {
	Transport RoundTripper
	CheckRedirect func(req *Request, via []*Request) error
	Jar       CookieJar
	Timeout   time.Duration // Go 1.3
}
func (c *Client) CloseIdleConnections()
func (c *Client) Do(req *Request) (*Response, error)
func (c *Client) Get(url string) (resp *Response, err error)
func (c *Client) Head(url string) (resp *Response, err error)
func (c *Client) Post(url, contentType string, body io.Reader) (resp *Response, err error)
func (c *Client) PostForm(url string, data url.Values) (resp *Response, err error)

type Transport struct {
	Proxy          func(*Request) (*url.URL, error)
	DialContext    func(ctx context.Context, network, addr string) (net.Conn, error)  // for creating unencrypted TCP connections
	DialTLSContext func(ctx context.Context, network, addr string) (net.Conn, error)
	Dial           func(network, addr string) (net.Conn, error)                       // Deprecated
	TLSClientConfig    *tls.Config
	TLSHandshakeTimeout time.Duration  // 10s
	DisableKeepAlives  bool
	DisableCompression bool
	MaxIdleConns        int  // 100 - connections across all hosts
	MaxIdleConnsPerHost int  //       connections to keep per-host
	MaxConnsPerHost     int  //       dialing, active, and idle states
	IdleConnTimeout       time.Duration  // 90s
	ResponseHeaderTimeout time.Duration  // 
	MaxResponseHeaderBytes int64
	WriteBufferSize   int
	ReadBufferSize    int
	...
}
func (t *Transport) Clone() *Transport
func (t *Transport) RoundTrip(req *Request) (*Response, error)  // executes a single HTTP transaction,
func (t *Transport) CancelRequest(req *Request)  // Deprecated
func (t *Transport) CloseIdleConnections()

var DefaultTransport RoundTripper = &Transport{
	Proxy: ProxyFromEnvironment,
	DialContext: (&net.Dialer{
		Timeout:   30 * time.Second,
		KeepAlive: 30 * time.Second,
		DualStack: true,   // Deprecated -> FallbackDelay (300ms)
	}).DialContext,
	ForceAttemptHTTP2:     true,
	MaxIdleConns:          100,
	IdleConnTimeout:       90 * time.Second,
	TLSHandshakeTimeout:   10 * time.Second,
	ExpectContinueTimeout: 1 * time.Second,
}

type Server struct {
	Addr    string
	Handler Handler
	TLSConfig  *tls.Config
	ReadTimeout       time.Duration   // 0 - Header + Body
	ReadHeaderTimeout time.Duration   // 0 - Header
	WriteTimeout      time.Duration   // 0
	IdleTimeout       time.Duration   // 0 - time to wait for the next request when keep-alives are enabled
	MaxHeaderBytes int
	ConnState   func(net.Conn, ConnState)           // called when a client connection changes state
	BaseContext func(net.Listener) context.Context  // base context for incoming requests on this server
	ConnContext func(ctx context.Context, c net.Conn) context.Context  // modifies the context used for a new connection
	...
}
func (srv *Server) Close() error
func (srv *Server) Shutdown(ctx context.Context) error   // gracefully shuts down the server without interrupting any active connections
func (srv *Server) ListenAndServe() error
func (srv *Server) ListenAndServeTLS(certFile, keyFile string) error
func (srv *Server) Serve(l net.Listener) error
func (srv *Server) ServeTLS(l net.Listener, certFile, keyFile string) error


// --------------------------------
//    Client
// --------------------------------
// GET
resp,_ := http.Get(URL)
defer resp.Body.Close()
_,err := io.Copy(os.Stdout, resp.Body)

// --------------------------------
// POST
post,_ := json.Marshal( map[string]int{"a":1, "b":2} )
resp,_ := http.Post(URL, "application/json", bytes.NewBuffer(post))
defer resp.Body.Close()

1. body,_ := ioutil.ReadAll(resp.Body)  // text resp
2. var res map[string]interface{}       // json resp
json.NewDecoder(resp.Body).Decode(&res)

// --------------------------------
// POST FORM
resp,_ := http.PostForm("http://example.com/form", url.Values{"key":{"Value"}, "id":{"123"}})
defer resp.Body.Close()

var res map[string]interface{}        // json resp
json.NewDecoder(resp.Body).Decode(&res)

// --------------------------------
// File Server
http.Handle("/tmpfiles/", http.StripPrefix("/tmpfiles/", http.FileServer(http.Dir("/tmp"))))

// --------------------------------
// http.Client + registerProtocol
t := &http.Transport{}
t.RegisterProtocol("file", http.NewFileTransport(http.Dir("/")))
c := &http.Client{Transport: t}
res,_ := c.Get("file:///etc/passwd")

// --------------------------------
// http.Client -> Do()
c := &http.Client{
	Timeout: 15 * time.Second,
	Transport: &http.Transport{},  // c.Transport.CancelRequest(req)  <-- DEPRECATED
}
req,_ := http.NewRequest("GET", URL.String(), nil)
resp,_ := c.Do(req)
defer resp.Body.Close()
	//resp.Body
  //resp.Status
  //resp.Header.Get("Content-Type")
  //resp.ContentLength
htmlData,_ := ioutil.ReadAll(resp.Body)
fmt.Printf(string(htmlData))

// --------------------------------
// http.Client -> Do() + ctx
func connect(url string, ctx context.Context) {
	c := &http.Client{}
	req,_ := http.NewRequestWithContext(ctx, "GET", url, nil)
	
	resp,_ := c.Do(req)
	defer res.Body.Close()
	
	htmlData,_ := ioutil.ReadAll(resp.Body)
	fmt.Printf(string(htmlData))
}

// --------------------------------
// http.Client (Transport + ctx) -> Get()
var timeout = time.Duration(time.Second)
var URL = "mail.ru"

func DialCtx(ctx context.Context, network, host string) (net.Conn, error) {
	//conn,_ := net.DialTimeout(network, host, timeout)
	//conn.SetDeadline(time.Now().Add(timeout))
	//return conn,nil
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	c := http.Client {
		Transport: &http.Transport {
		//DialContext: DialCtx,
			DialContext: (&net.Dialer{
				Timeout:   30 * time.Second,
				KeepAlive: 30 * time.Second,
				DualStack: true,                       // Deprecated -> FallbackDelay (300ms)
			}).DialContext,
		//Dial           func(network, host)       // Deprecated ! 1.4
		//DialTLS        func(network, host)       // Deprecated | 1.4
		//DialContext    func(ctx, network, host)  // 1.7
		//DialTLSContext func(ctx, network, host)  // 1.14
			ForceAttemptHTTP2:   true,
			IdleConnTimeout:     30 * time.Second,   // 90s - keep-alive | 1.7
			MaxIdleConnsPerHost: 0,                  // 2   - keep-alive MAX соединений с удаленным хостом
			DisableKeepAlives:   false,              // TRUE для единичного HTTP запроса
			MaxConnsPerHostL     0,                  // dialing, active, and idle states  | 1.11
			DisableCompression:  true,               // true = "Accept-Encoding: gzip"
			WriteBufferSize:     0,                  // 0 = 4KB | 1.13
			ReadBufferSize:      0,                  // 0 = 4KB | 1.13
		},
	}

	data,_ := c.Get(URL)
	defer data.Body.Close()
	_,err := io.Copy(os.Stdout, data.Body)
}

// --------------------------------
// SSL
package main
import (
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func main() {
	URL := "mail.ru"

	c := &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{},
			InsecureSkipVerify: true,             // для самоподписных серверных сертификатов
		}
	}
	data,_ := c.Get(URL)
	defer data.Body.Close()

	htmlData,_ := ioutil.ReadAll(data.Body)
	fmt.Printf(string(htmlData))
}

// --------------------------------
// TLS
package main
import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
)

func main() {
	URL := "mail.ru"

	caCert,_   := ioutil.ReadFile("server.crt")
	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)
	cert,_ := tls.LoadX509KeyPair("client.crt", "client.key")

	c := &http.Client {
		Transport: &http.Transport {
			TLSClientConfig: &tls.Config {
				RootCAs: caCertPool,
				InsecureSkipVerify: true,       // для самоподписных серверных сертификатов
				Certificates: []tls.Certificate{ cert },
			},
		},
	}
	resp,_ := c.Get(URL)
	defer resp.Body.Close()

	htmlData,_ := ioutil.ReadAll(resp.Body)

	fmt.Printf(resp.Status)
	fmt.Printf(string(htmlData))
}


// --------------------------------
//    Server
// --------------------------------
// http.Handle() + struct{ ServeHTTP() }
type countHandler struct {
	mu sync.Mutex
	n  int
}

func (h *countHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.mu.Lock();  defer h.mu.Unlock();
	h.n++
	fmt.Fprintf(w, "count is %d\n", h.n)
}

func main() {
	http.Handle("/count", new(countHandler))
	http.ListenAndServe(":8080", nil)
}

// --------------------------------
// m.Handle() + HandlerFunc{}
func h1() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "h1")
	})
}
m := http.NewServeMux()
m.Handle("/h1", h1())
http.ListenAndServe(":8080", m)

// --------------------------------
// http.HandleFunc()
h1 := func(w http.ResponseWriter, r *http.Request) {
	r.URL.Path
	r.Host
	io.WriteString(w, "text")
}
http.HandleFunc("/",     h1)
http.HandleFunc("/test", h2)
err := http.ListenAndServe(":8080", nil)
if err != nil { return; }

// --------------------------------
// m.HandleFunc()
m := http.NewServeMux()
m.HandleFunc("/time", h1)
m.HandleFunc("/",     h2)
err := http.ListenAndServe(":8080", m)
if err != nil { return; } 

// --------------------------------
// Timeout
m := http.NewServeMux()
m.HandleFunc("/time", h1)
m.HandleFunc("/",     h2)
srv := &http.Server {
	Addr:    "8001",
	Handler: m,
	ReadTimeout:  3 * time.Second,  // максимальная продолжительность операций чтения всего запроса, включая его тело
	WriteTimeout: 3 * time.Second,  // максимально допустимое время ожидания ответа
}
err := srv.ListenAndServe()
if err != nil { return; } 

// --------------------------------
// SSL
package main
import (
	"fmt"
	"net/http"
)

func Default(w http.ResponseWriter, req *http.Request) {
	fmt.Fprintf(w, "test\n")
}

func main() {
	http.HandleFunc("/", Default)
	err := http.ListenAndServeTLS(":2000", "server.crt", "server.key", nil)
	if err != nil { return; }
}

// --------------------------------
// TLS
package main
import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io/ioutil"
	"net/http"
)

type handler struct {}
func (h *handler) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	w.Write([]byte("test\n"))
}

func main() {
	caCert, err := ioutil.ReadFile("client.crt");    if err != nil { return; }
	caCertPool := x509.NewCertPool()              // x509
	caCertPool.AppendCertsFromPEM(caCert)

	cfg := &tls.Config {
		ClientAuth: tls.RequireAndVerifyClientCert,
		ClientCAs:  caCertPool,
	}

	srv := &http.Server{
		Addr: PORT,
		Handler: &handler{},
		TLSConfig: cfg,
	}
	srv.ListenAndServeTLS("server.crt", "server.key")
}

// --------------------------------
// Handle -> ServeHTTP (Mutex, Trailer) | .secure return && ServeFile()
package main
import (
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"sync"
)

type apiOne struct {  // type Handler interface { ServeHTTP(ResponseWriter, *Request) }
	mu sync.Mutex       // guards n
	n  int
}

func (h *apiOne) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.n++
	fmt.Fprintf(w, "apiOne count is %d\n", h.n)
}

func apiSecond() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "apiSecond\n")
	})
}

type dotHidingFS struct { // type FileSystem interface { Open(name string) (File, error); }
	http.FileSystem
}

func (fs dotHidingFS) Open(name string) (http.File, error) {
	if containsDotFile(name) {
		return nil, os.ErrPermission
	}
	file, err := fs.FileSystem.Open(name)
	if err != nil { return nil, err; }
	return dotHidingFile{file}, err
}

type dotHidingFile struct { // type File interface { Readdir(count int) ([]os.FileInfo, error), ... }
	http.File
}

func (f dotHidingFile) Readdir(n int) (fis []os.FileInfo, err error) {
	files, err := f.File.Readdir(n)
	for _, file := range files {
		if !strings.HasPrefix(file.Name(), ".") {
			fis = append(fis, file)
		}
	}
	return
}

func containsDotFile(name string) bool {
	parts := strings.Split(name, "/")
	for _, part := range parts {
		if strings.HasPrefix(part, ".") {
			return true
		}
	}
	return false
}

func myHendleFunc(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Trailer", "example")
	w.Header().Set("Content-Type", "text/plain; charset=utf-8") // normal header
	w.WriteHeader(http.StatusOK)
	io.WriteString(w, "This HTTP response has both headers before this text and trailers at the end.\n")
}

func main() {
	fs := dotHidingFS{
		http.Dir("."),
	}
	m := http.NewServeMux()
	m.Handle("/api1", new(apiOne))
	m.Handle("/api2", apiSecond())
	m.Handle("/file/", http.StripPrefix("/file/", http.FileServer(http.Dir("."))))
	m.Handle("/secure/", http.StripPrefix("/secure/", http.FileServer(fs)))  // func FileServer(root FileSystem) Handler
	m.HandleFunc("/send", myHendleFunc)
	m.HandleFunc("/file2/", func(w http.ResponseWriter, r *http.Request) {
		fname := r.URL.Path[7:]
		if len(fname) == 0 || strings.HasPrefix(fname, ".") {
			http.NotFound(w, r)
			return
		}
		http.ServeFile(w, r, r.URL.Path[7:])
	})
	m.HandleFunc("/", func(w http.ResponseWriter, req *http.Request) {
		if req.URL.Path != "/" {
			http.NotFound(w, req)
			return
		}
		io.WriteString(w, "Welcome to the home page!")
	})

	srv := &http.Server{
		Addr:    "127.0.0.1:8080",
		Handler: m,
	}

	err := srv.ListenAndServe()
	if err != nil { fmt.Println(err); return; }
}


// --------------------------------
//    File Server
// --------------------------------
// v1
http.Handle("/", http.FileServer(http.Dir("/tmp")))
http.Handle("/", http.FileServer(http.FS(fsys)))
http.Handle("/tmpfiles/", http.StripPrefix("/tmpfiles/", http.FileServer(http.Dir("/tmp"))))
http.ListenAndServe(":8080", nil)
// v2
http.ListenAndServe(":8080", http.FileServer(http.Dir("/usr/share/doc")))