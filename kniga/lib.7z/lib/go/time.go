
// --------------------------------
//    Time
// --------------------------------
golang.org/src/time/format.go
Mon Jan 2 15:04:05 MST 2006
"2006-01-02 15:04:05.999999999 -0700 MST"
// const
time.Nanosecond
time.Microsecond
time.Millisecond
time.Minute
time.Hour 
// --------------------------------
start   := time.Now()
stop    := time.Now()
latency := stop.Sub(start)
fmt.Printf("struct: %13v \n", latency)
// --------------------------------
t := time.Now()
t.Hour(), t.Minute()
t.Weekday(), t.Day(), t.Month(), t.Year()
t.Format(time.RFC3339)       // 2019-01-29T11:18:35+02:00
t.Format("01 January 2006")  // 01 January 2019
loc, _ := time.LoadLocation("Europe/Paris")
t.In(loc)                    // 2019-01-29 10:18:35.01478 +0100 CET
// --------------------------------
t := time.Now()              // 1643975457
t1 := t.Add(time.Second * 2) // 1643975459
// --------------------------------
// https://www.utctime.net/msk-time-now
time.Date(year int, month Month, day, hour, min, sec, nsec int, loc *Location) Time
time.Date(2022, time.February, 5, 13, 50, 5, 0, time.UTC).Local()                 // 2022-02-05 13:50:05 +0000 UTC
t, _ := time.Parse("2006-Jan-02", "2022-Feb-05")                                  // 2022-02-05 00:00:00 +0000 UTC
t, _ := time.Parse(time.RFC3339, "2022-02-05T13:50:05Z")                          // 2022-02-05 13:50:05 +0000 UTC
t, _ := time.Parse(time.RFC3339, "2022-02-05T10:50:05+03:00")                     // 2022-02-05 10:50:05 +0300 +0300
// --------------------------------
const (
	Sunday Weekday = iota
	Monday
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
)
type Weekday int
func (d Weekday) String() string
// --------------------------------
const (
	January Month = 1 + iota
	February
	March
	April
	May
	June
	July
	August
	September
	October
	November
	December
)
type Month int
func (m Month) String() string


// --------------------------------
//    Tick & Ticker & Timer
// --------------------------------
time.Sleep(time.Second)
time.After(d Duration) <-chan Time
time.Tick(d Duration) <-chan Time
// --------------------------------
c := time.Tick(time.Second)
for n := range c {
	fmt.Printf("%v \n", n)
}
// --------------------------------
ticker := time.NewTicker(time.Second)  // таймер - type Ticker struct { C <-chan Time }
defer ticker.Stop()                    // Ticker требует ручного закрытия
for {
	select {
		case <-done:
			return
		case t := <-ticker.C:  // срабатывет каждую секунду
			fmt.Println("Current time: ", t)
	}
}
// --------------------------------
for {
	select {
		case <chan> <- rand.Intn(10):
		case <-time.After(time.Second):
			close(<chan>)
			break
	}
}
// --------------------------------
t := time.NewTimer(time.Second)  // таймер - type Timer struct { C <-chan Time }
for {
	select {
		case <chan> <- rand.Intn(10):
		case <-t.C:   // задает время работы цыкла 'for'
			close(<chan>)
			break
	}
}


// --------------------------------
//    Parse
// --------------------------------
d, err := time.Parse("15:04", "12:10")  // 0000-01-01 12:10:00 +0000 UTC
d.Hour()    // 12
d.Minute()  // 10
// --------------------------------
// in := "[16/Nov/2017:10:49:46 +0200]"
r := regexp.MustCompile(`.*\[(\d\d\/\w+/\d\d\d\d:\d\d:\d\d:\d\d.*)\].*`)
if r.MatchString(in) {
	match := r.FindStringSubmatch(in)
	dt, err := time.Parse("02/Jan/2006:15:04:05 -0700", match[1])
	newFormat := dt.Format(time.RFC850)   // Thursday, 16-Nov-17 10:49:46 EET
}


// --------------------------------
//    Random
// --------------------------------
rand.Seed(time.Now().UnixNano())
t := time.Second
r := rand.Int63n(int64(t * 3))
s := t + time.Duration(r)
fmt.Printf("%v %v %v \n", t, r, s)  // 1s 1889237169 2.889237169s
