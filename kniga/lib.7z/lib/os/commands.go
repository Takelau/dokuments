
// --------------------------
//   sys info
// --------------------------
whoami        // логин
pwd           // сведения о текущей рабочей директории

uname -a      // показать информацию о версии операционной системы
lsmod         // вывести загруженные модули ядра
ps -e         // Отобразить запущенные процессы

cat /proc/cpuinfo     // отобразить информацию о процессоре
cat /proc/interrupts  // показать прерывания
cat /proc/meminfo     // проверить использование памяти
cat /proc/swaps       // показать файл(ы) подкачки
cat /proc/version     // вывести версию ядра
cat /proc/net/dev     // показать сетевые интерфейсы и статистику по ним
cat /proc/mounts      // отобразить смонтированные файловые системы

lspci -tv   // показать в виде дерева PCI устройства
lsusb -tv   // показать в виде дерева USB устройства

date      // текущая дата / date ММДДЧЧммГГГГ.СС
clock -w  // сохранить системное время в BIOS

last reboot   // отобразить историю перезагрузок системы
last user1    // отобразить историю регистрации пользователя user1 в системе и время его нахождения в ней


// --------------------------
//   process
// --------------------------
ps -e            // показывает запущенные процессы
ps aux           // показывает все системные процессы.
ps aux --forest  // показывает все системные процессы, вывод процессов в форме дерева в определенной иерархии
ps -u root
fuser -va 23/tcp            // идентификатор процесса, открывшего ТСР порт 23
fuser -va /etc/resolv.conf  // идентификатор процесса, открывшего файл


// --------------------------
//   Net
// --------------------------
lsof -i 4
lsof -i TCP
lsof -i :21
lsof -i @127.0.0.1
lsof -i @127.0.0.1:1000=1234
lsof -i -s TCP:LISTEN
lsof -i | grep -i LISTEN
lsof -i -s TCP:ESTABLISHED
lsof -i | grep -i ESTABLISHED
// активные процессы
lsof -i -P -n -s TCP:LISTEN
lsof -i -P -n | cut -f 1 -d " "| uniq | tail -n +2 
lsof -p 8236              // список открытых файлов конкретного процесса
lsof -c httpd | head -15  // первые 15 файлов открытых процессом 'httpd'
// пользователь
lsof -u <uid> | wc -l     // список файлов открытых пользователем
lsof -u <uid> -i -a

route         // Показать таблицу маршрутизации
netstat -rn   // Показать таблицу маршрутизации
netstat -a    // Показать сетевые подключения
arp -a        // Показать таблицу ARP (протокол определения адреса)

ifconfig      // Вывести информацию о сетевом интерфейсе
ip link show  // отобразить состояние всех интерфейсов
mii-tool eth0 // отобразить статус и тип соединения для интерфейса eth0
ethtool eth0  // отображает статистику интерфеса eth0 с выводом такой информации, как поддерживаемые и текущие режимы соединения
iwconfig eth1 // показать конфигурацию беспроводного сетевого интерфейса eth1
iwlist scan   // просканировать эфир на предмет, доступности беспроводных точек доступа

tcpdump tcp port 80  // отобразить весь трафик на TCP-порт 80

tracepath [options] <destination>
traceroute [ -46dFITnreAUDV ] [ -f first_ttl ] [ -g gate,... ] [ -i device ] [ -m max_ttl ] [ -N squeries ] [ -p port ] [ -t tos ] [ -l flow_label ] [ -w MAX,HERE,NEAR ] [ -q nqueries ] [ -s src_addr ] [ -z sendwait ] [ --fwmark=num ] host [ packetlen ]

trafshow [-vpnb] [-a len] [-c conf] [-i ifname] [-s str] [-u port] [-R refresh] [-P purge] [-F file | expr]
nethogs
iptraf-ng
iftop


// --------------------------
//   ssh
// --------------------------
ssh myserver ps >  /tmp/ps.out   // вывод в файл локальной системы
ssh myserver ps \> /tmp/ps.out   // вывод в файл удаленной системы
ssh myserver bash < ./run.sh     // запуск локального скрипта на удаленной системе


// --------------------------
//   action
// --------------------------
cp f d/f     // Копирование файла в файл
cp f d/      // Копирования файла в папку / {i-требуется ли перезапись;  n-не перезаписывать файлы;  --backup=numbered создавать резервную копию}
cp -r s d/   // Копирование папки в папку
cp -rT s d/  // Копирование содержимого папки в папку (v1)
cp s/* d/    // Копирование содержимого папки в папку (v2)  / {p-сохранение аттрибутов}                   */
cp -reflink=always f d/  // Обработка разреженных файлов

chmod ugo+rwx d
chown    user1 file1   // назначить владельцем файла file1 пользователя user1
chown -R user1 d       // назначить рекурсивно владельцем директории d пользователя user1
chgrp group1 file1     // сменить группу-владельца файла file1 на group1

find / -perm -u+s           // найти, начиная от корня, все файлы с выставленным SUID
chmod u+s /bin/binary_file  // назначить SUID-бит файлу /bin/binary_file. Это даёт возможность любому пользователю запускать на выполнение файл с полномочиями владельца файла
chmod u-s /bin/binary_file  // снять SUID-бит с файла /bin/binary_file
chmod g+s /home/public      // назначить SGID-бит директории /home/public
chmod g-s /home/public      // снять SGID-бит с директории /home/public
chmod o+t /home/public      // назначить STIKY-бит директории /home/public. Позволяет удалять файлы только владельцам
chmod o-t /home/public      // снять STIKY-бит с директории /home/public

	
chattr +a file1  // позволить открывать файл на запись только в режиме добавления
chattr +c file1  // позволяет ядру автоматически сжимать/разжимать содержимое файла
chattr +d file1  // указывает утилите dump игнорировать данный файл во время выполнения backup
chattr +i file1  // делает файл недоступным для любых изменений: редактирование, удаление, перемещение, создание линков на него
chattr +s file1  // позволяет сделать удаление файла безопасным, т.е. выставленный атрибут s говорит о том, что при удалении файла, место, занимаемое файлом на диске заполняется нулями, что предотвращяет возможность восстановления данных
chattr +S file1  // указывает, что, при сохранении изменений, будет произведена синхронизация, как при выполнении команды sync
chattr +u file1  // данный атрибут указывает, что при удалении файла содержимое его будет сохранено и при необходимости пользователь сможет его восстановить


// --------------------------
//   find
// --------------------------
which halt    // отображает полный путь к файлу 'halt'
whereis halt  // показывает размещение бинарных файлов, исходных кодов и руководств, относящихся к файлу 'halt'

// поиск в файлах
ack    "root" /etc/             // поиск всех файлов содержащих слово root в папке /etc/
ack -C "root" /etc/             // + строки до и после найденой мтроки
ack "^A[A-Z_]+=" /etc/   
ack --type=xml "root" /etc/     // ack --help-types

grep --color=always ...         // {r - выполнить рекурсивный поиск подкаталогов, E - включить расширенное регулярное выражение}
grep -r "root" /etc/
grep -r -С2 "root" /etc/        // + строки до и после найденой мтроки
grep -r -E "^A[A-Z_]+\=" /etc/  // поиск по регулярному выражения
grep -r -F "[Install]" /usr/    // поиск фиксированной строки

// поиск файлов
find / -name file1                        // найти файлы и директории с именем file1. Поиск начать с корня (/)
find / -user user1                        // найти файл и директорию принадлежащие пользователю user1. Поиск начать с корня (/)
find /usr/bin -type f -atime +100         // найти все файлы в '/usr/bin', время последнего обращения к которым более 100 дней
find /usr/bin -type f -mtime -10          // найти все файлы в '/usr/bin', созданные или изменённые в течении последних 10 дней
find / -name *.rpm -exec chmod 755 '{}';  // найти все фалы и директории '.rpm', и изменить права доступа к ним
find / -xdev -name "*.rpm"                // найти все фалы и директории, имена которых оканчиваются на '.rpm', игнорируя съёмные носители
find / -perm -u+s                         // найти, начиная от корня, все файлы с выставленным SUID

// поиск больших файлов
ncdu /home                               // размер + список [дерево]
du -a /home/ | sort -n -r | head -n 20   // размер + список
find /home -xdev -type f -size +100M     // список
find /home -xdev -type f -size +100M -exec du -sh {} ';' | sort -rh  // размер + список


// --------------------------
//   hdd
// --------------------------
df -h                // отображает информацию о смонтированных разделах
du -sh dir1          // подсчитывает и выводит размер, занимаемый директорией 'dir1'
du -sk * | sort -rn  // отображает размер и имена файлов и директорий

hdparm -i  /dev/hda   // характеристики жесткого диска
hdparm -tT /dev/sda   // протестировать производительность чтения данных с жесткого диска

mount /dev/hda2 /mnt/hda2
mount /dev/cdrom /mnt/cdrom        // CD или DVD
mount /dev/fd0 /mnt/floppy         // флоппи-диск
mount /dev/hdc /mnt/cdrecorder     // CD-R/CD-RW или DVD-R/DVD-RW(+-)
mount -o loop file.iso /mnt/cdrom  // ISO-образ
mount -t vfat /dev/hda5 /mnt/hda5  // Windows FAT32
mount -t smbfs -o username=user,password=pass //winclient/share /mnt/share    // монтировать сетевую файловую систему Windows (SMB/CIFS)

umount -n /mnt/hda2   // если недостаточно места на диске
fuser -km /mnt/hda2   // принудительное размонтирование раздела

badblocks -v /dev/hda1  // проверить раздел hda1 на наличие bad-блоков
fsck /dev/hda1          // проверить/восстановить целостность linux-файловой системы раздела hda1
fsck.ext3 /dev/hda1     // проверить/восстановить целостность файловой системы ext3 раздела hda1
fsck.vfat /dev/hda1  ||  fsck.msdos /dev/hda1  ||  dosfsck /dev/hda1  // FAT

mkfs -t vfat 32 -F /dev/hda1  // создать файловую систему FAT32 на разделе hda1
fdformat -n /dev/fd0          // форматирование флоппи-диска без проверки


// --------------------------
//   swap
// --------------------------
mkswap /dev/hda3  // создание swap-пространства на разделе hda3
swapon /dev/hda3  // активировать swap-пространство, расположенное на разделе hda3


// --------------------------
//   архивация
// --------------------------
tar  // {c - создание архивного файла, z - архивирование файла, f - имя файла вывода}
tar -czf ${HOSTNAME}_logs.tar.gz /var/log/


// --------------------------
//   backup
// --------------------------
dump -0aj -f /tmp/home0.bak /home  // создать полную резервную копию директории /home в файл /tmp/home0.bak
dump -1aj -f /tmp/home0.bak /home  // создать инкрементальную резервную копию директории /home в файл /tmp/home0.bak
restore -if /tmp/home0.bak         // восстановить из резервной копии /tmp/home0.bak
rsync -rogpav --delete /home /tmp                    // синхронизировать /tmp с /home
rsync -rogpav -e ssh --delete /home ip_address:/tmp  // синхронизировать через SSH-туннель
rsync -az -e ssh --delete ip_addr:/home/public /home/local // синхронизировать локальную директорию с удалённой директорией через ssh-туннель со сжатием
rsync -az -e ssh --delete /home/local ip_addr:/home/public // синхронизировать удалённую директорию с локальной директорией через ssh-туннель со сжатием
dd bs=1M if=/dev/hda | gzip | ssh user@ip_addr 'dd of=hda.gz'                     // сделать «слепок» локального диска в файл на удалённом компьютере через ssh-туннель
tar -Puf backup.tar /home/user                                                    // создать инкрементальную резервную копию директории '/home/user' в файл backup.tar с сохранением полномочий
( cd /tmp/local/ && tar c . ) | ssh -C user@ip_addr 'cd /home/share/ && tar x -p' // копирование содержимого /tmp/local на удалённый компьютер через ssh-туннель в /home/share/
( tar c /home ) | ssh -C user@ip_addr 'cd /home/backup-home && tar x -p'          // копирование содержимого /home на удалённый компьютер через ssh-туннель в /home/backup-home
tar cf - . | (cd /tmp/backup ; tar xf - )                                         // копирование одной директории в другую с сохранением полномочий и линков
find /home/user1 -name '*.txt' | xargs cp -av --target-directory=/home/backup/ --parents  // поиск в /home/user1 всех файлов, имена которых оканчиваются на '.txt', и копирование их в другую директорию
find /var/log -name '*.log' | tar cv --files-from=- | bzip2 > log.tar.bz2                 // поиск в /var/log всех файлов, имена которых оканчиваются на '.log', и создание bzip-архива из них
dd if=/dev/hda of=/dev/fd0 bs=512 count=1  // создать копию MBR (Master Boot Record) с /dev/hda на флоппи-диск
dd if=/dev/fd0 of=/dev/hda bs=512 count=1  // восстановить MBR с флоппи-диска на /dev/hda


// --------------------------
//   user
// --------------------------
id <user>  // uid=1000(user) gid=1000(user) groups=1002(user)
useradd    // не интерактивная утилита
adduser    // интерактивная утилита

groupadd <name>  // создать новую группу с именем name
groupdel <name>  // удалить группу name
groupmod -n new_name old_name  // переименовать группу

useradd -c "comment" -g <group> -d /home/<user> -s /bin/bash <user>
usermod -c "comment" -g <group> -d /ftp/<user> -s /bin/nologin <user>
usermod -aG <group> <user>  // добавление пользователя в группу
usermod -g <group1> <user>  // изменить основнуб группу пользователя на 'group1'
userdel -r <user>           // {r-даление домашнего каталога, f-авершить все процессы}



chage -E 2005-12-31 <user>  // установить дату окончания действия учётной записи пользователя
pwck    // проверить корректность системных файлов учётных записей. Проверяются файлы /etc/passwd и /etc/shadow
grpck   // проверяет корректность системных файлов учётных записей. Проверяется файл/etc/group


// --------------------------
//   Nginx
// --------------------------
  Referrer-Policy
add_header Referrer-Policy 'origin-when-cross-origin';
// значения
""                            браузер устанавливает заголовок самостоятельно на остове данных из <meta>, <a> или <link>
no-referrer                   говорит браузеру никогда не слать заголовок referer для запросов с твоего сайта
no-referrer-when-downgrade    браузер НЕ будет отправлять значение referer при переходе с HTTPS на HTTP, но отправит полную ссылку при переходе с HTTP куда-то еще
	https://scotthelme.co.uk/blog1/  ->  http://scotthelme.co.uk/blog2/   NULL
	https://scotthelme.co.uk/blog1/  ->  https://scotthelme.co.uk/blog2/  https://scotthelme.co.uk/blog1/
	http://scotthelme.co.uk/blog1/   ->  http://scotthelme.co.uk/blog2/   http://scotthelme.co.uk/blog1/
	http://scotthelme.co.uk/blog1/   ->  http://example.com               http://scotthelme.co.uk/blog1/
	http://scotthelme.co.uk/blog1/   ->  https://example.com              http://scotthelme.co.uk/blog1/
	https://scotthelme.co.uk/blog1/  ->  http://example.com               NULL
origin                     браузер всегда отображает в referer только сайт, откуда пришел запрос. Всю дополнительную информацию из URL он вырезает
	https://scotthelme.co.uk/blog1/  ->  https://scotthelme.co.uk/blog2/  https://scotthelme.co.uk/
	https://scotthelme.co.uk/blog1/  ->  http://scotthelme.co.uk/blog2/   https://scotthelme.co.uk/
	https://scotthelme.co.uk/blog1/  ->  http://example.com               https://scotthelme.co.uk/
origin-when-cross-origin   браузер отправляет полный URL на тот же сайт, и неполный (только название) на все остальные
	https://scotthelme.co.uk/blog1/  ->  https://scotthelme.co.uk/blog2/  https://scotthelme.co.uk/blog1/
	https://scotthelme.co.uk/blog1/  ->  https://example.com/             https://scotthelme.co.uk/
	https://scotthelme.co.uk/blog1/  ->  http://scotthelme.co.uk/blog2/   https://scotthelme.co.uk/
	https://scotthelme.co.uk/blog1/  ->  http://example.com/              https://scotthelme.co.uk/
	http://scotthelme.co.uk/blog1/   ->  https://scotthelme.co.uk/blog2/  http://scotthelme.co.uk/
same-origin                браузер отправляет значение referer только в том случае, если ссылка ведет на тот же сайт. В любом другом случае значение будет пустое
	https://scotthelme.co.uk/blog1/  ->  https://scotthelme.co.uk/blog2/  https://scotthelme.co.uk/blog1/
	https://scotthelme.co.uk/blog1/  ->  http://scotthelme.co.uk/blog2/   NULL
	https://scotthelme.co.uk/blog1/  ->  http://example.com               NULL
	https://scotthelme.co.uk/blog1/  ->  https://example.com              NULL
strict-origin              аналогично origin, но данный заголовок запрещает слать информацию на HTTP, только на защищенные ссылки: HTTPS
	https://scotthelme.co.uk/blog1/  ->  https://scotthelme.co.uk/blog2/  https://scotthelme.co.uk/
	https://scotthelme.co.uk/blog1/  ->  http://scotthelme.co.uk/blog2/   NULL
	https://scotthelme.co.uk/blog1/  ->  http://example.com               NULL
	http://scotthelme.co.uk/blog1/   ->  https://scotthelme.co.uk/blog2/  http://scotthelme.co.uk/
	http://scotthelme.co.uk/blog1/   ->  https://scotthelme.co.uk/blog2/  http://scotthelme.co.uk/
	http://scotthelme.co.uk/blog1/   ->  http://example.com               http://scotthelme.co.uk/
strict-origin-when-cross-origin   аналогично origin-when-cross-origin, но запрещает делать downgrade безопасности: отправляет пустоту, если пользователь переходит с HTTPS на HTTP
  https://scotthelme.co.uk/blog1/  ->  https://scotthelme.co.uk/blog2/  https://scotthelme.co.uk/blog1/
	https://scotthelme.co.uk/blog1/  ->  https://example.com/             https://scotthelme.co.uk/
	https://scotthelme.co.uk/blog1/  ->  http://scotthelme.co.uk/blog2/   NULL
	https://scotthelme.co.uk/blog1/  ->  http://example.com/              NULL
	http://scotthelme.co.uk/blog1/   ->  http://example.com/              http://scotthelme.co.uk/
unsafe-url                 браузер всегда посылает полный URL, с любого сайта

// referrer
no-referrer-when-downgrade      информация отправляется в том случае, когда уровень безопасности протокола остается неизменным или ведет на более защищенный (HTTP > HTTP, HTTPS > HTTPS или HTTP > HTTPS);
no-referrer-when-cross-origin   информация отправляется только в том случае, когда уровень безопасности протокола остается неизменным (HTTP > HTTP или HTTPS > HTTPS);
origin                          оставляет только источник документа: https://domain.ru/page.html > https://domain.ru;
origin-when-cross-origin        если запрос направляет на отличающийся протокол или веб-ресурс, то срабатывает как origin;
no-referrer                     информация не отправляется вместе с запросами.

// proxy
HTTP_VIA
VIA
Proxy-Connection
HTTP_X_FORWARDED_FOR
HTTP_FORWARDED_FOR
HTTP_X_FORWARDED
HTTP_FORWARDED
HTTP_CLIENT_IP
HTTP_FORWARDED_FOR_IP
X-PROXY-ID
MT-PROXY-ID
X-TINYPROXY
X_FORWARDED_FOR
FORWARDED_FOR
X_FORWARDED
FORWARDED
CLIENT-IP
CLIENT_IP
PROXY-AGENT
HTTP_X_CLUSTER_CLIENT_IP
FORWARDED_FOR_IP
HTTP_PROXY_CONNECTION