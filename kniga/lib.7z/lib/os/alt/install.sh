#!/bin/bash


# --------------------------
#   Sisyphus
# --------------------------
apt-get clean
apt-get update
apt-get dist-upgrade
apt-get install apt-repo
apt-repo rm all
apt-repo set sisyphus
echo "%_priority_distbranch sisyphus" >> /etc/rpm/macros


# --------------------------
#   Update
# --------------------------
apt-get clean
apt-get update
apt-get dist-upgrade -d   # загрузка обновлений
apt-get dist-upgrade      # само обновление
reboot


# --------------------------
#   VirtualBox
# --------------------------
# apt-get install dkms linux-headers-$(uname -r)
mount /dev/cdrom /mnt
bash /mnt/VBoxLinuxAdditions.run
reboot


# --------------------------
#   Util
# --------------------------
timedatectl set-timezone Europe/Moscow
hostnamectl set-hostname name
hostnamectl status

apt-get install nano htop mc
apt-get install git wget curl dnsutils
apt-get install net-tools
apt-get install iptraf-ng
apt-get install httpie


# --------------------------
#   Network
# --------------------------
systemctl stop rpcbind && systemctl disable rpcbind   # simpla
systemctl stop smb && systemctl disable smb           # simpla  samba

# ipv6
nano /etc/sysctl.conf
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1

/sbin/sysctl -p

nano /etc/sysconfig/network
NETWORKING="yes"
NETWORKING_IPV6="no"

nano /etc/avahi/avahi-daemon.conf   # Desktop
use-ipv6=no

# dns
systemctl stop dnsmasq && systemctl disable dnsmasq   # simpla
nano /etc/resolv.conf
nameserver 77.88.8.8


# --------------------------
#   IpFw
# --------------------------
apt-get install iptables && apt-get install iptables-ipv6
systemctl enable iptables  && systemctl start iptables
systemctl enable ip6tables && systemctl start ip6tables

cat <<EOT > /etc/sysconfig/iptables_params
IPTABLES_MODULES=""
IPTABLES_MODULES_UNLOAD="yes"
IPTABLES_SAVE_ON_STOP="no"
IPTABLES_SAVE_ON_RESTART="yes"
IPTABLES_SAVE_COUNTER="no"
IPTABLES_STATUS_NUMERIC="yes"
IPTABLES_STATUS_VERBOSE="yes"
IPTABLES_STATUS_LINENUMBERS="yes"
EOT

cat <<EOT > /etc/sysconfig/ip6tables_params
IP6TABLES_MODULES=""
IP6TABLES_MODULES_UNLOAD="yes"
IP6TABLES_SAVE_ON_STOP="no"
IP6TABLES_SAVE_ON_RESTART="yes"
IP6TABLES_SAVE_COUNTER="no"
IP6TABLES_STATUS_NUMERIC="yes"
IP6TABLES_STATUS_VERBOSE="no"
IP6TABLES_STATUS_LINENUMBERS="yes"
EOT


# --------------------------
#   Post update
# --------------------------
# .bashrc && .cshrc
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'

# .bash_history
go clean -cache && go clean -modcache && go clean -testcache
go mod tidy
docker run -it -v /vlm/work/src/nami_f35:/work/src/nami_f35 --name nami-f35 fedora:35 /bin/bash
git clone https://github.com/ds248a/notify.git
git remote set-url origin git@github.com:ds248a/notify
git add -A
git commit -am "Notify dir"
git push
go test -run='TestWatcher_createEvent/create_directory_(regexp)'
ssh -l hataru 192.168.1.211 -p 40004
ssh -l hataru 192.168.1.200 -p 40004
ssh -l takelau 192.168.1.210 -p 40004


# --------------------------
#   Git
# --------------------------
# .gitconfig
[user]
    email = ds248a@gmail.com
    name = ds248a
[init]
    defaultBranch = "main"
[alias]
    hist = log --pretty=format:\"%h %cd | %s%d [%cn]\" --since=3.month --graph --date=short
    type = cat-file -t
    dump = cat-file -p


# --------------------------
#   C
# --------------------------
# apt-get install -y build-essential
apt-get install clang clang-tool clang-libs
apt-get install gcc
apt-get install llvm
apt-get install cmake gdb lldb


# --------------------------
#   Go
# --------------------------
# .bash_profile
export GOOS=linux             # LiteIDE
export GOARCH=amd64           # LiteIDE
export LC_CTYPE=en_US.UTF-8   # docui
export TERM=xterm-256color    # docui
export GOROOT=/vlm/go/go117
export GOPATH=/vlm/work
PATH=$PATH:$GOROOT/bin:$GOPATH/bin
export PATH


# --------------------------
#   Codelite
# --------------------------
apt-get install -y clangd
# apt install libpcre2-32-0

Diff Plugin
Editor Config
Git
LSP
Outline
SFTP
SmartComplrtion
Source Code Formater
Wizards
Word Completion
wxcrafter

# desktop -> codelite %f


# --------------------------
#   Sublime
# --------------------------
# desktop -> /opt/sublime_text/sublime_text %F
# desktop -> /opt/sublime_merge/sublime_merge %F


# --------------------------
#   Lite IDE
# --------------------------
# desktop -> sh -c "export LD_LIBRARY_PATH=/home/takelau/liteide/lib:$LD_LIBRARY_PATH; /home/takelau/liteide/bin/liteide %F"


# --------------------------
#   Code
# --------------------------
# desktop -> /usr/share/code/code --no-sandbox --unity-launch %F



