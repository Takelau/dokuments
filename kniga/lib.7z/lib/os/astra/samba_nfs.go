
// --------------------------------
//    Samba & NFS
// --------------------------------

// --------------------------------
// настройка
apt install ifenslave-2.6

// 1 узел
nano  /etc/network/interfaces
auto lo
iface lo inet loopback

auto eth0  // интерфейс для доступа к отдельным узлам кластера
iface eth0 inet static  address 10.10.10.99  netmask 255.255.255.0  gateway 10.10.10.2

auto eth1  // heartbeat-интерфейс, по которому осуществляется доступ к сервису
iface eth1 inet static  address 192.168.25.8  netmask 255.255.255.0

auto bond0  // логический интерфейс (bonding) на базе физических eth2 и eth3 и используется для синхронизации DRBD-ресурсов
iface bond0 inet static  address 192.168.122.10  netmask 255.255.255.0  gateway 192.168.122.1

bond_mode balance-rr
bond_miimon 100
bond_downdelay 200
bond_updelay 200
slaves eth2 eth3

// 2 узел
auto lo
iface lo inet loopback

auto eth0
iface eth0 inet static  address 10.10.10.100  netmask 255.255.255.0  gateway 10.10.10.2

auto eth1
iface eth1 inet static  address 192.168.25.9  netmask 255.255.255.0

auto bond0
iface bond0 inet static  address 192.168.122.11  netmask 255.255.255.0  gateway 192.168.122.1

bond_mode balance-rr
bond_miimon 100
bond_downdelay 200
bond_updelay 200
slaves eth2 eth3

// на узлах выполнить
modprobe bonding
echo "bonding" >> /etc/modules
init 6


// --------------------------------
// Samba-сервер
// убрать на узлах скрипты из автозагрузки
update-rc.d -f drbd  remove
update-rc.d -f samba remove

nano /etc/samba/smb.conf
[share-drbd]
comment = Astra Linux Samba Share
path = /opt/main
browsable = yes
guest ok = yes
read only = no
create mask = 0755

// 1 узел
// создать ресурс DRBD-раздела
crm configure primitive drbd_main ocf:linbit:drbd params  // drbd_main - наименование
	drbd_resource="main"
	op monitor interval="60s"
	op start interval="0" timeout="240s"
	op stop  interval="0" timeout="240s"
	op monitor role=Master interval="10s"
	op monitor role=Slave  interval="30s"

// указать определение ведущего master/slave для созданного DRBD-ресурса
crm configure ms ms_drbd_main drbd_main meta   // ms_drbd_main - наименование
	master-max="1" master-node-max="1"
	clone-max="2"  clone-node-max="1"
	notify="true"

// создать ресурс точки монтирования DRBD-раздела -> /opt/main
crm configure primitive fs_main ocf:heartbeat:Filesystem params   // fs_main - наименование
	device="/dev/drbd0" directory="/opt/main" fstype="ext4" options="noatime"

// создать ресурс отказоустойчивого IP-адреса
crm configure primitive failover_ip ocf:heartbeat:IPaddr2 params ip=192.168.25.10 nic=eth  // failover_ip - наименование
crm configure primitive samba lsb:samba                                                    // samba       - наименование
crm configure group group_main fs_main failover_ip samba                                   // group_main  - наименование

// правило монтирования -> монтировать ресурсы на узле, где DRBD-ресурсы находятся в состоянии ведущих
crm configure colocation cluster_resources inf: fs_main ms_drbd_main:Master                // cluster_resources - наименование

// порядок запуска сервисов -> после запуска соответствующих DRBD разделов
crm configure order all_after_drbd                                                         // all_after_drbd - наименование
	inf: ms_drbd_main:promote group_main:start

// установить предпочтение запуска ресурсов ведущего/ведомого
crm configure location  prefer_main_server-1  ms_drbd_main 100: server-1      // будет основной сервер
crm configure location  prefer_main_server-2  ms_drbd_main 50:  server-2
crm configure location  prefer_group_main_server-1  group_main 100: server-1  // будет основной сервер
crm configure location  prefer_group_main_server-2  group_main 50:  server-2

// проверка состояния
crm status


// --------------------------------
// NFS-сервер
// на узлах убрать из автозагрузки скрипты, которые в дальнейшем будут контролироваться corosync
update-rc.d -f drbd remove
update-rc.d -f nfs-common remove
update-rc.d -f nfs-kernel-server remove

// 1 узел
// создать ресурс DRBD-раздела
crm configure primitive drbd_main ocf:linbit:drbd params
	drbd_resource="main"
	op monitor interval="60s"
	op start interval="0" timeout="240s"
	op stop  interval="0" timeout="240s"
	op monitor role=Master interval="10s"
	op monitor role=Slave  interval="30s"

// указать определение ведущего/ведомого для созданного DRBD-ресурса
crm configure ms ms_drbd_main drbd_main
	meta master-max="1"  master-node-max="1"
	clone-max="2"        clone-node-max="1"
	notify="true"

// создать ресурс точки монтирования DRBD-раздела -> /opt/main
crm configure primitive fs_main ocf:heartbeat:Filesystem           // fs_main - 
	params device="/dev/drbd0" directory="/opt/main" fstype="ext4" options="noatime"

// создать ресурс отказоустойчивого IP-адреса
crm configure primitive failover_ip ocf:heartbeat:IPaddr2          // failover_ip - 
	params ip=192.168.25.10 nic=eth1

// создать ресурсы nfs
crm configure primitive nfs-kernel-server  lsb:nfs-kernel-server
crm configure primitive nfs-common         lsb:nfs-common
crm configure group group_main fs_main failover_ip nfs-kernel-server nfs-common  // group_main - 

// указать правило монтирования — монтировать ресурсы на узле, где DRBD-ресурсы находятся в состоянии ведущих
crm configure colocation cluster_resources inf: fs_main ms_drbd_main:Master      // cluster_resources - 

// указать порядок запуска сервисов — после запуска соответствующих DRBD-разделов
crm configure order all_after_drbd inf: ms_drbd_main:promote group_main:start    // all_after_drbd - 

// установить предпочтение запуска ресурсов
crm configure location  prefer_main_server-1  ms_drbd_main 100: server-1      // будет основной сервер
crm configure location  prefer_main_server-2  ms_drbd_main 50:  server-2
crm configure location  prefer_group_main_server-1  group_main 100: server-1  // будет основной сервер
crm configure location  prefer_group_main_server-2  group_main 50:  server-2

// проверка состояния
crm status

// на каждом узле -> только чтение для всех
nano /etc/exports
/opt/main *(ro,sync)


// --------------------------------
// 

