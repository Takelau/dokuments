
// --------------------------------
//    DRDB & RAID
// --------------------------------

drbdadm

// Установка и настройка DRBD в раздел 'sdb1'
apt install lvm2 drbd8-utils
modprobe drbd

// на каждом узле создать том 'main' требуемого разиера
pvcreate     /dev/sdb1
vgcreate vg0 /dev/sdb1
lvcreate -L100G -n main vg0

nano /etc/drbd.d/main.res
resource main {
	protocol C;
	disk {
		fencing resource-only;
	}
	handlers {
		fence-peer          "/usr/lib/drbd/crm-fence-peer.sh";
		after-resync-target "/usr/lib/drbd/crm-unfence-peer.sh";
	}
	net {
		after-sb-0pri discard-least-changes;
		after-sb-1pri call-pri-lost-after-sb;
		after-sb-2pri call-pri-lost-after-sb;
	}
	syncer {
		rate 1000M;   // максимальная скорость синхронизации данных между узлами
	}
	on server-1
	{
		device /dev/drbd0;
		disk   /dev/vg0/main;
		address 192.168.122.10:7794;
		meta-disk internal;
	}
	on server-2
	{
		device /dev/drbd0;
		disk   /dev/vg0/main;
		address 192.168.122.11:7794;
		meta-disk internal;
	}
}

drbdadm create-md main
drbdadm up all

// на первом сервере сделать созданный DRBD-ресурс первичным (primary)
drbdadm -- --overwrite-data-of-peer primary all
service drbd status

// на первом сервере создать файловую систему
mkfs.ext4    /dev/drbd0
tune2fs -m 0 /dev/drbd0

