
// --------------------------------
//    Common Edition
// --------------------------------

// Astra Linux Red Books -> Red Book: Astra Linux Common Edition 2.12

/	       | С защитным преобразованием (при условии, что /boot размещен в отдельном дисковом разделе).
         | Рекомендуется использовать файловую систему 'ext4'
/boot    | Без защитного преобразования.
         | Допускается использовать файловую систему 'ext2, ext3, ext4'
/home    | С защитным преобразованием.
         | Рекомендуется использовать файловую систему 'ext4'
         | Рекомендуется монтировать с опциями 'noexec,nodev,nosuid'
/tmp     | С защитным преобразованием.
         | Рекомендуется использовать файловую систему 'ext4'
         | Рекомендуется монтировать с опциями 'noexec,nodev,nosuid'
/var/tmp | С защитным преобразованием.
         | Рекомендуется использовать файловую систему 'ext4'
         | Рекомендуется монтировать с опциями 'noexec,nodev,nosuid'
swap     | Опционально. С защитным преобразованием.

/home, /tmp, /var/tmp  с опциями 'noexec,nodev,nosuid'


// --------------------------------
// Virtual Box
sudo mount /dev/sr0 /mnt
sudo bash /mnt/VBoxLinuxAdditions.run
sudo apt install gcc make perl linux-headers-`uname -r`  // доп пакеты 
sudo bash /mnt/VBoxLinuxAdditions.run                    // повторный запуск
sudo reboot
lsmod | grep -io vboxguest  // info v1
modinfo vboxguest           // info v2


// --------------------------------
// Grub2 - https://wiki.astralinux.ru/pages/viewpage.action?pageId=18874503

1. // изменение пароля на загрузчик
grub-mkpasswd-pbkdf2  // генерация хеша

sudo nano /etc/grub.d/07_password
#!/bin/bash
cat << EOF
set superusers="<username>"
password_pbkdf2 <username> <grub.pbkdf2.sha512.10000.9C319610666...........>
EOF

sudo chmod 700 /etc/grub.d/07_password
sudo update-grub

2. // Запрет загрузки в режиме восстановления
sudo nano /etc/default/grub
GRUB_DISABLE_RECOVERY="true"
GRUB_TIMEOUT=0
GRUB_HIDDEN_TIMEOUT=5   // время на отработку Shift

sudo update-grub

