
// --------------------------------
//    Open Nebula
// --------------------------------
По возможности необходимо использовать virtio для сети (в случае, если не используется мандатное управление доступом) и дисков.
Драйвер KVM в OpenNebula подключен по умолчанию.
В случае использования дисков с установкой кэша, отличной от «none», могут возникнуть трудности с динамическим перемещением в зависимости от версии libvirt.
KVM поддерживает горячее подключение к virtio и шинам SCSI.
Узел, который предполагается использовать для виртуализации, должен поддерживать I/O MMU (Intel VT-d, AMD-Vi)

типы хранилищ образов
	Filesystem - хранилище данных файловой системы для хранения образов в форме файла
	LVM        - хранение образов в логических томах LVM (менеджер логических томов)
	Ceph       - хранение образов с помощью блочных устройств Ceph
	Raw Device Mapping      - прямое подключение к ВМ существующих блочных устройств в узлах
	iSCSI-Libvirt Datastore - доступ к устройствам iSCSI через встроенную поддержку QEMU


1. Фронтальная машина (61 admin)  // необходимо, чтобы она входила в домен ALD или FreeIPA (Ansible)

// добавления репозитория ПК СВ в список источников
nano sources.list

sudo aptitude install brestcloud-ald  // при использовании ALD
sudo aptitude install brestcloud-ipa  // при использовании FreeIPA

// firefox
about:config
   network.negotiate-auth.delegation-uris -> "http://,https://"
   network.negotiate-auth.trusted-uris    -> "http://,https://"

// v1 - Настройка с помощью скрипта
sudo brestcloud-configure
sudo pdpl-user -i 127 <user>  // user - имя администратора системы
reboot

// v2 - Ansible для FreeIPA
sudo aptitude install brest-ansible  // установка ansible
cp -r /var/lib/brest-ansible $HOM    // копия плейбуков znsible в домашний каталог

nano inventory.ini
[all:vars]
### FreeIPA
freeipa_server_fqdn="astral.m.dom"    // полное доменное имя сервера FreeIPA
freeipa_admin="admin"                 // имя администратора сервера FreeIPA
freeipa_admin_pass="Asdf1234"
### Postgresql
db_name="onedb"
db_user="onedbuser"
db_user_pass="Asdf1234"
### Brest
brestadmin_pass="Asdf1234"            // пароль администратора Бреста (brestadmin)
### Reboot system
reboot_system=l
[brest-front]  // группа для описания фронтальной машины OpenNebula | имя и пароль локального администратора фм
brest_front  ansible_host="10.10.10.108"  ansible_user="toor"  ansible_password="quertyl23"
[brest-nodes]  // группа для описания узлов OpenNebula | имя и пароль локального администратора узла
brest_node_l ansible_host="10.10.10.103"  ansible_user="toor"  ansible_password="quertyl23"

cd ~/brest-ansible
ansible-playbook brestcloud_ipa_configure.yml

// RAFT кластер - добавление экземпляра фм
sudo brestcloud-raft-configure

// конфигурация сервиса oned
nano /etc/one/oned.conf
LOG = [
	SYSTEM = "file", DEBUG_LEVEL = 3
]
#MANAGER_TIMER = 15
MONITORING_INTERVAL = 60
MONITORING_THREADS = 50
#
#HOST_PER_INTERVAL = 15
#HOST_MONITORING_EXPIRATION_TIME = 43200
#
#VM_INDIVIDUAL_MONITORING = "no"
#VM_PER_INTERVAL = 5
#VM_MONITORING_EXPIRATION_TIME = 14400
#
SCRIPTS_REMOTE_DIR = /var/tmp/one
PORT = 2633
LISTEN_ADDRESS = "0.0.0.0"
#
#DB = [ BACKEND = "sqlite" ]
# конфиг для PostgreSQL
DB = [ BACKEND = "pgsql",
SERVER = "localhost",
PORT = 5432,
USER = "postgres",
PASSWD = "postgres",
DB_NAME = "opennebula" ]
#
VNC_PORTS = [
	START = 5900
	#RESERVED = "6800, 6801, 9869"
]
#VM_SUBMIT_ON_HOLD = "NO"
# -------------
## NETWORK
NETWORK_SIZE = 254
MAC_PREFIX = "02:00" VLAN_IDS = [
	START = "2",
	RESERVED = "0, 1, 4095"
]
VXLAN_IDS = [
	START = "2"
]
# -------------
## Хранилища
DATASTORE_CAPACITY_CHECK = "yes"
DEFAULT_IMAGE_TYPE = "OS"
DEFAUL_ DEVICE_PREFIX = "hd"
DEFAUL_CDROM_DEVICE_PREFIX = "hd"
# -------------
## Сборщик информации 
IM_MAD = [
	name = "collectd"
	executable = "collectd",
	arguments = "-p 4124-f S-t 50 -i20"
]

// конфигурирование узла KVM
// на узле входящем в один домен с фронтальной машиной
sudo aptitude install ald-libvirt-qemu opennebula-node qemu-block-extra  // для ALD
sudo aptitude install ipa-libvirt-qemu opennebula-node qemu-block-extra  // для FreeIPA
sudo ald-libvirt-qemu-configure  // для ALD
sudo ipa-libvirt-qemu-configure  // для FreeIPA
sudo pdpl-user -i 127 <user>     // <user> — имя администратора системы
nano /var/lib/one/remotes/vmm/kvm/kvmrc // (90 admin)
reboot


// Добавление узла - на фм от пользователя состоящего в группах astra-admin и astra-console
sudo onehost create <node01> -i kvm -v kvm  
sudo onehost list


