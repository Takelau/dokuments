
// --------------------------------
//    Command line
// --------------------------------
// документация - https://wiki.astralinux.ru/pages/viewpage.action?pageId=109020865
enable | disable | status |is-enabled

astra-security-monitor list | status | status N | switches

astra-autologin-control  // Управление автоматическим входом в графическую среду
astra-digsig-control     // Управляет режим замкнутой программной среды (ЗПС) в исполняемых файлах. | После перезагрузки
astra-format-lock        // Включает или отключает запрос пароля администратора при форматировании съемных носителей
astra-overlay            // Включает overlay на корневой файловой системе (ФС) | после перезагрузки
astra-secdel-control     // Включает режим безопасного удаления файлов на разделах с файловыми системами, присутствующими в файле /etc/fstab
astra-shutdown-lock      // Блокирует выключение компьютера пользователями, не являющимися суперпользователями
astra-sudo-control       // Включает требование ввода пароля при использовании sudo
astra-swapwiper-control  // Включает функцию очистки разделов подкачки при завершении работы ОС
astra-sysrq-lock         // Отключает функции системы, доступные при нажатии клавиши SysRq (/etc/sysctl.d/999-astra.conf)
astra-ufw-control        // Включает межсетевой экран 'ufw'
astra-ulimits-control    // изменяет /etc/security/limits.conf | после следующего входа пользователя

astra-nobootmenu-control // Отключает отображение меню загрузчика 'grub2'
astra-hardened-control   // Включает/отключает в загрузчике 'grub2' загрузку ядра hardened по умолчанию, если такое ядро присутствует в системе.
astra-lkrg-control       // {lkrg-5.10.0-1045-generic, lkrg-5.4.0-81-generic, lkrg-5.10-generic, lkrg-5.4.0-54-generic, lkrg-5.4-generic ...}

astra-bash-lock          // Управление блокировкой интерпретатора команд bash
astra-console-lock       // Управление блокировкой доступа к консоли и терминалам для пользователей, не входящих в группу 'astra-console'
astra-commands-lock      // {df, chattr, arp, ip}
astra-interpreters-lock  // {perl, python, irb, dash, ksh, zsh, csh, tcl, tk, expect, lua}
astra-macros-lock        // {libreoffice}
astra-nochmodx-lock      // {chmod +x}
astra-ptrace-lock        // {ptrace} устанавливает 'kernel.yama.ptrace_scope = 3'

astra-mic-control        // Включает или отключает механизм контроля целостности в ядре, изменяя значение параметра 'parsec.max_ilev' командной строки ядра
astra-mac-control        // Включает или отключает возможность работы приложений с ненулевым уровнем конфиденциальности
astra-modban-lock        // Блокирует загрузку неиспользуемых модулей ядра | немедленно
astra-mount-lock         // Запрещает монтирование съемных носителей с помощью службы fly-reflex-service/fly-admin-reflex непривилегированным пользователям
astra-noautonet-control  // Отключает автоматическое конфигурирование сетевых подключений
astra-mode-apps          // {apache2 + cups} (/etc/apache2/apache2.conf + /etc/cups/cupsd.conf) | после перезапуска служб
astra-docker-isolation   // {docker} переводит на 2 уровень целостности | после перезапуска сервиса docker
astra-ilev1-control      // {apache2, dovecot, exim4} переводит на 1 уровень целостности
astra-sumac-lock         // {sumac, fly-sumac}

astra-modeswitch  // режимы работы систем защиты | необходимо перезагрузить систему
  list        // вывести список доступных режимов
  get         // вывести текущий режим в числовом представлении
  getname     // вывести текущий режим в текстовом представлении;
  set <0|1|2> // {Базовый | Усиленный | Максимальный}



