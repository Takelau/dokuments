#!/bin/sh

ip a
ip route show

sudo passwd root     # подключение учетной записи root
sudo passwd -l root  # отключение учетной записи root
sudo lshw -class network
sudo ethtool enp0s3


# --------------------------
#   Network
# --------------------------
nano /etc/netplan/<NAME>.yaml
netplan apply
systemctl restart networking

# time zone
timedatectl set-timezone Europe/Moscow

# ipv6
nano /etc/sysctl.conf
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1

sysctl -p

nano /etc/avahi/avahi-daemon.conf   # Desktop
use-ipv6=no

# dns
nano /etc/resolv.conf
nameserver 77.88.8.8


# --------------------------
#   Post install
# --------------------------
snap set system refresh.retain=2

apt update
apt install --reinstall ca-certificates
apt install htop
apt install mc
apt install wget
apt install nano

apt install net-tools    # ifconfig, netstat, rarp, nameif and route
apt install httpie
apt install iftop
apt install iptraf-ng

apt install gtkorphan
apt install ubuntu-cleaner

apt clean
apt autoremove --purge  # Remove Old Kernels
apt autoremove


# --------------------------
#   Firewall UFW
# --------------------------
apt install gufw -y

nano /etc/default/ufw
IPV6=no

ufw default deny incoming
ufw default allow outgoing
ufw enable


# --------------------------
#   Firewall Iptables
# --------------------------


# --------------------------
#   Git
# --------------------------
add-apt-repository ppa:git-core/ppa
apt update
apt install git


# --------------------------
#   Editor
# --------------------------
add-apt-repository ppa:neovim-ppa/stable
apt-get update
apt-get install neovim


# --------------------------
#   Docker
# --------------------------
## install
apt-get remove docker docker-engine docker.io containerd runc
apt-get update
apt-get install ca-certificates curl gnupg lsb-release
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
apt-get update
apt-get install docker-ce docker-ce-cli containerd.io

groupadd docker
usermod -aG docker <USER>
# !!! Log out !!!

chown <USER>:<USER> /home/<USER>/.docker -R
chmod g+rwx /home/<USER>/.docker -R

## remote access
nano /usr/lib/systemd/system/docker.service
[Service]
ExecStart=/usr/bin/dockerd -H fd:// -H tcp://127.0.0.1:2375
   или
nano /etc/docker/daemon.json
{
# "ipv6": false,
# "fixed-cidr-v6": "2001:db8:1::/64",
	"hosts": ["unix:///var/run/docker.sock", "tcp://127.0.0.1:2375"]
}

## DNS
nano /etc/docker/daemon.json
{
  "dns": ["8.8.8.8", "8.8.4.4"]
}

## dnsmasq
nano /etc/NetworkManager/NetworkManager.conf  -> # dns=dnsmasq
systemctl restart network-manager

systemctl daemon-reload
systemctl enable containerd
systemctl enable docker
systemctl start docker

netstat -lntp | grep dockerd
env | grep DOCKER_HOST

docker run hello-world


# --------------------------
#   Docker Compose
# --------------------------
https://github.com/docker/compose/releases
sudo curl -L "https://github.com/docker/compose/releases/download/v2.2.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
# bash command completion
sudo curl \
 -L https://raw.githubusercontent.com/docker/compose/1.29.2/contrib/completion/bash/docker-compose \
 -o /etc/bash_completion.d/docker-compose


# --------------------------
#   Git
# --------------------------
apt-get install git


# --------------------------
#   Sublime
# --------------------------
sudo apt-get update

