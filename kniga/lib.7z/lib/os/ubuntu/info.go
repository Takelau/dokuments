
// --------------------------
//   apt
// --------------------------
apt-cache show nginx | grep ^Version:    // Version: 1.4.6-1ubuntu3
apt-cache --recurse depends nginx        // список зависимостей


