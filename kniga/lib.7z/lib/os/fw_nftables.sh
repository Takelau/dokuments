
systemctl restart nftables
/etc/nftables.conf

# инфо
https://wiki.nftables.org/wiki-nftables/index.php/Quick_reference-nftables_in_10_minutes

# сохранение правил
echo '#!/usr/sbin/nft -f' > /etc/nftables.conf
echo 'flush ruleset' >> /etc/nftables.conf
nft -s list ruleset >> /etc/nftables.conf

# загрузка правил
nft -f /etc/nftables.conf

# очистка && список
nft {list | flush} ruleset [family]
nft flush ruleset                   # полная очитка
nft flush chain inet filter input   # очистить правила 'nftables' в цепочке 'INPUT' таблицы 'filter'
nft list tables [<family>]
nft list table [<family>] <name> [-n] [-a]    # {n-нумерованный формат, a-отображать 'handle'}
nft -a list chain [<family>] <table> <chain>  # {n --numeric, a --handle}
nft -s list ruleset
nft -j list ruleset   # JSON


# --------------------------
#   Общие положения
# --------------------------
family     {ip, ip6, inet[v4+v6], arp, bridge, netdev[ingress+egress]}
hooks      {prerouting, input, forward, output, postrouting, ingress[5.10]}
table      # имя таблицы семейства <family>
chain      # имя цепочки в таблице <table>
position   # номер правила в цепочке <chain>, перед которым будет вставлено добавляемое правило
handle     # номер правила в цепочке <chain>, которое будет заменено/удалено
matches    # правило фильтрации пакетов в форматах, описанных в #Matches
statements # действие, предпринимаемое с пакетами, подпадающими под правило <matches>

# Переход
jump   # после jump продолжается обработка пакетов по всей цепочке
goto   # после goto сразу срабатывает действие по умолчанию

# переиенные
define   int_if1 = eth0
undefine int_if1
filter input iif $int_ifs accept

# rule
nft add     rule [<family>] <table> <chain> <matches> <statements>
nft insert  rule [<family>] <table> <chain> [position <position>] <matches> <statements>
nft replace rule [<family>] <table> <chain> [handle <handle>] <matches> <statements>
nft delete  rule [<family>] <table> <chain> [handle <handle>]


# --------------------------
#   Table
# --------------------------
nft {add | create} table [<family>] <table> [{ flags <flags> ; }]
nft {delete | list | flush} table [<family>] <table>
nft list tables [<family>]
nft delete table [<family>] handle <handle>

nft add table inet filter                                                                 # создание таблицы 'filter'
nft add chain inet filter input \{ type filter hook input priority 0 \; policy accept \}  # создание цепочки 'input' таблицы 'filter'
nft add chain inet filter input '{ policy drop; }'                                        # изменение политики цепочки input
nft add rule inet filter input iif eth0 tcp dport \{ telnet, ssh, http, https \} accept   # добавление правила
nft add rule inet filter input iifname lo counter accept                                  # разрешаем подключаться к loopback интерфейсу
nft add rule inet filter input iifname eth0 ip saddr 172.28.80.0/24 tcp dport {445, 139, 80, 443} counter accept  # разрешить подключения к samba, web и ntp
nft add rule inet filter input ip saddr 172.28.80.0/24 icmp type echo-request counter accept  # Разрешаем ping сервера
nft delete rule inet filter input handle 8  # удаление правила
nft delete table inet filter                # удаление таблюцы
nft flush table inet filter                 # очистка таблицы

nft add table filter {flags dormant \;}  # временно отключить таблицу
nft add table filter                     # включить таблицу обратно


# --------------------------
#   Chain
# --------------------------
nft {add | create} chain [<family>] <table> <chain> [{ type <type> hook <hook> [device <device>] priority <priority> ; [policy <policy> ;] }]
nft {delete | list | flush} chain [<family>] <table> <chain>
nft list chains [<family>]
nft delete chain [<family>] <table> handle <handle>
nft rename chain [<family>] <table> <chain> newname

> type
    filter {ip, ip6, inet, arp, bridge}  # используется по умолчанию
    nat    {ip, ip6, inet}  # обрабатывается только первый пакет соединения, остальные отправляются через conntrack
    route  {ip, ip6}        # применяется в хуке output для маркировки пакетов
> hook
    for ip, ip6 -> prerouting, input, forward, output, postrouting, ingress
    for arp     -> input, output
    for bridge  -> prerouting, input, forward, output, postrouting, ingress
    for netdev  -> ingress, egress
    ethernet    -> bridge
> priority                                    # Families                      Hooks
            -400 NF_IP_PRI_CONNTRACK_DEFRAG     
       raw  -300 NF_IP_PRI_RAW                  ip, ip6, inet                 all
            -225 NF_IP_PRI_SELINUX_FIRST    
            -200 NF_IP_PRI_CONNTRACK        
    mangle  -150 NF_IP_PRI_MANGLE               ip, ip6, inet                 all
    dstnat  -100 NF_IP_PRI_NAT_DST              ip, ip6, inet                 prerouting
    filter  0    NF_IP_PRI_FILTER               ip, ip6, inet, arp, netdev    all
  security  50   NF_IP_PRI_SECURITY             ip, ip6, inet                 all
    srcnat  100  NF_IP_PRI_NAT_SRC              ip, ip6, inet                 postrouting
            225  NF_IP_PRI_SELINUX_LAST
            300  NF_IP_PRI_CONNTRACK_HELPER
> priority for bridge
    dstnat  -300  prerouting
    filter  -200  all
       out  100   output
    srcnat  300   postrouting
> policy # default verdict statement
    {accept, drop}


# --------------------------
#   Matches
# --------------------------
ip  saddr|daddr <ip_адрес> # ip адрес
tcp sport|dport <порт>     # tcp порт
udp sport|dport <порт>     # udp порт
sctp sport|dport <порт>    # sctp
dccp sport|dport <порт>    # dccp
iifname|oifname <имя_интерфейса>
ah hdrlength|reserved|spi|sequence <num>
esp spi|sequence
comp nexthdr|flags|cpi
icmp type|code|mtu|gateway
ether saddr|type
dst nexthdr|hdrlength
vlan id|cfi|pcp
arp ptype|htype|hlen|plen|operation
ct state|direction|status|mark
#
ip protocol { icmp, esp, ah, comp, udp, udplite, tcp, dccp, sctp }
ip saddr 192.168.3.1 ip daddr 192.168.3.100
ip saddr { 10.0.0.0/8, 192.168.0.0/16 }
ip daddr { 192.168.0.1-192.168.0.250 }
#
tcp sport 1024 tcp dport 22
tcp dport vmap { 25:accept, 28:drop }
tcp flags { fin, syn, rst, psh, ack, urg, ecn, cwr}
#
sctp vtag 22
sctp chunk init exists
dccp type {request, response, data, ack, dataack, closereq, close, reset, sync, syncack}
#
ct original proto-dst 22
ct reply proto-src 53
ct state { new, established, related, untracked }
ct status {expected,seen-reply,assured,confirmed,snat,dnat,dying}
ct expiration 30s


# --------------------------
#   Statements
# --------------------------
log level {err,warn,notice,info,debug,emerg,alert,crit}
reject with icmp type {host-unreachable, net-unreachable, port-unreachable, host-prohibited}
reject with icmpx type no-route
  > ip protocol tcp reject with tcp reset
counter packets 0 bytes 0
#
limit rate 400/minute
limit rate 1025 kbytes/second
limit rate 1025 kbytes/second burst 1023 kbytes
limit rate over 1023/second burst 10 packets
#
dnat to 192.168.3.2
dnat to ct mark map { 0x00000014 : 1.2.3.4}
masquerade to :1024
#
queue num <value> <scheduler>
queue num 2
queue num 4-5 fanout
queue num 4-5 fanout bypass


# --------------------------
#   Sets (Множества)
# --------------------------
nft add set [family] <table> <set> {type <type> | typeof <expression>; [flags <flags>;] [timeout <timeout>;] [gc-interval <gc-interval>;] [elements = {<element>[, ...]};] [size size ;] [policy policy ;] [auto-merge ;] }
nft (delete|list|flush) set [family] <table> <set>
nft delete set [family] <table> handle <handle>
nft (add|delete) element [family] <table> <set> { <element>[, ...] }
nft list sets [family]

type         {ipv4_addr, ipv6_addr, ether_addr, inet_proto, inet_service, mark}
typeof       expression to derive the data type from
flags        {constant, dynamic, interval, timeout}
timeout      string, decimal followed by unit. Units are: d, h, m, s
gc-interval  ...


# --------------------------
#   Maps
# --------------------------

# iptables -> nft
iptables-translate -A INPUT -s 192.168.1.0/24 -i eth0 -p tcp -m state --state NEW -m tcp --dport 22 -m comment --comment "Allow to SSH-server" -j ACCEPT
nft add rule ip filter INPUT iifname "eth0" ip saddr 192.168.1.0/24 ct state new  tcp dport 22 counter accept comment \"Allow to SSH-server\"


# --------------------------
#   Пример
# --------------------------
#!/usr/sbin/nft -f
flush ruleset
table inet filter {
#
# INPUT
chain input {
  type filter hook input priority 0; policy accept;
  ct state invalid counter drop comment "INVALID PACKET DROP"

  # Разрешаем любой трафик от нас
  ct state {related,established} counter accept comment "RELATED CONNECTIONC ACCEPT"

  # Разрешаем любой трафик с localhost
  iif lo accept comment "LOOPBACK ACCEPT"
  iif != lo ip  daddr 127.0.0.1/8 counter drop comment "DROP CONNECTIONC TO LOOPBACK NOT COMING FROM LOOPBACK"
  iif != lo ip6 daddr ::1/128     counter drop comment "DROP CONNECTIONC TO LOOPBACK NOT COMING FROM LOOPBACK"

  # Запрещаем ping floods
  ip protocol icmp   icmp   type echo-request limit rate over 10/second burst 4 packets drop
  ip6 nexthdr icmpv6 icmpv6 type echo-request limit rate over 10/second burst 4 packets drop

  # Разрешаем ICMP & IGMP
  ip6 nexthdr  icmpv6 icmpv6 type { destination-unreachable, packet-too-big, time-exceeded, parameter-problem, mld-listener-query, mld-listener-report, mld-listener-reduction, nd-router-solicit, nd-router-advert, nd-neighbor-solicit, nd-neighbor-advert, ind-neighbor-soli>
  ip  protocol icmp   icmp   type { destination-unreachable, router-solicitation, router-advertisement, time-exceeded, parameter-problem } accept
  ip  protocol igmp accept

  # Избегаем brute force на SSH
  tcp dport ssh ct state new limit rate 15/minute accept

  # Сохраняем данные в лог
  log

  ct state new         tcp flags & (fin|syn|rst|ack) != syn counter drop
  ct state invalid,new tcp flags & (syn|ack) == syn|ack     counter reject with tcp reset

  #
  ct state new tcp dport 22 counter jump VOIP_ACCESS

  # Блокируем недействительные подключения
  limit rate 5/minute burst 5 packets counter log prefix "DROPPED: " level debug
  tcp flags & (fin|syn|rst|ack) == syn limit rate 1/second burst 5 packets counter accept
  tcp flags & (fin|syn|rst|ack) == syn counter drop
}
#
# USER INPUT
chain VOIP_ACCESS {
  ip saddr 192.168.1.0/16 accept
  limit rate 2/minute burst 5 packets counter log prefix "DROPPED: " level debug
  counter drop
}
# 
# FORWARD
chain forward {
  type filter hook forward priority 0; policy drop;
  counter log
}
#
# OUTPUT
chain output {
  type filter hook output priority 0; policy accept;
  counter comment "COUNT ACCEPTED PACKETS"
}
}

# --------------------------
#   Пример
# --------------------------
#!/usr/sbin/nft -f
flush ruleset
define wan_if = eth0
define lan_if = eth1
define admin_ip = 203.0.113.15

table ip filter {
  # blocked
  set blocked_services {
    type inet_service
    elements = { 22, 23 }
  }
  # wan
  chain input_wan {
    ip saddr $admin_ip tcp dport ssh accept
    tcp dport @blocked_services drop
  }
  # lan
  chain input_lan {
    icmp type echo-request limit rate 5/second accept
    ip protocol . th dport vmap { tcp . 22 : accept, udp . 53 : accept, tcp . 53 : accept, udp . 67 : accept}
  }
  # input
  chain input { 
    type filter hook input priority 0; policy drop;
    ct state vmap { established : accept, related : accept, invalid : drop }
    iifname vmap { lo : accept, $wan_if : jump input_wan, $lan_if : jump input_lan }
  }
  # forward
  chain forward { 
    type filter hook forward priority 0; policy drop;
    ct state vmap { established : accept, related : accept, invalid : drop }
    iif $lan_if accept
  }
  # post routing
  chain postrouting { 
    type nat hook postrouting priority srcnat; policy accept;
    masquerade comment "Masquerading rule example"
  }
}

# --------------------------
#   Пример JUMP
# --------------------------
table ip filter {
  chain input {
    type filter hook input priority 0; policy accept;
    ip saddr 1.1.1.1 ip daddr 2.2.2.2 tcp sport 111 tcp dport 222  jump other-chain
    ip saddr 1.1.1.1 ip daddr 2.2.2.2 tcp sport 111 tcp dport 222  accept
  }
  chain other-chain {
    counter packets 8 bytes 2020
  }
}


# --------------------------
#   Пример SETS
# --------------------------
# @blocked_services {22,23}
nft add set inet filter blocked_services { type inet_service \; }
nft add element inet filter blocked_services { ssh, telnet }
# доступ к множеству 
nft insert rule inet filter input iif eth0 tcp dport @blocked_services drop
# удаление из множества сервиса ssh
nft delete element inet filter blocked_services { 22 }
