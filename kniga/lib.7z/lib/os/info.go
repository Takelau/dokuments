
// --------------------------------
//    Virtual Box
// --------------------------------

orl10   192.168.1.9   E:\Namikot\ASTRA\orl10.vdi
alt     192.168.1.    E:\Namikot\ASTRA\alt.vdi
debian  192.168.1.8   E:\Namikot\W\debian.vdi
