#!/bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~
IPF="iptables -t filter"
IRAW="iptables -t raw"
INAT="iptables -t nat"
IMANGLE="iptables -t mangle"

WAN="enp0s3"
WAN_IP="192.168.1.8"
DOCKER="172.17.0.1/17"  # 172.17.0.1 - 172.17.127.254

GIT_LIST_ALLOW="/etc/ipfw/git_list_allow"
WEB_LIST_ALLOW="/etc/ipfw/web_list_allow"
DKR_LIST_ALLOW="/etc/ipfw/dkr_list_allow"
# ~~~~~~~~~~~~~~~~~~~~~~~~~

$IPF -F nami-input
$IPF -F nami-forward
$IPF -F nami-output
$IPF -F nami-docker-input
$IPF -F nami-docker-output

# Re-Init
if [[ $1 == "--init" ]]; then
$IPF -D INPUT   -j nami-input
$IPF -D FORWARD -j nami-forward
$IPF -D OUTPUT  -j nami-output

$IPF -X nami-input
$IPF -X nami-forward
$IPF -X nami-output
$IPF -X nami-docker-input
$IPF -X nami-docker-output

$IPF -N nami-input
$IPF -N nami-forward
$IPF -N nami-output
$IPF -N nami-docker-input
$IPF -N nami-docker-output

$IPF -F INPUT
$IPF -F OUTPUT

$IPF -I INPUT 1  -j nami-input
$IPF -A FORWARD  -j nami-forward
$IPF -I OUTPUT 1 -j nami-output
fi

if [[ $1 == "--docker-init" ]]; then
$IPF -D DOCKER-USER -i $WAN -j nami-docker-input
$IPF -D DOCKER-USER -o $WAN -j nami-docker-output
$IPF -F DOCKER-USER
$IPF -F DOCKER-USER
$IPF -I DOCKER-USER -i $WAN -j nami-docker-input
$IPF -I DOCKER-USER -o $WAN -j nami-docker-output
fi

$IPF -P INPUT   DROP
$IPF -P FORWARD DROP
$IPF -P OUTPUT  DROP

# ~~~~~~~~~~~~~~~~~~~~~~~~~
# drop
$IPF -A nami-input -p tcp --tcp-flags SYN,ACK SYN,ACK -m conntrack --ctstate NEW,INVALID -j REJECT --reject-with tcp-reset
$IPF -A nami-input -p tcp ! --syn -m conntrack --ctstate NEW     -j DROP
$IPF -A nami-input                -m conntrack --ctstate INVALID -j LOG --log-level info --log-prefix "[INVAL ] "
$IPF -A nami-input                -m conntrack --ctstate INVALID -j DROP

# drop frag
$IPF -A nami-input -f -j DROP

# estab
$IPF -A nami-input   -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
$IPF -A nami-forward -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
$IPF -A nami-output  -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

# lo
$IPF -A nami-input -m addrtype --src-type LOCAL ! -i lo -j DROP
$IPF -A nami-input  -i lo -j ACCEPT
$IPF -A nami-output -o lo -j ACCEPT

# ~~~~~~~~~~~~~~~~~~~~~~~~~
# dns
$IPF -A nami-input  -s 77.88.8.8/32 -i $WAN -p udp -m udp --sport 53 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
$IPF -A nami-output -d 77.88.8.8/32 -o $WAN -p udp -m udp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# icmp
$IPF -A nami-input -p icmp --icmp-type echo-request -m limit --limit 1/s -j ACCEPT
$IPF -A nami-input -p icmp --icmp-type echo-request -j DROP

# web host update
if [[ $1 == "--host" ]]; then
$IPF -A nami-input  -d $WAN_IP -i $WAN -p tcp -m multiport --sports 80,443 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
$IPF -A nami-output -s $WAN_IP -o $WAN -p tcp -m multiport --dports 80,443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
fi

# delve
$IPF -A nami-output -s $WAN_IP -d 192.168.1.200 -o $WAN -p tcp -m tcp --dport 30003 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# webc
$IPF -A nami-output -s $WAN_IP -d 192.168.1.210 -o $WAN -p tcp -m tcp --dport 5555 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# web c7w
$IPF -A nami-output -s $WAN_IP -d 192.168.1.211 -o $WAN -p tcp -m multiport --dports 80,443,4443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# ~~~~~~~~~~~~~~~~~~~~~~~~~
# web filter
if [[ $1 == "--filter" ]]; then
  while IFS= read -r URL
  do
    if [[ "$URL" == *"."* ]]; then
      IP_LIST=`dig $URL +short`
      for IP in $IP_LIST; do
        echo "web $URL - $IP"
        $IPF -A nami-input  -d $WAN_IP  -s $IP -i $WAN -p tcp -m tcp -m multiport --sports 80,443 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
        $IPF -A nami-output -s $WAN_IP  -d $IP -o $WAN -p tcp -m tcp -m multiport --dports 80,443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
      done
    fi
  done < $WEB_LIST_ALLOW
fi

# ssh
$IPF -A nami-input  -d $WAN_IP -s 192.168.1.210 -i $WAN -p tcp -m multiport --sports 22,40004 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
$IPF -A nami-output -s $WAN_IP -d 192.168.1.210 -o $WAN -p tcp -m multiport --dports 22,40004 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
$IPF -A nami-input  -d $WAN_IP -s 192.168.1.211 -i $WAN -p tcp -m tcp --sport 40004 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
$IPF -A nami-output -s $WAN_IP -d 192.168.1.211 -o $WAN -p tcp -m tcp --dport 40004 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
$IPF -A nami-input  -d $WAN_IP -s 192.168.1.200 -i $WAN -p tcp -m tcp --sport 40004 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
$IPF -A nami-output -s $WAN_IP -d 192.168.1.200 -o $WAN -p tcp -m tcp --dport 40004 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# ssh-git filter
if [[ $1 == "--filter" ]]; then
  while IFS= read -r URL
  do
    if [[ "$URL" == *"."* ]]; then
      IP_LIST=`dig $URL +short`
      for IP in $IP_LIST; do
        echo "git $URL - $IP"
        $IPF -A nami-input  -d $WAN_IP  -s $IP -i $WAN -p tcp -m tcp --sport 22 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
        $IPF -A nami-output -s $WAN_IP  -d $IP -o $WAN -p tcp -m tcp --dport 22 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
      done
    fi
  done < $GIT_LIST_ALLOW
fi

# ~~~~~~~~~~~~~~~~~~~~~~~~~
# docker
# dns
$IPF -A nami-docker-input  -s 77.88.8.8/32 -i $WAN -p udp -m udp --sport 53 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
$IPF -A nami-docker-output -d 77.88.8.8/32 -o $WAN -p udp -m udp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# web update
if [[ $1 == "--docker" ]]; then
  $IPF -A nami-docker-input  -d $DOCKER -i $WAN -p tcp -m multiport --sports 80,443 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
  $IPF -A nami-docker-output -s $DOCKER -o $WAN -p tcp -m multiport --dports 80,443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
fi

# web filter
if [[ $1 == "--filter" ]]; then
  while IFS= read -r URL
  do
    if [[ "$URL" == *"."* ]]; then
      IP_LIST=`dig $URL +short`
      for IP in $IP_LIST; do
        echo "dkr $URL - $IP"
        $IPF -A nami-docker-input  -d $DOCKER  -s $IP -i $WAN -p tcp -m multiport --sports 80,443 -m conntrack --ctstate ESTABLISHED     -j ACCEPT
        $IPF -A nami-docker-output -s $DOCKER  -d $IP -o $WAN -p tcp -m multiport --dports 80,443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
      done
    fi
  done < $DKR_LIST_ALLOW
fi

# ~~~~~~~~~~~~~~~~~~~~~~~~~
# log
$IPF -A nami-input  -m limit --limit 3/min --limit-burst 10 -j LOG --log-level info --log-prefix "[LOGIN ] "
$IPF -A nami-output -m limit --limit 3/min --limit-burst 10 -j LOG --log-level info --log-prefix "[LOGOUT] "
$IPF -A nami-docker-input  -j LOG --log-level debug --log-prefix "[DKRIN ] "
$IPF -A nami-docker-output -j LOG --log-level debug --log-prefix "[DKROUT] "

# drop
$IPF -A nami-docker-input  -i $WAN -j RETURN
$IPF -A nami-docker-output -o $WAN -j RETURN
$IPF -A nami-input  -j DROP
$IPF -A nami-output -j DROP

iptables-save  > /etc/sysconfig/iptables

# clear
iptables -Z
# iptables -S
# iptables -L DOCKER-USER -v -n --line-number
