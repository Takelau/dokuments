#!/bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~
IPF="ip6tables -t filter"
IRAW="ip6tables -t raw"
IMANGLE="ip6tables -t mangle"
# ~~~~~~~~~~~~~~~~~~~~~~~~~

# filter
$IPF -F INPUT
$IPF -F FORWARD
$IPF -F OUTPUT
$IPF -P INPUT   DROP
$IPF -P FORWARD DROP
$IPF -P OUTPUT  DROP

# raw
$IRAW -F PREROUTING
$IRAW -F OUTPUT
$IRAW -P PREROUTING DROP
$IRAW -P OUTPUT     DROP

# mangle
$IMANGLE -F PREROUTING
$IMANGLE -F INPUT
$IMANGLE -F FORWARD
$IMANGLE -F OUTPUT
$IMANGLE -F POSTROUTING
$IMANGLE -P PREROUTING  DROP
$IMANGLE -P INPUT       DROP
$IMANGLE -P FORWARD     DROP
$IMANGLE -P OUTPUT      DROP
$IMANGLE -P POSTROUTING DROP

ip6tables-save > /etc/sysconfig/ip6tables

ip6tables -Z
ip6tables -S
