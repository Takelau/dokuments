
ufw status numbered
ufw show listening
ufw show user-rules
ufw show added

iptables -L DOCKER-USER -v -n --line-number
iptables -L ufw-user-output -v -n --line-number
iptables -L ufw-user-input -v -n --line-number && iptables -L ufw-user-output -v -n --line-number

// -------------
ufw enable
ufw default deny incoming
ufw default deny outgoing
ufw app list
ufw status verbose
ufw status numbered
ufw show raw
ufw show listening
ufw show builtins
ufw show before-rules
ufw show after-rules
ufw show user-rules
ufw show added        // список правил
ufw reload
ufw reset             // обнуление

ufw logging on        // логирование
ufw logging medium

ufw
 [insert NUM]
  allow|deny|reject|limit
  [in|out [on INTERFACE]]
  [log|log-all] [proto PROTOCOL]
  [from ADDRESS [port PORT | app APPNAME ]]
  [to ADDRESS [port PORT | app APPNAME ]]
  [comment COMMENT]

ufw allow out 22/tcp
ufw allow out 6000:6007/tcp

ufw allow in on eth0 to any port 80    // ALLOW IN
ufw allow out on eth1 to 10.0.0.0/8    // ALLOW OUT

ufw allow out on enp0s3 proto tcp from 192.168.1.8 to 192.168.1.200 port 40004 comment 'SSH 200'

ufw route allow in on eth0 out on eth1 to 10.0.0.0/8 from 192.168.0.0/16   // ALLOW FWD
ufw route allow in on eth1 out on eth2

ufw deny in  on any
ufw deny out on any

ufw delete allow out 80/tcp
ufw delete 2


// -------------
ufw [--dry-run] show REPORT
ufw [--dry-run] app list|info|default|update
OPTIONS
REPORTS
  raw
  builtins
  before-rules
  user-rules
  after-rules
  logging-rules
  listening
  added


// -------------
//-- Docker
// текущий вариант
iptables -I DOCKER-USER -j RETURN     // -A DOCKER-USER -j RETURN

// вариант №1
iptables -I DOCKER-USER ! -s 192.168.1.210 -i enp0s3 -j DROP    // запретить доступ в инет
iptables -D DOCKER-USER ! -s 192.168.1.210 -i enp0s3 -j DROP    // удалить правило

// вариант №2
iptables -I DOCKER-USER -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
iptables -I DOCKER-USER -m conntrack --ctstate INVALID -j DROP
iptables -I DOCKER-USER -i enp0s3 -j ufw-user-input
iptables -I DOCKER-USER -i enp0s3 -j DROP
iptables -I DOCKER-USER -j RETURN

iptables -L DOCKER-USER -v -n --line-number


// --------------------------------------
iptables -t raw -S
-P PREROUTING ACCEPT
-P OUTPUT ACCEPT

iptables -t mangle -S
-P PREROUTING ACCEPT
-P INPUT ACCEPT
-P FORWARD ACCEPT
-P OUTPUT ACCEPT
-P POSTROUTING ACCEPT

iptables -t security -S
-P INPUT ACCEPT
-P FORWARD ACCEPT
-P OUTPUT ACCEPT

iptables -t nat -S
-P PREROUTING ACCEPT
-P INPUT ACCEPT
-P OUTPUT ACCEPT
-P POSTROUTING ACCEPT
-N DOCKER
-A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER
-A OUTPUT ! -d 127.0.0.0/8 -m addrtype --dst-type LOCAL -j DOCKER
-A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE
-A POSTROUTING -s 172.17.0.2/32 -d 172.17.0.2/32 -p tcp -m tcp --dport 9443 -j MASQUERADE
-A POSTROUTING -s 172.17.0.2/32 -d 172.17.0.2/32 -p tcp -m tcp --dport 8000 -j MASQUERADE
-A DOCKER -i docker0 -j RETURN
-A DOCKER ! -i docker0 -p tcp -m tcp --dport 9443 -j DNAT --to-destination 172.17.0.2:9443
-A DOCKER ! -i docker0 -p tcp -m tcp --dport 8000 -j DNAT --to-destination 172.17.0.2:8000

iptables -t filter -S
-P INPUT DROP
-P FORWARD DROP
-P OUTPUT DROP

-N DOCKER
-N DOCKER-ISOLATION-STAGE-1
-N DOCKER-ISOLATION-STAGE-2
-N DOCKER-USER

-N ufw-after-forward
-N ufw-after-input
-N ufw-after-logging-forward
-N ufw-after-logging-input
-N ufw-after-logging-output
-N ufw-after-output
-N ufw-before-forward
-N ufw-before-input
-N ufw-before-logging-forward
-N ufw-before-logging-input
-N ufw-before-logging-output
-N ufw-before-output
-N ufw-logging-allow
-N ufw-logging-deny
-N ufw-not-local
-N ufw-reject-forward
-N ufw-reject-input
-N ufw-reject-output
-N ufw-skip-to-policy-forward
-N ufw-skip-to-policy-input
-N ufw-skip-to-policy-output
-N ufw-track-forward
-N ufw-track-input
-N ufw-track-output
-N ufw-user-forward
-N ufw-user-input
-N ufw-user-limit
-N ufw-user-limit-accept
-N ufw-user-logging-forward
-N ufw-user-logging-input
-N ufw-user-logging-output
-N ufw-user-output

-A INPUT -j ufw-before-logging-input
-A INPUT -j ufw-before-input
-A INPUT -j ufw-after-input
-A INPUT -j ufw-after-logging-input
-A INPUT -j ufw-reject-input
-A INPUT -j ufw-track-input

-A FORWARD -j DOCKER-USER
-A FORWARD -j DOCKER-ISOLATION-STAGE-1
-A FORWARD -o docker0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
-A FORWARD -o docker0 -j DOCKER
-A FORWARD -i docker0 ! -o docker0 -j ACCEPT
-A FORWARD -i docker0 -o docker0 -j ACCEPT
-A FORWARD -j ufw-before-logging-forward
-A FORWARD -j ufw-before-forward
-A FORWARD -j ufw-after-forward
-A FORWARD -j ufw-after-logging-forward
-A FORWARD -j ufw-reject-forward
-A FORWARD -j ufw-track-forward

-A OUTPUT -j ufw-before-logging-output
-A OUTPUT -j ufw-before-output
-A OUTPUT -j ufw-after-output
-A OUTPUT -j ufw-after-logging-output
-A OUTPUT -j ufw-reject-output
-A OUTPUT -j ufw-track-output

-A DOCKER -d 172.17.0.2/32 ! -i docker0 -o docker0 -p tcp -m tcp --dport 9443 -j ACCEPT
-A DOCKER -d 172.17.0.2/32 ! -i docker0 -o docker0 -p tcp -m tcp --dport 8000 -j ACCEPT
-A DOCKER-ISOLATION-STAGE-1 -i docker0 ! -o docker0 -j DOCKER-ISOLATION-STAGE-2
-A DOCKER-ISOLATION-STAGE-1 -j RETURN
-A DOCKER-ISOLATION-STAGE-2 -o docker0 -j DROP
-A DOCKER-ISOLATION-STAGE-2 -j RETURN
-A DOCKER-USER -o enp0s3 -j DROP
-A DOCKER-USER ! -s 192.168.1.8/32 -i enp0s3 -j DROP
-A DOCKER-USER -j RETURN

-A ufw-after-input -m addrtype --dst-type BROADCAST -j ufw-skip-to-policy-input

// before-log
-A ufw-before-logging-forward -m conntrack --ctstate NEW -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW AUDIT] "
-A ufw-before-logging-input   -m conntrack --ctstate NEW -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW AUDIT] "
-A ufw-before-logging-output  -m conntrack --ctstate NEW -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW AUDIT] "
// after-log
-A ufw-after-logging-forward -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW BLOCK] "
-A ufw-after-logging-input   -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW BLOCK] "
-A ufw-after-logging-output  -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW BLOCK] "

-A ufw-before-forward -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
-A ufw-before-forward -j ufw-user-forward

-A ufw-before-input -i lo -j ACCEPT
-A ufw-before-input -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
-A ufw-before-input -m conntrack --ctstate INVALID -j ufw-logging-deny
-A ufw-before-input -m conntrack --ctstate INVALID -j DROP
-A ufw-before-input -j ufw-not-local
-A ufw-before-input -j ufw-user-input

-A ufw-before-output -o lo -j ACCEPT
-A ufw-before-output -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
-A ufw-before-output -j ufw-user-output

-A ufw-logging-allow -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW ALLOW] "
-A ufw-logging-deny  -m conntrack --ctstate INVALID -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW AUDIT INVALID] "
-A ufw-logging-deny  -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix "[UFW BLOCK] "

-A ufw-not-local -m addrtype --dst-type LOCAL     -j RETURN
-A ufw-not-local -m addrtype --dst-type MULTICAST -j RETURN
-A ufw-not-local -m addrtype --dst-type BROADCAST -j RETURN
-A ufw-not-local -m limit --limit 3/min --limit-burst 10 -j ufw-logging-deny
-A ufw-not-local -j DROP

-A ufw-skip-to-policy-forward -j DROP
-A ufw-skip-to-policy-input   -j DROP
-A ufw-skip-to-policy-output  -j DROP

-A ufw-user-limit -m limit --limit 3/min -j LOG --log-prefix "[UFW LIMIT BLOCK] "
-A ufw-user-limit -j REJECT --reject-with icmp-port-unreachable
-A ufw-user-limit-accept -j ACCEPT

-A ufw-user-output -d 8.8.8.8/32 -o enp0s3 -p udp -m udp --dport 53 -j ACCEPT
-A ufw-user-output -s 192.168.1.8/32 -d 192.168.1.211/32 -o enp0s3 -p tcp -m tcp --dport 40004 -j ACCEPT
-A ufw-user-output -s 172.16.10.8/32 -d 172.16.10.211/32 -o enp0s8 -p tcp -m tcp --dport 6379 -j ACCEPT
-A ufw-user-output -s 192.168.1.8/32 -d 192.168.1.211/32 -o enp0s3 -p tcp -m multiport --dports 80,443,4443 -j ACCEPT
-A ufw-user-output -s 192.168.1.8/32 -d 192.168.1.200/32 -o enp0s3 -p tcp -m tcp --dport 40004 -j ACCEPT
