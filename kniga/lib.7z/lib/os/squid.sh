
# --------------------------
#    Squid
# --------------------------
acl localnet src 0.0.0.1-0.255.255.255  # RFC 1122 "this" network (LAN)
acl localnet src 10.0.0.0/8             # RFC 1918 local private network (LAN)
acl localnet src 100.64.0.0/10          # RFC 6598 shared address space (CGN)
acl localnet src 169.254.0.0/16         # RFC 3927 link-local (directly plugged) machines
acl localnet src 172.16.0.0/12          # RFC 1918 local private network (LAN)
acl localnet src 192.168.0.0/16         # RFC 1918 local private network (LAN)
acl localnet src fc00::/7               # RFC 4193 local private network range
acl localnet src fe80::/10              # RFC 4291 link-local (directly plugged) machines
acl localnet src 109.124.208.1/24       # <--

acl SSL_ports  port 443
acl Safe_ports port 80          # http
acl Safe_ports port 21          # ftp
acl Safe_ports port 443         # https
acl Safe_ports port 70          # gopher
acl Safe_ports port 210         # wais
acl Safe_ports port 1025-65535  # unregistered ports
acl Safe_ports port 280         # http-mgmt
acl Safe_ports port 488         # gss-http
acl Safe_ports port 591         # filemaker
acl Safe_ports port 777         # multiling http
acl CONNECT    method CONNECT

# Deny
http_access deny         !Safe_ports
http_access deny CONNECT !SSL_ports

# Block URL
acl bad_urls dstdomain "/etc/squid/block_list.acl"   # .badsite1.com
http_access deny bad_urls

# telegram
acl DiscoverSNIHost at_step SslBump1
acl NoSSLIntercept  ssl::server_name_regex "/etc/squid/telegram.nobump"
ssl_bump peek   DiscoverSNIHost
ssl_bump splice NoSSLIntercept
ssl_bump bump   all

# Allow cachemgr access from localhost
http_access allow localhost manager
http_access deny            manager
include /etc/squid/conf.d/*

# Allow hosts
http_access allow localnet
http_access allow localhost

# Final
http_access deny all

# Server config
http_port 192.168.0.1:56724
via off             # скрывает версию прокси
forwarded_for off   # on, off, transparent, truncate, delete

# Cache & Dump
cache deny all    # отключение кеширования
#cache_dir    ufs /var/spool/squid 100 16 256
#coredump_dir     /var/spool/squid

refresh_pattern ^ftp:    1440  20%  10080
refresh_pattern ^gopher: 1440  0%   1440
refresh_pattern -i (/cgi-bin/|\?) 0 0% 0
refresh_pattern \/(Packages|Sources)(|\.bz2|\.gz|\.xz)$ 0 0% 0 refresh-ims
refresh_pattern \/Release(|\.gpg)$ 0 0% 0 refresh-ims
refresh_pattern \/InRelease$ 0 0% 0 refresh-ims
refresh_pattern \/(Translation-.*)(|\.bz2|\.gz|\.xz)$ 0 0% 0 refresh-ims
refresh_pattern .         0     20%  4320


# --------------------------
#    Описание
# --------------------------
#   имя_списка  параметр  содержимое
acl localnet    src       172.16.0.0/12
src           # 172.16.0.0/12
dst           # 172.16.0.1-172.16.0.255
srcdomain     # .temp.ru
dstdomain     # .temp.ru
srcdom_regex  # \.org$
url_regex     # \.avi$  для обработки видеофайлов формата avi
urlpath_regex # шаблон регулярного выражения для части URL, исключая протокол и имя хоста
proto         # http
port          # 80 | 475-556
time          # MTWHF 12:00-13:00  с понедельника по пятницу, со временем с 12:00 до 13:00
maxconn       # ограничение максимального количества соединений с одного клиентского IP-адреса

#           инструкция  acl
http_access allow       localnet
no_cache           # объявляет ответы, которые не будет попадать в кэш;
redirector_access  # проверяет, какие запросы должны пройти через процесс редиректор;
miss_access        # разрешает неким клиентам передавать cache misses через ваш кэш;
always_direct      # контролирует, какие запросы всегда должны посылаться напрямую к серверу назначения;
never_direct       # проверяет запросы, которые никогда не должны посылаться напрямую к серверу назначения;
snmp_access        # контролирует доступ клиентов к кэшу по SNMP;
broken_posts       # определяет запросы, для которых squid добавляет дополнительный CRLF после сообщений POST как требуют некоторые неправильно функционирующие сервера.
cache_peer_access  # контролирует, какие запросы должны быть переданы соседскому кэшу (peer).


delay_pools 2	   # Укажем количество пулов
delay_class 1 1  # Присвоим класс первому пулу
delay_class 2 1  # Присвоим класс второму пулу
delay_access 1 allow us_groupe_1  # Разрешить доступ к пулу №1 пользователям,состоящим в списке us_groupe_1
delay_access 1 deny all           # Запрещаем всем остальным доступ к этому пулу
delay_access 2 allow us_groupe_2  #
delay_access 2 deny all           #
delay_parameters 1 -1/-1          # Первому пулу оставляем настройку без ограничения размера буфера и скорости
delay_parameters 2 8000/8000      # Второму пулу ограничиваем размер буфера и скорость до 64 кБ/с


# --------------------------
#    Авторизация
# --------------------------
# 1. по логину и паролю
apt install apache2-utils   # Ubuntu
yum -y install httpd-tools  # CentOS
htpasswd -c /etc/squid/passwd <user>

auth_param basic program /usr/lib64/squid/basic_ncsa_auth /etc/squid/passwd
auth_param basic children 1               # максимальное количество запускаемых процессов аутентификатора
auth_param basic credentialsttl 2 hours   # нужно будет вводить пароль каждые два часа
auth_param basic casesensitive on         # имена пользователей и пароли чувствительны к регистру
auth_param basic realm Squid proxy for Nami
acl auth_users proxy_auth REQUIRED
http_access allow auth_users

# 2.
htdigest -c /etc/squid/passwd_digest 'Squid proxy for HackWare.ru' <user>

auth_param digest program /usr/lib64/squid/digest_file_auth -c /etc/squid/passwd_digest
auth_param digest children 1
auth_param digest credentialsttl 2 hours
auth_param digest casesensitive on
auth_param digest realm Squid proxy for Nami
acl auth_users proxy_auth REQUIRED
http_access allow auth_users


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

nano /etc/squid/telegram.nobump
# 149.154.164.0/22  149.154.172.0/22
# 91.108.4.0/22     91.108.56.0/24
149\.154\.1(6[0-9]|7[0-5])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])
91\.108\.([4-7]|5[6|7])\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])
