
systemctl restart network
systemctl restart firewalld

# ------------------------
#  INFO
# ------------------------
https://ru.wikibooks.org/wiki/Iptables

PREROUTING  — позволяет модифицировать пакет до принятия решения о маршрутизации
INPUT       — для входящих пакетов адресованных непосредственно локальному процессу (клиенту или серверу)
FORWARD     — цепочка, позволяющая модифицировать транзитные пакеты (перенаправляемые пакеты проходят сначала цепь PREROUTING, затем FORWARD и POSTROUTING)
OUTPUT      — позволяет модифицировать пакеты генерируемые локальными процессами
POSTROUTING — дает возможность модифицировать все исходящие пакеты, как сгенерированные самим хостом, так и транзитные

raw    — просматривается до передачи пакета системе определения состояний. Используется редко, например для маркировки пакетов, которые НЕ должны обрабатываться системой определения состояний. Для этого в правиле указывается действие NOTRACK. Содержит цепочки PREROUTING и OUTPUT.
mangle — содержит правила модификации (обычно заголовка) IP‐пакетов. Среди прочего, поддерживает действия TTL (Time to live), TOS (Type of Service), и MARK (для изменения полей TTL и TOS, и для изменения маркеров пакета). Редко необходима и может быть опасна. Содержит все пять стандартных цепочек.
nat    — просматривает только пакеты, создающие новое соединение (согласно системе определения состояний). Поддерживает действия DNAT, SNAT, MASQUERADE, REDIRECT. Содержит цепочки PREROUTING, OUTPUT, и POSTROUTING.
filter — основная таблица, используется по умолчанию если название таблицы не указано. Содержит цепочки INPUT, FORWARD, и OUTPUT.
Цепочки с одинаковым названием, но в разных таблицах — совершенно независимые объекты. Например, raw PREROUTING и mangle PREROUTING обычно содержат разный набор правил; пакеты сначала проходят через цепочку raw PREROUTING, а потом через mangle PREROUTING.

ACCEPT, DROP и REJECT
RETURN  — обеспечивает возврат из текущей цепочки
LOG     — позволяет записывать информацию о пакетах в журнал ядра   # iptables -A INPUT -p tcp -m multiport --dports 22,53,8080,139,445 -j LOG --log-level INFO --log-prefix "New connection from ours: "
LOGMARK — Отличается тем, что заносит в лог информацию, специфичную для системы conntrack, в частности, маркировку соединения (connmark aka ctmark), состояния соединения (ctstate и ctstatus) и т. п
ULOG    — заносить ее в базы данных, такие как MySQL, PostgreSQL или SQLite
NFLOG   — более универсальный вариант ULOG
NFQUEUE — во многом похоже на ULOG, но передает специальному демону не информацию о пакете, а сам пакет целиком
QUEUE   — устаревшая версия NFQUEUE
TRACE   — трассировка прохождения пакетов по цепочке

# ------------------------
#  DEBUG
# ------------------------
https://firewalld.org/documentation/howto/debug-firewalld.html
iptables --list | less
journalctl -xe | grep firewalld | grep ERROR | less

https://firewalld.org/documentation/man-pages/firewall-cmd.html

firewall-cmd 
--state
--reload
--complete-reload
--panic-on               режим паники, блокирующий все сетевые соединения
--panic-off              отмена режима паники
--query-panic            0 если режим паники включен и 1 если выключен

--get-ipsets
--path-ipset=<>          путь к конфигурационному файлу
--delete-ipset=<>
--info-ipset=<>
--get-services           список всех поддерживаемых служб
--get-icmptypes
--list-all-zones         список всех действий во всех зонах
--get-zones              список всех заданных зон
--get-active-zones       список всех активных зон
--get-default-zone       возвращает зону по умолчанию
--set-default-zone=<>    устанавливает зону по умолчанию
--get-zone-of-interface=<>
--get-zone-of-source=<ip>[/mask]|MAC|ipset:<ipset>

--zone=<> --list-all

--zone=<> --add-interface=<>      добавить интерфейс к зоне
--zone=<> --change-interface=<>  	изменить интерфейс
--zone=<> --remove-interface=<>	  удалить интерфейс из зоны
--zone=<> --list-interfaces       список интерфейсов которые пренадлежат к зоне
--zone=<> --query-interface=<>    0 если интерфейс принадлежит к зоне и 1 если не пренадлежит

--zone=<> --add-service=<> [--timeout=]     добавить службу к зоне
--zone=<> --remove-service=<> [--timeout=]  удалить службу из зоны
--zone=<> --list-services

--zone=<> --add-port=[-]/ [--timeout=]      добавить порт к зоне
--zone=<> --remove-port=[-]/ [--timeout=]   удалить порт из зоны
--zone=<> --query-port=[-]/
--zone=<> --list-ports

--zone=<> --add-source-port=[-]/ [--timeout=]
--zone=<> --remove-source-port=[-]/
--zone=<> --query-source-port=[-]/
--zone=<> --list-source-ports

--zone=<> --add-protocol=[-] [--timeout=]
--zone=<> --remove-protocol=[=]
--zone=<> --query-protocol=[-]
--zone=<> --list-protocols

--zone=<> --add-icmp-block=[-] [--timeout=]
--zone=<> --remove-icmp-block=[-]
--zone=<> --query-icmp-block=[-]
--zone=<> --list-icmp-blocks

--zone=<> --list-sources

--zone=<> --add-masquerade [--timeout=]      добавить маскарадинг к зоне
--zone=<> --remove-masquerade [--timeout=]   удалить маскарадинг
--zone=<> --query-masquerade

--zone=<> --add-forward-port=port=[-]:proto= { :toport=[-] | :toaddr=| :toport=[-]:toaddr=}
--zone=<> --remove-forward-port=port=[-]:proto= { :toport=[-] | :toaddr=| :toport=[-]:toaddr=}
--zone=<> --query-forward-port=port=[-]:proto= { :toport=[-] | :toaddr= }
--zone=<> --list-forward-ports

--ipset=<> --get-description
--ipset=<> --get-entries
--ipset=<> --add-entries-from-file=[filename]
--ipset=<> --remove-entries-from-file=[filename]
--ipset=<> --add-entry=[-]
--ipset=<> --remove-entry=[-]
--ipset=<> --query-entry=[-]

# ------------------------
#  ACTION
# ------------------------
--add-ACTION, --remove-ACTION и --query-ACTION
service=<service>
port=<port>[-<port>]/<protocol>
icmp-block=<icmptype>
forward-port=port=<port>[-<port>]:proto=<protocol>:toport=<port>[-<port>]
forward-port=port=<port>[-<port>]:proto=<protocol>:toaddr=<address>
forward-port=port=<port>[-<port>]:proto=<protocol>:toport=<port>[-<port>]:toaddr=<address>

# ------------------------
#  DIRECT
# ------------------------
table (filter/mangle/nat/...)
chain (INPUT/OUTPUT/FORWARD/...)
commands (-A/-D/-I/...)
parameters (-p/-s/-d/-j/...)
targets (ACCEPT/DROP/REJECT/...)

--direct --get-all-chains
--direct --get-chains { ipv4 | ipv6 | eb } <table>
--direct --add-chain { ipv4 | ipv6 | eb } <table> <chain>
--direct --remove-chain { ipv4 | ipv6 | eb } <table> <chain>

--direct --get-all-rules
--direct --get-rules { ipv4 | ipv6 | eb } <table> <chain>

--direct --get-all-passthroughs

# ------------------------
#  Permanent
# ------------------------
--permanent { --get-zones | --get-services | --get-icmptypes }
--permanent [--zone=<zone>] { --list-services | --list-ports | --list-icmp-blocks | --list-forward-ports }
--permanent [--zone=<zone>] { --add-ACTION | --remove-ACTION | --query-ACTION }
--permanent [--zone=<zone>] { --add-masquerade | --remove-masquerade |--query-masquerade }




firewall-cmd --zone=<> --add-port=5280/tcp --permanent
firewall-cmd --zone=<> --query-port