
redis-cli -h 172.16.10.211 -p 6379
AUTH Gy72dkLvt
INFO
INFO Server

// --------------------------
//   Benchmark
// --------------------------
redis-benchmark --help
redis-benchmark -h 127.0.0.1 -p 6379 -n 100000 -c 20
