
systemctl --full --type service --all

// /etc/systemd/system/namikot.service
[Unit]
Description=namikot - high performance web server
After=network.target
After=postgresql-9.5.service
StartLimitBurst=5
StartLimitIntervalSec=10

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/local/bin/namikot
Restart=always

[Install]
WantedBy=multi-user.target
