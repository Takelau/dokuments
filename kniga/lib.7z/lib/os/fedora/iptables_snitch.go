
var (
	ctx           = (context.Context)(nil)      // main()
	cancel        = (context.CancelFunc)(nil)   // main()
	// signal
	sigChan       = (chan os.Signal)(nil)       // setupSignals()
	exitChan      = (chan bool)(nil)            // setupSignals()
	// rule
	rulesPath     = "rules"
	noLiveReload  = false
	rules         = (*rule.Loader)(nil)
	stats         = (*statistics.Statistics)(nil)
	// queue
	queueNum       = 0
	repeatQueueNum int  //will be set later to queueNum + 1
	procmonMethod  = ""
	// worker
	wrkChan       = (chan netfilter.Packet)(nil)
)

func main() {
	ctx, cancel = context.WithCancel(context.Background())
	defer cancel()

	setupSignals()
	err :=rules.Load(rulesPath)
	setupWorkers()

	// Queue
	queue, err := netfilter.NewQueue(uint16(queueNum))
	pktChan = queue.Packets()

	// repeatQueue
	repeatQueueNum = queueNum + 1
	repeatQueue, rqerr := netfilter.NewQueue(uint16(repeatQueueNum))
	repeatPktChan = repeatQueue.Packets()

	// queue is ready, run firewall rules
	firewall.Init(uiClient.GetFirewallType(), &queueNum)

	// monitor
	monitor.ReconfigureMonitorMethod(procmonMethod)

	for {
		select {
		case <-ctx.Done():
			goto Exit
		case pkt, ok := <-pktChan:
			if !ok {
				goto Exit
			}
			wrkChan <- pkt
		}
	}
Exit:
	close(wrkChan)
	doCleanup(queue, repeatQueue)
	os.Exit(0)
}

func setupSignals() {
	sigChan  = make(chan os.Signal, 1)
	exitChan = make(chan bool, workers+1)
	go func() {
		sig := <-sigChan
		cancel()
	}
}

func setupWorkers() {
	wrkChan = make(chan netfilter.Packet)
	for i := 0; i < workers; i++ {
		go worker(i)
	}
}

func worker(id int) {
	for true {
		select {
		case <-ctx.Done():
			goto Exit
		default:
			pkt, ok := <-wrkChan
			if !ok {
				goto Exit
			}
			onPacket(pkt)
		}
	}
Exit:
	log.Debug("worker #%d exit", id)
}

func onPacket(packet netfilter.Packet) {
	// DNS response, just parse, track and accept.
	if dns.TrackAnswers(packet.Packet) == true {
		packet.SetVerdictAndMark(netfilter.NF_ACCEPT, packet.Mark)
		stats.OnDNSResponse()
		return
	}

	// Parse the connection state
	con := conman.Parse(packet, uiClient.InterceptUnknown())
	if con == nil {
		applyDefaultAction(&packet)
		return
	}
	// accept our own connections
	if con.Process.ID == os.Getpid() {
		packet.SetVerdict(netfilter.NF_ACCEPT)
		return
	}

	// search a match in preloaded rules
	r := acceptOrDeny(&packet, con)

	stats.OnConnectionEvent(con, r, r == nil)
}


// -----------------------
//    Packet
// -----------------------
type Packet struct {
	Packet          gopacket.Packet
	Mark            uint32
	verdictChannel  chan VerdictContainer
	UID             uint32
	NetworkProtocol uint8
}

type Verdict C.uint

type VerdictContainer struct {
	Verdict Verdict
	Mark    uint32
	Packet  []byte
}


// -----------------------
//    NetFilter
// -----------------------
var (
	queueIndex     = make(map[uint32]*chan Packet, 0)
	queueIndexLock = sync.RWMutex{}
	exitChan       = make(chan bool, 1)
)

const (
	NF_DEFAULT_QUEUE_SIZE  uint32 = 4096
	NF_DEFAULT_PACKET_SIZE uint32 = 4096
)

type VerdictContainerC C.verdictContainer

type Queue struct {
	h       *C.struct_nfq_handle
	qh      *C.struct_nfq_q_handle
	fd      C.int
	packets chan Packet    // pktChan  from main.go
	idx     uint32
}

func NewQueue(queueID uint16) (q *Queue, err error) {
	q = &Queue{
		idx:     uint32(time.Now().UnixNano()),
		packets: make(chan Packet),   // pktChan  from main.go
	}

	if err = q.create(queueID); err != nil {  return nil, err;
	} else if err = q.setup(); err != nil {   return nil, err; }

	go q.run(exitChan)
	return q, nil
}

func (q *Queue) Packets() <-chan Packet {
	return q.packets
}

func (q *Queue) create(queueID uint16) (err error) {
	if q.h, err = C.nfq_open(); err != nil {   // <--
		C.nfq_unbind_pf(q.h, AF_INET)
		C.nfq_bind_pf(q.h, AF_INET)
	// <--
	} else if q.qh, err = C.CreateQueue(q.h, C.u_int16_t(queueID), C.u_int32_t(q.idx)); err != nil || q.qh == nil {
		q.destroy()
		return fmt.Errorf("Error binding to queue: %v", err)
	}

	queueIndexLock.Lock()
	queueIndex[q.idx] = &q.packets   // pktChan  from main.go
	queueIndexLock.Unlock()

	return nil
}

func (q *Queue) setup() (err error) {
	queueSize := C.u_int32_t(NF_DEFAULT_QUEUE_SIZE)
	totSize := C.uint(NF_DEFAULT_QUEUE_SIZE * NF_DEFAULT_PACKET_SIZE)
	if ret, err = C.nfq_set_queue_maxlen(q.qh, queueSize); err != nil || ret < 0 {  // maximum number of packets before dropping upcoming packets
	} else if C.nfq_set_mode(q.qh, C.u_int8_t(2), bufferSize) < 0 {                 // copy entire packet
	} else if q.fd, err = C.nfq_fd(q.h); err != nil {                               // get the file descriptor associated with the nfqueue handler
	} else if C.nfnl_rcvbufsiz(C.nfq_nfnlh(q.h), totSize) < 0 { ... }               // increase the default socket buffer size
	return nil
}

func (q *Queue) run(exitCh chan<- bool) {
	// <--
	if errno := C.Run(q.h, q.fd); errno != 0 { fmt.Fprintf(os.Stderr, "Terminating, unable to receive packet due to errno=%d", errno); }
	exitChan <- true
}

C.CreateQueue(struct nfq_handle *h, u_int16_t queue, u_int32_t idx) {
	nfq_q_handle* qh = nfq_create_queue(h, queue, &nf_callback, (void*)((uintptr_t)idx));
	configure_uid_if_available(qh);  // UID GID <-- nfq_set_queue_flags(qh, NFQA_CFG_F_UID_GID, NFQA_CFG_F_UID_GID)
	return qh;
}

C.Run(struct nfq_handle *h, int fd) {
	setsockopt(fd, SOL_NETLINK, NETLINK_NO_ENOBUFS, &opt, sizeof(int));
	while ((rcvd = recv(fd, buf, sizeof(buf), 0)) >= 0) {
		if (stop == 1) {
			return errno;
		}
		nfq_handle_packet(h, buf, rcvd);  // Triggers an associated callback -> nfnl_handle_packet(h->nfnlh, buf, len);
	}
}

C.nf_callback(struct nfq_q_handle *qh, struct nfgenmsg *nfmsg, struct nfq_data *nfa, void *arg){
	...
	go_callback(id, buffer, size, mark, idx, &vc, uid);
	nfq_set_verdict2(qh, id, vc.verdict, vc.mark, vc.length, vc.data);
}

// go_callback
func go_callback(queueID C.int, data *C.uchar, length C.int, mark C.uint, idx uint32, vc *VerdictContainerC, uid uint32) {
	queueChannel, found := queueIndex[idx]  // pktChan  from main.go

	p := Packet{
		verdictChannel:  make(chan VerdictContainer),
		NetworkProtocol: xdata[0] >> 4, // first 4 bits is the version
		...
	}

	select {
	case *queueChannel <- p:   // pktChan  from main.go
		select {
		case v := <-p.verdictChannel:
			if v.Packet == nil {
				(*vc).verdict = C.uint(v.Verdict)
			} else {
				(*vc).verdict = C.uint(v.Verdict)
				(*vc).data = (*C.uchar)(unsafe.Pointer(&v.Packet[0]))
				(*vc).length = C.uint(len(v.Packet))
			}

			if v.Mark != 0 {
				(*vc).mark_set = C.uint(1)
				(*vc).mark = C.uint(v.Mark)
			}
		}

	case <-time.After(1 * time.Millisecond):
		fmt.Fprintf(os.Stderr, "Timed out while sending packet to queue channel %d\n", idx)
	}
}
