
// --------------------------
//   Install
// --------------------------
// dnf | yum
sudo dnf install <rpm_package_name>    
sudo dnf remove  <rpm_package_name>
// rpm
sudo rpm -e   <package_name>.rpm   // install
sudo rpm -qpR <package_name>.rpm   // remove

