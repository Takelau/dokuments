
// -------------
// SSL
// -------------
certbot --nginx
certbot --expand -d takelau.ru,www.takelau.ru,mag.takelau.ru,p1.takelau.ru,bazis.takelau.ru  // добавить bazis.takelau.ru
certbot certonly --cert-name takelau.ru -d www.takelau.ru,mag.takelau.ru,p1.takelau.ru       // удалить bazis.takelau.ru
certbot renew --pre-hook "systemctl stop nginx" --post-hook "systemctl start nginx"
certbot certificates
certbot renew --cert-name takelau.ru --pre-hook "systemctl stop nginx" --post-hook "systemctl start nginx"

// -------------
// development cert and key -> cert.pem, key.pem
go run $GOROOT/src/crypto/tls/generate_cert.go --host="localhost"
go run $GOROOT/src/crypto/tls/generate_cert.go --ecdsa-curve P256 --host localhost

// -------------
// SSL, самозаверяющий сертификат
// сервер
openssl genrsa -out server.key 2048
openssl ecparam -genkey -name secp384r1 -out server.key
openssl req -new -x509 -sha256 -key server.key -out server.crt -days 3650
http.Transport{
	InsecureSkipVerify: true
}
// клиент
openssl req -x509 -nodes -newkey rsa:2048 -keyout client.key -out // client.crt, client.key


// -------------
// gRPC - mTLS | CA and self-signed
// -------------
// github.com/grpc-up-and-running/samples/tree/master/ch06/mutual-tls-channel/certs
gRPC server {ca.crt, server.key, server.crt}
gRPC client {ca.crt, client.key, server.crt}

1.2 // Generate CA and self-signed certificates
openssl genrsa -aes256 -out ca.key 4096
openssl req -new -x509 -sha256 -days 730 -key ca.key -out ca.crt  // root CA
openssl x509 -noout -text -in ca.crt  // верификация (не обязательно)

1.3 // Server certificate | {ca.crt, server.key, server.crt}
openssl genrsa -out server.key 2048                       // gRPC server
openssl req -new -sha256 -key server.key -out server.csr  // CSR - Certificate Signing Request
openssl x509 -req -days 365 -sha256 -in server.csr -CA ca.crt -CAkey ca.key -set_serial 1 -out server.crt  // {server.csr + ca.crt + ca.key}

1.4 // Client key and certificate | {ca.crt, client.key, server.crt}
openssl genrsa -out client.key 2048
openssl req -new -key client.key -out client.csr
openssl x509 -req -days 365 -sha256 -in client.csr -CA ca.crt -CAkey ca.key -set_serial 2 -out client.crt


1.5 //  java application | Convert server/client keys to pem format
openssl pkcs8 -topk8 -inform pem -in server.key -outform pem -nocrypt -out server.pem
openssl pkcs8 -topk8 -inform pem -in client.key -outform pem -nocrypt -out client.pem


// -------------
// gRPC - public key/certificate | (no CA)
// -------------
// github.com/grpc-up-and-running/samples/tree/master/ch06/secure-channel/certs
gRPC server {server.crt + server.key}
grpc client {server.cr}

1.1
openssl genrsa -out server.key 2048                                        // gRPC server {server.crt + server.key}
openssl req -new -x509 -sha256 -key server.key -out server.crt -days 3650  // grpc client {server.cr}

1.2 // for java application | Convert server/client keys to pem format
$ openssl pkcs8 -topk8 -inform pem -in server.key -outform pem -nocrypt -out server.pem
$ openssl pkcs8 -topk8 -inform pem -in client.key -outform pem -nocrypt -out client.pem


// -------------
// crypt
// -------------
lsblk
cryptsetup -v status volumes


// -------------
// nvme
// -------------
cryptsetup luksFormat /dev/nvme0n1
cryptsetup luksOpen /dev/nvme0n1 volumes
cryptsetup -v status volumes
dd if=/dev/zero of=/dev/mapper/volumes status=progress
mkfs.ext4 /dev/mapper/volumes
mkdir /volumes
mount /dev/mapper/volumes /volumes
nano /etc/sudoers
<user>  ALL=/usr/sbin/cryptsetup, /usr/bin/mount, /usr/bin/umount
umount /volumes
cryptsetup luksClose volumes

sudo cryptsetup luksOpen /dev/nvme0n1 volumes
sudo mount /dev/mapper/volumes /volumes
