#!/bin/bash

# --------------------------
#   Info
# --------------------------
uname -a
hostnamectl
lshw, lscpu, lsblk, lsusb
hdparm /dev/sda1


# ---------------------
# Подготовка
# ---------------------
timedatectl set-timezone Europe/Moscow
hostnamectl set-hostname name
hostnamectl status


# --------------------------
#   VirtualBox
# --------------------------
dnf install -y dkms kernel-devel   # kernel-headers
if uname -r != rpm -qa kernel-devel { dnf update kernel-* }


# --------------------------
#   Firewall
# --------------------------
dnf install -y iptables-services
iptables-save  > /etc/sysconfig/iptables
ip6tables-save > /etc/sysconfig/ip6tables

systemctl stop firewalld  && systemctl disable firewalld  && systemctl mask firewalld
systemctl start iptables  && systemctl enable iptables
systemctl start ip6tables && systemctl enable ip6tables


# --------------------------
#   Volumes
# --------------------------
mkfs.btrfs /dev/nvme0n1
mkfs.xfs   /dev/nvme0n1  <-- CentOS
mount /dev/nvme0n1 /vlm
nano /etc/fstab
/dev/nvme0n1 /vlm btrfs defaults 0 0


# --------------------------
#   Encrypt Volumes
# --------------------------
nano ~/volumes.sh
#!/bin/sh
sudo umount /volumes
sudo cryptsetup luksOpen /dev/nvme0n1 volumes
sudo mount /dev/mapper/volumes /volumes
cd /volumes


# --------------------------
#   Network
# --------------------------
dnf install httpie     <- http [options] [METHOD] URL [ITEM [ITEM]]
dnf install iptraf-ng
dnf install iftop
dnf install trafshow
dnf install nethogs    <- какой процесс создает тот или иной трафик

nano /etc/sysctl.conf
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1


# ---------------------
# SSH
# ---------------------
# рабочие каталоги Go
dnf install -y sshfs


# --------------------------
#   C++
# --------------------------
dnf install -y kernel-devel
dnf install -y llvm && dnf install -y clang && dnf install -y gcc
dnf install -y clang-tools-extra && dnf install -y clang-libs
dnf install -y cmake && dnf install -y gdb && dnf install -y lldb


# --------------------------
#   Go
# --------------------------
## disk
fdisk -l
mkdir /vlm && mkdir /vlm/work && mkdir /vlm/work/bin && mkdir /vlm/work/pkg && mkdir /vlm/work/src
chown 1000:1000 -R /vlm && chmod u=rwx,g=x,o=x -R /vlm
mount /dev/nvme0n1 /vlm

nano ~/.bash_profile
export GOOS=linux             # LiteIDE
export GOARCH=amd64           # LiteIDE
export LC_CTYPE=en_US.UTF-8   # docui
export TERM=xterm-256color    # docui
export GOROOT=$HOME/go
export GOPATH=/vlm/work
# PATH=$PATH:$HOME/.local/bin:$GOROOT/bin:$GOPATH/bin
PATH=$PATH:$GOROOT/bin:$GOPATH/bin
export PATH

dnf update git
go clean -cache && go clean -modcache && go clean -testcache

go get github.com/julienschmidt/httprouter
go get github.com/oxequa/realize
go get github.com/patrickmn/go-cache
go get github.com/gorilla/css
go get github.com/microcosm-cc/bluemonday
go get github.com/golang/protobuf
go get github.com/oxequa/realize    # reload
go get github.com/cosmtrek/air      # reload
go get github.com/gin-gonic/gin
go get github.com/lib/pq            # postgres
go get github.com/jackc/pgx         # postgres
go get github.com/go-redis/redis    # redis
go get github.com/valyala/fasthttp  # fast http
go get github.com/fasthttp/router   # fast router
# go get github.com/jmoiron/sqlx
# go get github.com/pkg/sftp
go get github.com/pkg/errors
go get github.com/pkg/profile                # профилирование
go get github.com/mssola/user_agent          # User Agent
go get github.com/jesseduffield/lazydocker   # lazydocker (Docker)
go get -u github.com/onsi/ginkgo/ginkgo      # test

# gopls (editor)
go install golang.org/x/tools/gopls@latest  # GO111MODULE=on

# dlv (delve)
go install github.com/go-delve/delve/cmd/dlv@latest

# gdlv
git clone https://github.com/aarzilli/gdlv && cd gdlv/
go install  # GO111MODULE=on

# docui (Docker)
git clone https://github.com/skanehira/docui.git && cd docui/
go install  # GO111MODULE=on

# lazydocker (Docker)
go install github.com/jesseduffield/lazydocker@latest
echo "alias lzd='lazydocker'" >> ~/.zshrc


# периодически обновлять
go get -u github.com/pkg/...
go get -u github.com/oxequa/...
go get -u github.com/golang/...
go get -u github.com/labstack/...
go get -u github.com/microcosm-cc/...
go get -u github.com/patrickmn/go-cache


# --------------------------
#   Git
# --------------------------
dnf install git

git config --global user.name "Takelau"
git config --global user.email takelau@gmail.com
git config --global core.editor nano
git config --global init.defaultBranch master
git config --global core.autocrlf input
git config --global core.safecrlf warn

nano ~/.gitconfig
[user]
  email = takelau@gmail.com
  name = Takelau
[init]
  defaultBranch = master
[alias]
  hist = log --pretty=format:\"%h %cd | %s%d [%cn]\" --since=3.month --graph --date=short
  type = cat-file -t
  dump = cat-file -p
[core]
  editor = nano

ssh-keygen -t rsa -b 4096 -C "nami@mail.ru"
ssh-add ~/.ssh/id_key    # if agent admitted
eval "$(ssh-agent -s)"   # проверка агента
ssh -T git@github.com    # тест | -vT подробный вывод

git remote set-url origin git@github.com:ds248a/notify.git


# --------------------------
#   Docker / Fedora 34
# --------------------------
dnf remove docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-selinux docker-engine-selinux docker-engine
rm -rf /var/lib/docker
## repo && install
dnf -y install dnf-plugins-core
dnf config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo
dnf config-manager --set-disabled docker-ce-nightly   # <-- disabled 'nightly'
dnf install docker-ce docker-ce-cli containerd.io
dnf list docker-ce  --showduplicates | sort -r

## disk
fdisk -l
mkdir /var/lib/docker && chmod u=rwx,g=x,o=x /var/lib/docker
mount /dev/nvme0n2 /var/lib/docker
nano /etc/fstab
/dev/nvme0n2 /var/lib/docker btrfs defaults 0 0

## remote access && namespace
systemctl edit docker.service                # v1
nano /usr/lib/systemd/system/docker.service  # v2
[Service]
ExecStart=/usr/bin/dockerd -H fd:// -H tcp://127.0.0.1:2375
# Environment="HTTPS_PROXY=https://proxy.example.com:443"                         # <- PROXY
# Environment="NO_PROXY=localhost,127.0.0.1,docker-registry.example.com,.corp"    # <- PROXY

## config
nano /etc/docker/daemon.json
{
  "dns": ["8.8.8.8", "8.8.4.4"],
  "userns-remap": "takelau",      # namespase
  "data-root": "/mnt/docker-data",
  "storage-driver": "overlay2",
  "hosts": ["unix:///var/run/docker.sock", "tcp://127.0.0.1:2375"]  # v3 remote access
}

## dnsmasq
systemctl stop dnsmasq
systemctl disable dnsmasq

## user
mkdir /home/"$USER"/.docker
nano  /home/"$USER"/.docker/config.json
chown "$USER":"$USER" /home/"$USER"/.docker -R && chmod g+rwx "$HOME/.docker" -R

groupadd docker
usermod -aG docker takelau
# !!! Log out !!!

## IP forwarding
# nano /etc/sysctl.conf
# net.ipv4.conf.all.forwarding = 1
nano /usr/lib/systemd/network/<80-container-host0>.network
[Network]
IPForward=true

iptables -P FORWARD ACCEPT

## start
systemctl daemon-reload
systemctl enable containerd
systemctl enable docker
systemctl start docker        # htop -> /usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock
docker run hello-world

## Portainer 2.9.3
docker volume create portainer_data
# off namespase
docker run -d -p 8000:8000 -p 9443:9443 --name portainer --restart=always -v /var/run/docker.sock:/var/run/docker.sock -v portainer_data:/data  cr.portainer.io/portainer/portainer-ce:2.9.3
# on namespase
docker run -d -p 8000:8000 -p 9443:9443 --name portainer --restart=always --userns=host -v /var/run/docker.sock:/var/run/docker.sock -v portainer_data:/data  cr.portainer.io/portainer/portainer-ce:2.9.3
# on namespase  && SeLinux
docker run -d -p 8000:8000 -p 9443:9443 --name portainer --restart=always --userns=host --privileged -v /var/run/docker.sock:/var/run/docker.sock -v portainer_data:/data  cr.portainer.io/portainer/portainer-ce:2.9.3

## images
docker pull ubuntu:focal
docker pull busybox:stable
docker pull alpine:3.15
docker pull fedora:36

## SSH remote
docker context create --docker host=ssh://<user>@<ip>:<port> --description="cnt docker" work
docker context use work
docker info
export DOCKER_CONTEXT=docker-test
export DOCKER_HOST=ssh://docker-user@host1.example.com


# --------------------------
#   OpenSnitch
# --------------------------
wget https://github.com/evilsocket/opensnitch/releases/download/v1.4.3/opensnitch-1.4.1-1.x86_64.rpm
wget https://github.com/evilsocket/opensnitch/releases/download/v1.4.2/opensnitch-ui-1.4.2-1.noarch.rpm

dnf install libnetfilter_queue
dnf install python3-inotify
dnf install python3-pip

pip3 install unicode_slugify   # пол пользователем
pip3 install grpcio-tools      # пол пользователем

systemctl enable opensnitch
systemctl start opensnitch

mkdir /media/ads-list/
wget https://www.github.developerdan.com/hosts/lists/ads-and-tracking-extended.txt -O /media/ads-list/ads-and-tracking-extended.txt


# ---------------------
#   js graphic
# ---------------------
plot.ly       https://plot.ly/javascript/subplots/
recharts.org  http://recharts.org/en-US/examples/SynchronizedLineChart
konvajs.org   https://konvajs.org/docs/
anychart.com
canvasjs.com


# ---------------------
#   Vue
# ---------------------
npm install echarts    ( node node_modules/echarts/build/build.js --help )


# --------------------------
#   LiteIde
# --------------------------
https://github.com/visualfc/Kiteide
go install github.com/visualfc/gotools@latest
go install github.com/visualfc/gocode@latest
Windows/Linux: copy GOPATH/bin gotools and gocode to liteide/bin

Launcher:
  sh -c "export LD_LIBRARY_PATH=/home/takelau/liteide/lib:$LD_LIBRARY_PATH; /home/takelau/liteide/bin/liteide %F"

linux64.env:
  LITEIDE_TERM=/usr/bin/xfce4-terminal   # from /usr/bin/gnome-terminal
  LITEIDE_SHELL=xfce4-terminal;x-terminal-emulator;gnome-terminal;lxterminal;konsole;xterm
  # PATH=$GOROOT/bin:$PATH               # !!

dark-gray.xml
<?xml version="1.0" encoding="UTF-8"?>
<style-scheme version="1.0" name="dark">
  <style name="Text" foreground="#dedcee" background="#282828"/>
  <style name="Extra" foreground="#7A7C78" background="#282828"/>
  <style name="Selection" background="#214283"/>
  <style name="CurrentLine" background="#3F3F3F"/>
  <style name="MatchBrackets" background="#808080"/>
  <style name="IndentLine" foreground="#008B8B"/>
  <style name="VisualWhitespace" foreground="#F92672"/>
  <style name="Keyword" foreground="#F8D267" />
  <style name="DataType" foreground="#FD971F" />
  <style name="Decimal" foreground="#D5A4CF" />
  <style name="BaseN" foreground="#0000FF"/>
  <style name="Float" foreground="#ff55ff"/>
  <style name="Char" foreground="#CE7DDB"/>
  <style name="String" foreground="#7EBC59"/>
  <style name="Comment" foreground="#7A7C78"/>
  <style name="Alert" foreground="#ff0000"/>
  <style name="Error" foreground="#ff0000"/>
  <style name="Function" foreground="#6290C5"/>
  <style name="RegionMarker" foreground="#F92672"/> 
  <style name="Symbol" foreground="#F92672"/>
  <style name="BuiltinFunc" foreground="#AE81FF" /> 
  <style name="Predeclared" foreground="#FF5F0E" /> 
  <style name="FuncDecl" foreground="#96B5D8" /> 
  <style name="Placeholder" foreground="#CC2E05"/>
  <style name="ToDo" foreground="#C7C7FF" />
</style-scheme>


# --------------------------
#   Sublime
# --------------------------
1.Packages
- Golang Build
- LSP                 # https://lsp.sublimetext.io
- LSP-gopls
- LSP-clangd
- Terminus
- CSS Unminifier  < ?
- Vue Syntax Highlight

2. LSP - langserver.org
  go get golang.org/x/tools/gopls@latest    # GO111MODULE=on go install golang.org/x/tools/gopls@latest
  packagecontrol.io/packages/LSP            # go install golang.org/x/tools/gopls@latest
  - Package Control: Install Package -> LSP
  - LSP: Enable Language Server Globally -> gopls
  - Preferences -> Package Settings -> LSP

# настройки приложения
{
  "color_scheme": "Takelau.sublime-color-scheme",
  "font_face": "DejaVu Sans Mono",
  "font_size": 9,
  "theme_font_options": [
    "no_antialias",
    "gray_antialias",
    "subpixel_antialias"
  ],
  "font_options": [
    "no_bold",
    "no_antialias",
    "no_italic",
    "gray_antialias",
    "subpixel_antialias"
  ],
  "highlight_line": false,
  "ignored_packages": [
    "Vintage",
  ],
  "margin": 0,
  "show_tab_close_buttons": false,
  "tab_size": 2,
  "theme": "Adaptive.sublime-theme",
  "translate_tabs_to_spaces": false,
  "remember_workspace": true,
  "remember_layout": true,
}

# настройки темы
Preferences -> Customize Theme (Adaptive.sublime-theme)
{
  "variables":
  {
    "font_face": "DejaVu Sans Mono",
    "font_size_sm": 12,
    "font_size": 12,
  },
  "rules":[]
}

# Golang Build - глобальная настройка
Package Settings -> Golang Config -> Settings User  
{
  "GOOS": "linux",
  "GOARCH": "amd64",
  "CGO_ENABLED": 1,
  "GO111MODULE": "auto",

  "PATH": "/vlm/go/go120/bin",
  "GOROOT": "/vlm/go/go120",
  "GOPATH": "/vlm/work",
  "GOMODCACHE":"/vlm/work/pkg/mod"
}

# LSP - глобальная настройка
Package Settings -> LSP -> Settings   
{
  # go117
  "clients": {
    "gopls": {
      "enabled": false,
      "command": ["/vlm/work/bin/gopls"],
      "initializationOptions": {
        "experimentalWorkspaceModule": false
      }
    }
  },
  "lsp_format_on_save": false,

  # go120   https://github.com/golang/tools/blob/master/gopls/doc/subl.md
  "clients": {
    "gopls": { "enabled": false },
    "clangd": { "enabled": false }
  },
  "lsp_format_on_save": false,
  "show_diagnostics_panel_on_save": 3,      // {0-no, 1-e, 2-w, 3-i }
  "inhibit_snippet_completions": true,
  "inhibit_word_completions": true,
}

Package Settings -> LSP -> Serverc -> LSP-gopls
{
  "command": [
    "/vlm/work/bin/gopls"
  ],
  "settings": {
    "manageGoplsBinary": false,
  },
}

Package Settings -> LSP -> Serverc -> LSP-clangd
{}

# Go Project
{
  "folders": [ { "path": "." } ],
  "settings": {
    
    "LSP": {
      "gopls": {
        "enabled": true,
        "env": {
          "PATH": "/vlm/work/bin",
        }
      },
    },
    "lsp_format_on_save": true,
    "show_references_in_quick_panel": true,
    "log_debug": true,
    "log_stderr": true,

    "golang": {
      "linux": {
        "GO111MODULE": "auto",
        "PATH": "/vlm/go/go120/bin",
        "GOROOT": "/vlm/go/go120",
        "GOPATH": "/vlm/fw/wrk",
        "GOMODCACHE":"/vlm/fw/wrk/pkg/mod",
      },
    },
  },
}

# C++ Project
{
  "folders": [ { "path": "." } ],
  "settings": {
    "LSP": {
      "clangd": {
        "initializationOptions": {
          // ...
        }
      },
    },
    "lsp_format_on_save": true,
    "show_references_in_quick_panel": true,
    "log_debug": true,
    "log_stderr": true,
  },
}

Key Bindings
[
  { "keys": ["ctrl+b"], "command":"toggle_side_bar" },
  { "keys": ["command+shift+c"], "command":"golang_build_cancel" },
  { "keys": ["f5"], "command":"golang_build", "args": { "task":"run" } },
  { "keys": ["f8"], "command":"golang_build", "args": { "task":"clean" } },
  { "keys": ["f9"], "command":"golang_build", "args": { "task":"test" } },
]


# --------------------------
#   Visual Studio
# --------------------------
rpm --import https://packages.microsoft.com/keys/microsoft.asc
sh -c 'echo -e "[code]\nname=Visual Studio Code\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\nenabled=1\ngpgcheck=1\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc" > /etc/yum.repos.d/vscode.repo'
dnf check-update
dnf install code


# --------------------------
#   Code Blocks
# --------------------------
# codeblocks.org
sudo dnf install codeblocks-20.03-1.el7.x86_64.rpm
sudo dnf install codeblocks-libs-20.03-1.el7.x86_64.rpm
sudo dnf install codeblocks-devel-20.03-1.el7.x86_64.rpm
sudo dnf install codeblocks-debuginfo-20.03-1.el7.x86_64.rpm
sudo dnf install codeblocks-contrib-libs-20.03-1.el7.x86_64.rpm
git clone https://github.com/ds248a/Codeblocks-Themes


# --------------------------
#   Codelite
# --------------------------
dnf install -y SDL
rpm --import https://repos.codelite.org/CodeLite.asc
# 15.0.1
rpm -Uvh https://repos.codelite.org/rpms-15.0/fedora/33/codelite-15.0.1-1.fc33.x86_64.rpm
# 16.0-1
rpm -Uvh https://repos.codelite.org/rpms/fedora/35/codelite-16.0-1.fc35.x86_64.rpm
rpm -Uvh https://repos.codelite.org/rpms/fedora/36/codelite-16.0-1.fc36.x86_64.rpm
# libpcre2-32.so.0 - https://pkgs.org/download/libpcre2-32.so.0()(64bit)
dnf install pcre2-utf32


# --------------------------
#   Builder IDE
# --------------------------
# https://builder.readthedocs.io/en/latest/exploring.html
dnf install -y clang-devel llvm-devel libssh2-devel


# --------------------------
#   Bluefish
# --------------------------


# --------------------------
#   Redis
# --------------------------
# CentOS 7
yum -y install http://rpms.remirepo.net/enterprise/remi-release-7.rpm
yum --enablerepo=remi install redis
rpm -qi redis
systemctl enable --now redis   

# Fedora
dnf install redis
systemctl enable --now redis

nano /etc/redis.conf
  bind 127.0.0.1
  requirepass <AuthPassword>    # Gy72dkLvt
  appendonly yes                # for Recovery
  appendfilename "appendonly.aof"

firewall-cmd --add-port=6379/tcp --permanenent
firewall-cmd --reload
ss -tunelp | grep 6379

redis-cli
redis-cli -h 172.16.10.211 -p 6379
AUTH <AuthPassword>
CONFIG SET requirepass ""
INFO SERVER

# RDM - Redis Desktop Manager
dnf install snapd  # restart system
ln -s /var/lib/snapd/snap /snap
snap install redis-desktop-manager


# --------------------------
#   xRDP
# --------------------------
nano /etc/xrdp/xrdp.ini
