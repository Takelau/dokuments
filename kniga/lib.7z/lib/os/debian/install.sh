#!/bin/bash

USER="takelau"

## apt-key list
## apt-key del <id>

sudo passwd root
# echo "$USER ALL=(ALL) ALL" >> /etc/sudoers
# reboot


# --------------------------
#   VirtualBox
# --------------------------
apt-get install dkms linux-headers-$(uname -r)
mount /dev/cdrom /mnt
bash /mnt/VBoxLinuxAdditions.run
reboot


# --------------------------
#   Network
# --------------------------
# time zone
timedatectl set-timezone Europe/Moscow

# ipv6
nano /etc/sysctl.conf
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1

/sbin/sysctl -p

nano /etc/avahi/avahi-daemon.conf   # Desktop
use-ipv6=no

# dns
nano /etc/resolv.conf
nameserver 77.88.8.8


# --------------------------
#   Update
# --------------------------
echo "# Secure
deb     http://security.debian.org/debian-security/ bullseye-security main contrib 
deb-src http://security.debian.org/debian-security/ bullseye-security main contrib 

# Updates and Backports
deb http://deb.debian.org/debian bookworm main
deb http://deb.debian.org/debian bookworm-updates main
deb http://deb.debian.org/debian-security bookworm-security main

deb http://deb.debian.org/debian/ bullseye main contrib non-free
deb http://deb.debian.org/debian/ bullseye-updates main contrib non-free
deb http://deb.debian.org/debian/ bullseye-backports main contrib non-free" > /etc/apt/sources.list

# update
apt-get clean
apt-get update
apt-get dist-upgrade -d
apt-get dist-upgrade
reboot


# --------------------------
#   Post update
# --------------------------
apt-get install htop mc
apt-get install wget curl


# --------------------------
#   iptables
# --------------------------
# nftables -> iptables
update-alternatives --set iptables  /usr/sbin/iptables-legacy
update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy
update-alternatives --set arptables /usr/sbin/arptables-legacy
update-alternatives --set ebtables  /usr/sbin/ebtables-legacy
# iptables -> nftables
update-alternatives --set iptables  /usr/sbin/iptables-nft
update-alternatives --set ip6tables /usr/sbin/ip6tables-nft
update-alternatives --set arptables /usr/sbin/arptables-nft
update-alternatives --set ebtables  /usr/sbin/ebtables-nft

echo '#!/usr/sbin/nft -f
flush ruleset
table inet filter {
	chain input {
		type filter hook input priority filter; policy accept;
	}
	chain forward {
		type filter hook forward priority filter; policy accept;
	}
	chain output {
		type filter hook output priority filter; policy accept;
	}
}
' > /etc/nftables2.conf

echo '#!/bin/sh
/sbin/iptables-restore  < /etc/ipfw/iprule
/sbin/ip6tables-restore < /etc/ipfw/ip6rule
' > /etc/network/if-pre-up.d/iptables
chmod 750 /etc/network/if-pre-up.d/iptables

echo ':msg, contains, "[LOG" -/var/log/iptables
& ~' > /etc/rsyslog.d/iptables.conf
chmod 640 /etc/rsyslog.d/iptables.conf
systemctl restart rsyslog

echo '/var/log/iptables {
	daily
	rotate 30
	compress
	missingok
	notifempty
	sharedscripts
}' > /etc/logrotate.d/iptables
chmod 640 /etc/logrotate.d/iptables


# --------------------------
#   Volumes
# --------------------------
mkdir /vlm && mkdir /vlm/work && mkdir /vlm/work/bin && mkdir /vlm/work/pkg && mkdir /vlm/work/src
chown 1000:1000 -R /vlm && chmod g-rwx,o-rwx -R /vlm

mkfs.btrfs /dev/nvme0n1
mkfs.xfs   /dev/nvme0n1  <-- CentOS
mount /dev/nvme0n1 /vlm
nano /etc/fstab
/dev/nvme0n1 /vlm btrfs defaults 0 0


# --------------------------
#   Util
# --------------------------
# util
apt-get install dnsutils    # dig
apt-get install net-tools
apt-get install iptraf-ng
apt-get install httpie
# c
apt-get install build-essential 
apt-get install clang gcc
apt-get install gdb lldb
apt-get install cmake
# ssh
apt-get install -y sshfs


# --------------------------
#   Profile
# --------------------------
nano ~/.bashrc
export GOOS=linux             # LiteIDE
export GOARCH=amd64           # LiteIDE
export LC_CTYPE=en_US.UTF-8   # docui
export TERM=xterm-256color    # docui
export GOROOT=/vlm/go/go117
export GOPATH=/vlm/work
PATH=$PATH:$GOROOT/bin:$GOPATH/bin
export PATH

nano ~/.bash_history
go clean -cache && go clean -modcache && go clean -testcache
go mod tidy
docker run -it -v /vlm/work/src/nami_f35:/work/src/nami_f35 --name nami-f35 fedora:35 /bin/bash
git clone https://github.com/ds248a/notify.git
git remote set-url origin git@github.com:ds248a/notify
git add -A
git commit -am "Notify dir"
git push
go test -run='TestWatcher_createEvent/create_directory_(regexp)'
ssh -l hataru 192.168.1.211 -p 40004
ssh -l hataru 192.168.1.200 -p 40004
ssh -l takelau 192.168.1.210 -p 40004
go run .

nano ~/.bash_aliases
alias dir='dir --color=auto'
alias vdir='vdir --color=auto'
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'
alias ll='ls -l'


# --------------------------
#   Git
# --------------------------
apt-get install git

git config --global user.name "Takelau"
git config --global user.email takelau@gmail.com
git config --global core.editor nano
git config --global init.defaultBranch master
git config --global core.autocrlf input
git config --global core.safecrlf warn

nano ~/.gitconfig
[user]
  email = takelau@gmail.com
  name = Takelau
[init]
  defaultBranch = master
[alias]
  hist = log --pretty=format:\"%h %cd | %s%d [%cn]\" --since=3.month --graph --date=short
  type = cat-file -t
  dump = cat-file -p
[core]
  editor = nano

ssh-keygen -t rsa -b 4096 -C "ds248a@nami" -f "d2a"
eval "$(ssh-agent -s)"   # проверка агента
ssh-add ~/.ssh/id_key    # if agent admitted
ssh -T git@github.com    # тест | -vT подробный вывод

git remote set-url origin git@github.com:ds248a/notify.git


# --------------------------
#   C++
# --------------------------
nano ~/.bashrc
export GCC_COLORS='error=01;31:warning=01;35:note=01;36:caret=01;32:locus=01:quote=01'


# --------------------------
#   Go
# --------------------------
## disk
fdisk -l
mkdir /vlm && mkdir /vlm/work && mkdir /vlm/work/bin && mkdir /vlm/work/pkg && mkdir /vlm/work/src
chown 1000:1000 -R /vlm && chmod u=rwx,g=x,o=x -R /vlm
mount /dev/nvme0n1 /vlm

nano ~/.bashrc
export GOOS=linux             # LiteIDE
export GOARCH=amd64           # LiteIDE
export LC_CTYPE=en_US.UTF-8   # docui
export TERM=xterm-256color    # docui
export GOROOT=$HOME/go
export GOPATH=/vlm/work
# PATH=$PATH:$HOME/.local/bin:$GOROOT/bin:$GOPATH/bin
PATH=$PATH:$GOROOT/bin:$GOPATH/bin
export PATH

go clean -cache && go clean -modcache && go clean -testcache

go install github.com/cosmtrek/air@latest   # air
go install golang.org/x/tools/gopls@latest  # gopls
go install github.com/aarzilli/gdlv@latest  # gdlv

# docui (Docker)
cd /vlm/git
git clone https://github.com/skanehira/docui.git
cd docui/
GO111MODULE=on go install

# периодически обновлять
go get -u github.com/pkg/...
go get -u github.com/golang/...
go get -u github.com/patrickmn/go-cache


# --------------------------
#   Codelite
# --------------------------
apt-get install gdb lldb
apt-get install clang clang-tools clangd
# apt install libpcre2-32-0


# --------------------------
#   Builder IDE
# --------------------------
# https://builder.readthedocs.io/en/latest/installation.html
apt-get install clang-3.9 libclang-3.9-dev llvm-3.9-dev libssh2-1-dev


# --------------------------
#   Sublime
# --------------------------
# https://packagecontrol.io
1.Packages
- GoDebug                  # https://github.com/dishmaev/GoDebug
- Golang Build
- Gomod                    # https://packagecontrol.io/packages/Gomod
- LSP                      # https://packagecontrol.io/packages/LSP
- LSP-gopls                # https://packagecontrol.io/packages/LSP-gopls
- Vue Syntax Highlight

# LSP - langserver.org
Package Settings -> LSP -> Servers -> LSP-gopls
{
	"command": [
    "/vlm/work/bin/gopls"
  ],
  "settings": {
  	"manageGoplsBinary": false,
  },
}

# Golang Build - глобальная настройка
Package Settings -> Golang Config -> Settings User  
{
  "GOOS": "linux",
  "GOARCH": "amd64",
  "CGO_ENABLED": 1,
  "GO111MODULE": "auto",

  "PATH": "/vlm/go/go120/bin",
  "GOROOT": "/vlm/go/go120",
  "GOPATH": "/vlm/work",
  "GOMODCACHE":"/vlm/work/pkg/mod"
}

# настройки приложения
{
	"theme": "Adaptive.sublime-theme",
	"color_scheme": "Monokai.sublime-color-scheme",
	"font_face": "Noto Sans Mono Thin", // "Monospace Regular, DejaVu Sans Mono",
	"font_size": 10,
	"theme_font_options": [
		"no_antialias",
		"gray_antialias",
	    "subpixel_antialias"
	],
	"font_options": [
	    "no_bold",
	    "no_italic",
	    "no_antialias",
	    "gray_antialias",
	    "subpixel_antialias"
	],
	"highlight_line": false,
	"ignored_packages":
	[
		"Vintage",
	],
	"margin": 0,
	"show_tab_close_buttons": false,
	"tab_size": 2,
	"translate_tabs_to_spaces": false,
	"remember_workspace": true,
	"remember_layout": true,
}

# настройки темы
Preferences -> Customize Theme (Adaptive.sublime-theme)
{
  "variables":
  {
    "font_face": "DejaVu Sans Mono",
    "font_size_sm": 12,
    "font_size": 12,
  },
  "rules":[]
}

Key Bindings  # https://github.com/golang/sublime-build/blob/master/docs/commands.md
[
  { "keys": ["ctrl+b"], "command":"toggle_side_bar" },
  { "keys": ["command+shift+c"], "command":"golang_build_cancel" },
  { "keys": ["f5"], "command":"golang_build", "args": { "task":"run" } },
  { "keys": ["f8"], "command":"golang_build", "args": { "task":"clean" } },
  { "keys": ["f9"], "command":"golang_build", "args": { "task":"test" } },
]

# Go Project
{
  "folders": [ { "path": "." } ],
  "settings": {
    "LSP": {
      "gopls": {
        "enabled": true,
        "env": {
          "PATH": "/vlm/work/bin",
        }
      },
    },
    "lsp_format_on_save": true,
    "show_references_in_quick_panel": true,
    "log_debug": true,
    "log_stderr": true,

    "golang": {
      "linux": {
        "GO111MODULE": "auto",
        "PATH": "/vlm/go/go117/bin",
        "GOROOT": "/vlm/go/go117",
        "GOPATH": "/vlm/fw/fw_go17",
        "GOMODCACHE":"/vlm/fw/fw_go17/pkg/mod",
      },
    },
  },
}


# --------------------------
#   Visual Code
# --------------------------
sudo apt install apt-transport-https
sudo apt install <file>.deb


# --------------------------
#   xRDP
# --------------------------
nano /etc/xrdp/xrdp.ini
