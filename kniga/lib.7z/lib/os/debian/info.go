
// --------------------------
//   Info
// --------------------------

// repo
cat /etc/apt/sources.list

// apt
apt-get  // устанавливает 'рекомендуемые' пакеты по умолчанию
apt-get update              -> apt update          // обновление без удаления старых пакетов
apt-get upgrade             -> apt upgrade
apt-get dist-upgrade        -> apt full-upgrade    // обновление с удалением
apt-get install <package>   -> apt install <package>
apt-get remove <package>    -> apt remove <package>
apt-get autoremove          -> apt autoremove
apt-cache search <string>   -> apt search <string>
apt-cache policy <package>  -> apt list -a <package>
apt-cache show <package>    -> apt show <package>    // подробное описание установленной версии
apt-cache showpkg <package> -> apt show -a <package> // подробное описание + доступные версии
apt-cache depends <package>    // зависимости пакета

// installed
apt list --installed
apt list --installed | less
dpkg-query -l | less

dpkg -i <name>.deb    // не устанавливает зависимости -> apt install -f
gdebi <name>.deb      // устанавливает зависимоти     <- apt install gdebi-core



apt dist-upgrade      // список пакетов, для которых доступны обновления
apt full-upgrade      // обновить все установленные в системе пакеты с установкой или удалением дополнительных пакетов,
apt source <package>  // удалить из системы пакет и все его файлы настроек
apt show <package>    // подробное описание
apt clean             // Удалить все источники типа cdrom и все хранилища задач
apt autoclean

// repo
apt-repo list           // список активных репозитариев
apt-repo list -a        // список всех репозитариев
apt-repo rm source|all
apt-repo add source     // apt-repo add p10 | symply
apt-repo set branch     // apt-repo rm all  &&  apt-repo add p10
apt-repo clean

// dpkg
dpkg-query -l '*<string>*'
  /var/lib/apt/lists/*      */
  /var/lib/dpkg/available   // 
  /var/lib/dpkg/status      //
dpkg --list                 // список установленных пакетов
dpkg -L <package>           // список файлов установленного пакета
dpkg-reconfigure <package>  // изменение конфигурации установленного пакета
