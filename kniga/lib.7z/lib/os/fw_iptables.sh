
iptstate

# -------------
#!/bin/sh
iptables -F               # очищает все цепочки в текущей таблице
iptables -t nat -F
iptables -t mangle -F
iptables -X               # удаляет все пустые пользовательские цепочки в таблице
iptables -t nat -X
iptables -t mangle -X
# default ACCEPT | DROP
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# -------------
# --- DROP (Sync)
$IpFw -A INPUT -p tcp --tcp-flags SYN,ACK SYN,ACK -m conntrack --ctstate NEW,INVALID -j REJECT --reject-with tcp-reset  # анти спуфинг-атака от нашего хоста
$IpFw -A INPUT -p tcp ! --syn -m conntrack --ctstate NEW      -j DROP
$IpFw -A INPUT                -m conntrack --ctstate INVALID  -j DROP
# --- DROP (Frag)
$IpFw -A INPUT -f -j DROP
# --- Ested
$IpFw -A INPUT -m conntrack --ctstate RELATED,ESTABLISHED 
# --- lo
$IpFw -A INPUT -m addrtype --src-type LOCAL ! -i lo -j DROP
$IpFw -A INPUT  -i lo -j ACCEPT
$IpFw -A OUTPUT -o lo -j ACCEPT
# --- Limit
$IpFw -A INPUT -d $WAN_IP -m conntrack --ctstate NEW -m hashlimit --hashlimit-mode srcip --hashlimit-upto 70/sec --hashlimit-name lim_ip -i $WAN  -j ACCEPT

# не более 32 новых соединений в секунду
iptables -A INPUT -p tcp --dport 80 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -p tcp --dport 80 -m conntrack --ctstate NEW -m limit --limit 32/sec --limit-burst 32 -j ACCEPT
# ограничение на 5 соединений (INPUT) на 80 порт
iptables -A INPUT -p tcp --syn --dport 80 -m connlimit --connlimit-above 5 -j REJECT  # v1  above + REJECT
iptables -A INPUT -p tcp --syn --dport 80 -m connlimit --connlimit-upto  5 -j ACCEPT  # v2  upto + ACCEPT
# limit ssh-port connections per minute
iptables -A INPUT -p tcp --dport 22 -i $IFACE_EXT -m state --state NEW -m recent --set
iptables -A INPUT -p tcp --dport 22 -i $IFACE_EXT -m state --state NEW -m recent --update --seconds 60 --hitcount 2 -j DROP
iptables -A INPUT -p tcp --dport 22 -i $IFACE_EXT -j ACCEPT
# owner
iptables -A OUTPUT -m owner --uid-owner 1000
# ttl
iptables -A OUTPUT -m ttl --ttl 64
# redirect
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 8080
# nat
iptables -t nat -A PREROUTING -p tcp -d 15.45.23.67 --dport 80 -j DNAT --to-destination 192.168.1.1-192.168.1.10  # во всех пакетах, пришедших на адрес 15.45.23.67, адрес назначения будет изменен на один из диапазона от 192.168.1.1 до 192.168.1.10
iptables -t nat -A POSTROUTING -p TCP -j MASQUERADE --to-ports 1024-31000
iptables -t nat -A POSTROUTING -p tcp -o eth0 -j SNAT --to-source $WAN_IP  # $WAN_IP будет подставлен в заголовок пакета в качестве исходящего
# log
iptables -A INPUT -p tcp -m multiport --dports 22 -j LOG --log-level INFO --log-prefix "New connection from ours: "
iptables -A INPUT -i eth0 -m limit --limit-burst 5 --limit 1/sec -j LOG --log-level debug --log-prefix "text"

# -------------
iptables-save -c -t filter

iptables -vnL --line-numbers
iptables -t nat -L     # отобразить все цепочки правил в NAT-таблице
iptables -m limit -h   # Получить справочную информацию по любому из дополнительных критериев
iptables -vL -Z INPUT  # Обнуление всех счетчиков в заданной цепочке

# -------------
# таблицы
raw     просматривается до передачи пакета системе определения состояний.
        Используется редко, например для маркировки пакетов, которые НЕ должны обрабатываться системой определения состояний. Для этого в правиле указывается действие NOTRACK. Содержит цепочки PREROUTING и OUTPUT.
mangle  содержит правила модификации (обычно заголовка) IP‐пакетов. Среди прочего, поддерживает действия TTL (Time to live), TOS (Type of Service), и MARK (для изменения полей TTL и TOS, и для изменения маркеров пакета).
        Редко необходима и может быть опасна. Содержит все пять стандартных цепочек.
nat     просматривает только пакеты, создающие новое соединение (согласно системе определения состояний). Поддерживает действия DNAT, SNAT, MASQUERADE, REDIRECT. Содержит цепочки PREROUTING, OUTPUT, и POSTROUTING.
filter  основная таблица, используется по умолчанию если название таблицы не указано. Содержит цепочки INPUT, FORWARD, и OUTPUT.
security

# цепочки
PREROUTING  для изначальной обработки входящих пакетов
INPUT       для входящих пакетов адресованных непосредственно локальному процессу (клиенту или серверу)
FORWARD     для входящих пакетов перенаправленных на выход (заметьте, что перенаправляемые пакеты проходят сначала цепь PREROUTING, затем FORWARD и POSTROUTING)
OUTPUT      для пакетов генерируемых локальными процессами
POSTROUTING для окончательной обработки исходящих пакетов

# Действия
ACCEPT  пропустить
DROP    удалить
QUEUE   передать на анализ внешней программе
NFQUEUE
RETURN  вернуть на анализ в предыдущую цепочку
REJECT  пакет отклоняется, может быть использована только с цепочками INPUT, OUTPUT и FORWARD
LOG, ULOG, NFLOG

# QUEUE    / https://git.netfilter.org/iptables/tree/extensions/libxt_NFQUEUE.t?h=v1.8.8
iptables -t mangle -A POSTROUTING -p tcp --dport 5555 -j NFQUEUE --queue-num 0
iptables -A INPUT -j NFQUEUE --queue-num 0
iptables -A INPUT -j NFQUEUE --queue-balance 0:3
cat /proc/net/netfilter/nfnetlink_queue

# критерии
addrtype UNSPEC (адрес 0.0.0.0), UNICAST, LOCAL (адрес принадлежит нашему хосту), BROADCAST, ANYCAST, MULTICAST, BLACKHOLE, UNREACHABLE, PROHIBIT, THROW, NAT, XRESOLVE

-p tcp
	--sport, --source-port  # /etc/services
	--dport, --destination-port
	--tcp-flags SYN, ACK, FIN, RST, URG, PSH [ALL, NONE]
	--syn      # Критерию соответствуют пакеты с установленным флагом SYN и сброшенными флагами ACK и FIN | --tcp-flags SYN,ACK,FIN SYN
	--tcp-option
-p udp
  --sport, --source-port  # /etc/services
	--dport, --destination-port
-p icmp
  --icmp-type
-p sctp
  --sport, --dport, --chunk-types
-p dccp
	--sport, --dport, --dccp-types


-m multiport --source-port 80,443
-m iprange --src-range 192.168.0.8-192.168.0.25
-m mac --mac-source 00:00:00:00:00:01  #  имеет смысл только в цепочках PREROUTING, FORWARD и INPUT
-m comment --comment "запрет Invalid пакетов"
-m limit
  --limit 3/min     # задает ограничение на количество пакетов в [/second | /minute | /hour | /day]
  --limit-burst 5   # задает длину очереди, то есть максимальную пропускную способность
-m hashlimit        # для каждого хоста, подсети или порта создается отдельная очередь
-m connlimit --connlimit-above 1 # позволяет ограничивать количество одновременно открытых соединений с каждого IP-адреса (или подсети)
-m mark --mark 1
  iptables -t mangle -A INPUT -m mark --mark 1  # [0 - 4294967296]
-m recent           # позволяет запоминать проходящие через него пакеты, а затем использовать полученную информацию для принятия решений
-m state --state INVALID, ESTABLISHED, NEW, RELATED # не поддерживающий состояния DNAT и SNAT
-m conntrack --ctstate NEW, ESTABLISHED, RELATED, INVALID, UNTRACKED, DNAT, SNAT
-m conntrack --ctstatus NONE, EXPECTED, SEEN_REPLY, ASSURED, CONFIRMED

-j ACCEPT  # обработка пакета в этой цепочке прекращается и он передается следующей цепочке, где над ним может быть произведена дополнительная обработка
-j DROP    # может оставлять незакрытые сокеты на стороне сервера
-j RETURN  # возврат в вызывающую цепочку
-j REJECT  # отправителю будет отправлено IСМР-сообщение "Port unreachable"
-j REJECT --reject-with icmp-net-unreachable # изменяет тип ICMP-сообщения
	icmp-net-unreachable   # сеть недоступна
	icmp-host-unreachable  # узел недоступен
	icmp-port-unreachable  # порт недоступен  <-- default
	icmp-proto-unreahable  # неподдерживаемый протокол
	icmp-net-prohibited    # сеть запрещена
	icmp-host-prohibited   # узел запрещен
  + tcp-reset  # TCP RST пакеты используются для закрытия TCP соединений
-j REDIRECT --to-ports    # Выполняет перенаправление пакетов и потоков на другой порт той же самой машины | может использоваться только в цепочках PREROUTING и OUTPUT таблицы nat
-j MASQUERADE --to-ports  # только в цепочке POSTROUTING таблицы nat
-j DNAT --to-destination  # используется для преобразования адреса места назначения в IP заголовке пакета | может выполняться только в цепочках PREROUTING и OUTPUT таблицы nat
-j SNAT --to-source       # использовать для предоставления выхода в Интернет другим компьютерам из локальной сети | выполнять только в таблице nat, в цепочке POSTROUTING
-j LOG    #
  --log-level INFO     # [debug, info, notice, warning, warn, err, error, crit, alert, emerg и panic]
  --log-prefix "text:"
  --log-tcp-sequence   # TCP Sequence идентифицирует каждый пакет в потоке и определяет порядок "сборки" потока
  --log-tcp-options    # опции протокола TCP | debug
  --log-ip-options     # опции ip | debug
  --log-uid            # user id
-j ULOG
	--ulog-nlgroup 2     # сообщает ULOG в какую группу netlink должен быть передан пакет | [1 - 32]
	--ulog-prefix "text:"
	--ulog-cprange 100   # определяет, какую долю пакета, в байтах, надо передавать демону ULOG
	--ulog-qthreshold 10 # устанавливает величину буфера в области ядра

# -------------
iptables -A INPUT    # Добавляет новое правило в конец заданной цепочки
iptables -D INPUT 1  # Удаление правила из цепочки
iptables -R INPUT 1 -s 192.168.0.1 -j DROP  # заменяет одно правило другим
iptables -I INPUT 1 --dport 80 -j ACCEPT    # 
iptables -F INPUT
iptables -Z INPUT       # Обнуление всех счетчиков в заданной цепочке
iptables -X chain_name  # Удаление заданной цепочки из заданной таблицы
iptables -P INPUT DROP  # Задает политику по-умолчанию для заданной цепочки
iptables -E chain_name_from chain_name_to

# -------------
# создание цепочки
iptables -N chain_name
iptables -A chain_name  packet-description  --jump [ACCEPT | DROP]      # правила цепочки
iptables -A chain_name -j RETURN                                        # правила по умолчанию
iptables -A INPUT -p tcp -m multiport --dports 22:80 -j chain_name      # перенаправление в цепочку

# переход к цепочке (должны находиться в одной таблице)
iptables -A INPUT -j chain_name


# -------------
# QUEUE
libipq API
testsuite tools (например redirect.c) на CVS
/proc/net/ip_queue                  # Статус ip_queue
/proc/sys/net/ipv4/ip_queue_maxlen  # Максимальная длинна очереди / 1024

modprobe iptable_filter
modprobe ip_queue
iptables -A OUTPUT -p icmp -j QUEUE


# -------------
# NAT
	В цепочке PREROUTING мы будем менять информацию о получателе пакета (DNAT), а в цепочке POSTROUTING - об отправителе (SNAT).
	Действие MASQUERADE допускается указывать только в цепочке POSTROUTING таблицы nat.
	# /etc/sysctl.conf
	sysctl    net.ipv4.ip_forward    # 0
	sysctl -w net.ipv4.ip_forward=1  # 1

# для постоянного IP (10.5.21.24)
iptables -t nat -A POSTROUTING -p tcp -o eth0 -j SNAT --to-source $WAN_IP:[30000-50000]
# для динамического IP
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
# проброс порта 3389
iptables -t nat -A PREROUTING -p tcp --dport 3389 -j DNAT --to-destination 172.16.23.24:3389
# Transmission (порт 51413)
iptables -t nat -A PREROUTING -i $ISP_Valor -p tcp -m tcp                 --dport 51413 -j DNAT --to 10.26.95.251:51413
iptables        -A FORWARD                  -p tcp -m tcp -d 10.26.95.251 --dport 51413    -j ACCEPT
iptables -t nat -A PREROUTING -i $ISP_Valor -p udp -m udp                 --dport 51413 -j DNAT --to 10.26.95.251:51413
iptables        -A FORWARD                  -p udp -m udp -d 10.26.95.251 --dport 51413    -j ACCEPT
# доспуп к локальному HTTP серверу из инета
iptables -t nat -A PREROUTING --dst $WAN_IP -p tcp --dport 80 -j DNAT --to-destination $HTTP_LAN_IP
# доспуп к локальному HTTP серверу из лан
iptables -t nat -A POSTROUTING -p tcp --dst $HTTP_LAN_IP --dport 80 -j SNAT --to-source $LAN_IP
# доспуп к локальному HTTP серверу с хоста фаэрвола
iptables -t nat -A OUTPUT --dst $WAN_IP -p tcp --dport 80 -j DNAT --to-destination $HTTP_LAN_IP

# -------------
# TCP
Для сокетов TCP допустимы следующие значения состояния
CLOSED 	     Закрыт. Сокет не используется
LISTEN 	     Сокет ожидает входящих соединений
SYN_SENT     Активно пытается установить соединение. Cокет в процессе установки соединения
SYN_RECEIVED (SYN_RCVD)	Идет начальная синхронизация соединения. Был принят запрос установки соединения из сети
ESTABLISHED  Соединение установлено
CLOSE_WAIT   Удаленная сторона отключилась; ожидание закрытия сокета
FIN_WAIT_1   Сокет закрыт; соединение закрывается
CLOSING      Сокет закрыт, затем удаленная сторона отключилась; ожидание подтверждения
LAST_ACK     Удаленная сторона отключилась, затем сокет закрыт; ожидание подтверждения
FIN_WAIT_2   Сокет закрыт; ожидание отключения удаленной стороны
TIME_WAIT    Сокет закрыт, но ожидает пакеты, ещё находящиеся в сети для обработки
UNKNOWN      Статус сокета неизвестен
