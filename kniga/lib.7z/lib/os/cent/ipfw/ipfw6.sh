#!/bin/sh

cat << EOT > "/etc/ipfw/ipfw6"
#!/bin/bash
IpFw6="/sbin/ip6tables"

\$IpFw6 -F
\$IpFw6 -X
\$IpFw6 -t nat -F
\$IpFw6 -t nat -X
\$IpFw6 -t mangle -F
\$IpFw6 -t mangle -X

\$IpFw6 -P INPUT   DROP
\$IpFw6 -P OUTPUT  DROP
\$IpFw6 -P FORWARD DROP

# \$IpFw6 -P INPUT   ACCEPT
# \$IpFw6 -P OUTPUT  ACCEPT
# \$IpFw6 -P FORWARD ACCEPT

# ~~~ Save Config
ip6tables-save -c > /etc/sysconfig/ip6tables
EOT

chmod 700	/etc/ipfw/ipfw6
chown root:root /etc/ipfw/ipfw6
