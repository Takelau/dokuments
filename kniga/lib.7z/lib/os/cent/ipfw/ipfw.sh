#!/bin/sh

if [ "$1" ]
then

cat << EOT > "/etc/ipfw/ipfw"
#!/bin/bash

# ========================
IpFw="/sbin/iptables"

WAN="$1"
WAN_IP="$2"
ADMIN_IP="$3"

DNS_SERVER="8.8.8.8 8.8.2.2"
NM_UPDATE=0

if [ "\$1" -a "\$1" == "u+" ]
then
  NM_UPDATE=1
fi

# ========================

\$IpFw -F
\$IpFw -X
\$IpFw -t nat -F
\$IpFw -t nat -X
\$IpFw -t mangle -F
\$IpFw -t mangle -X

\$IpFw -P INPUT   DROP
\$IpFw -P OUTPUT  DROP
\$IpFw -P FORWARD DROP

# ========================

# --- DROP (Sync)
\$IpFw -A INPUT -p tcp ! --syn -m state --state NEW      -i \$WAN  -j DROP
\$IpFw -A INPUT                -m state --state INVALID  -i \$WAN  -j DROP

# --- DROP (Frag)
\$IpFw -A INPUT -f -j DROP

# --- Ested
\$IpFw -A INPUT -m state --state RELATED,ESTABLISHED  -j ACCEPT

# --- lo
\$IpFw -A INPUT  -i lo -j ACCEPT
\$IpFw -A OUTPUT -o lo -j ACCEPT

# --- Limit
\$IpFw -A INPUT -d \$WAN_IP -m state --state NEW -m hashlimit --hashlimit-mode srcip --hashlimit-upto 70/sec --hashlimit-name lim_ip -i \$WAN  -j ACCEPT

# ========================

# --- UPDATE
if (( \$NM_UPDATE == 1 ))
then
  \$IpFw -A INPUT  -p tcp  -d \$WAN_IP  -m multiport --sport 21,80,443  -i \$WAN -m state --state ESTABLISHED      -j ACCEPT
  \$IpFw -A OUTPUT -p tcp  -s \$WAN_IP  -m multiport --dport 21,80,443  -o \$WAN -m state --state NEW,ESTABLISHED  -j ACCEPT
fi

# HTTP IN
\$IpFw -A INPUT  -p tcp  -d \$WAN_IP -m multiport --dport 80,443  -s \$ADMIN_IP  -i \$WAN -m state --state NEW,ESTABLISHED  -j ACCEPT
\$IpFw -A OUTPUT -p tcp  -s \$WAN_IP -m multiport --sport 80,443  -d \$ADMIN_IP  -o \$WAN -m state --state ESTABLISHED      -j ACCEPT

# --- DNS GET
for ip in \$DNS_SERVER
do
  \$IpFw -A INPUT  -p udp  -s \$ip  -m udp --sport 53  -d \$WAN_IP -m multiport --dports 1024:65535  -i \$WAN -m state --state ESTABLISHED      -j ACCEPT
  \$IpFw -A OUTPUT -p udp  -s \$WAN_IP -m multiport --sports 1024:65535  -d \$ip -m udp --dport 53  -o \$WAN  -m state --state NEW,ESTABLISHED  -j ACCEPT
done

# ========================

# --- SSH Admin
\$IpFw -A INPUT  -p tcp  -s \$ADMIN_IP  -d \$WAN_IP  --dport 40004  -i \$WAN -m state --state NEW,ESTABLISHED  -j ACCEPT
\$IpFw -A OUTPUT -p tcp  -d \$ADMIN_IP  -s \$WAN_IP  --sport 40004  -o \$WAN -m state --state ESTABLISHED      -j ACCEPT

# --- ICMP
\$IpFw -A INPUT  -p icmp -d \$WAN_IP --icmp-type 0 -i \$WAN  -j ACCEPT
\$IpFw -A OUTPUT -p icmp -s \$WAN_IP --icmp-type 8 -o \$WAN  -j ACCEPT

# --- DROP ALL
if (( \$NM_UPDATE == 1 ))
then
  \$IpFw -A INPUT  -j ACCEPT
  \$IpFw -A OUTPUT -j ACCEPT
else
  \$IpFw -A INPUT  -j DROP
  \$IpFw -A OUTPUT -j DROP
fi

# ~~~ Save Config
iptables-save -c > /etc/sysconfig/iptables
#
exit 0
EOT

chmod 700	/etc/ipfw/ipfw
chown root:root /etc/ipfw/ipfw

fi
