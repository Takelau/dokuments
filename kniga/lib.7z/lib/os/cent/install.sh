#!/bin/sh


## mkdir /nami
## mkdir /nami/ssh
## mkdir /nami/ipfw
## copy /nami/ssh/ssh.sh
## copy /nami/ipfw/ipfw.sh
## copy /nami/ipfw/ipfw6.sh


# ---------------------
SERVER_NAME="cnt"
USER="hataru"

WAN="enp0s3"
WAN_IP="192.168.1.200"

ADMIN="192.168.1.8"
# ---------------------


# ---------------------
# Подготовка
# ---------------------
timedatectl set-timezone Europe/Moscow
hostnamectl set-hostname $SERVER_NAME
hostnamectl status

chmod -R u-w,g-rwx,o-rwx /nami
chmod 500 /nami
chmod 700 -f /nami/*/*.sh

chown -R root:root   /nami
#chcon -R -u system_u /nami


# ---------------------
# Resolv
# ---------------------
cat <<EOT > /etc/resolv.conf
search 8.8.2.2
nameserver 8.8.8.8
EOT


# ---------------------
# SeLinux
# ---------------------
setenforce 0

cat <<EOT > /etc/sysconfig/selinux
# This file controls the state of SELinux on the system.
# SELINUX= can take one of these three values:
#     enforcing - SELinux security policy is enforced.
#     permissive - SELinux prints warnings instead of enforcing.
#     disabled - No SELinux policy is loaded.
SELINUX=disabled
# SELINUXTYPE= can take one of three two values:
#     targeted - Targeted processes are protected,
#     minimum - Modification of targeted policy. Only selected processes are protected..
#     mls - Multi Level Security protection.
SELINUXTYPE=targeted
EOT


# ---------------------
# Update
# ---------------------
dnf update -y

dnf install -y epel-release
dnf install -y htop
dnf install -y mc
dnf install -y wget
dnf install -y nano


# ---------------------
# Net
# ---------------------
# dnf install -y net-tools
# dnf install -y lsof

chmod 444	/etc/sysconfig/network-scripts/ifcfg*
chown root:root /etc/sysconfig/network-scripts/ifcfg*


# ---------------------
# Iptables
# ---------------------
systemctl stop firewalld
systemctl mask firewalld

yum install -y iptables-services
systemctl enable iptables
systemctl enable ip6tables
systemctl restart iptables
systemctl restart ip6tables
iptables -S
ip6tables -S

cat <<EOT > /etc/sysconfig/iptables-config
IPTABLES_MODULES=""
IPTABLES_MODULES_UNLOAD="yes"
IPTABLES_SAVE_ON_STOP="no"
IPTABLES_SAVE_ON_RESTART="yes"
IPTABLES_SAVE_COUNTER="no"
IPTABLES_STATUS_NUMERIC="yes"
IPTABLES_STATUS_VERBOSE="yes"
IPTABLES_STATUS_LINENUMBERS="yes"
EOT

cat <<EOT > /etc/sysconfig/ip6tables-config
IP6TABLES_MODULES=""
IP6TABLES_MODULES_UNLOAD="yes"
IP6TABLES_SAVE_ON_STOP="no"
IP6TABLES_SAVE_ON_RESTART="yes"
IP6TABLES_SAVE_COUNTER="no"
IP6TABLES_STATUS_NUMERIC="yes"
IP6TABLES_STATUS_VERBOSE="no"
IP6TABLES_STATUS_LINENUMBERS="yes"
EOT

cat <<EOT > /etc/sysconfig/network
NETWORKING="yes"
NETWORKING_IPV6="no"
EOT

mkdir /etc/ipfw
chown root:root /etc/ipfw
chmod 500 /etc/ipfw

cat <<EOT > /etc/ipfw/ipfw
#!/bin/bash
IpFw="/sbin/iptables"

# ---
\$IpFw -F
\$IpFw -X
\$IpFw -t nat -F
\$IpFw -t nat -X
\$IpFw -t mangle -F
\$IpFw -t mangle -X
# ---
\$IpFw -P INPUT   ACCEPT
\$IpFw -P OUTPUT  ACCEPT
\$IpFw -P FORWARD ACCEPT
# --- lo
\$IpFw -A INPUT  -i lo -j ACCEPT
\$IpFw -A OUTPUT -o lo -j ACCEPT
EOT

cat <<EOT > /etc/ipfw/ipfw6
#!/bin/sh
IpFw6="/sbin/ip6tables"
\$IpFw6 -F
\$IpFw6 -X
\$IpFw6 -t nat -F
\$IpFw6 -t nat -X
\$IpFw6 -t mangle -F
\$IpFw6 -t mangle -X
\$IpFw6 -P INPUT   DROP
\$IpFw6 -P OUTPUT  DROP
\$IpFw6 -P FORWARD DROP
EOT

chown root:root /etc/ipfw/ipfw
chown root:root /etc/ipfw/ipfw6
chmod 700	/etc/ipfw/ipfw
chmod 700	/etc/ipfw/ipfw6

/etc/ipfw/ipfw
/etc/ipfw/ipfw6

iptables-save -c  > /etc/sysconfig/iptables
ip6tables-save -c > /etc/sysconfig/ip6tables

# iptables -S
# ip6tables -S

# sestatus
# hostnamectl status

# ---------------------
# SSH
# ---------------------
# semanage port -a -t ssh_port_t -p tcp 40004
/nami/ssh/ssh.sh  $USER  $WAN_IP

rm -R -f /home/$USER/.ssh
mkdir    /home/$USER/.ssh

# cp /nami/id_rsa      /home/$USER/.ssh
# cp /nami/id_rsa.pub  /home/$USER/.ssh
# cp /nami/known_hosts /home/$USER/.ssh

chmod 700 /home/$USER/.ssh
# chmod 400 /home/$USER/.ssh/id_rsa
# chmod 440 /home/$USER/.ssh/id_rsa.pub

chown -R $USER:$USER    /home/$USER/.ssh
#chcon -R -t ssh_home_t  /home/$USER/.ssh

systemctl restart sshd


# ---------------------
# ipfw
# ---------------------
#                    1     2        3
/nami/ipfw/ipfw.sh   $WAN  $WAN_IP  $ADMIN
/nami/ipfw/ipfw6.sh

/nami/ipfw/ipfw
/nami/ipfw/ipfw6
