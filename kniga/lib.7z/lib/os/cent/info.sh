
# --------------------------
#   Network
# --------------------------
nano /etc/sysctl.conf
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1


# --------------------------
#   Go
# --------------------------
## disk
fdisk -l
mkfs.xfs /dev/nvme0n2
mkdir /home/hataru/work && mkdir /home/hataru/work/bin && mkdir /home/hataru/work/pkg && mkdir /home/hataru/work/src
chown 1000:1000 -R /home/hataru/work && chmod u=rwx,g=x,o=x -R /home/hataru/work
mount /dev/nvme0n2 /home/hataru/work

nano /etc/fstab
/dev/nvme0n2 /home/hataru/work xfs defaults 0 0


# --------------------------
#   Docker
# --------------------------
## disk
fdisk -l
mkfs.xfs /dev/nvme0n1
mkdir /var/lib/docker && chmod u=rwx,g=x,o=x /var/lib/docker
mount /dev/nvme0n1 /var/lib/docker

nano /etc/fstab
/dev/nvme0n1 /var/lib/docker   xfs defaults 0 0

## remove
dnf remove docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine
## repo && install
dnf config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo
dnf config-manager --set-disabled docker-ce-nightly   # <-- disabled 'nightly'
dnf install containerd.io
dnf install docker-ce docker-ce-cli --nobest
dnf list docker-ce  --showduplicates | sort -r
# fedora
