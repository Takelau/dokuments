#!/bin/sh

if [ "$1" -a "$2" ]
then

USER="$1"
WAN_IP="$2"

cat <<EOT > /etc/ssh/sshd_config
#
# If you want to change the port on a SELinux system, you have to tell
# SELinux about this change.
# semanage port -a -t ssh_port_t -p tcp #PORTNUMBER
#

Port 40004
AllowUsers $USER
AddressFamily inet         # <-- IpV4 only
ListenAddress $WAN_IP

HostKey /etc/ssh/ssh_host_rsa_key
#HostKey /etc/ssh/ssh_host_ecdsa_key
#HostKey /etc/ssh/ssh_host_ed25519_key

UsePrivilegeSeparation  yes
KeyRegenerationInterval 1h
ServerKeyBits    1024
#RekeyLimit      default none
#SyslogFacility  AUTH
SyslogFacility   AUTHPRIV
LogLevel         INFO

LoginGraceTime   1m
PermitRootLogin  no
StrictModes      yes
MaxAuthTries     2
MaxSessions      4

RSAAuthentication    no
PubkeyAuthentication no

AuthorizedKeysFile        .ssh/authorized_keys
AuthorizedPrincipalsFile  none
AuthorizedKeysCommand     none
AuthorizedKeysCommandUser nobody

RhostsRSAAuthentication no
HostbasedAuthentication no
IgnoreRhosts            yes
# IgnoreUserKnownHosts    yes

PasswordAuthentication          no
PermitEmptyPasswords            no
ChallengeResponseAuthentication no

# Kerberos options
#KerberosAuthentication no
#KerberosOrLocalPasswd yes
#KerberosTicketCleanup yes
#KerberosGetAFSToken no
#KerberosUseKuserok yes

UsePAM yes

#AllowAgentForwarding yes
#AllowTcpForwarding yes
#GatewayPorts no
X11Forwarding no
X11DisplayOffset 10
#X11UseLocalhost yes
PermitTTY no
PrintMotd no
PrintLastLog yes
TCPKeepAlive no
UseLogin no
UsePrivilegeSeparation sandbox       # Default for new installations.
#PermitUserEnvironment no
#Compression delayed
ClientAliveInterval 20
ClientAliveCountMax 3
#ShowPatchLevel no
#UseDNS yes
#PidFile /var/run/sshd.pid
#MaxStartups 10:30:100
#PermitTunnel no
#ChrootDirectory none
#VersionAddendum none

# no default banner path
Banner none

# Accept locale-related environment variables
AcceptEnv LANG LC_CTYPE LC_NUMERIC LC_TIME LC_COLLATE LC_MONETARY LC_MESSAGES
AcceptEnv LC_PAPER LC_NAME LC_ADDRESS LC_TELEPHONE LC_MEASUREMENT
AcceptEnv LC_IDENTIFICATION LC_ALL LANGUAGE
AcceptEnv XMODIFIERS

Subsystem  sftp  /usr/libexec/openssh/sftp-server
#Subsystem  sftp  internal-sftp

Match User $USER
  X11Forwarding no
  AllowTcpForwarding yes
  PermitTTY yes
  PasswordAuthentication yes
  RSAAuthentication	     no
  PubkeyAuthentication   yes
  #  ChrootDirectory  /home/$USER
  #  ForceCommand cvs server

EOT

chmod 440         /etc/ssh/sshd_config
#chcon -t etc_t    /etc/ssh/sshd_config
#chcon -u system_u /etc/ssh/sshd_config

fi
