#!/bin/sh

# --------------------------
#   Virtual Box
# --------------------------
Система -> Материнская плата -> Включить EFI
Дисплей -> 128
# --- процесс установки
В окне с ошибкой -> Shift + F10 -> regedit
в дир HKEY_LOCAL_MACHINE\SYSTEM\Setup
	создать новый раздел с именем LabConfig
		создать три новых параметра DWORD-32
			BypassSecureBootCheck  1
			BypassRAMCheck         1
			BybassTPMCheck         1

