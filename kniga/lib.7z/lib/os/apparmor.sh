
# --------------------------
#    Install
# --------------------------
sudo apt-get install apparmor-profiles


# --------------------------
#    Info
# --------------------------
sudo aa-status    # статус профилей
sudo aa-logprof   # просмотр логов

sudo /etc/init.d/apparmor start      # запуск
sudo update-rc.d apparmor defaults   # загрузка модуля

sudo /etc/init.d/apparmor stop       # остановка
sudo update-rc.d -f apparmor remove  # выгрузка модуля

sudo aa-genprof <exec>  # создание нового профиля

sudo aa-complain /path/to/bin            # переводит профиль в режим обучения (complain) 
sudo aa-enforce  /path/to/bin            # переводит профиль в режим ограничений (enforce)
sudo aa-complain /etc/apparmor.d/<name>  # перевод профиля в режим обучения

sudo /etc/init.d/apparmor reload                      # перезагрузка всех профилей
cat /etc/apparmor.d/<name> | sudo apparmor_parser -a  # загрузка профиля в ядро
cat /etc/apparmor.d/<name> | sudo apparmor_parser -r  # перезагрузка профиля в ядре

# отключение профиля
ln -s /etc/apparmor.d/profile.name /etc/apparmor.d/disable/
apparmor_parser -R /etc/apparmor.d/profile.name
# подключение отключенного ранее профиля
sudo rm /etc/apparmor.d/disable/profile.name
cat /etc/apparmor.d/profile.name | sudo apparmor_parser -a


# --------------------------
#    /etc/apparmor.d
# --------------------------
#include <tunables/global>      # включает операторы из других файлов
/bin/ping flags=(complain) {    # режим обучения
  #include <abstractions/base>
  #include <abstractions/consoles>
  #include <abstractions/nameservice>

  capability net_raw,    # разрешает приложению доступ к возможностям CAP_NET_RAW Posix.1e
  capability setuid,     #
  network inet raw,      #
  
  /bin/ping mixr,        # доступ на чтение и выполнение файла
  /etc/modules.conf r,
}


# --------------------------
#    Синтаксис
# --------------------------
# https://gitlab.com/apparmor/apparmor/-/wikis/QuickProfileLanguage

# File permissions  | /foo/src rw
r - read
w - write
a - append (implied by w)
x - execute
	ux  - Выполнение без ограничений (сохранение окружающей среды)
	Ux  - Выполнять без ограничений (очищать окружающую среду)
	px  - Выполнять под определенным профилем (сохранять среду)
	Px  - Выполнить под определенным профилем (очистить среду)
	pix - как px, но вернуться к наследованию текущего профиля, если целевой профиль не найден
	Pix - как Px
	pux - как px, но вернуться к выполнению без ограничений, если целевой профиль не найден
	Pux - как Px
	ix  - Выполнить и наследовать текущий профиль
	cx  - Выполнить и перейти к дочернему профилю (сохранить среду)
m - исполняемый файл карты памяти
k - блокировка (требуется r или w, AppArmor 2.1 и выше)
l - ссылка

# Rule Modifiers  | audit /foo/src rw
audit       # force logging
deny        # explicitly deny, without logging
audit deny  # combination to explicitly deny, but log

# ---
/dir/*      # соответствовать любым файлам в каталоге
/dir/[^.]*  # соответствует любому файлу в каталоге, кроме точечных файлов
/dir/       # соответствует каталогу
/dir/*/     # соответствует любому каталогу внутри
/dir/**     # соответствует любому файлу или каталогу в /dir/
/dir/**/    # соответствует любому каталогу в /dir/ или любому каталогу ниже /dir/
/dir/**[^/] # соответствует любому файлу в /dir/ или любому каталогу ниже /dir

(  ) # групповое выражение должно рассматриваться как одно выражение
*    # 0 или более раз
+    # 1 или более раз
?    # 0 или 1 раз
[]   # символы
|    # ИЛИ
^    # привязать выражение к началу строки
$    # привязать выражение к хвосту строки
[^]  # инверсия

