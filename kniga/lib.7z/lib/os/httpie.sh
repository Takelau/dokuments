
# --------------------------
#   httpie
# --------------------------

# Upload a File
http https://transfer.sh < file.txt

# Download a File
http https://transfer.sh/Vq3Kg/file.txt > file.txt	
http --download https://transfer.sh/Vq3Kg/file.txt

# Submit a Form
http -f POST mail.ru date='Hello World'

# View Request Details
http -v mail.ru
http -v -f POST mail.ru date='Hello World'
http PUT mail.ru/put X-API-Token:123 name=John

# Basic HTTP Auth
http -a username:password mail.ru/auth
http --session=logged-in -a username:password mail.ru/auth API-Key:123

# Custom HTTP Headers
http GET https://httpbin.org/headers User-Agent:'TEST 1.0'
