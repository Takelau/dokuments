
// информация о образах
lxc image list images:                  // списки доступных неофициальных образов
lxc image list [amd64 | os=ubuntu]      // список локальных образов
lxc image info <oname | alias-image>    // нформация о образе
lxc image delete <oname | alias-image>  // удаление
lxc image export <alias-image> .        // экспорт тарбола
lxc image import <name-tarball>         // импорт тарбола

// информация о контейнерах
lxc list                   // Список всех контейнеров
lxc list --fast <NAME>
lxc info <cname>           // детальная информация о контейнере

// создание контейнера
lxc image copy ubuntu:14.04 local: --alias <oname>  // загрузка образа
lxc image copy ubuntu:14.04 local: --auto-update    // загрузка образа и поддержка его актуальности
lxc launch ubuntu:14.04/i386 <cname>                // загрузка образа, создание и запуск нового контейнера
lxc init   ubuntu:14.04/i386 <cname>                // Создание контейнера без его запуска
lxc publish <cname> --alias <new-image>             // превращение контейнера в образ

// запуск контейнера
lxc start | stop | restart | pause | delete <cname>
lxc move <имя-контейнера> <новое-имя-контейнера>    // переименование контейнера
lxc copy <имя-контейнера> <имя-нового-контейнера>   // копия контейнера | новый MAC и сброс снимков состояния

lxc exec <cname> bash
lxc file pull <cname>/<file> <host-file>  // чтение файла из контейнера
lxc file pull <cname>/<file> -            // вывод на стандартный output
lxc file push <host-file> <cname>/<file>  // запись файла в контейнер
lxc file edit <cname>/<file>              // едактирование файла в текстовом редакторе

// снимки состояния
lxc snapshot <cname> <имя-снимка>
lxc restore <cname> <имя-снимка>
lxc move <cname>/<имя-снимка> <cname>/<новое-имя-снимка>                  // переименование снимка
lxc copy <имя-исходного-контейнера>/<имя-снимка> <имя-нового-контейнера>  // Создание контейнера из снимка | новый MAC
lxc delete <cname>/<имя-снимка>

// профили и конфигурирование образа
lxc profile list
lxc profile show <имя-профиля>
lxc profile edit <имя-профиля>
lxc profile apply <имя-контейнера> <имя-профиля-1>,<имя-профиля-2>,...
lxc profile set <имя-контейнера> <имя-ключа> <значение>
lxc profile device add <имя-контейнера> kvm unix-char path=/dev/kvm  // Добавляет устройство

lxc config edit <имя-контейнера>             // редактирование конфигурации конкретного контейнера
lxc config set <имя-контейнера> <имя-ключа> <значение>
lxc config device add <имя-контейнера> kvm unix-char path=/dev/kvm   // Добавляет устройство

lxc config show <имя-контейнера>             // чтение конфигурации
lxc config show --expanded <имя-контейнера>  // расширенный формат

// нформация
lxc info <cname>
lxc exec <cname> -- cat /proc/cpuinfo | grep ^proces  // CPU
lxc exec <cname> -- df -h /                           // HDD


// --------------------------
//  Лимиты
// --------------------------
lxc exec <cname> -- cat /proc/cpuinfo | grep ^proces  // информация о числе ядер
lxc exec <cname> -- df -h /                           // HDD

lxc config set <cname> limits.cpu 2         // только 2 CPU
lxc config set <cname> limits.cpu 1,3       // конкретные ядра
lxc config set <cname> limits.cpu 0-3,7-11  // диаппазон ядер

lxc profile set <pname> limits.cpu 3

lxc config set <cname> limits.memory 256MB
lxc config set <cname> limits.memory.swap false       // отключить swap для контейнера (включён по умолчанию)
lxc config set <cname> limits.memory.swap.priority 0  // приоритет на вытеснение памяти в swap

lxc config device set <cname> root size 20GB
lxc config device set <cname> limits.read 30MB
lxc config device set my-container limits.write 10MB
lxc config device set my-container limits.read 20Iops
lxc config device set my-container limits.write 10Iops


// --------------------------
//  Конфигурация LXD
// --------------------------
/var/lib/lxd/unix.socket

// Сетевая конфигурация
lxc config set core.https_address [::]          // предписывает LXD привязаться (bind) на все сетевые интерфейсы данной машины
lxc config set core.trust_password <password>   // устанавливает пароль, который используется удалёнными клиентами при добавлении себя в хранилище доверенных сертификатов LXD (certificate trust store)

// Конфигурация прокси
lxc config set core.proxy_http http://squid01.internal:3128
lxc config set core.proxy_https http://squid01.internal:3128
lxc config set core.proxy_ignore_hosts image-server.local

// Управление образами
lxc config set images.remote_cache_expiry 5      // образ удаляется из кеша через 5 дней
lxc config set images.auto_update_interval 24    // поиск новых образов каждые 24 часа
lxc config set images.auto_update_cached false   // обновлять образы только при указании флага --auto-update, без автоматического обновления кэшированных образов


// --------------------------
//  Конфигурация контейнера
// --------------------------

// поддерживаемые устройства
disk         Физический диск или раздел, который может быть смонтирован внутри контейнера
nic          Сетевой интерфейс. Это может быть виртуальный сетевой интерфейс типа bridge, устройство point-to-point, сетевое устройство macvlan или физический интерфейс, который пробросили в контейнер
unix-block   Блочное UNIX устройство типа /dev/sda
unix-char    Символьное UNIX устройство типа /dev/kvm
none         Специальный тип для скрытия устройства, которое иначе могло быть унаследовано через профили

// ----------------------------------

  Remotes
local          по умолчанию связь с локальным LXD демоном через unix сокет
ubuntu         сервер со стабильными образами Ubuntu
ubuntu-daily   сервер с дневными сборками Ubuntu
images         сервер images.linuxcontainers.org

  Security
Kernel namespaces   LXD использует по умолчанию более безопасное пользовательское пространство имён (user namespace) в отличии от LXC (Непривилегированные контейнеры). Это позволяет гарантировать изоляцию действий в контейнере от системы-хоста
Seccomp             Фильтры для потенциально опасных системных вызовов
AppArmor            Дополнительные ограничения для mount, сокетов, ptrace и доступ к файлам. Ограничение межконтейнерного взаимодействия
Capabilities        Предотвращение загрузки модулей ядра, изменение времени хост-системы и т.д.
CGroups             Ограничение использования ресурсов и защита хоста от DoS из контейнера


// --------------------------
//  Client - Server
// --------------------------
  сервер
lxc config set core.https_address [::]:8443
lxc config set core.trust_password <password>
  клиент
lxc config set core.https_address [::]:8443
lxc remote add foo <server_ip>

lxc remote list
lxc remote get-default

lxc launch <server>:my-image <server>:c2   // запуск контейнера на сервере
lxc copy <server>:<c1> <c2>                // копия контейнера с сервера. С1 должен быть остановлен
lxc snapshot <server>:<c1> <c2>            // нимок контейнера с сервера. С1 не требует остановки
lxc stop <server>:<c1>  &&  lxc move <server>:<c1> <c1>  // перемещение контейнера с сервера


// --------------------------
//  Литература
// --------------------------
vasilisc.com/lxd-2-0-series


// ----------------------------------
// ----------------------------------
// ----------------------------------
