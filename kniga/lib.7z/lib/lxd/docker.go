
http://vasilisc.com/lxd-2-0-docker-in-lxd

// ----------------------------------
Только хранилище типа 'overlayfs' работает с 'Docker' в режиме 'namespace'
// ----------------------------------

// подготовка
lxc launch ubuntu-daily:16.04 docker -p default -p docker  // профили default и docker
lxc exec docker -- apt update
lxc exec docker -- apt dist-upgrade -y
lxc exec docker -- apt install docker.io -y
lxc config set docker security.privileged true && lxc restart docker  // привилегированный контейнер ( root host = root cont )

// запуск Docker контейнера
lxc exec docker -- docker run --detach --name app carinamarina/hello-world-app
lxc exec docker -- docker run --detach --name web --link app:helloapp -p 80:5000 carinamarina/hello-world-web
lxc list

