#!/bin/bash

| sort -rn | uniq -c | sort -rn   <- сортировка выходных строк с подсчетом повторений


getconf ARG_MAX         <- максимальное количество аргументов
lsof -a -p $$ -d 0,1,2  <- список дескрипторов текущего процесса
cat /dev/null > file    <- чистка файла


# ============
# переменные среды
# ============
$HOME
$REPLY   <- read -p "Enter name: "


# ============
# пользовательские переменные
# ============
mydir=$(pwd)
a1=$(( 5 + 5 ))
a2=$(( $a1 * 2 ))
a3=$[ $a1 - $a2 ]


# ============
# ввод
# ============
exec 0< file

echo -n "Enter name: "
read name

read -p "Enter name: " first last

## ./sh -a -b
while [ -n "$1" ]
do
  case "$1" in
   -a) echo "Found -a option" ;;
    *) echo "$1 is not an option" ;;
  esac
  shift
done


## ./sh -a -b -- 5 10
while [ -n "$1" ]
do
  case "$1" in
    -a) echo "Found the -a option" ;;
    --) shift
      break ;;
    *) echo "$1 is not an option";;
  esac
  shift
done
count=1
for param in $@
do
  echo "Parameter #$count: $param"
  count=$(( $count + 1 ))
done


## ./sh -a -b 15 -d
while [ -n "$1" ]
do
  case "$1" in
    -a) echo "Found the -a option";;
    -b) param="$2"z
      echo "Found the -b option, with parameter value $param"
      shift ;;
    --) shift
      break ;;
    *) echo "$1 is not an option";;
  esac
  shift
done
count=1
for param in "$@"
do
  echo "Parameter #$count: $param"
  count=$(( $count + 1 ))
done


##
exec 6<&0
exec 0< myfile
  while read line
    ...
exec 0<&6


# ============
# вывод
# ============
echo "Number is $a"
echo $#     <- кол-во переданых параметров
echo ${!#}  <- последний переданный параметр
echo "$*"   <- "1 2 3"
echo "$@"   <- ["1", "2", "3"] 

exec 3> file
echo "text" >&3
exec 3>&-


# ============
# err
# ============
ls –l myfile xfile afile 1> correctcontent 2> errorcontent
ls –l myfile xfile afile &> content
ls -al badfile 2> /dev/null    <- подавление вывода

echo "error" >&2   <- ./sh 2> erfile

exec 2>erfile
echo "error" >&2


# ============
# конструкции
# ============
if команда
then
  команды
elif команда2
  команды
else
  команды
fi

if [ -n "$1" ]           <- наличие переданного параметра
if [ $a -gt 5 ] && [ $a -lt 10 ]
if [ $srt1 \> "$str2" ]
if [ $srt = $USER ]
if [ -d $dir ]
if [ -d "$file" ]        <- "" тк может содержать пробелы


# Сравнение чисел
# ------------
n1 -eq n2   n1 == n2
n1 -ge n2   n1 >= n2
n1 -gt n2   n1 >  n2
n1 -le n2   n1 <= n2
n1 -lt n2   n1 <  n2
n1 -ne n2   n1 != n2


# Сравнение строк
# ------------
str1 =  str2   идентичны
str1 != str2   не идентичны
str1 <  str2   str1 меньше str2
str1 >  str2   str1 больше str2.
-n str1        длина str1 больше нуля
-z str1        длина str1 равна нулю


# Проверки файлов
# ------------
-d file  существует ли файл, и является ли он директорией
-e file  существует ли файл
-f file  существует ли файл, и является ли он файлом
-r file  существует ли файл, и доступен ли он для чтения
-s file  существует ли файл, и не является ли он пустым
-w file  существует ли файл, и доступен ли он для записи
-x file  существует ли файл, и является ли он исполняемым
file1 -nt file2  новее ли file1, чем file2
file1 -ot file2  старше ли file1, чем file2
-O file  существует ли файл, и является ли его владельцем текущий пользователь
-G file  существует ли файл, и соответствует ли его идентификатор группы идентификатору группы текущего пользователя


# ============
# циклы
# ============
IFS=$'\n'    <- разделитель полей <- построчный вывод
IFS=:

break
continue


for var in list
do
  команды
done

for item in "$@"                <- перебор переданных параметров
for item in $(cat /etc/passwd)
for (( a = 1; a < 10; a++ ))


while команда проверки условия
do
  другие команды
done

while [ $a1 -lt 10 ]


# ============
# функции
# ============
function myfunc {
  read -p "Enter a value: " value
  local b = $[ $value + 5 ]       <- локальная переменная
  echo $(( $value + 10 ))
}
a1=$(myfunc)

# array
function myfunc {
  local newarray = ("$@")
  echo "The new array value is: ${newarray[*]}"
}
myarray=(1 2 3 4 5)
echo "The original array is ${myarray[*]}"
myfunc ${myarray[*]}


# ============
# сигналы
# ============
1  SIGHUP   Закрытие терминала
2  SIGINT   Сигнал  остановки процесса пользователем с терминала (CTRL + C)
3  SIGQUIT  Сигнал  остановки процесса пользователем с терминала (CTRL + \) сдампом памяти
9  SIGKILL  Безусловное завершение процесса
15 SIGTERM  Сигнал  запроса завершения процесса
17 SIGSTOP  Принудительная приостановка выполнения процесса, но не завершение его работы
18 SIGTSTP  Приостановка процесса с терминала (CTRL + Z), но не завершение работы
19 SIGCONT  Продолжение выполнения ранее остановленного процесса

trap "echo 'Ctrl-C is trapped'" SIGINT
trap -- SIGINT


# ============
# фон & планировщик
# ============
./sh &
nohup ./sh &
bg 2001   <- перезапуск задания в фоновом режиме
fg 2001   <- перезапуск в обычном режиме

at -f ./sh now  <- MM/DD/YY | 10:15 | now, noon, midnight | now + 25 minutes
atq       <- список заданий, ожидающих выполнение
atrm 18   <- удаление указанного задания

crontab –l  <- таблица заданий cron / минута, час, день месяца, месяц, день недели


# ============
# sed
# ============
s/pattern/replacement/flags
 | flags
 | num    - порядковый номер вхождения шаблона в строку
 | g      - все вхождения шаблона
 | p      - нужно вывести содержимое исходной строки
 | w file - записать результаты обработки текста в файл
sed    's/t2/t2' ./file
sed -e 's/t1/t2/g; s/t10/t20/g' ./file      <- несколько комманд
sed -f commandsfile textfile                <- комманды из файла
sed    's!/bin/bash!/bin/csh!' /etc/passwd
sed   '2s/t1/t2/' file         <- 2 строка файла
sed '2,3s/t1/t2/' file         <- с 2 по 3 строки файла
sed '2,3s/t1/t2/' file         <- с 2 строки и до конца
sed '/шаблон/s/t1/t2/' ./file  <- только строки соответствующие шаблону

sed 'd'    file        <- удалить все строки
sed '3d'   file        <- удаление 3 строки
sed '3,$d' file        <- удалить с 3 и до конца
sed '/шаблон/d'  file  <- удалить строки соотв шаблону
sed '/ш1/,/ш2/d' file  <- удалить строки с шаблоками ш1, ш2 и строки между ними

sed '3r newfile' file  <- вставка newfile в file полсе 3 строки
sed '/шаблон/ {r newfile d}' file  <- вставить вместо шаблона содержимое файла newfile
sed '2i\t1' file       <- вставка t1 до 2 строчки
sed '2a\t1' file       <- вставка t1 после 2 строчки
sed '2c\t1' file       <- замена 2 строки на t1
sed -n '/шаблон/=' myfile  <- номера строк, соотв шаблону


# ============
# awk
# ============
awk options program file

-F fs        — позволяет указать символ-разделитель для полей в записи
-f file      — указывает имя файла, из которого нужно прочесть awk-скрипт
-v var=value — позволяет объявить переменную и задать её значение по умолчанию, которое будет использовать awk
-mf N        — задаёт максимальное число полей для обработки в файле данных
-mr N        — задаёт максимальный размер записи в файле данных
-W keyword   — позволяет задать режим совместимости или уровень выдачи предупреждений awk

FS  — символ-разделитель полей
RS  — символ-разделитель записей
OFS — разделитель полей на выводе awk-скрипта
ORS — разделитель записей на выводе awk-скрипта

ARGC       — количество аргументов командной строки
ARGV       — массив с аргументами командной строки
ARGIND     — индекс текущего обрабатываемого файла в массиве ARGV
ENVIRON    — ассоциативный массив с переменными окружения и их значениями
ERRNO      — код системной ошибки, которая может возникнуть при чтении или закрытии входных файлов
FILENAME   — имя входного файла с данными
FNR        — номер текущей записи в файле данных
IGNORECASE — если эта переменная установлена в ненулевое значение, при обработке игнорируется регистр символов
NF         — общее число полей данных в текущей записи
NR         — общее число обработанных записей

awk -F: '{print $1}' /etc/passwd
awk 'BEGIN {print "..."} {print $0} END {print "..."}' file
awk 'BEGIN{FS=":"; OFS="-"} {print $1,$6,$NF}' /etc/passwd
awk 'BEGIN{print ENVIRON["HOME"]}'
echo | awk -v home=$HOME '{print home}'
awk 'BEGIN{test="..." print test}'




Bash и кибербезопасность
  https://www.piter.com/collection/bezopasnost/product/bash-i-kiberbezopasnost-ataka-zaschita-i-analiz-iz-komandnoy-stroki-linux
