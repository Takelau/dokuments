
// --------------------------------
// запись в файл  &&  посимвольное чтение
#include <stdio.h>
#include <stdlib.h>
int main(void) {
	const char* fname = "/tmp/unique_name.txt"; // or tmpnam(NULL);
	FILE* fp = fopen(fname, "w+");
	if(!fp) { return EXIT_FAILURE;; }
	fputs("Hello, world!\n", fp);
	rewind(fp);
 
	int c; // note: int, not char, required to handle EOF
	while ((c = fgetc(fp)) != EOF) { // standard C I/O file reading loop
		putchar(c);
	}

	if (ferror(fp)) {    puts("I/O error when reading"); }
	else if (feof(fp)) { puts("End of file reached successfully"); }
 
	fclose(fp);
	remove(fname);
	return EXIT_SUCCESS;
}