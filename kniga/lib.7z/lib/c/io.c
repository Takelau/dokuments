
FILE* fopen(const char *pathname, const char *mode);
FILE* fdopen(int fd, const char *mode);
FILE* freopen(const char *pathname, const char *mode, FILE *stream);


// --------------------------------
//    In-Out
// --------------------------------
// Библиотеки
stdio.h
wchar.h

// string
int puts(const char *str)                 // вывод str+'\n' в stdout
int putc(int ch, FILE *stream)            // вывод 'ch' в stream
int putchar(int ch)                       // вывод 'ch' в stdout

wint_t putwc(wchar_t ch, FILE *stream);   // вывод 'ch' в stream
wint_t putwchar(wchar_t ch);              // вывод 'ch' в stdout

// stream
int fputs(const char *restrict str, FILE *restrict stream)
int fputc(int ch, FILE *stream)
int fgetc(FILE *stream)        // читает следующий символ из переданного потока

int fputws(const wchar_t *restrict str, FILE *restrict stream);
wint_t fputwc(wchar_t ch, FILE *stream);

// file
FILE *fopen(const char *restrict filename, const char *restrict mode);
errno_t fopen_s(FILE *restrict *restrict streamptr, const char *restrict filename, const char *restrict mode);
int fclose( FILE *stream );

// file access 
"r"    read from start   | failure to open
"w"    destroy contents  | create new
"a"    write to end      | create new
"r+"   read/write        | error
"w+"   read/write        | create new 
"a+"   read/write        | create new 
"b"    binary mode
"x"    "xw", "xw+"       | to fail if the file exists

/*
int open(const char *name, int flags)               // {O_RDONLY, O_WRONLY, O_RDWR}
int open(const char *name, int flags, mode_t mode)
int creat(const char *name, mode_t mode)
int fclose(FILE *stream)
// flags
O_APPEND    // Файл будет открыт в режиме дозаписи
O_ASYNC     // создает сигнал (SIGIO), когда указанный файл станет доступным для чтения или записи 
O_CLOEXEC   // задает флаг 'close-on-exec' для открытого файла
O_CREAT     // создает файл, если отсутствует
O_DIRECT    // открывает файл для непосредственного ввода­вывода
O_DIRECTORY // выдает ошибку, если файл не является каталогом
O_EXCL      // +O_CREAT возвращает ошибку, если файл уже откпыт. Предотвращает гонку
O_LARGEFILE // для файлов > 2 Гбайт
O_NOATIME+  // последнее значение времени доступа к файлу не обновляется при его чтении -> исп при копировании
O_NOCTTY    // если файл с именем 'name' указывает на терминальное устройство (/dev/tty), это устройство не получает контроля над процессом
O_NOFOLLOW  // ошибка, если 'name' это символьная ссылка
O_NONBLOCK  // если это возможно, файл будет открыт в неблокирующем режиме. Такое поведение может быть определено лишь для FIFO
O_SYNC      // файл будет открыт для синхронного ввода­вывода. Никакие операции записи не завершатся, пока данные физически не окажутся на диске
O_TRUNC     // если файл уже существует, является обычным файлом и заданные для него флаги допускают запись, то файл будет усечен до нулевой длины
// mode
S_IRWXU  // владелец имеет право на чтение, запись и исполнение файла
S_IRUSR  // владелец имеет право на чтение
S_IWUSR  // владелец имеет право на запись
S_IXUSR  // владелец имеет право на исполнение
S_IRWXG  // владеющая группа имеет право на чтение, запись и исполнение файла
S_IRGRP  // владеющая группа имеет право на чтение
S_IWGRP  // владеющая группа имеет право на запись
S_IXGRP  // владеющая группа имеет право на исполнение
S_IRWXO  // любой пользователь имеет право на чтение, запись и исполнение файла
S_IROTH  // любой пользователь имеет право на чтение
S_IWOTH  // любой пользователь имеет право на запись
S_IXOTH  // любой пользователь имеет право на исполнение
*/

ssize_t read(int fd, void *buf, size_t len);  // ssize_t{SSIZE_MAX}, size_t{SIZE_MAX}
  n==0                   // EOF
  0 < n < len            // возможно процесс был прерван сигналом. Требуется повторный вызов
  –1 errno==EINTR        // Это означает, что сигнал был получен прежде, чем были считаны какие­либо байты. Вызов будет повторен
  –1 errno==EAGAIN       // Это означает, что вызов блокировался потому, что в настоящий момент нет доступных данных, и запрос следует повторить позже. Это происходит только в неблокирующем режиме
  –1 errno!=EINTR|EAGAIN // Это означает более серьезную ошибку. Простое повторение вызова в дан­ном случае, скорее всего, не поможет
ssize_t write(int fd, const void *buf, size_t count);


// --------------------------------
//    Read
// --------------------------------
// 
#include <stdio.h>
#include <stdlib.h>
 
int main(void) {
	int is_ok = EXIT_FAILURE;
	const char* fname = "/tmp/unique_name.txt";  // or tmpnam(NULL);
	FILE* fp = fopen(fname, "w+");
	if(!fp) { perror("File opening failed");  return is_ok; }
	rewind(fp);
 
	int c;                            // note: int, not char, required to handle EOF
	while ((c = fgetc(fp)) != EOF) {  // standard C I/O file reading loop
		putchar(c);
	}
 
	if (ferror(fp)) {       puts("I/O error when reading");
	} else if (feof(fp)) {  puts("End of file reached successfully");
		is_ok = EXIT_SUCCESS;
	}
 
	fclose(fp);
	remove(fname);
	return is_ok;
}

// --------------------------------
// print mem maps
#include <stdio.h> // для функции printf
#include <stdlib.h> // для функций по работе с кучей из библиотеки C
void print_mem_maps() {
	#ifdef __linux__
	FILE* fd = fopen("/proc/self/maps", "r");
	if (!fd) { printf("Could not open maps file.\n"); exit(1); }
	char line[1024];
	while (!feof(fd)) {
		fgets(line, 1024, fd);
		printf("> %s", line);
	}
	fclose(fd);
	#endif
}

int main(int argc, char** argv) {
	char* ptr = (char*)malloc(10 * sizeof(char));  // выделяем 10 байт без инициализации
	for (int i = 0; i < 10; i++) {
		printf("0x%02x ", (unsigned char)ptr[i]);    // 0x00 0x00 0x00 0x00
	}
	print_mem_maps();
	free(ptr);
	return 0;
}


// --------------------------------
//    Wreate
// --------------------------------



// --------------------------------
//    Функционал
// --------------------------------
// побайтовый вывод любых данных / void* + sizeof
void print_bytes(void* data, size_t length) {
	unsigned char* ptr = data;         // длина одного шага типа "char" равна 1 байту
	for (size_t i = 0; i < length; i++) {
		printf("0x%x", *ptr);
		ptr++;
	}
}
int main(int argc, char** argv) {
	int a = 9;
	print_bytes(&a, sizeof(int));
}
