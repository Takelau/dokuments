
// --------------------------------
//    Компиляция
// --------------------------------
gcc -Wall -Wextra -O2 -g -o <name> <name>.c
  -std=c18   // стандарт языка {c89, c90, c99, c11, c17, c18 и c2x}
  -E         // создает единицу трансляции (компиляции)
  -S         // компиляция в ассемблерный код, рассчитанный на целевую архитектуру
  -c         // (E+S) создание объектного файла из исходника
  -g         // дополнительная отладочная информация, используется совместно с gdb
  -Werror    // считать ошибками любые предупреждения
  -lpthread  // pthread

//
gcc -E <name>.c   -> <name>.s // единица трансляции (компиляции)
gcc -S <name>.c   -> <name>.s // компиляция в ассемблерный код
gcc -c <name>.c -o <name>.o   // объектный файл
gcc [<name>.o]                // компановка
gcc [<name>.o] -o ex3_1.out

nm <name>.o            // вывод символов объектного файла
readelf -s <name>.o    // таблица символов
readelf -hSl <name>.o  // содержимое исполняемого объектного файла
objdump -d <name>.o    // символы и их машинные инструкции из объектного файла


// --------------------------------
//    Отладка
// --------------------------------
gcc -g <name>.c -o <name>.out
gdb <name>.out
(gdb) break main
(gdb) run             // r
(gdb) next            // n
(gdb) x/4b <name>     // выводит 4 байта, хранящиеся на том участке, куда указывает <name>
(gdb) set <m>[1]='A'  // модификация ячейки памяти
(gdb) print <m>       // вывод
(gdb) continue        // возобновление выполнения процесса в gdb
(gdb) quit            // q


// --------------------------------
// 1. статическая библиотека (129)
// Компиляция исходников в соответствующие переносимые объектные файлы
gcc -c trigon.c -o trigon.o  
gcc -c 2d.c     -o 2d.o
gcc -c 3d.c     -o 3d.o
ar crs libgeometry.a trigon.o 2d.o 3d.o               // Создание статической библиотеки
mkdir -p /opt/geometry
mv libgeometry.a /opt/geometry                        // ar t /opt/geometry/libgeometry.a
gcc -c main.c -o main.o                               // компиляция исполняемого переносимого объектнго файла
gcc main.o -L/opt/geometry -lgeometry -lm -o ex.out   // Компоновка со статической библиотекой

// --------------------------------
// 2. динамическая библиотека (138)
// 2.1 Компиляция исходников в соответствующие позиционно независимые переносимые объектные файлы
gcc -c trigon.c  -fPIC  -o trigon.o                   // position independent code (позиционно независимый код)
gcc -c 2d.c      -fPIC  -o 2d.o
gcc -c 3d.c      -fPIC  -o 3d.o

// 2.2.1 автоматическая загрузка
gcc -shared 2d.o 3d.o trigon.o -o libgeometry.so      // Создание динамической библиотеки из переносимых объектных файлов
mkdir -p /opt/geometry
mv libgeometry.so /opt/geometry
gcc -c main.c -o main.o
gcc main.o -L/opt/geometry -lgeometry -lm -o ex.out   // lm - библиотека libm.a (cos, sin, acos)
export LD_LIBRARY_PATH=/opt/geometry                  // <--
./ex.out

// 2.2.2 ручная загрузка
gcc -shared 2d.o 3d.o trigon.o -lm -o libgeometry.so  // -lm libm.so стандартная математическая библиотека
// main.c (143)
#include <stdio.h>
#include <stdlib.h>
#include "geometry.h"
polar_pos_2d_t (*func_ptr)(cartesian_pos_2d_t*);
void* handle = dlopen ("/opt/geometry/libgeometry.so", RTLD_LAZY);
	if (!handle) {
	fprintf(stderr, "%s\n", dlerror());
	exit(1);
}
func_ptr = dlsym(handle, "convert_to_2d_polar_pos");  // возвращает указатель, с помощью которого можно вызвать нужную функцию
if (!func_ptr) {
	fprintf(stderr, "%s\n", dlerror());
	exit(1);
}
cartesian_pos_2d_t cartesian_pos;
cartesian_pos.x = 100;
cartesian_pos.y = 200;
polar_pos_2d_t polar_pos = func_ptr(&cartesian_pos);
printf("Polar Position: Length: %f, Theta: %f (deg)\n", polar_pos.length, polar_pos.theta);
return 0;

gcc main.c -ldl -o ex.out
