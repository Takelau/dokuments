

// --------------------------------
//    Valgrind
// --------------------------------
valgrind --xtree-memory=full --xtree-memory-file=xtmemory.kcg <prog>
