
// --------------------------------
//    Начало
// --------------------------------
// аргументы
int main(int argc, char** argv) {
	if (argc < 3) { exit(1); }
	if (strcmp(argv[1], "-n") != 0) { ... }
	return EXIT_SUCCESS;
}


// --------------------------------
//    Заголовок
// --------------------------------
#ifndef AVG_2_1_H
#define AVG_2_1_H typedef enum {
	NONE,
	NORMAL,
	SQUARED
} average_type_t;
double avg(int*, int, average_type_t);  // объявление функции
#endif


// --------------------------------
//    Указатели на функции
// --------------------------------
#include <stdio.h>
int sum(int a, int b) {      return a + b; }
int subtract(int a, int b) { return a - b; }
int main() {
	int (*func_ptr)(int, int);    // <-- указатель на функцию соответствующей сигнатуры
	func_ptr = NULL;
	func_ptr = &sum;
	int result = func_ptr(5, 4);
	printf("Sum: %d\n", result);

	func_ptr = &subtract;
	result = func_ptr(5, 4);
	printf("Subtract: %d\n", result);
	return 0;
}

// --------------------------------
#include <stdio.h>
typedef int bool_t;
typedef bool_t (*less_than_func_t)(int, int);  // <-- псевдоним типа
bool_t less_than(int a, int b) {         return a < b ? 1 : 0; }
bool_t less_than_modular(int a, int b) { return (a % 5) < (b % 5) ? 1 : 0; }
int main(int argc, char** argv) {
	less_than_func_t func_ptr = NULL;  // <--

	func_ptr = &less_than;
	bool_t result = func_ptr(3, 7);    // printf("%d\n", result);

	func_ptr = &less_than_modular;
	result = func_ptr(3, 7);           // printf("%d\n", result);
	return 0;
}


// --------------------------------
//    Структуры
// --------------------------------
// машинное слово в 64-битных системах занимает 32 бита или 4 байта
struct sample_t {
	char first;
	char second;
};

void print_size(struct sample_t* var) {
	printf("Size: %lu bytes\n", sizeof(*var));
}

void print_bytes(struct sample_t* var) {
	unsigned char* ptr = (unsigned char*)var;
	for (int i = 0; i < sizeof(*var); i++, ptr++) {
		printf("%d ", (unsigned int)*ptr);
	}
	printf("\n");
}

struct sample_t var;
var.first = 'A';
print_size(&var);

// --------------------------------
// вложенные структуры на основе псевдонимов структур
typedef struct {
	int x;
	int y;
} point_t;

typedef struct {
	point_t center;
	int     radius;
} circle_t;

circle_t с;
circle_t* p1 = &c;            // 0x7ffee846c8e0
point_t*  p2 = (point_t*)&c;  // 0x7ffee846c8e0
int*      p3 = (int*)&c;      // 0x7ffee846c8e0

// --------------------------------
// упакованная структура / не выровненная - занимает меньше памяти, но снижает быстровдействие и может привести к двоичной не совместимости
struct __attribute__((__packed__)) sample_t {
	char first;
};

// --------------------------------
// анонимные структуры
typedef struct {
	union {
		struct {
			int x;
			int y;
		};
		int data[2];
	};
} point_t;

point_t p;
p.x = 10;        printf("%d, %d)\n", p.x, p.y);              // (10, -5)
p.data[1] = -5;  printf("%d, %d)\n", p.data[0], p.data[1]);  // (10, -5)

