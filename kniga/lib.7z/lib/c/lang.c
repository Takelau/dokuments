
// --------------------------------
//    Языковая поддержка
// --------------------------------
#include <Windows.h>
main() {
	SetConsoleCP(1251);         // c++
	SetConsoleOutputCP(1251);   // c++
}

// --------------------------------
setlocale(LC_ALL, "Russian");


