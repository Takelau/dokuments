
// --------------------------------
//    Макрос
// --------------------------------
// директива препроцессора
#include <...>
#define      // определение макроса
#undef       // делает макрос неопределенным
__VA_ARGS__  // переменное число аргументов
NULL

EXIT_SUCCESS  0  // stdlib.h
EXIT_FAILURE
EOF

// условная компиляция
#ifdef
#ifndef       // предотвращение дублирования заголовков
#else
#elif
#endif
#pragma once  // === #ifndef-#endif

// --------------------------------
#ifndef EXAMPLE_1_8_H
#define EXAMPLE_1_8_H
...
#endif

// --------------------------------
#define	ABC 5              // определение макроса
#define ADD(a, b) a + b    // функциональный макрос
int main(int argc, char** argv) {
	int x = 2;
	int y = ABC;
	int z = ADD(x, y);
	return 0;
}

// --------------------------------
#include <stdio.h>
#define file 1000

// --------------------------------
#include <stdio.h>
#define PRINT(a) printf("%d\n", a);
#define LOOP(v, s, e) for (int v = s; v <= e; v++) {
#define ENDLOOP }
int main(int argc, char** argv) {
	LOOP(counter, 1, 10)   // for (int counter = 1; counter <= 10; counter++) {
		PRINT(counter)       //   printf("%d\n", counter);
	ENDLOOP                // }
	return 0;
}

// --------------------------------
#include <stdio.h>
#include <string.h>
#define CMD(NAME) char NAME ## _cmd[256] = "";  strcpy(NAME ## _cmd, #NAME);
int main(int argc, char** argv) {
	CMD(copy)      // char copy_cmd[256] = "";  strcpy(copy_cmd, "copy");
	CMD(paste)     // char paste_cmd[256] = ""; strcpy(paste_cmd, "paste");
	CMD(cut)       // char cut_cmd[256] = "";   strcpy(cut_cmd, "cut");
	char cmd[256];
	scanf("%s", cmd);
	if (strcmp(cmd, copy_cmd) == 0) {...}
	return 0;
}

// --------------------------------
// переменное число аргументов
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LOG_ERROR(format, ...) fprintf(stderr, format, __VA_ARGS__)
int main(int argc, char** argv) {
	if (argc < 3) {
		LOG_ERROR("Invalid number of arguments for version %s\n.", "abc");
		exit(1);
	}
	if (strcmp(argv[1], "-n") != 0) {
		LOG_ERROR("%s is a wrong param at index %d for version %s.", argv[1], 1, "abc");
		exit(1);
	}
	return 0;
}

// --------------------------------
// версия C
#include <stdio.h>
int main(int argc, char** argv) {
	#if   __STDC_VERSION__ >= 201710L   printf("C18!\n");
	#elif __STDC_VERSION__ >= 201112L   printf("C11!\n");
	#elif __STDC_VERSION__ >= 199901L   printf("C99!\n");
	#else                               printf("C89/C90!\n");
	#endif
	return 0;
}

// --------------------------------
// обобщенные типы
#define abs(x) _Generic((x), int:absi, double:absd)(x)

int    absi(int a) {    return a > 0 ? a : -a; }
double absd(double a) { return a > 0 ? a : -a; }

int main(int argc, char** argv) {
	printf("abs(-2): %d\n",  abs(-2));
	printf("abs(2.5): %f\n", abs(2.5));
	return 0;
}