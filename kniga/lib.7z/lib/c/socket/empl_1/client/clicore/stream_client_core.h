#ifndef STREAM_CLIENT_CORE_H
#define STREAM_CLIENT_CORE_H

void stream_client_loop(int conn_sd);

#endif
