
// --------------------------------
//    Streem
// --------------------------------

// TCP Streem
int server_sd = socket(AF_INET, SOCK_STREAM, 0);    struct sockaddr_in addr;
// TCP Datagram
int server_sd = socket(AF_INET, SOCK_DGRAM, 0);     struct sockaddr_in addr;
// UDS Streem
int server_sd = socket(AF_UNIX, SOCK_STREAM, 0);    struct sockaddr_un addr;
// UDS Datagram
int server_sd = socket(AF_UNIX, SOCK_DGRAM, 0);     struct sockaddr_un addr;


// --------------------------------
//    NetLink
// --------------------------------
socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE)    // https://habr.com/ru/articles/121254/    https://mdlayher.com/blog/linux-netlink-and-go-part-1-netlink/
NETLINK_ROUTE           // позволяет получать уведомления об изменениях таблицы маршрутизации и сетевых интерфейсов
NETLINK_USERSOCK        // зарезервировано для определения пользовательских протоколов
NETLINK_FIREWALL        // служит для передачи IPv4 пакетов из сетевого фильтра на пользовательский уровень
NETLINK_INET_DIAG       // мониторинг inet сокетов
NETLINK_NFLOG           // ULOG сетевого/пакетного фильтра
NETLINK_SELINUX         // получать уведомления от системы Selinux
NETLINK_NETFILTER       // работа с подсистемой сетевого фильтра
NETLINK_KOBJECT_UEVENT  // получение сообщений ядра


// --------------------------------
//    Streem UDS (Unix)
// --------------------------------
// Server
void stream_write_resp(struct client_context_t* context, struct calc_proto_resp_t* resp) {
	struct buffer_t buf = calc_proto_ser_server_serialize(context->ser, resp);
	int ret = write(context->addr->sd, buf.data, buf.len);
}

void request_callback(void* obj, struct calc_proto_req_t req) {
	struct client_context_t* context = (struct client_context_t*)obj;
	switch (req.method) {
		case ADDM:
      result = calc_service_add(context->svc, req.operand1, req.operand2, req.method == ADDM);
  }
  struct calc_proto_resp_t resp;
  resp.req_id = req.id;
  resp.status = status;
  resp.result = result;
  context->write_resp(context, &resp);  // <-- stream_write_resp()
}

void* client_handler(void *arg) {
	struct client_context_t context;
	// addr
	context.addr = (struct client_addr_t*) malloc(sizeof(struct client_addr_t));
	context.addr->sd = *((int*)arg);
	// proto
	context.ser = calc_proto_ser_new();
  calc_proto_ser_ctor(context.ser, &context, 256);
  calc_proto_ser_set_req_callback(context.ser, request_callback);   // <-- request
  calc_prto_ser_set_error_callback(context.ser, error_callback);
  // service
  context.svc = calc_service_new();
  calc_service_ctor(context.svc);

  context.write_resp = &stream_write_resp;           // <-- response

  char buffer[128];
  while (1) {
  	int ret = read(context.addr->sd, buffer, 128);   // <-- read()
  	struct buffer_t buf;
    buf.data = buffer; buf.len = ret;
  	calc_proto_ser_server_deserialize(context.ser, buf, NULL);  // calc() + request_callback()
  }
}

void accept_forever(int server_sd) {
	while (1) {
		int client_sd = accept(server_sd, NULL, NULL);
		pthread_t client_handler_thread;
    int* arg = (int *)malloc(sizeof(int));
    *arg = client_sd;
    int result = pthread_create(&client_handler_thread, NULL, &client_handler, arg);  // <-- client_handler()
	}
}

// Server main
main() {
	char sock_file[] = "/tmp/calc_svc.sock";
	unlink(sock_file);

	// 1. Create socket object
	int server_sd = socket(AF_UNIX, SOCK_STREAM, 0);

	// Prepare the address
  struct sockaddr_un addr;
  memset(&addr, 0, sizeof(addr));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, sock_file, sizeof(addr.sun_path) - 1);

	// 2. Bind the socket file
	int result = bind(server_sd, (struct sockaddr*)&addr, sizeof(addr));

	// 3. Prepare backlog
	result = listen(server_sd, 10);

	accept_forever(server_sd);
}


// --------------------------------
//    Datagram UDS (Unix)
// --------------------------------
// Server
void datagram_write_resp(struct client_context_t* context, struct calc_proto_resp_t* resp) {
	struct buffer_t buf = calc_proto_ser_server_serialize(context->ser, resp);
	int ret = sendto(context->addr->server_sd, buf.data, buf.len, 0, context->addr->sockaddr, context->addr->socklen);
}

void request_callback(void* obj, struct calc_proto_req_t req) {
	struct client_context_t* context = (struct client_context_t*)obj;
	switch (req.method) {
		case ADDM:
      result = calc_service_add(context->svc, req.operand1, req.operand2, req.method == ADDM);
  }
  struct calc_proto_resp_t resp;
  resp.req_id = req.id;
  resp.status = status;
  resp.result = result;
  context->write_resp(context, &resp);  // <-- datagram_write_resp()
}

void serve_forever(int server_sd) {
  char buffer[64];
  while (1) {
    struct sockaddr* sockaddr = sockaddr_new();
    socklen_t socklen = sockaddr_sizeof();
    int read_nr_bytes = recvfrom(server_sd, buffer, sizeof(buffer), 0, sockaddr, &socklen);

    struct client_context_t context;
    // addr
    context.addr = (struct client_addr_t*) malloc(sizeof(struct client_addr_t));
    context.addr->server_sd = server_sd;
    context.addr->sockaddr = sockaddr;
    context.addr->socklen = socklen;
    // proto
    context.ser = calc_proto_ser_new();
    calc_proto_ser_ctor(context.ser, &context, 256);
    calc_proto_ser_set_req_callback(context.ser, request_callback);   // <-- request
    calc_proto_ser_set_error_callback(context.ser, error_callback);
    // service
    context.svc = calc_service_new();
    calc_service_ctor(context.svc);

    context.write_resp = &datagram_write_resp;                        // <-- response

    bool_t req_found = FALSE;
    struct buffer_t buf;
    buf.data = buffer;
    buf.len = read_nr_bytes;
    calc_proto_ser_server_deserialize(context.ser, buf, &req_found);  // calc() + request_callback()
  }
}

// Server main
struct sockaddr* sockaddr_new() {
  return malloc(sizeof(struct sockaddr_un));
}

socklen_t sockaddr_sizeof() {
  return sizeof(struct sockaddr_un);
}

int main(int argc, char** argv) {
  har sock_file[] = "/tmp/calc_svc.sock";
  unlink(sock_file);

  // 1. Create socket object
  int server_sd = socket(AF_UNIX, SOCK_DGRAM, 0);
  
  // Prepare the address
  struct sockaddr_un addr;
  memset(&addr, 0, sizeof(addr));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, sock_file, sizeof(addr.sun_path) - 1);

  // 2. Bind the socket file
  int result = bind(server_sd, (struct sockaddr*)&addr, sizeof(addr));

  serve_forever(server_sd);
 }


// --------------------------------
//    TCP
// --------------------------------

