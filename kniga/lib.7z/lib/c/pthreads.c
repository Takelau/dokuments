
https://github.com/netsniff-ng/netsniff-ng
https://man7.org/linux/man-pages/index.html

https://man7.org/linux/man-pages/dir_section_8.html
https://man7.org/linux/man-pages/man7/pthreads.7.html

Portscan Attack Detection
https://www.vuurmuur.org/trac/wiki/PSAD
https://www.cipherdyne.com/psad/

// профилировщики
valgrind


// --------------------------------
//    Потоки
// --------------------------------
уровни потоков:
- поток уровня ядра
- поток пользовательского уровня

Native POSIX Threading Library (NPTL) - библиотека потоков POSIX

семафоры - позволяют заходить на критический участок сразу нескольким заданиям
мьютексы - ... одному заданию
условные переменные - используются для организации обмена сигналами между разными заданиями, позволяют перевести задание в спящий режим или оповестить другие задания

ulimit -s        // размер стека потока по умолчанию
volatile int a;  // тключение кеша компилятора для указанной переменной (500)

// --------------------------------
#include <pthread.h>

pthread_t thread;
pthread_create(&thread, NULL, thread_body, NULL);  // k
pthread_join(thread, NULL);                        // k
pthread_detach(thread);
pthread_exit(NULL);

pthread_mutex_t mtx;
pthread_mutex_init(&mtx, NULL);
pthread_mutex_lock(&mtx);      // k lock
pthread_mutex_trylock(&mtx);   // k
pthread_mutex_unlock(&mtx);    // k unlock
pthread_mutex_timedlock(pthread_mutex_t *restrict mutex, const struct timespec *restrict abs_timeout);  // k
pthread_mutex_destroy(&mtx);

pthread_spin_t spn;      // циклическая блокировка (холостой цикл)
pthread_spin_init();
pthread_spin_lock();                            // k
pthread_spin_trylock(pthread_spinlock_t *spn);  // k
pthread_spin_unlock();                          // k
pthread_spin_destroy();

pthread_cond_t cv;
pthread_cond_init(&shared_state->cv, NULL);
pthread_cond_signal(&ss->cv);             // k уведомление одного потока
pthread_cond_broadcast();                 // k уведомление несколких потоков
pthread_cond_wait(&ss->cv, &ss->mtx);     // k
pthread_cond_timedwait(pthread_cond_t *restrict cond, pthread_mutex_t *restrict mutex, const struct timespec *restrict abstime);  // k
pthread_cond_destroy(&shared_state->cv);

pthread_rwlock_rdlock();       // k
pthread_rwlock_timedrdlock();  // k
pthread_rwlock_timedwrlock();  // k
pthread_rwlock_tryrdlock();    // k
pthread_rwlock_trywrlock();    // k
pthread_rwlock_unlock();       // k
pthread_rwlock_wrlock();       // k

pthread_barrier_t barrier;
pthread_barrier_init(&barrier, NULL, 2);  // Инициализируем объект барьера
pthread_barrier_wait(&barrier);           // k
pthread_barrier_destroy(&barrier);

sem_t sem;
sem_init(&sem, 0, 1);  //   двоичный семафор, неименованный
sem_wait(&sem);        // k ждем
sem_trywait(&sem);     // k
sem_timedwait(&sem, const struct timespec *restrict abstime);  // k
sem_post(&sem);        // k освобождаем
sem_destroy(&sem);

PTHREAD_STACK_MIN     // #include <limits.h>

// attr
pthread_attr_t attr;
pthread_attr_init(&attr);
if (pthread_attr_setstack(&attr, buffer, buffer_len)) { exit(2); }

// --------------------------------
int* shared_var_ptr = (int*)arg;
(*shared_var_ptr)++

// --------------------------------
// поток + 
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* thread_body(void* arg) { printf("Hello from first thread!\n"); return NULL; }

int main(int argc, char** argv) {
	pthread_t thread;   // Обработчик потоков
	int result = pthread_create(&thread, NULL, thread_body, NULL);
	if (result) { printf("Thread could not be created. Error number: %d\n", result); exit(1); }
	
	result = pthread_join(thread, NULL);  // Ждем, пока созданный поток не завершит работу
	if (result) { printf("The thread could not be joined. Error number: %d\n", result); exit(2); }
	return 0;
}

gcc <name>.c -o <name>.out -lpthread
valgrind ./<name>.out  (463)

// --------------------------------
// поток -
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* thread_body(void* arg) { printf("Hello from first thread!\n"); return NULL; }

int main(int argc, char** argv) {
	pthread_t thread;
	int result = pthread_create(&thread, NULL, thread_body, NULL);
	if (result) { printf("Thread could not be created. Error number: %d\n", result); exit(1); }
	
	result = pthread_detach(thread);   // Отсоединяем поток
	if (result) { printf("The thread could not be joined. Error number: %d\n", result); exit(2); }

	pthread_exit(NULL);  // Выходим из главного потока
	return 0;
}

// --------------------------------
// циклические блокировки
Concurrent System {
	Shared State {
		Done : Boolean = False
		M : Mutex
	}
	Task P {
		1.1. print 'A'
		1.2. SpinLock(M)
		1.2. Done = True
		1.3. SpinUnlock(M)
	}
	Task Q {
		2.1 SpinLock(M)
		2.2. While Not Done {  // холостой цикл
		2.3.   SpinUnlock(M)   // барьер памяти
		2.4.   SpinLock(M)
		2.5. }
		2.6. SpinUnlock(M)
		2.4. print 'B'
	}
}

// --------------------------------
// условные переменные
Concurrent System {
	Shared State {
		Done : Boolean = False
		CV : Condition Variable
		M : Mutex
	}
	Task P {
		1.1. print 'A'
		1.2. Lock(M)
		1.3. Done = True
		1.4. Notify(CV)
		1.5. Unlock(M)
	}
	Task Q {
		2.1. Lock(M)
		2.2. While Not Done {
		2.3.   Sleep(M, CV)
		2.4. }
		2.5. Unlock(M)
		2.6. print 'B'
	}
}

// --------------------------------
// мьютекс + условная переменная
Concurrent System {
	Shared State {
		Done : Boolean = False
		CV : Condition Variable   // условная переменная
		M : Mutex
	}
	Task P {
		1.1. print 'A'
		1.2. Lock(M)
		1.3. Done = True
		1.4. Notify(CV)
		1.5. Unlock(M)
	}
	Task Q {
		2.1. Lock(M)
		2.2. While Not Done {
		2.3.   Sleep(M, CV)     // монитор
		2.4. }
		2.5. Unlock(M)
		2.6. print 'B'
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define TRUE 1
#define FALSE 0
typedef unsigned int bool_t;

typedef struct {
	bool_t done;          // Флаг, показывающий, был выведен символ 'A' или нет
	pthread_mutex_t mtx;  // Объект мьютекса для защиты критического участка
	pthread_cond_t cv;    // Условная переменная для синхронизации двух потоков
} shared_state_t;
// Инициализирует члены объекта shared_state_t
void shared_state_init(shared_state_t *shared_state) {
	shared_state->done = FALSE;
	pthread_mutex_init(&shared_state->mtx, NULL);
	pthread_cond_init(&shared_state->cv, NULL);
}
// Уничтожает члены объекта shared_state_t
void shared_state_destroy(shared_state_t *shared_state) {
	pthread_mutex_destroy(&shared_state->mtx);
	pthread_cond_destroy(&shared_state->cv);
}
void* thread_body_1(void* arg) {
	shared_state_t* ss = (shared_state_t*)arg;
	pthread_mutex_lock(&ss->mtx);
	printf("A\n");
	ss->done = TRUE;
	pthread_cond_signal(&ss->cv);    // Шлем сигнал потокам, ожидающим условной переменной
	pthread_mutex_unlock(&ss->mtx);
	return NULL;
}
void* thread_body_2(void* arg) {
	shared_state_t* ss = (shared_state_t*)arg;
	pthread_mutex_lock(&ss->mtx);
	while (!ss->done) {
		pthread_cond_wait(&ss->cv, &ss->mtx);   // Ждем условную переменную
	}
	printf("B\n");
	pthread_mutex_unlock(&ss->mtx);
	return NULL;
}
int main(int argc, char** argv) {
	shared_state_t shared_state;       // Разделяемое состояние
	shared_state_init(&shared_state);  // Инициализируем разделяемое состояние
	// Обработчики потоков
	pthread_t thread1;
	pthread_t thread2;
	// Создаем новые потоки
	int result1 = pthread_create(&thread1, NULL, thread_body_1, &shared_state);
	int result2 = pthread_create(&thread2, NULL, thread_body_2, &shared_state);
	if (result1 || result2) { printf("The threads could not be created.\n"); exit(1); }
	// Ждем, пока потоки не завершат работу
	result1 = pthread_join(thread1, NULL);
	result2 = pthread_join(thread2, NULL);
	if (result1 || result2) { printf("The threads could not be joined.\n"); exit(2); }
	// Уничтожаем разделяемое состояние, освобождаем мьютекс и объекты условных переменных
	shared_state_destroy(&shared_state);
	return 0;
}

// --------------------------------
// барьер
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
pthread_barrier_t barrier;         // Объект барьера
void* thread_body_1(void* arg) {
	printf("A\n");
	pthread_barrier_wait(&barrier);  // Ждем присоединения другого потока
	return NULL;
}
void* thread_body_2(void* arg) {
	pthread_barrier_wait(&barrier);  // Ждем присоединения другого потока
	printf("B\n");
	return NULL;
}
int main(int argc, char** argv) {
	pthread_barrier_init(&barrier, NULL, 2);  // Инициализируем объект барьера
	pthread_t thread1;
	pthread_t thread2;
	int result1 = pthread_create(&thread1, NULL, thread_body_1, NULL);
	int result2 = pthread_create(&thread2, NULL, thread_body_2, NULL);
	if (result1 || result2) { printf("The threads could not be created.\n"); exit(1); }
	result1 = pthread_join(thread1, NULL);
	result2 = pthread_join(thread2, NULL);
	if (result1 || result2) { printf("The threads could not be joined.\n"); exit(2); }
	pthread_barrier_destroy(&barrier);        // Уничтожаем объект барьера
	return 0;
}

// --------------------------------
// двоичный семафор
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
sem_t *semaphore;         // указатель на объект семафора, применяемый для синхронизации доступа к разделяемому состоянию
void* thread_body_1(void* arg) {
	int* shared_var_ptr = (int*)arg;
	sem_wait(semaphore);    // Ждем семафор
	(*shared_var_ptr)++;
	printf("%d\n", *shared_var_ptr);
	sem_post(semaphore);    // Освобождаем семафор
	return NULL;
}
void* thread_body_2(void* arg) {
	int* shared_var_ptr = (int*)arg;
	sem_wait(semaphore);    // Ждем семафор
	(*shared_var_ptr) += 2;
	printf("%d\n", *shared_var_ptr);
	sem_post(semaphore);    // Освобождаем семафор
	return NULL;
}
int main(int argc, char** argv) {
	int shared_var = 0;     // Разделяемая переменная
	pthread_t thread1;
	pthread_t thread2;
	sem_t local_semaphore;
	semaphore = &local_semaphore;
	sem_init(semaphore, 0, 1);   // Инициализируем семафор как мьютекс (двоичный семафор)
	int result1 = pthread_create(&thread1, NULL, thread_body_1, &shared_var);
	int result2 = pthread_create(&thread2, NULL, thread_body_2, &shared_var);
	if (result1 || result2) { printf("The threads could not be created.\n"); exit(1); }
	result1 = pthread_join(thread1, NULL);
	result2 = pthread_join(thread2, NULL);
	if (result1 || result2) { printf("The threads could not be joined.\n"); exit(2); }
	sem_destroy(semaphore);
	return 0;
}

// --------------------------------
// семафор общего вида
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>   // For errno and strerror function
#include <pthread.h>
#include <semaphore.h>
pthread_barrier_t water_barrier;   // Барьер для синхронизации потоков водорода и кислорода
pthread_mutex_t oxygen_mutex;      // Мьютекс для синхронизации потоков кислорода
sem_t* hydrogen_sem;               // Общий семафор для синхронизации потоков водорода
unsigned int num_of_water_molecules;  // Разделяемое целое число для подсчета созданных молекул воды

void* hydrogen_thread_body(void* arg) {
	sem_wait(hydrogen_sem);          // На этот критический участок может зайти два потока водорода
	pthread_barrier_wait(&water_barrier);
	sem_post(hydrogen_sem);
	return NULL;
}

void* oxygen_thread_body(void* arg) {
	pthread_mutex_lock(&oxygen_mutex);
	pthread_barrier_wait(&water_barrier);
	num_of_water_molecules++;
	pthread_mutex_unlock(&oxygen_mutex);
	return NULL;
}

int main(int argc, char** argv) {
	num_of_water_molecules = 0;
	// Инициализируем мьютекс кислорода
	pthread_mutex_init(&oxygen_mutex, NULL);    
	// Инициализируем семафор водорода
	sem_t local_sem;
	hydrogen_sem = &local_sem;
	sem_init(hydrogen_sem, 0, 2);               
	// Инициализируем барьер воды
	pthread_barrier_init(&water_barrier, NULL, 3);
	// Чтобы создать 50 молекул воды, нам понадобится 50 атомов кислорода и 100 атомов водорода
	pthread_t thread[150];
	// Создаем потоки кислорода
	for (int i = 0; i < 50; i++) {
		if (pthread_create(thread + i, NULL, oxygen_thread_body, NULL)) { printf("Couldn't create an oxygen thread.\n"); exit(1); }
	}
	// Создаем потоки водорода
	for (int i = 50; i < 150; i++) {
		if (pthread_create(thread + i, NULL, hydrogen_thread_body, NULL)) { printf("Couldn't create an hydrogen thread.\n"); exit(2); }
	}
	printf("Waiting for hydrogen and oxygen atoms to react ...\n");
	// Ждем завершения всех потоков
	for (int i = 0; i < 150; i++) {
		if (pthread_join(thread[i], NULL)) { printf("The thread could not be joined.\n"); exit(3); }
	}
	printf("Number of made water molecules: %d\n", num_of_water_molecules);
	sem_destroy(hydrogen_sem);
	return 0;
}

// --------------------------------
// стек потока в куче (490)
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <pthread.h>

void* thread_body(void* arg) {
	int local_var = 0;
	printf("Thread2 > Stack Address: %p\n", (void*)&local_var);
	return 0;
}

int main(int argc, char** argv) {
	size_t buffer_len = PTHREAD_STACK_MIN + 100;               // минимальный размер стека + 100
	char *buffer = (char*)malloc(buffer_len * sizeof(char));   // Буфер, выделенный из кучи и используемый как стек потока
	// Создаем новый поток с атрибутами по умолчанию
	pthread_t thread;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	// Задаем адрес и размер стека
	if (pthread_attr_setstack(&attr, buffer, buffer_len)) { printf("Failed while setting the stack attributes.\n"); exit(1); }
	int result = pthread_create(&thread, &attr, thread_body, NULL);
	if (result) { printf("The threads could not be created.\n"); exit(2); }
	printf("Main Thread > Heap Address: %p\n", (void*)buffer);
	printf("Main Thread > Stack Address: %p\n", (void*)&buffer_len);
	// Ждем, пока потоки не завершат работу
	result = pthread_join(thread, NULL);
	if (result) { printf("The threads could not be joined.\n"); exit(3); }
	free(buffer);
	return 0;
}
