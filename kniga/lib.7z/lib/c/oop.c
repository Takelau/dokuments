

// --------------------------------
//    ООП
// --------------------------------
// публичная реализация
// .h
typedef struct {
	char   name[32];
	double speed;
	double fuel;
} car_t;
void car_construct(car_t*, const char*);
void car_destruct(car_t*);
void car_accelerate(car_t*);

// .c
#include <string.h>
#include ".h"
void car_construct(car_t* car, const char* name) {
	strcpy(car->name, name);
	car->speed = 0.0;
	car->fuel = 0.0;
}
void car_destruct(car_t* car) {
	...
}
void car_accelerate(car_t* car) {
	car->speed += 0.05;
	car->fuel -= 1.0;
	if (car->fuel < 0.0) {
		car->fuel = 0.0;
	}
}

// --------------------------------
//  приватная реализация
// .h
#include <unistd.h>
struct list_t;
// функция выделения памяти
struct list_t* list_malloc();
// конструктор и деструктор
void list_init(struct list_t*);
void list_destroy(struct list_t*);
// публичные поведенческие функции
int list_add(struct list_t*, int);
int list_get(struct list_t*, int, int*);
void list_clear(struct list_t*);
size_t list_size(struct list_t*);
void list_print(struct list_t*);

// .c
#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 10
// создаем псевдоним bool_t
typedef int bool_t;
// определяем тип list_t
typedef struct {
	size_t size;
	int* items;
} list_t;
// приватное поведение
bool_t __list_is_full(list_t* list) {
	return (list->size == MAX_SIZE);
}
bool_t __check_index(list_t* list, const int index) {
	return (index >= 0 && index <= list->size);
}
// выделяет память для объекта list
list_t* list_malloc() {
	return (list_t*)malloc(sizeof(list_t));
}
// конструктор
void list_init(list_t* list) {
	list->size = 0;
	list->items = (int*)malloc(MAX_SIZE * sizeof(int));
}
// деструктор
void list_destroy(list_t* list) {
	free(list->items);
}
int list_add(list_t* list, const int item) {
	if (__list_is_full(list)) { return -1; }
	list->items[list->size++] = item;
	return 0;
}

// main.c
#include <stdlib.h>
#include ".h"
int main(int argc, char** argv) {
	struct list_t* list1 = list_malloc();
	list_init(list1);
	list_add(list1, 4);
	list_destroy(list1);
	free(list1);
	return 0;
}

// компиляция
gcc -c <name>.c -o private.o
gcc -c main.c   -o main.o
gcc main.o private.o -o <name>.out


// --------------------------------
//    Композиция (247)
// --------------------------------
// car.h
struct car_t;
struct car_t* car_new();        // аллокатор памяти
void car_ctor(struct car_t*);   // конструктор
void car_dtor(struct car_t*);   // деструктор
void car_start(struct car_t*);
void car_stop(struct car_t*);
double car_get_engine_temperature(struct car_t*);

// engine.h
struct engine_t;
struct engine_t* engine_new();           // аллокатор памяти
void engine_ctor(struct engine_t*);      // конструктор
void engine_dtor(struct engine_t*);      // деструктор
void engine_turn_on(struct engine_t*);   // поведенческие функции
void engine_turn_off(struct engine_t*);
double engine_get_temperature(struct engine_t*);

// car.c
#include <stdlib.h>
#include "engine.h"
typedef struct {
	struct engine_t* engine;   // <!-- композиция
} car_t;
// аллокатор памяти
car_t* car_new() {
	return (car_t*)malloc(sizeof(car_t));
}
// конструктор
void car_ctor(car_t* car) {
	car->engine = engine_new();
	engine_ctor(car->engine);
}
// деструктор
void car_dtor(car_t* car) {
	engine_dtor(car->engine);
	free(car->engine);
}
void car_start(car_t* car) {
	engine_turn_on(car->engine);
}
void car_stop(car_t* car) {
	engine_turn_off(car->engine);
}
double car_get_engine_temperature(car_t* car) {
	return engine_get_temperature(car->engine);
}

// engine.c
#include <stdlib.h>
typedef enum {
	ON,
	OFF
} state_t;
typedef struct {
	state_t state;
	double  temperature;
} engine_t;
// аллокатор памяти
engine_t* engine_new() {
	return (engine_t*)malloc(sizeof(engine_t));
}
// конструктор
void engine_ctor(engine_t* engine) {
	engine->state = OFF;
	engine->temperature = 15;
}
// деструктор
void engine_dtor(engine_t* engine) {
	// ...
}
// поведенческие функции
void engine_turn_on(engine_t* engine) {
	if (engine->state == ON) { return; }
	engine->state = ON;
	engine->temperature = 75;
}
void engine_turn_off(engine_t* engine) {
	if (engine->state == OFF) { return; }
	engine->state = OFF;
	engine->temperature = 15;
}
double engine_get_temperature(engine_t* engine) {
	return engine->temperature;
}

// main.c
#include <stdio.h>
#include <stdlib.h>
#include "car.h"
int main(int argc, char** argv) {
	struct car_t *car = car_new();
	car_ctor(car);      printf("Engine temperature before starting the car: %f\n",  car_get_engine_temperature(car));
	car_start(car);     printf("Engine temperature after starting the car: %f\n",   car_get_engine_temperature(car));
	car_stop(car);      printf("Engine temperature after stopping the car: %f\n",   car_get_engine_temperature(car));
	car_dtor(car);   // уничтожаем объект car
	free(car);       // освобождаем память, выделенную для объекта car
	return 0;
}

gcc -c engine.c -o engine.o
gcc -c car.c -o car.o
gcc -c main.c -o main.o
gcc engine.o car.o main.o -o <name>.out
./<name>.out


// --------------------------------
//    Агрегация (253)
// --------------------------------
// gun.h
typedef int bool_t;
struct gun_t;
struct gun_t* gun_new();                // аллокатор памяти
void gun_ctor(struct gun_t*, int);      // конструктор
void gun_dtor(struct gun_t*);           // деструктор
bool_t gun_has_bullets(struct gun_t*);  // поведенческие функции
void gun_trigger(struct gun_t*);
void gun_refill(struct gun_t*);

// player.h
struct player_t;
struct gun_t;                                             // <!-- 
struct player_t* player_new();                            // аллокатор памяти
void player_ctor(struct player_t*, const char*);          // конструктор
void player_dtor(struct player_t*);                       // деструктор
void player_pickup_gun(struct player_t*, struct gun_t*);  // поведенческие функции
void player_shoot(struct player_t*);
void player_drop_gun(struct player_t*);

// player.c
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "gun.h"
// структура атрибутов
typedef struct {
	char* name;
	struct gun_t* gun;   // <!-- при агрегации требует обнуления в конструкторе
} player_t;
// аллокатор памяти
player_t* player_new() {
	return (player_t*)malloc(sizeof(player_t));
}
// конструктор
void player_ctor(player_t* player, const char* name) {
	player->name = (char*)malloc((strlen(name) + 1) * sizeof(char));
	strcpy(player->name, name);
	player->gun = NULL;  // ! Указатели агрегации, которые не должны быть заданы в конструкторе, необходимо обнулить
}
// деструктор
void player_dtor(player_t* player) {
	free(player->name);
}
// поведенческие функции
void player_pickup_gun(player_t* player, struct gun_t* gun) {
	player->gun = gun;   // начало отношений типа «агрегация»
}
void player_shoot(player_t* player) {
	if (player->gun) {
		gun_trigger(player->gun);
	} else {
		printf("Player wants to shoot but he doesn't have a gun!");
		exit(1);
	}
}
void player_drop_gun(player_t* player) {
	player->gun = NULL;    // Завершение агрегации двух объектов
}

// gun.c
#include <stdlib.h>
typedef int bool_t;
typedef struct {
	int bullets;
} gun_t;
// аллокатор памяти
gun_t* gun_new() {
	return (gun_t*)malloc(sizeof(gun_t));
}
// конструктор
void gun_ctor(gun_t* gun, int initial_bullets) {
	gun->bullets = 0;
	if (initial_bullets > 0) {
		gun->bullets = initial_bullets;
	}
}
// деструктор
void gun_dtor(gun_t* gun) {
	// ...
}
// поведенческие функции
bool_t gun_has_bullets(gun_t* gun) {
	return (gun->bullets > 0);
}
void gun_trigger(gun_t* gun) {
	gun->bullets--;
}
void gun_refill(gun_t* gun) {
	gun->bullets = 7;
}

// main.c
#include <stdio.h>
#include <stdlib.h>
#include "player.h"
#include "gun.h"
int main(int argc, char** argv) {
	struct gun_t* gun = gun_new();               // Завершение агрегации двух объектов
	gun_ctor(gun, 3);
	struct player_t* player = player_new();      // создаем и инициализируем объект player
	player_ctor(player, "Billy");
	// начинаем агрегацию
	player_pickup_gun(player, gun);
	while (gun_has_bullets(gun)) { player_shoot(player); }   // стреляем, пока не закончатся патроны
	gun_refill(gun);                                         // перезаряжаем ружье
	while (gun_has_bullets(gun)) { player_shoot(player); }   // стреляем, пока не закончатся патроны
	// завершаем агрегацию
	player_drop_gun(player);
	player_dtor(player);  free(player);   // <!--
	gun_dtor(gun);        free(gun);      // <!-- 
	return 0;
}


// --------------------------------
//    Наследование
// --------------------------------
#include <stdio.h>
typedef struct {
	char first_name[32];
	char last_name[32];
	unsigned int birth_year;
} person_t;

typedef struct {
	person_t person;
	char student_number[16];      // дополнительный атрибут
	unsigned int passed_credits;  // дополнительный атрибут
} student_t;

int main(int argc, char** argv) {
	student_t s;
	student_t* s_ptr = &s;
	person_t* p_ptr = (person_t*)&s;
	printf("Student pointer points to %p\n", (void*)s_ptr);  // 0x7ffeecd41810
	printf("Person pointer points to %p\n",  (void*)p_ptr);  // 0x7ffeecd41810
	return 0;
}

// --------------------------------
// приватная реализация
// person.h
struct person_t;
struct person_t* person_new();       // аллокатор памяти
void person_ctor(struct person_t*,   // конструктор
	const char*  /* имя */,
	const char*  /* фамилия */,
	unsigned int /* год рождения */
);
void person_dtor(struct person_t*);  // деструктор
void person_get_first_name(struct person_t*, char*);  // поведенческие функции
void person_get_last_name(struct person_t*, char*);
unsigned int person_get_birth_year(struct person_t*);

// person_p.h  - приватное определение
typedef struct {
	char first_name[32];
	char last_name[32];
	unsigned int birth_year;
} person_t;

// person.c
#include <stdlib.h>
#include <string.h>
#include "person_p.h"
person_t* person_new() { return (person_t*)malloc(sizeof(person_t)); }
// конструктор
void person_ctor(person_t* person,      // <!-- 1
								 const char* first_name,
								 const char* last_name,
								 unsigned int birth_year) {
	strcpy(person->first_name, first_name);
	strcpy(person->last_name, last_name);
	person->birth_year = birth_year;
}
// деструктор
void person_dtor(person_t* person) {}
// поведенческие функции
void person_get_first_name(person_t* person, char* buffer) { strcpy(buffer, person->first_name); }
void person_get_last_name(person_t* person, char* buffer) {  strcpy(buffer, person->last_name); }
unsigned int person_get_birth_year(person_t* person) { return person->birth_year; }

// student.h
struct student_t;
struct student_t* student_new();      // аллокатор памяти
void student_ctor(struct student_t*,  // конструктор
	const char*  /* имя */,
	const char*  /* фамилия */,
	unsigned int /* год рождения */,
	const char*  /* номер студенческого билета */,
	unsigned int /* засчитанные кредиты */
);
void student_dtor(struct student_t*);  // деструктор
void student_get_student_number(struct student_t*, char*);
unsigned int student_get_passed_credits(struct student_t*);

// student.c
#include <stdlib.h>
#include <string.h>
#include "person.h"
#include "person_p.h"
typedef struct {        // наследуем все атрибуты класса Person
	person_t person;      // <!-- 2
	char* student_number;
	unsigned int passed_credits;
} student_t;
// аллокатор памяти
student_t* student_new() {
	return (student_t*)malloc(sizeof(student_t));
}
// конструктор
void student_ctor(student_t* student,
									const char* first_name,
									const char* last_name,
									unsigned int birth_year,
									const char* student_number,
									unsigned int passed_credits) {
	person_ctor(
		(struct person_t*)student,             // <!-- 3
		first_name, last_name, birth_year);
	student->student_number = (char*)malloc(16 * sizeof(char));
	strcpy(student->student_number, student_number);
	student->passed_credits = passed_credits;
}
// деструктор
void student_dtor(student_t* student) {
	free(student->student_number);           //         сначала нужно уничтожить дочерний объект
	person_dtor((struct person_t*)student);  // <!-- 4  затем следует вызвать деструктор родительского класса
}
void student_get_student_number(student_t* student, char* buffer) {
	strcpy(buffer, student->student_number);
}
unsigned int student_get_passed_credits(student_t* student) {
	return student->passed_credits;
}

// main.c
#include <stdio.h>
#include <stdlib.h>
#include "person.h"
#include "student.h"
int main(int argc, char** argv) {
	struct student_t* student = student_new();
	student_ctor(student, "John", "Doe", 1987, "TA5667", 134);
	// теперь мы используем поведенческие функции объекта person для чтения атрибутов объекта student
	char buffer[32];
	// восходящее приведение указателя к родительскому типу
	struct person_t* person_ptr = (struct person_t*)student;
	person_get_first_name(person_ptr, buffer);    // <!-- 5  прямой вызов метода родителя по указателю 'person_ptr'
	printf("First name: %s\n", buffer);
	person_get_last_name(person_ptr, buffer);
	printf("Last name: %s\n", buffer);
	printf("Birth year: %d\n", person_get_birth_year(person_ptr));
	// теперь мы читаем атрибуты, принадлежащие объекту student
	student_get_student_number(student, buffer);
	printf("Student number: %s\n", buffer);
	printf("Passed credits: %d\n",
	student_get_passed_credits(student));
	// уничтожаем и освобождаем объект student
	student_dtor(student);
	free(student);
	return 0;
}


// --------------------------------
// публичная реализация
// person.h
struct person_t;
struct person_t* person_new();       // аллокатор памяти
void person_ctor(struct person_t*,   // конструктор
								 const char*  /* имя */,
								 const char*  /* фамилия */,
								 unsigned int /* год рождения */
);
void person_dtor(struct person_t*);  // деструктор
void person_get_first_name(struct person_t*, char*);  // поведенческие функции
void person_get_last_name(struct person_t*, char*);
unsigned int person_get_birth_year(struct person_t*);

// student.h
struct student_t;
struct student_t* student_new();      // аллокатор памяти
void student_ctor(struct student_t*,  // конструктор
									const char*  /* имя */,
									const char*  /* фамилия */,
									unsigned int /* год рождения */,
									const char*  /* номер студенческого билета */,
									unsigned int /* засчитанные кредиты */
);
void student_dtor(struct student_t*);  // деструктор
// поведенческие функции
void student_get_first_name(struct student_t*, char*);     // <!-- 1 функции-обертки т.к. нет возможности привести к типу 'person_t'
void student_get_last_name(struct student_t*, char*);      // ... вызывает person_get_last_name()
unsigned int student_get_birth_year(struct student_t*);
void student_get_student_number(struct student_t*, char*);
unsigned int student_get_passed_credits(struct student_t*);

// student.c
#include <stdlib.h>
#include <string.h>
#include "person.h"
typedef struct {                // предварительное объявление
	char* student_number;
	unsigned int passed_credits;
	struct person_t* person;      // <!-- 2  здесь нам нужен указатель, так как тип 'person_t' является неполным
} student_t;
student_t* student_new() { return (student_t*)malloc(sizeof(student_t)); }  // аллокатор памяти
// конструктор
void student_ctor(student_t* student,
									const char* first_name,
									const char* last_name,
									unsigned int birth_year,
									const char* student_number,
									unsigned int passed_credits) {
	student->person = person_new();                                    // <!-- 3
	person_ctor(student->person, first_name, last_name, birth_year);   // <!-- 3
	student->student_number = (char*)malloc(16 * sizeof(char));
	strcpy(student->student_number, student_number);
	student->passed_credits = passed_credits;
}
// деструктор
void student_dtor(student_t* student) {
	free(student->student_number);
	person_dtor(student->person);   // <!-- 4
	free(student->person);          // <!-- 4
}
// поведенческие функции
void student_get_first_name(student_t* student, char* buffer) {       person_get_first_name(student->person, buffer); }
void student_get_last_name(student_t* student, char* buffer) {        person_get_last_name(student->person, buffer); }
unsigned int student_get_birth_year(student_t* student) {      return person_get_birth_year(student->person); }
void student_get_student_number(student_t* student, char* buffer) {   strcpy(buffer, student->student_number); }
unsigned int student_get_passed_credits(student_t* student) {  return student->passed_credits; }

// person.c
#include <stdlib.h>
#include <string.h>
typedef struct {          // приватное определение
	char first_name[32];
	char last_name[32];
	unsigned int birth_year;
} person_t;
person_t* person_new() {  // аллокатор памяти
	return (person_t*)malloc(sizeof(person_t));
}
void person_ctor(person_t* person, // конструктор
								 const char* first_name,
								 const char* last_name,
								 unsigned int birth_year) {
	strcpy(person->first_name, first_name);
	strcpy(person->last_name, last_name);
	person->birth_year = birth_year;
}
void person_dtor(person_t* person) {}  // деструктор
void person_get_first_name(person_t* person, char* buffer) { strcpy(buffer, person->first_name); }
void person_get_last_name(person_t* person, char* buffer) {  strcpy(buffer, person->last_name);  }
unsigned int person_get_birth_year(person_t* person) { return person->birth_year; }

// main.c
#include <stdio.h>
#include <stdlib.h>
#include "student.h"
int main(int argc, char** argv) {
	struct student_t* student = student_new();
	student_ctor(student, "John", "Doe", 1987, "TA5667", 134);
	char buffer[32];
	// ---
	student_get_first_name(student, buffer);   // <!-- 5  функция-обертка для доступа к интерфейсу 'person'
	printf("First name: %s\n", buffer);
	student_get_last_name(student, buffer);    // <!-- 5
	printf("Last name: %s\n", buffer);
	printf("Birth year: %d\n", student_get_birth_year(student));
	student_get_student_number(student, buffer);
	printf("Student number: %s\n", buffer);
	printf("Passed credits: %d\n", student_get_passed_credits(student));
	// уничтожаем и освобождаем объект student
	student_dtor(student);
	free(student);
	return 0;
}

// компиляция
gcc -c person.c -o person.o
gcc -c student.c -o student.o
gcc -c main.c -o main.o
gcc person.o student.o main.o -o <name>.out


// --------------------------------
//    Полиморфизм
// --------------------------------
// animal.h
struct animal_t;                     // предварительное объявление / не полный тип
struct animal_t* animal_new();       // аллокатор памяти
void animal_ctor(struct animal_t*);  // конструктор
void animal_dtor(struct animal_t*);  // деструктор
void animal_get_name(struct animal_t*, char*);  // поведенческие функции
void animal_sound(struct animal_t*)

// animal_p.h
typedef void (*sound_func_t)(void*);  // <!-- 1
typedef struct {
	char* name;
	sound_func_t sound_func;            // <!-- 2  указатель на функцию
} animal_t;

// animal.c
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "animal_p.h"
void __animal_sound(void* this_ptr) {    // родительское определение animal_sound, используемое по умолчанию
	animal_t* animal = (animal_t*)this_ptr;
	printf("%s: Beeeep\n", animal->name);
}
// аллокатор памяти
animal_t* animal_new() {
	return (animal_t*)malloc(sizeof(animal_t));
}
// конструктор
void animal_ctor(animal_t* animal) {
	animal->name = (char*)malloc(10 * sizeof(char));
	strcpy(animal->name, "Animal");       // значения по умолчанию
	animal->sound_func = __animal_sound;
}
// деструктор
void animal_dtor(animal_t* animal) {
	free(animal->name);
}
// поведенческие функции
void animal_get_name(animal_t* animal, char* buffer) {
	strcpy(buffer, animal->name);
}
void animal_sound(animal_t* animal) {
	animal->sound_func(animal);
}

// cat.h
struct cat_t;
struct cat_t* cat_new();
void cat_ctor(struct cat_t*);   // конструктор
void cat_dtor(struct cat_t*);   // деструктор

// cat.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "animal.h"
#include "animal_p.h"
typedef struct {
	animal_t animal;              // <!-- 3
} cat_t;
void __cat_sound(void* ptr) {          // определяем новое поведение для операции sound
	animal_t* animal = (animal_t*)ptr;   // <!-- 4
	printf("%s: Meow\n", animal->name);
}
// аллокатор памяти
cat_t* cat_new() {
	return (cat_t*)malloc(sizeof(cat_t));
}
// конструктор
void cat_ctor(cat_t* cat) {
	animal_ctor((struct animal_t*)cat);    // <!-- 5
	strcpy(cat->animal.name, "Cat");
	cat->animal.sound_func = __cat_sound;  // указываем на новую поведенческую функцию переопределение происходит именно здесь
}
// деструктор
void cat_dtor(cat_t* cat) {
	animal_dtor((struct animal_t*)cat);
}

// main.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "animal.h"
#include "cat.h"
int main(int argc, char** argv) {
	struct animal_t* animal = animal_new();
	struct cat_t*    cat    = cat_new();
	animal_ctor(animal);
	cat_ctor(cat);
	//
	animal_sound(animal);
	animal_sound((struct animal_t*)cat);
	//
	animal_dtor(animal);
	cat_dtor(cat);
	free(cat);
	free(animal);
return 0;
}
