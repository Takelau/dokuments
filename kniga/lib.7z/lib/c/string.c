
https://unicodebook.readthedocs.io/unicode_encodings.html

Unicode 1.0 - 65 536 code points     U+0000—U+FFFF     BMP (Basic Multilingual Plane)
Unicode 6.0 - 1 114 112 code points  U+10000—U+10FFFF  non-BMP

code point       // unsigned integer | '0x35'
byte string      // array of 8 bits unsigned integers
character        // буквы, пробелы или управляющие символы
character string // сторока в котрой каждый элемент это 'character'
encoding         // describes how to encode 'code points' to 'bytes' and how to decode 'bytes' to 'code points'

В UTF-8 первый байт используется для хранения первой половины таблицы ASCII, а остальные - для второй половины символов ASCII со всеми другими широкими символами
UTF-32 всегда используется фиксированное число байтов, даже для символов ASCII
UTF-8 строка не является Unicode string потому, что string unit - byte, а не character

// --------------------------------
//    Строки
// --------------------------------
if (strcmp(argv[1], "-n") != 0) { ... }

// --------------------------------
#include <stdint.h>
typedef uint16_t char16_t;
typedef uint32_t char32_t;
char     utf8_string[32]  = u8"Hello World!";  // UTF-8
char16_t utf16_string[32] =  u"Hello World!";  // UTF-16
char32_t utf32_string[32] =  U"Hello World!";  // UTF-32

// --------------------------------
// locale
unsigned char c = '\xa0'; // the non-breaking space in ISO-8859-1
printf("In the default C locale, \\xa0 is %sprintable\n", isprint(c)?"":"not ");  // In the default C locale, \xa0 is not printable
setlocale(LC_ALL, "en_GB.iso88591");
printf("In ISO-8859-1 locale, \\xa0 is %sprintable\n", isprint(c)?"":"not ");     // In ISO-8859-1 locale, \xa0 is printable

// --------------------------------
int ret_code = 0;
for (char c = 'a'; (ret_code != EOF) && (c != 'z'); c++) {
	ret_code = putchar(c);  // abcdefghijklmnopqrstuvwxy
}



