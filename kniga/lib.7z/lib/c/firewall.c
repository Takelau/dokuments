
// http://c-sec.ru/snort/Snort-Part-9-Rules-Examples/
nmap -sF IP_ADDR   // FIN сканирование
nmap --scanflags SYN,FIN HOSTNAME  // SYN-FIN сканирование

