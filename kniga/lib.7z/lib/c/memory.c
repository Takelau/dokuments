
     размер страницы
BSS  8 byte


size <anme>                 // выводит статическую схему размещения в памяти исполняемого файла
objdump -s -j .data <name>  // просмотр содержимого сегмента Data
readelf
hexdump
valgrind <name>                     // профилировщик, служит для поиска утечки памяти (190)
valgrind --leak-check=full <name>   // строка вызвавшая утечку
ulimit -s     // размер стека потока по умолчанию


// --------------------------------
//    Функционал
// --------------------------------
// stdlib.h 
malloc()    // выделение памяти
calloc()    // выделение памяти с очисткой
realloc()   // расширение существующего блока пямяти, за счет перераспределения
ptmalloc()
tcmalloc()
dlmalloc()
free()
memset()    // инициализация блока памяти

char *buffer = (char*)malloc(buffer_len * sizeof(char));


// --------------------------------
//    Куча
// --------------------------------
// указатели и куча, int
#include <stdio.h>
#include <stdlib.h>
int* create_an_integer(int default_value) {
	int* var_ptr = (int*)malloc(sizeof(int));   // malloc()
	*var_ptr = default_value;
	return var_ptr;
}
int main() {
	int* ptr = NULL;
	ptr = create_an_integer(10);
	free(ptr);                                  // free()
	return 0;
}

// --------------------------------
// указатели и куча, char
#include <stdio.h>   // printf()
#include <stdlib.h>  // malloc() & free()
void fill(char* ptr) {
	ptr[0] = 'a';
	ptr[1] = 'b';
	ptr[2] = 'c';
	ptr[4] = 0;
}
int main(int argc, char** argv) {
	void* gptr = malloc(10 * sizeof(char));
	char* ptr = (char*)gptr;
	fill(ptr);
	free(ptr);
	return 0;
}

// --------------------------------
// инициализация кучи
#include <stdlib.h> // malloc()
#include <string.h> // memset()
int main(int argc, char** argv) {
	char* ptr = (char*)malloc(16 * sizeof(char));
	memset(ptr, 0,    16 * sizeof(char));  // заполняем нулями
	memset(ptr, 0xff, 16 * sizeof(char));  // заполняем байтами 0xff
	...
	free(ptr);
	return 0;
}

// --------------------------------
// изменения размера уже выделенного блока
int main(int argc, char** argv) {
	char* ptr = (char*)malloc(16 * sizeof(char));
	...
	ptr = (char*)realloc(32 * sizeof(char));  // фрагнентация приводит к перераспределению
	...
	free(ptr);
	return 0;
}
