
// --------------------------------
//    Сигналы
// --------------------------------

SIGTERM  // сигнал, запрашивающий завершение; дает возможность процессу подготовиться к выходу
SIGINT   // сигнал прерывания, который обычно отправляется активным процессам путем нажатия Ctrl+C;
SIGKILL  // сигнал немедленного завершения; принудительно закрывает процесс, не давая ему возможности подготовиться.

SIGUSR1  // Определяемый пользователем сигнал № 1
SIGUSR2  // Определяемый пользователем сигнал № 2

SIGABRT  // Сигнал о прекращении, посланный abort
SIGALRM  // Сигнал таймера от alarm

SIGTSTP  // Остановка с помощью клавиатуры
SIGSTOP  // Процесс остановлен
SIGCONT  // Продолжить в случае остановки
SIGCHLD  // Дочерний процесс остановлен или прерван

SIGILL   // Некорректная инструкция от процессора
SIGHUP   // Обнаружено закрытие управляющего терминала

// ----------------------------
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
void handle_user_signals(int signal) {
	switch (signal) {
		case SIGUSR1:
			printf("SIGUSR1 received!\n");
			break;
		case SIGUSR2:
			printf("SIGUSR2 received!\n");
			break;
		default:
			printf("Unsupported signal is received!\n");
	}
}
void handle_sigint(int signal) {
	printf("Interrupt signal is received!\n");
}
void handle_sigkill(int signal) {
	printf("Kill signal is received! Bye.\n");  // процессы не могут обрабатывать  SIGKILL
	exit(0);
}
int main(int argc, char** argv) {
	signal(SIGUSR1, handle_user_signals);
	signal(SIGUSR2, handle_user_signals);
	signal(SIGINT, handle_sigint);
	signal(SIGKILL, handle_sigkill);
	while (1);
	return 0;
}
