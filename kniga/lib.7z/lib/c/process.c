
fork()  https://man7.org/linux/man-pages/man2/fork.2.html
	<0 fail
	=0 for child process
	>0 parent process

// tcp
socket(AF_INET, SOCK_STREAM) -> bind -> listen -> for { accept }
socket(AF_INET, SOCK_STREAM) -> connect
// udp
socket(SOCK_DGRAM) -> bind -> recvfrom
socket(SOCK_DGRAM) -> sendto

// --------------------------------
printf("PID: %d\n", getpid());


// --------------------------------
//    Процесс
// --------------------------------
#include <stdio.h>
#include <unistd.h>
int main(int argc, char** argv) {
	pid_t ret = fork();
	if (ret) {
		//
	} else {
		//
	}
	return 0;
}

// --------------------------------
// --------------------------------
// --------------------------------
// --------------------------------
