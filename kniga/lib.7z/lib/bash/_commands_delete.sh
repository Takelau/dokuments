
# --------------------------
#   Комманды
# --------------------------
pwd     # сведения о текущей рабочей директории
whoami  # данные о пользователе, под которым вы вошли в систему

grep
 -c # вывести количество строк, соответствующих шаблону
 -E # включить расширенное регулярное выражение
 -f # читать шаблон поиска, находящийся в предоставленном файле. Файл.может.содержать.несколько.шаблонов,.причем.каждая.строка.включает.в.себя.один.шаблон
 -i # игнорировать регистр символов
 -l # вывести только имя файла и путь, по которому был найден шаблон
 -n # вывести номер строки файла, в которой был найден шаблон
 -P # включить механизм регулярных выражений Perl
 -R, -r # выполнить рекурсивный поиск подкаталогов

file  # информация о типе файла
 -f # читать список файлов для анализа из данного файла
 -k # не останавливаться на первом совпадении, перечислять все совпадения для типа файла
 -z # просмотреть сжатые файлы

head  # отображает несколько первых строк или байтов файла
 -n # количество строк для вывода
 -c # количество байтов для вывода

# --------------------------
ssh myserver ps >  /tmp/ps.out   # вывод в файл локальной системы
ssh myserver ps \> /tmp/ps.out   # вывод в файл удаленной системы
ssh myserver bash < ./run.sh     # запуск локального скрипта на удаленной системе


# --------------------------
#   SYS INFO
# --------------------------
uname -a            uname -a    # Показать информацию о версии операционной системы
cat /proc/cpuinfo   systeminfo  # Вывести сведения о системном оборудовании и связанную информацию
ifconfig            ipconfig    # Вывести информацию о сетевом интерфейсе
route               route print # Показать таблицу маршрутизации
arp -a              arp -a      # Вывести таблицу ARP (протокол определения адреса)
netstat -a          netstat -a  # Отобразить сетевые подключения
mount               net share   # Вывести информацию о файловых системах
ps -e               tasklist    # Отобразить запущенные процессы


# --------------------------
# архивация
# --------------------------
tar
 -c # создание архивного файла
 -z # архивирование файла
 -f # имя файла вывода

tar -czf ${HOSTNAME}_logs.tar.gz /var/log/

# --------------------------
#  action
# --------------------------
cp f d/f     # Копирование файла в файл
cp f d/      # Копирования файла в папку / {i-требуется ли перезапись;  n-не перезаписывать файлы;  --backup=numbered создавать резервную копию}
cp -r s d/   # Копирование папки в папку
cp -rT s d/  # Копирование содержимого папки в папку (v1)
cp s/* d/    # Копирование содержимого папки в папку (v2)  / {p-сохранение аттрибутов}                   */
cp -reflink=always f d/  # Обработка разреженных файлов

# --------------------------
#   find
# --------------------------
# поиск в файлах
ack    "root" /etc/             // поиск всех файлов содержащих слово root в папке /etc/
ack -C "root" /etc/             // + строки до и после найденой мтроки
ack "^A[A-Z_]+=" /etc/   
ack --type=xml "root" /etc/     // ack --help-types

# поиск в файлах
grep --color=always ...
grep -r "root" /etc/
grep -r -С2 "root" /etc/        // + строки до и после найденой мтроки
grep -r -E "^A[A-Z_]+\=" /etc/  // поиск по регулярному выражения
grep -r -F "[Install]" /usr/    // поиск фиксированной строки

# Поиск больших файлов
ncdu /home                               // размер + список [дерево]
du -a /home/ | sort -n -r | head -n 20   // размер + список
find /home -xdev -type f -size +100M     // список
find /home -xdev -type f -size +100M -exec du -sh {} ';' | sort -rh  // размер + список

# --------------------------
#  Net
# --------------------------
lsof -i 4
lsof -i TCP
lsof -i :21
lsof -i @127.0.0.1
lsof -i @127.0.0.1:1000=1234
lsof -i -s TCP:LISTEN
lsof -i | grep -i LISTEN
lsof -i -s TCP:ESTABLISHED
lsof -i | grep -i ESTABLISHED
# активные процессы
lsof -i -P -n -s TCP:LISTEN
lsof -i -P -n | cut -f 1 -d " "| uniq | tail -n +2 
lsof -p 8236              // список открытых файлов конкретного процесса
lsof -c httpd | head -15  // первые 15 файлов открытых процессом 'httpd'
# пользователь
lsof -u <uid> | wc -l     // список файлов открытых пользователем
lsof -u <uid> -i -a

tracepath [options] <destination>
traceroute [ -46dFITnreAUDV ] [ -f first_ttl ] [ -g gate,... ] [ -i device ] [ -m max_ttl ] [ -N squeries ] [ -p port ] [ -t tos ] [ -l flow_label ] [ -w MAX,HERE,NEAR ] [ -q nqueries ] [ -s src_addr ] [ -z sendwait ] [ --fwmark=num ] host [ packetlen ]

trafshow [-vpnb] [-a len] [-c conf] [-i ifname] [-s str] [-u port] [-R refresh] [-P purge] [-F file | expr]
nethogs
iptraf-ng
iftop


# --------------------------
#   disk
# --------------------------
df -h
ls -l /dev/sda
fdisk -l /dev/sda    # информация о диске

# создание логического раздела 1 емкостью 1G
fdisk /dev/sda -> n -> p -> 1 -> +1G  
mkfs.ext4 /dev/sda1
mount /dev/sda1 /mnt/sda1

# удаление раздела 2
fdisk /dev/sda -> d -> 2

# применение изменений
partprobe             # cat /proc/partitions
resize2fs /dev/sda2   # для ext4

# LVM
pvdisplay -v -m
pvs                   # список физических томов
pvcreate /dev/sda1    # создание физического тома
vgs                         # список рабочих групп  
vgcreate vg_name /dev/sda1  # создание рабочей группы vg_name
lvs                                     # список логических томов
lvcreate vg_name -n lv1_name -L 100M    # создание логического тома lv1_name объемом 100M
mkfs.ext4 /dev/mapper/vg_name-lv1_name  # оздание файловой системы ext4 на логическом томе lv1_name
mount /dev/mapper/vg_name-lv1_name /mnt/lv1_name

lvextend /dev/mapper/vg_name-lv1_name -L +100M -r  # расшиление логического раздела lv1_name на 100M
vgextend vg_name /dev/sda2                         # добавление в группу vg_name диска sda2
pvmove /dev/sda1                 # перемещение данных с диска sda1 на sda2
vgreduce vg_name /dev/sda1       # исключение диска sda1 из группы vg_name


# --------------------------
#  log
# --------------------------
dmesg | less
