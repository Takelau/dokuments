#!/usr/bin/env bash

VERSION='v1.2b'

function Usage_Exit {
	echo "$0 [color|last|len|long]"
	exit
}

# Перед каждым именем файла вывести длину имени и отсортировать по длине имен.
function Ls-Length {
	ls -1 "$@" | while read fn; do
		printf '%3d %s\n' ${#fn} ${fn}
	done | sort -n
}

(( $# < 1 )) && Usage_Exit
sub=$1
shift

case $sub in
	(color)         # Использовать выделение цветом
		ls -N --color=tty -T 0 "$@"
	;;
	(last | latest) # Последние измененные файлы
		ls -lrt | tail "-n${1:-5}"
	;;
	(len*)          # Вывести имена файлов с их длинами
		Ls-Length "$@"
	;;
	(long)          # Файлы с самыми длинными именами
		Ls-Length "$@" | tail -1
	;;
	(*)             # По умолчанию
		echo "unknown command: $sub"
		Usage_Exit
	;;
esac