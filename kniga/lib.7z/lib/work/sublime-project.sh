
## docker
docker run -it \
-v /vlm/notify_go17:/go/src/notify \
-w /go/src/notify \
-p 80:8080 \
--expose 3000 --expose 3001 \
-e "TERM=xterm-256color" \
--network nami-ntw \
--hostname=notify \
--name notify-go17 \
golang:1.17.7-alpine3.15  /bin/sh


#!/bin/sh
# -------------------------
PROJECT="notify"
IMAGE="go17"
GO="go117"
# -------------------------

FOLDER=$PROJECT"_"$IMAGE
DIR="/vlm/"$FOLDER

## dir
mkdir $DIR

## sublime
cat << EOT > "$DIR/$PROJECT.sublime-project"
{
  "folders": [ { "path": "." } ],
  "settings": {

  "LSP": {
    "gopls": {
      "enabled": true,
      "env": {
        "PATH": "/vlm/work/bin",
      }
    },
  },
  "lsp_format_on_save": true,
  "show_references_in_quick_panel": true,
  "log_debug": true,
  "log_stderr": true,

  "golang": {
    "linux": {
      "GO111MODULE": "auto",
      "PATH":      "/vlm/go/$GO/bin",
      "GOROOT":    "/vlm/go/$GO",
      "GOPATH":    "/vlm/c1/$FOLDER",
     "GOMODCACHE": "/vlm/c1/$FOLDER/pkg/mod",
    },
  },
  },
}
EOT

chmod 640       "$DIR/$PROJECT.sublime-project"
chown 1000:1000 "$DIR/$PROJECT.sublime-project"
