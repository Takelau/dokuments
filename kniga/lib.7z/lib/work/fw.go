
for i in $(ls -d *); do echo ${i%}; cat /vlm/work/src/fire_original/${i%}/.git/config | grep url ; done
	
// firewall

0_Gui774ume
  bpf      | https://github.com/adidenko/bpf.git
  etrace   | https://github.com/Gui774ume/etrace.git
  fsprobe  | https://github.com/Gui774ume/fsprobe.git
  nfprobe  | https://github.com/Gui774ume/nfprobe.git
  utrace   | https://github.com/Gui774ume/utrace.git
0_aquasecurity
  btfhub   | https://github.com/aquasecurity/btfhub.git
  libbpfgo | https://github.com/aquasecurity/libbpfgo.git
  tracee   | https://github.com/aquasecurity/tracee.git
0_bol-van
  fingerprint | https://github.com/EgorMelentev/fingerprint.git
  ipobfs      | https://github.com/bol-van/ipobfs.git
  nfqueue_c2  | https://github.com/thesw4rm/nfqueue_c2.git
  zapret      | https://github.com/bol-van/zapret.git
0_florianl
  go-conntrack | https://github.com/florianl/go-conntrack.git
  go-nfqueue   | https://github.com/florianl/go-nfqueue
  go-tc        | https://github.com/florianl/go-tc.git
0_yuuki
  go-conntracer-bpf | https://github.com/yuuki/go-conntracer-bpf.git
  shawk             | https://github.com/yuuki/shawk.git
L4Wall        | https://github.com/RishabhGupta34/L4Wall.git
SYNwall       | https://github.com/SYNwall/SYNwall.git
SailFirewall  | https://github.com/isgasho/SailFirewall.git
beewall       | https://github.com/mmat11/beewall.git
ebpfscene     | https://github.com/lebauce/ebpfscene.git
ebpfsnitch    | https://github.com/harporoeder/ebpfsnitch.git
go-snitch     | https://github.com/r3boot/go-snitch.git
gopsutil      | https://github.com/shirou/gopsutil.git
gsocket       | https://github.com/hackerschoice/gsocket.git
packiffer     | https://github.com/massoudasadi/packiffer.git
tcptracer-bpf | https://github.com/weaveworks/tcptracer-bpf.git
vuurmuur      | https://github.com/inliniac/vuurmuur.git
xdp-fw        | https://github.com/acassen/xdp-fw.git
xdp-tcp-header-options | https://github.com/gamemann/XDP-TCP-Header-Options.git
xdp-tools     | https://github.com/xdp-project/xdp-tools.git
xdp_firewall  | https://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@github.com/ds248a/firewall_xdp.git
