
for i in $(ls -d *); do echo ${i%}; cat /vlm/work/src/vnc/${i%}/.git/config | grep url ; done

// vnc
arpg            | https://github.com/mikan/arpg.git
bring           | https://github.com/deluan/bring.git
clipboard       | https://github.com/golang-design/clipboard.git
GoFTP           | https://github.com/tomatome/GoFTP.git
gordp           | https://github.com/Madnikulin50/gordp.git
go-vnc          | https://github.com/mitchellh/go-vnc
go-vncdriver    | https://github.com/openai/go-vncdriver.git
grdp            | https://github.com/tomatome/grdp.git
hotkey          | https://github.com/golang-design/hotkey.git
kaginawa        | https://github.com/kaginawa/kaginawa.git
kaginawa-server | https://github.com/kaginawa/kaginawa-server.git
kvnc            | https://github.com/kaginawa/kvnc.git
Live-Desktop-Capture | https://github.com/SaturnsVoid/Live-Desktop-Capture.git
lwch
	logging       | https://github.com/lwch/logging.git
	natpass       | https://github.com/lwch/natpass.git
	rdesktop      | https://github.com/lwch/rdesktop
	runtime       | https://github.com/lwch/runtime
	service       | https://github.com/kardianos/service
npass
occamy          | https://github.com/changkun/occamy.git
screen-server   | https://github.com/function61/screen-server.git
vnc2video       | https://github.com/amitbet/vnc2video.git
vncpasswd       | https://github.com/KarpelesLab/vncpasswd.git
vncproxy        | https://github.com/amitbet/vncproxy.git
vnc-recorder    | https://github.com/saily/vnc-recorder.git
webRDP          | https://github.com/gonewbee/webRDP
