/*
https://user@host:port/~user/repo/project.git
ssh://user@host:port/~user/repo
git://user@host:port/~user/repo/project.git
git://path/repo.git
/home/username/project myrepo
*/

// -------------------------------
git remote add a-pgx https://github.com/jackc/pgx.git
git clone https://github.com/jackc/pgx.git c-pgx
git clone https://github.com/gin-gonic/gin.git
git clone https://github.com/hashicorp/go-memdb.git hc-memdb
// -------------------------------

// локалый репозиторий
git add <fname>               // индексация файла
git reset <branch>            // ? (283)
git reset <hash>              // перемещение 'HEAD' на соответствующий коммит текущей ветки
git reset HEAD -- <fname>     // отмена индексирования файла
git reset HEAD~               // возврат ветки к предыдущему коммиту с восс-ем индексов, но не рабочей директории
git reset --soft HEAD~[n]     // ... без восстановления индексов
git reset --hard HEAD~[n]     // ... с востановлением рабочей директории (297)
git reset <hash> <fname>      // замена индекса файла версией из указанного коммита / файл в рабочем каталоге не обновляется
git checkout <fname>          // замена локального файла содержимым из последнего коммита
git rm -f <fname>             // удаление файла с диска и индекса | f-принудительное удаление из индекса
git rm --cached <fname>       // удаление файла из индекса, но не с диска
git rm log/\*.log
git mv <from> <to >           // переименование

git commit -a -m "comment"    // автматическая индексация
git commit --amend --no-edit  // перезапись последнего репозитория
git rebase -i HEAD~3          // модификаци нескольких коммитов (256) | git-rebase.io
  squash   // слияние в предыдущим
  merge    // 
  exec     // запуск комманд
  drop     // удалить
git rebase --abort       // отмена предыдущей комманды во время выполнения
git rebase --continue    // перезапуск перебазирования после решения конфликтов слияния

git reflog               // журнал ссылок | для восстановление предыдущей версии ветки (477)

git checkout <fname>     // замена локального файла содержимым из последнего коммита
git checkout <hash>      // возврат репозитария к предыдущему состоянию
git checkout <tag>       // 'detached HEAD' состояние
git checkout <branch>    // перемещает HEAD на указанную ветку
git revert HEAD          // возврат в предыдущее состояние через создание нового коммита

git diff                 // изменено но не проиндексированно
git diff --staged        // проиндексированно и войдет в commit
git diff --cached        // проиндексированные изменения
git diff master...contrib   // просмотр изменений в ветке 'contrib' относително общего родителя с веткой 'master'
git status -s
?? - новые неотслеживаемые файлы
A  - файлы добавленные в отслеживаемые
M  - модифицирован и проиндексирован
 M - модифицирован и не проиндексирован
MM - модифицирован, проиндексирован и ещё раз модифицирован

git cat-file -p <hash>      // структура каталогов

// теги
git tag                         // список тегов
git tag -l 'v1.8.5*'            // список тегов соотв-е шаблону
git show <tag>                  // информация о теге
git tag    <tag>                // легковесная метк
git tag -a <tag> -m 'comment'   // объектная метка / аннотированная метка
git tag -a v1.2 <id>
git tag -d <tag>                // удаление тега в локальном репозитории
git push <remote> <tag>
git push <remote> --tags            // отправка всех тегов
git push <remote> :refs/tags/<tag>  // v1 - удаление тега с сервера
git push <remote> --delete <tag>    // v2 - удаление тега с сервера

// удаленный репозиторий
git clone <url> <directory>    // автоматическое отслеживание изменений
git remote add <remote> <url>  // Добавление удалённых репозиториев
git fetch --all
git fetch <remote>             // загрузка изменений из репозитория, не сливая с локальным | + указатели на ветки слежения
git pull                       // загрузка и автоматическое слияние с локальной версией

git remote -v                  // <name> <url>
git remote show <remote>       // информация об удалённом репозитории
git remote rename <from> <to>  // измение имена удалённых веток в локальном репозитории
git remote rm <branch>         // локальное удаление удаленного репозитория

// ветки локальные
git branch                      // список веток, (*) - текущая
git branch -vv                  // список веток с доп.инф для 'веток слежения'
git branch <branch>             // создание новой ветки без переключения на нее
git checkout -b <branch>        // создание новой ветки с переключением на нее
git checkout -b <branch> <remote>/<branch> // v2: создание 'ветки слежения' из удаленной ветки
git branch -u <remote>/<branch>            // v4: локальная ветка станет 'веткой слежения'
git branch -d <branch>          // удаление слитой ветки
git branch -D <branch>          // удаление не слитой ветки
git branch --merged <branch>    // список слитых веток отновительно указанной
git branch --no-merged          // список не слитых веток отновительно текущей (*)

// ветки удаленные
<remote>/<branch>                          // ветка слежения
git push    <remote> <branch>              // отправка локольной ветки в удаленный репозиторий
git push    <remote> <branch>:<rbranch>    // ... под другим именем
git push    <remote> --delete <branch>     // удаление удаленной ветки
git push -u <remote> <branch>              // отправляемая локальная ветка становится 'веткой слежения'
git push -f <remote> <branch>              // (--force) после перебазирования (157)
git merge   <remote>/<branch>              // v1: слияние локальной и удаленной ветки | ссылка получена четез 'git fetch <remote>'
git checkout -b <branch> <remote>/<branch> // v2: создание 'ветки слежения' из удаленной ветки
git checkout     --track <remote>/<branch> // v3: ...
git branch -u <remote>/<branch>            // v4: локальная ветка станет 'веткой слежения'


// --------------------------------
//    Слияние
// --------------------------------
git checkout <master>  // ветка, в которую включаются изменения
git merge <branch>     // ветка, которую потом можно удалить

git checkout <b2>                    // новая ветка, в которую включаются изменения (152)
git merge --no-commit --squash <b1>  // ветка 'b1' в виде одного коммента размещается в 'b2', без коммента слияния (один родитель)

git reset --soft HEAD~2   // перемещение HEAD на два шага назад (280)
git commit                // создание коммита с пропуском промежуточных коммитов, но актуальными изменениями


// --------------------------------
//    Перебазирование
// --------------------------------
git rebase --abort       // отмена предыдущей комманды во время выполнения
git rebase --continue    // перезапуск перебазирования после решения конфликтов слияния

git rebase <b>         // добавление изменений текущей ветки в <b>
git rebase <b2> <b1>   // добавит изменения ветки <b1> в <b2> | не требует 'checkout'
git rebase <remote>/<branch> // git pull --rebase | (104,151)

// 1. (97)
git checkout <branch>  // 1 переключение на ветку <branch>
git rebase <master>    // 2 перебазирование относительно ветки <master>
git checkout <master>  // 3 переключение на ветку <master>
git merge <branch>     // 4 слияние перемоткой
git branch -d <branch> // 5 удаление ветки <branch>

// 2. перебазирование веток <b2> & <b1> в ветку <master> (98)
git rebase --onto <master> <b2> <b1> // переключится на <b1>, найти изменения относительно <b2> и применить их ветке <master> (98)
git checkout <master>
git merge <b1>                       // перемотка (fast-forward) для ветки <master>
git rebase <master> <b2>             // перебазирование ветки <b2> в ветку <master>
git checkout <master>
git merge <b2>                       // перемотка для ветки <master>
git branch -d <b1>                   // удаление ветки 'b1'
git branch -d <b2>                   // удаление ветки 'b2'

// 3.
git pull --rebase                         // v1 (104,151) | git config --global pull.rebase true
git fetch + git rebase <remote>/<branch>  // v2

// 4. выборочное применение (166)
git checkout <b1>       // ветка, в которой будет создан коммит
git cherry-pick <hash>  // хеш коммита, изменения которого будут влиты в новый коммент ветки <b1>


// --------------------------------
//    Конфликты слияния
// --------------------------------
git merge --abort           // прекращение в процессе слияния (286)
git reset --hard HEAD~      // v1 локальный (287,297)
git revert -m 1 HEAD        // v2 восстановление через создание нового коммита (298)
git merge --continue

git merge-base <b1> master  // v1 - сравнивает последний коммит тематической ветки <b1> с первым общим родителем для обоих веток
git diff master...<b1>      // v2 - ...

git log --graph --oneline --decorate --all        // граф
git log --oneline --left-right HEAD...MERGE_HEAD  // полная история со списком добаленных файлов
git log --oneline --left-right --merge -p         // только конфликтующие строки файлов
git diff [--ours|--theirs|--base]                 // комбинированный формат изменений
git ls-files -u                                   // список конфликтующих файлов

git checkout --conflict=[merge|diff3] <fname>      // заново выкачает файл и заменит маркеры конфликта (292)
git checkout --conflict [--ours|--theirs] <fname>  // автоматизация выбора изменений файла

git merge -Xignore-all-space <branch>              // игнорирование изменений свзянных с пробельными символами
git merge [-Xours|-Xtheirs] <branch>               // без маркеров конфликта применяет изменения указанной ветки (300)
git merge-file --ours


// --------------------------------
//    Info
// --------------------------------
git status          // текущее состояние
git show topic1     // последний коммит в ветке
git show <hash>     // инфо о коммите
git show HEAD@{5}   // какой была 'HEAD' вашего репозитория пять шагов назад
git show master@{yesterday}  // где была ветка 'master' вчера


// --------------------------------
//    Log
// --------------------------------
git log --all               // просмотр истории во всех ветках
git log origin/master..HEAD // что будет отправлено в удалённый репозиторий
git log -S <function_name>
git log -p -2               // разница по каждому коммиту
git log --oneline --decorate --graph --all
git log --since=2.weeks     // --after, --before
git log --pretty=oneline    // short, full и fuller
git log --pretty=format:"%h - %an, %ar : %s"
git log --pretty=format:"%h %ad | %s%d [%an]" --graph --date=short
git log --pretty="%s" --author=<name> --since="2018-01-01"  --before="2018-02-01" --no-merges -- t/
git log --no-merges <lbranch>..<remote>/<rbranch>  // 
git log             <lbranch>..<remote>/<rbranch>  // просмотр отличий локальной и удаленной ветки
%H   Хеш коммита
%h   Сокращенный хеш коммита
%T   Хеш дерева
%t   Сокращенный хеш дерева
%P   Хеш родителей
%p   Сокращенный хеш родителей
%d   тег
%an  Имя автора
%ae  Электронная почта автора
%ad  Дата автора (формат даты можно задать опцией --date=option)
%ar  Относительная дата автора
%cn  Имя коммитера
%ce  Электронная почта коммитера
%cd  Дата коммитера
%cr  Относительная дата коммитера
%s   Содержание
--stat           // Показывает статистику измененных файлов для каждого коммита
--shortstat      // Отображает только строку с количеством изменений/вставок/удалений для команды --stat
--name-only      // Показывает список измененных файлов после информации о коммите
--name-status    // Показывает список файлов, которые добавлены/изменены/удалены
--abbrev-commit  // только несколько символов SHA-1 чек-суммы
--relative-date  // 2 weeks ago
--no-merges      // исключение коммитов слияния
--grep
--author
--committer


// --------------------------------
//    Дополнительно
// --------------------------------
git stash        // тайник
git stash list   // содержимое тайника
git stash apply --index  // восстановление из тайника с постановкой в индекс
git stash pop    // = apply + drop
git stash drop   // очистка тайника

git clean -n -d     // просмотр файлов (каталогов) которые будут удалены из рабочей директории
git clean -f -d     // удаление файлов
git clean -f -d -x  // ... + (файлы списка игнорирования)


// --------------------------------
//    e-mail
// --------------------------------
git format-patch -M <remote>/<branch>  // генерации файлов в формате 'mbox'
git apply name.patch  // роверка патча перед применением
git am -3 name.patch  // '-3' трехстороннее слияние


// --------------------------------
//    Архив
// --------------------------------
git archive master --prefix='project/' --format=zip > `git describe master`.zip


// --------------------------------
//    GPG (245)
// --------------------------------
gpg --list-keys    // список ключей   - pub 2048R/0A46826A 2014-06-04
gpg --gen-key      // генераци ключа
git config --global user.signingkey 0A46826A   // регистрация приватного ключа



// --------------------------------
//    SSH
// --------------------------------
ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
ssh -T git@github.com
git remote set-url origin git@github.com:<Username>/<Project>.git
git push --progress origin <main>


// --------------------------------
//    Install
// --------------------------------
git <команда> -h
man git-<команда>

/etc/gitconfig    // --system конфиг для всех пользователей
~/.gitconfig      // --global конфиг конкретного пользователя
/.git/config      // --local  конфиг репозитария
/.git/.gitignore  // игнорируемые файлы репозитария

git config --list                //                    user.name=Takelau
git config --list --show-origin  // /root/.gitconfig   user.name=Takelau
git config --list --show-scope   // global             user.name=Takelau

git config --global user.name "Takelau"
git config --global user.email takelau@mail.jp
git config --global core.editor nano
git config --global init.defaultBranch main
git config --global core.autocrlf input
git config --global core.safecrlf warn
git config --global pull.rebase "false"    // по умолчанию
git config --global rerere.enabled false   // 
git config --global diff.submodule log     // работа с подмодулями (319)


// --------------------------------
//    .gitignore
// --------------------------------
https://github.com/github/gitignore
*.a
!lib.a        - не игнорировать lib.a
*~            - все (временные) файлы
<catalog>/    - игнорировать все файлы в каталоге
doc/**/*.txt  - игнорировать все .txt файлы в директории doc/


// --------------------------------
//    ~/.gitconfig
// --------------------------------
[user]
    email = ds248a@gmail.com
    name = Takelau
[init]
    defaultBranch = "main"
[alias]
    hist = log --pretty=format:\"%h %cd | %s%d [%cn]\" --since=3.month --graph --date=short
    type = cat-file -t
    dump = cat-file -p
