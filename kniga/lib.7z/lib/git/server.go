
ufw allow out on enp0s3 proto tcp to 192.168.1.200 port 40004
ufw allow out on enp0s3 proto tcp from 192.168.1.210 to 192.168.1.211 port 22 comment 'SSH Docker'

// --------------------------------
//    Server
// --------------------------------
1. Локальный
git clone /srv/git/project.git
git clone file:///srv/git/project.git
git remote add <project> /srv/git/project.git
git pull /home/john/project

2. SSH
git clone ssh://[user@]server/project.git
git clone [user@]server:project.git

3. Git
порт 9418


Установка (112)
----------------------------
// на сервере
1.
which git-shell >> /etc/shells
groupadd -g 2000 git
adduser -u 2000 -g 2000 --create-home git
echo "git:PASSWORD" | chpasswd
chsh git -s $(which git-shell)
mkdir /home/git/.ssh && chmod 700 /home/git/.ssh && chown 2000:2000 /home/git/.ssh
cd /home/git/.ssh && touch authorized_keys && chmod 600 authorized_keys && chown 2000:2000 authorized_keys
2.
echo "no-port-forwarding,no-X11-forwarding,no-agent-forwarding,no-pty" >> .ssh/authorized_keys
3. // sshd_config
Match User git
  PasswordAuthentication no
  RSAAuthentication      no
  PubkeyAuthentication   yes
  AllowTcpForwarding     no
  AllowAgentForwarding   no

// на клиенте
4.
cd ~/.ssh
ssh-keygen -t rsa
5.
git clone --bare project project.git        // подготовка проекта на рабочей машине
scp -r project.git user@server:/srv/git     // отправка репозитария на сервер
ssh user@server
cd /srv/git/project.git
git init --bare [--shared]                  // инициализирует репозиторий без рабочего каталога
6.
git clone user@server:/srv/git/project.git  // клонирования проекта с сервера


// v1 на сервере
ssh-keygen -t rsa
cat ~/.ssh/id_rsa.pub  >>  ~/.ssh/authorized_keys
- отдать id_rsa.pub пользователю

// v2 на клиенте
ssh-keygen -t rsa
ssh-copy-id -i ~/.ssh/id_rsa.pub git@server

// comp 1
git commit -m 'initial commit'
git remote add origin git@server:/srv/git/project.git
git push origin master

// comp 2
git clone git@server:/srv/git/project.git


Git  (118)
----------------------------
git daemon --reuseaddr --base-path=/srv/git/ /srv/git/

nano /etc/systemd/system/git-daemon.service
[Unit]
Description=Start Git Daemon
[Service]
ExecStart=/usr/bin/git daemon --reuseaddr --base-path=/srv/git/ /srv/git/
Restart=always
RestartSec=500ms
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=git-daemon
User=git
Group=git
[Install]
WantedBy=multi-user.target

systemctl enable git-daemon

cd /path/to/project.git
touch git-daemon-export-ok   // предоставлять доступ без аутентификации
