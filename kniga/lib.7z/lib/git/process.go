
// слияние (136)
c1  git clone c1@host:project.git
    git remote set-url origin c1@host:project.git  // git@github.com:ds248a/notify.git
    git commit -am 'comment 1'
    // ---
c2  git clone c2@host:project.git
    git commit -am 'comment 2'
    git push origin master
    // ---
c1  git fetch origin
    git merge origin/master
    git push origin master
    // ---
c2  git commit -am 'comment 3'
    git commit -am 'comment 4'
    git fetch origin
    git log --no-merges <lbranch>..origin/master
    git checkout master      // локальная ветка <master>
    git merge <lbranch>      // локадьное слияние не выгруженной тематической ветки <lbranch> c <master>
    git merge origin/master  // слияние локальной и удаленной ветки <master>
    git push origin master


// слияние (143)
c1  git checkout -b bA                // создание ветки <bA> с переключением на нее
    git commit -am 'comment A-1'
    git push -u origin bA             // отправляемая локальная ветка становится 'веткой слежения'
    // ---
    git fetch origin
    git checkout -b bB origin/master  // создание 'ветки слежения' из удаленной ветки
    git commit -am 'comment B-1'
    git commit -am 'comment B-2'
    // ---                     // тем временем на <origin> уже появилась ветка <bB2>
    git fetch origin
    git merge origin/bB2
    git push -u origin bB:bB2  // отправка слитых изменений локальной ветки <bB> в ветку <bB2> на <origin>
    // --- 
    git fetch origin
    git checkout bA
    git merge origin/bA
    git commit -am 'comment A-3'
    git push origin bA


// fork (148)
git clone <url>
git checkout -b b1                   // создание тематической ветки 'b1'
git commit -am 'comment 1'
// ---
git remote add fork (url)
git push -u fork b1                  // отправляемая локальная ветка становится 'веткой слежения'
git request-pull origin/master fork  // отправка на проверку
// ---                               // работа над новыми исправлениями
git checkout -b b2 origin/master
git commit -am 'comment 1'
git push fork b2
// --- ветка 'origin/master' была обновлена
git checkout b1                      // v1 - перебазирование существующей ветки 'b1' (151)
git rebase origin/master             // с учетом изменений в 'origin/master'
git push -f fork <b1>                // '-f' - переписать историю ветки <b1> коммитами, не являющимися её потомками
// ---
git checkout -b b3 origin/master     // v2 - создание новой ветки 'b3' на базе измененной 'origin/master' (152)
git merge --no-commit --squash <b2>  // ветка 'b2' в виде одного коммента размещается в 'b3', без коммента слияния (один родитель)


// Слияние субдеревьев | read-tree (302)
git remote add <remote> <url>
git fetch <remote>
git checkout -b <br> <remote>/<master>
git checkout <master>                  // перелючение в ветку мастер локалного проекта
git read-tree --prefix=<dir>/ -u <br>  // выгрузка ветки 'br' в субдиректорию 'dir' ветки 'master' локального проекта
...
git checkout <br>
git pull
...
git checkout <master>
git merge --squash -s recursive -Xsubtree=rack --no-commit <br>


// подмодули
c1 git submodule add (url)
   git diff --cached --submodule
   git commit -am 'comment 1'
   // ---
c2 git clone (url2)              // v1 клонирование проекта с подмодулями
   git submodule init            //    инициализация локального конфигурационного файла
   git submodule update          //    извлечение всех данных проекта
   git clone --recursive (url2)  // v2
   // --- ручное обновление подмодуля
   git fetch                     // перейти в дир подмодуля и загрузить обновления
   git merge origin/master
   git checkout <master>
   git diff --submodule          // просмотр изменений
   // --- автоматическое обновление подмодутей
   git submodule update --remote <module-name>                   // v1 по умолчанию отслеживает ветку 'master'
   git config -f .gitmodules submodule.<module-name>.branch <b>  // v2 загать в конф файле подмодуля ветку отслеживания 'b'
   git submodule update --remote                                 