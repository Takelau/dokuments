
// --------------------------------
//    .gitignore
// --------------------------------
// Go
*~
*.exe
*.dll
*.dylib
*.so
*.test
*.out
*.toml   <- air reload
vendor/
