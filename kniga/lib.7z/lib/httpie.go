
// --------------------------------
//    httpie
// --------------------------------

// GET
http --verify=no https://nami.com:4443/new?count=5

// POST json
curl -v -X POST http://localhost:8080/loginJSON \
  -H 'content-type: application/json' \
  -d '{ "user":"manu" }'

// File upload
curl -X POST http://localhost:8080/upload \
  -F "file=@/Users/appleboy/test.zip" \
  -H "Content-Type: multipart/form-data"

curl -X POST http://localhost:8080/upload \
  -F "upload[]=@/Users/appleboy/test1.zip" \
  -F "upload[]=@/Users/appleboy/test2.zip" \
  -H "Content-Type: multipart/form-data"

// Base Auth
$ curl --cacert cert.pem -H "Authorization: Basic am9lOjEyMzQ=" https://localhost:4000/secret/    // echo -n "joe:1234" | base64 -> am9lOjEyMzQ=

