
// --------------------------------

SELECT * FROM flight
	WHERE departure_airport = 'LAG'
	AND (arrival_airport = 'ORD' OR arrival_airport = 'MDW')
	AND scheduled_departure BETWEEN '2020-05-27' AND '2020-05-28'

// --------------------------------

SELECT DISTINCT city, zip FROM address

// --------------------------------

