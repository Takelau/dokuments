
// --------------
FROM alpine:3.4
RUN groupadd -r runer && useradd -r -g runer runer
WORKDIR /app
COPY app /app
EXPOSE 9090 9191
USER runer
CMD ["python", "identidock.py"]

// --------------
// nano package.json
{
	"name": "app_foo",
	"version": "1.0",
	"description": "",
	"main": "index.js",
	"scripts": {
		"test": "echo \"Error: no test spec \" && exit 1",
		"start": "node index.js"
	},
	"author": "",
	"license": "ISC",
	"dependencies": {
		"express": "^4.16.4"
	}
}

// nano Dockerfile
FROM node:10.11
COPY ./ /usr/src/app
WORKDIR /usr/src/app
RUN  npm install > /dev/null
EXPOSE 3001
CMD ["npm", "start"]

// nano .dockerignore
/.idea
/node_modules
package-lock.json
Dockerfile


// --------------------------------
// C
// компиляция исполняемого файла
FROM gcc
RUN echo 'int main() { puts("Hello world!"); }' > hi.c
RUN gcc -static hi.c -w -o hi

docker build -t hello_build .
docker run --name hello hello_build /bin/true
docker cp hello:/hi hi
docker rm hello
docker rmi hello_build

mkdir -p new_folder
mv hi new_folder
cd new_folder

// обертка исполняемого файла
FROM scratch
ADD hi /hi
CMD ["/hi"]

docker build -t hello_world .
docker run hello_world   // <- "Hello world!"


// --------------------------------
// Go web-server (метод 58 - 209)
// компиляция
FROM golang:1.4.2
RUN CGO_ENABLED=0 \                  // предотвращения кросс-компиляци
go get -a -ldflags '-s' -installsuffix cgo github.com/docker-in-practice/go-web-server
CMD ["cat","/go/bin/go-web-server"]  // Репозиторий с исходным кодом веб-сервера

docker build -t go-web-server .              // Собирает и помечает образ
mkdir -p go-web-server && cd go-web-server
docker run go-web-server > go-web-server     // Запускает образ и перенаправляет двоичный вывод в файл
chmod +x go-web-server
echo "Hi" > page.html

// обертка исполняемого файла
FROM scratch
ADD go-web-server /go-web-server
ADD page.html /page.html
ENTRYPOINT ["/go-web-server"]

docker build -t go-web-server .
docker run -p 8080:8080 go-web-server -port 8080


// --------------------------------
// mysql-client (ubuntu)
FROM ubuntu:14.04
RUN apt-get update -q \
&& DEBIAN_FRONTEND=noninteractive apt-get install -qy mysql-client \
&& apt-get clean && rm -rf /var/lib/apt
ENTRYPOINT ["mysql"]


// --------------------------------
// mysql-client (alpine)
FROM gliderlabs/alpine:3.6
RUN apk-install mysql-client
ENTRYPOINT ["mysql"]


// --------------------------------
// v1 PostgreSQL + NodeJS + Nginx
FROM ubuntu:14.04
RUN apt-get update && apt-get install postgresql nodejs npm nginx
WORKDIR /opt
COPY db /opt/db
RUN service postgresql start && cat db/schema.sql | psql && service postgresql stop
COPY app /opt/app
RUN cd app && npm install
RUN cd app && ./minify_static.sh
COPY conf /opt/conf
RUN cp conf/mysite /etc/nginx/sites-available/ && cd /etc/nginx/sites-enabled &&  ln -s ../sites-available/mysite

// v2
// postgres
FROM ubuntu:14.04
RUN apt-get update && apt-get install postgresql
WORKDIR /opt
COPY db /opt/db
RUN service postgresql start && cat db/schema.sql | psql && service postgresql stop

// nodejs
FROM ubuntu:14.04
RUN apt-get update && apt-get install nodejs npm
WORKDIR /opt
COPY app/package.json /opt/app/package.json  // <-- разделение по слоям
RUN cd app
RUN npm install
COPY app /opt/app                            // <-- разделение по слоям
RUN cd app && ./minify_static.sh

// nginx
FROM ubuntu:14.04
RUN apt-get update && apt-get install nginx
WORKDIR /opt
COPY conf /opt/conf
RUN cp conf/mysite /etc/nginx/sites-available/ && cd /etc/nginx/sites-enabled && ln -s ../sites-available/mysite


// --------------------------------
// Nginx {{NGINX_HOST}} && {{NGINX_PROXY}}
FROM nginx:1.7
COPY default.conf /etc/nginx/conf.d/default.conf
COPY entrypoint.sh /entrypoint.sh
ENTRYPOINT ["/entrypoint.sh"]
CMD ["nginx", "-g", "daemon off;"]

// entrypoint.sh
#!/bin/bash
set -e
sed -i "s|{{NGINX_HOST}}|$NGINX_HOST|;s|{{NGINX_PROXY}}|$NGINX_PROXY|" /etc/nginx/conf.d/default.conf
cat /etc/nginx/conf.d/default.conf
exec "$@"

// nginx default.conf
server {
  listen 80;
  server_name {{NGINX_HOST}};    // 45.55.251.164
  location / {
    proxy_pass {{NGINX_PROXY}};  // http://identidock:9000
    proxy_next_upstream error timeout invalid_header http_500 http_502 http_503 http_504;
    proxy_redirect  off;
    proxy_buffering off;
    proxy_set_header Host            {{NGINX_HOST}};
    proxy_set_header X-Real-IP       $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}

-> chmod +x entrypoint.sh
-> docker build --no-cache -t proxy:1.0 .
