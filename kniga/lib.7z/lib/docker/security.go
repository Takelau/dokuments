
docker run
  --privileged    // Docker в Docker
  --read-only     // запуск контейнера с правами доступа только на чтение

// --------------------------------
// USER 5000
docker run -it --user 5000 ubuntu bash


