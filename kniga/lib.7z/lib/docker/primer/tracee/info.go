
// --------------------------------
//    builder/ go
// --------------------------------
1. builder/Makefile.release
	all: release
	release:
		$(MAKE) -f builder/Makefile.tracee-make alpine-prepare
		$(MAKE) -f builder/Makefile.tracee-make alpine-make ARG="clean"
		BTFHUB=1 $(MAKE) -f builder/Makefile.tracee-container build-tracee

		$(MAKE) -f builder/Makefile.tracee-make ubuntu-prepare
		$(MAKE) -f builder/Makefile.tracee-make ubuntu-make ARG="clean"
		BTFHUB=0 STATIC=1 $(MAKE) -f builder/Makefile.tracee-make ubuntu-make ARG="tracee-ebpf"   // static lib
		BTFHUB=0 STATIC=1 $(MAKE) -f builder/Makefile.tracee-make ubuntu-make ARG="tracee"        // static lib
		BTFHUB=0 STATIC=0 $(MAKE) -f builder/Makefile.tracee-make ubuntu-make ARG="all"           // shared libs

2. builder/Makefile.tracee-container
	help:
		$ make -f builder/Makefile.tracee-container build-tracee
		$ make -f builder/Makefile.tracee-container run-tracee
	build-tracee:
		$(CMD_DOCKER) build \
			--network host \
			-f $(TRACEE_CONT_DOCKERFILE) \      // Dockerfile.alpine-tracee-container
			-t $(TRACEE_CONT_NAME) \
			--build-arg=BTFHUB=$(BTFHUB) \
			--build-arg=FLAVOR=tracee-core \
			--target tracee-core \
			.
	run-tracee:
		$(CMD_DOCKER) $(DOCKER_RUN_ARGS) --rm -it $(TRACEE_CONT_NAME) $(ARG)

3. builder/Makefile.tracee-make
	help:
		$ make -f builder/Makefile.tracee-make alpine-prepare    // create alpine
		$ make -f builder/Makefile.tracee-make alpine-shell      // exec   alpine shell
		$ make -f builder/Makefile.tracee-make ubuntu-prepare    // create ubuntu
		$ make -f builder/Makefile.tracee-make ubuntu-shell      // exec   ubuctu shell

	ubuntu-prepare:
		$(CMD_DOCKER) build \
			--network host \
			-f $(UBUNTU_MAKE_DOCKERFILE) \          // Dockerfile.ubuntu-tracee-make
			-t $(UBUNTU_MAKE_CONTNAME):latest \
			--build-arg uid=$(UID) \
			--build-arg gid=$(GID) \
			.

	ubuntu-shell:
		$(CMD_DOCKER) $(DOCKER_RUN_ARGS) -it $(UBUNTU_MAKE_CONTNAME) /bin/bash

	ubuntu-make:
		$(CMD_DOCKER) $(DOCKER_RUN_ARGS) $(UBUNTU_MAKE_CONTNAME) $(MAKE) $(ARG)


// --------------------------------
//    packaging / rpmbuild
// --------------------------------
1. builder/Makefile.packaging
	help:
		$ make -f builder/Makefile.packaging fedora-bin-36

	fedora-bin-%:
		$(MAKE) .fedora-pkgs-make-$* ARG="packaging/fedora-pkgs.sh bin $*"

	.fedora-pkgs-make-%:
		.fedora-pkgs-prepare-%
		$(CMD_DOCKER) $(DOCKER_RUN_ARGS) -it $(FEDORA_PKGS_CONTNAME):$* $(ARG)

	.fedora-pkgs-prepare-%:
		$(CMD_DOCKER) \
			build \
			-f $(FEDORA_PKGS_DOCKERFILE) \     // Dockerfile.fedora-packaging
			-t $(FEDORA_PKGS_CONTNAME):$* \    // fedora-pkgs-make
			--build-arg uid=$(UID) \
			--build-arg gid=$(GID) \
			--build-arg version=$* \
			. && \
		$(CMD_TOUCH) $@

