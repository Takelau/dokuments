
https://github.com/chunghha/docker-go-gin

/src   // <-- ./src/main.go
.gitignore
Dockerfile
README.md
go.mod
run.sh
test.db

// Dockerfile
ARG GO_VERSION=1.11
FROM golang:${GO_VERSION}-alpine AS builder
RUN apk update && apk add alpine-sdk git && rm -rf /var/cache/apk/*   <-- */
RUN mkdir -p /api
WORKDIR /api
COPY go.mod .
COPY go.sum .
RUN go mod download
COPY . .
RUN go build -o ./app ./src/main.go

FROM alpine:latest
RUN apk update && apk add ca-certificates && rm -rf /var/cache/apk/*    <-- */
RUN mkdir -p /api
WORKDIR /api
COPY --from=builder /api/app .
COPY --from=builder /api/test.db .
EXPOSE 8080
ENTRYPOINT ["./app"]

// run.sh
#!/usr/bin/env bash
docker build . -t go-gin
docker run -i -t -p 8080:8080 go-gin

// .gitignore
.vscode/launch.json

// go.mod
module github.com/chunghha/docker-go-gin
require (
	github.com/gin-contrib/sse v0.0.0-20190125020943-a7658810eb74 // indirect
	github.com/gin-gonic/gin v1.3.0 // indirect
	github.com/golang/protobuf v1.2.0 // indirect
	github.com/jinzhu/gorm v1.9.2 // indirect
	github.com/jinzhu/inflection v0.0.0-20180308033659-04140366298a // indirect
	github.com/mattn/go-isatty v0.0.4 // indirect
	github.com/mattn/go-sqlite3 v1.10.0 // indirect
	github.com/ugorji/go/codec v0.0.0-20190204201341-e444a5086c43 // indirect
	gopkg.in/go-playground/validator.v8 v8.18.2 // indirect
	gopkg.in/yaml.v2 v2.2.2 // indirect
)

