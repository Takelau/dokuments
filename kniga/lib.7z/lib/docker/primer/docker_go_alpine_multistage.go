
https://github.com/codefresh-contrib/golang-sample-app

1. Dockerfile             // 775MB < GOPATH
2. Dockerfile.mod         // 389MB < Go modules 
3. Dockerfile.multistage  // 16 MB < Go modules and tests
4. hello_server.go
5. .gitignore

// 1. Dockerfile
FROM golang:1.10
WORKDIR $GOPATH/src/github.com/codefresh-contrib/go-sample-app
COPY . .                 // Copy everything from the current directory to the PWD
RUN go get -d -v ./...   // Download all the dependencies
RUN go install -v ./...  // Install the package
EXPOSE 8080
CMD ["go-sample-app"]    // Run the executable

// 2. Dockerfile.mod
FROM golang:1.12-alpine
RUN apk add --no-cache git
WORKDIR /app/go-sample-app
COPY go.mod .
COPY go.sum .
RUN go mod download      // module cache based on the go.{mod,sum} files
COPY . .
RUN go build -o ./out/go-sample-app .
EXPOSE 8080
CMD ["./out/go-sample-app"]

// 3. Dockerfile.multistage
FROM golang:1.12-alpine AS build_base
RUN apk add --no-cache git
WORKDIR /tmp/go-sample-app
COPY go.mod .
COPY go.sum .
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 go test -v           // Unit tests
RUN go build -o ./out/go-sample-app .  // Build the Go app

FROM alpine:3.9 
RUN apk add ca-certificates
COPY --from=build_base /tmp/go-sample-app/out/go-sample-app /app/go-sample-app
EXPOSE 8080
CMD ["/app/go-sample-app"]

// 5. .gitignore
hello_server
golang-sample-app
out/
vendor/
_vendor-*

// BUILD
docker build . -t go-sample-app-full                            // 775MB
docker build . -f Dockerfile.mod -t go-sample-app-modules       // 389MB
docker build . -f Dockerfile.multistage -t go-sample-app-multi  // 16 MB

// RUN
docker run -p 8080:8080 go-sample-app-multi
