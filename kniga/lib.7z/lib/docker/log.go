
// --------------------------------
//    Ведение логов
// --------------------------------
1. индивидуально для контейнера
docker run --log-driver=journald --log-opt tag=<tag>
2. Compose
# docker-compose.yml
mycontainer:
    image: myimage
    logging:
        driver: journald
        options:
            tag: mytag
3. Docker config
nano /etc/docker/daemon.json
{ "log-driver": "journald" }


// --------------------------------
//    Чтение логов
// --------------------------------
docker info --format '{{.LoggingDriver}}'    // сервер (драйвер) логирования Docker
docker logs $(docker ps -lq)
docker logs <cname>

docker run nginx ls -l /var/log/nginx        // access.log  -> /dev/stdout
docker inspect <cname> | grep -E "LogPath"   // "LogPath": "/var/lib/docker/containers/4e65e9b0f1412"

// https://sysadmin.pm/journald-journalctl/
// https://www.digitalocean.com/community/tutorials/how-to-use-journalctl-to-view-and-manipulate-systemd-logs-ru
journalctl -u[b] docker CONTAINER_NAME=<cname>
journalctl -u[b] docker CONTAINER_TAG=<tag>


// --------------------------------
//    Драйверы
// --------------------------------
none       - Логи не доступны для контейнера, и логи самого докера не возвращают никакого вывода.
json-file  - Log-и отформатированы как JSON. Данный драйвер используется по умолчанию в Docker.
syslog     - Записывает логи в syslog. Демон syslog должен быть запущен на самом хосте.
journald   - Записывает логи в journald. Демон journald должен быть запущен на самом хосте.
gelf       - Записывает сообщения в Graylog (GELF) или Logstash.
fluentd    - Записывает сообщения на fluentd (forward input). Демон fluentd должен быть запущен на самом хосте.
awslogs    - Записывает сообщения в Amazon CloudWatch.
splunk     - Записывает сообщения в splunk с помощью сборщика HTTP событий (HTTP Event Collector).
gcplogs    - Записывает сообщения в Google Cloud Platform (GCP).
logentries - Записывает сообщения в Rapid7 Logentries.


// --------------------------------
//    Особенности
// --------------------------------
1. В стандартном контейнере Docker любой сервис, который записывает сообщения в syslog, по умолчанию отбрасывается.
   Docker не запишет ничего, пока сообщение не попадает в STDOUT/STDERR.
2. Логи могут быть утеряны, если syslog не смог доставить их на удаленный сервер.
   Логи не буферизируются на диске.
3. Ограничение скорости ведения журнала в настройках journald может вызвать потерю части логов.
   Docker формирует логи для всех работающих приложений.
4. Команда 'docker logs' работает только с драйверами 'json-file' и 'journald'
5. Перезапуск сервера syslog может вызвать падение контейнеров.
6. Многострочные логи не поддерживаются. Например, трассировка стека ошибок.
   Она используется довольно часто и по своей природе многострочная.
   С использованием логирования Docker каждая строка трассировки становится новым событием.


// --------------------------------
//    HTTPD
// --------------------------------
FROM centos
RUN yum install -y httpd web-assets-httpd && yum clean all
RUN echo "logs are sending to stdout" > /var/www/html/index.html
RUN ln -s /dev/stdout /var/log/httpd/access_log && \ 
    ln -s /dev/stderr /var/log/httpd/error_log
EXPOSE 80 
CMD httpd -DFOREGROUND


// --------------------------------
//    Ротация логов
// --------------------------------
nano /etc/logrotate.d/docker-containers
/var/lib/docker/containers/*/*.log {
 rotate 7
 daily
 size 50M
 compress
 missingok
 notifempty
 copytruncate
 dateext
}

# Принудительно проктурить логи
logrotate -f /etc/logrotate.conf
