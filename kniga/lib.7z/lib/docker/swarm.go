
// --------------------------------
//  SWARM
// --------------------------------
docker info
docker node ls     // ID  HOSTNAME  STATUS  AVAILABILITY  MANAGER  STATUS
docker service ls  // ID  NAME  MODE  REPLICAS  IMAGE  PORTS
docker service ps <service-name>  // ID  NAME  IMAGE  NODE  DESIRED  STATE  CURRENT  STATE
docker service rm <service-name>

docker swarm leave  // убрать хост из роя


// --------------------------------
//  создание кластера Swarm
// --------------------------------
// global eth0 192.168.11.67/23 brd 192.168.11.255
// host-1
docker swarm init --advertise-addr 192.168.11.67
-> To add a worker
-> docker swarm join --token SWMTKN-<TOKEN> 192.168.11.67:2377
-> To add a manager
-> docker swarm join-token manager
// host-2
docker swarm join --token SWMTKN-<TOKEN> 192.168.11.67:2377
// 'drain' mode
docker node update --availability drain <id-host-manager>
// запуск контейнера
docker service create --name server -d -p 8000:8000 ubuntu:14.04 python3 -m http.server 8000
curl -sSL 192.168.11.50:8000 | head -n4


