
// --------------------------------
//    X11
// --------------------------------
// проверка параметров сокета
ls /tmp/.X11-unix/   // X0  проверка работы сокета Unix сервера X11
echo $DISPLAY        // :0  

1.1 // Запуск контейнера, используя экран с поддержкой Xauthority
ls $HOME/.Xauthority  // /home/myuser/.Xauthority
docker run -e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix \
--hostname=$HOSTNAME -v $HOME/.Xauthority:$HOME/.Xauthority \
-it -e EXTUSER=$USER ubuntu:16.04 bash -c 'useradd $USER && exec bash'
root@myhost:/# apt-get update && apt-get install -y x11-apps
root@myhost:/# su - $EXTUSER -c "xeyes"

1.2 // Запуск контейнера, используя экран с поддержкой xhost
xhost +    // отключает контроль доступа к X
docker run -e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix \
-it ubuntu:16.04 bash
root@ef351febcee4:/# apt-get update && apt-get install -y x11-apps
root@ef351febcee4:/# xeyes


