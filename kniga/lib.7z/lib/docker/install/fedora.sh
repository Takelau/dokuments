#!/bin/sh

dnf list wget
dnf install -y wget
dnf install -y mc
dnf install -y nano

## go
cd /work
mkdir go pkg bin
wget https://go.dev/dl/go1.17.7.linux-amd64.tar.gz
tar -xf go1.17.7.linux-amd64.tar.gz && rm -f go1.17.7.linux-amd64.tar.gz

cat <<EOT > /root/.bash_profile
# .bash_profile
if [ -f ~/.bashrc ]; then
  . ~/.bashrc
fi
export LC_CTYPE=en_US.UTF-8
export TERM=xterm-256color
export GOOS=linux
export GOARCH=amd64
export GOROOT=/work/go
export GOPATH=/work
PATH=$PATH:$GOROOT/bin:$GOPATH/bin
export PATH
EOT
chmod 640  /root/.bash_profile






## Dockerfile
FROM alpine
RUN apk add --no-cache bash

COPY . /app
RUN chmod +x /app/hello.sh
CMD /app/hello.sh

FROM golang:1.12-alpine
RUN apk add --no-cache git
WORKDIR /app/go-sample-app
COPY go.mod .
COPY go.sum .
RUN go mod download
EXPOSE 8080
CMD ["/app/go-sample-app"]

# sh
COPY . /app
RUN chmod +x /app/hello.sh
CMD /app/hello.s

# локали CentOS
RUN localedef -i en_US -f UTF-8 en_US.UTF-8

