#!/bin/switch

docker network create -d bridge--subnet 172.19.0.0/24 --ip-range 172.19.0.0/26 nami-ntw
docker pull golang:1.17.7-alpine3.15


docker run -it \
-v /vlm/nami_go17:/go/src/nami \
-w /go/src/nami \
-p 80:8080 \
--expose 3000 --expose 3001 \
-e "TERM=xterm-256color" \
--network nami-ntw \
--hostname=nami \
--name nami-go17 \
golang:1.17.7-alpine3.15  /bin/sh


# run
# bash bash-doc bash-completion
apk search mc && apk add mc mc-doc mc-lang nano net-tools   
go install github.com/cosmtrek/air@latest
air init


# bash
nano ~/.bash_profile
# .bash_profile
alias ll='ls -alF'
alias ls='ls --color=auto'


# test
http GET http://127.0.0.1:80/ping


# git
git clone git@github.com:ds248a/notify.git
git remote set-url origin git@github.com:ds248a/notify.git
git add -A
git commit -am "Update README.md"
git push


# .sublime-project
{
	"folders": [ { "path": "." } ],
	"settings": {
		
		"LSP": {
			"gopls": {
				"enabled": true,
				"env": {
					"PATH": "/vlm/work/bin",
				}
			},
		},
		"lsp_format_on_save": true,
		"show_references_in_quick_panel": true,
		"log_debug": true,
		"log_stderr": true,

		"golang": {
			"linux": {
				"GO111MODULE": "auto",
				"PATH": "/vlm/go/go117/bin",
				"GOROOT": "/vlm/go/go117",
				"GOPATH": "/vlm/c1/nami_go17",
				"GOMODCACHE":"/vlm/c1/nami_go17/pkg/mod",
			},
		},
	},
}
