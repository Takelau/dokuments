
DRIVER
- bridge   изолированная сеть ограниченная одним хостом (по умолчанию)
- overlay  несколько хостов. Требуется Consul, Etcd или ZooKeeper
	--cluster-store
	--cluster-store-opt
	--cluster-advertise

docker network create [OPTIONS] NETWORK
docker network inspect [OPTIONS] NETWORK [NETWORK...]
docker network connect [OPTIONS] NETWORK CONTAINER      // Connect a container to a network
docker network disconnect [OPTIONS] NETWORK CONTAINER

docker network ls
docker network prune       // удалить все не используемые сети
docker network rm <id|net-name>

// --------------------------------
// именнованные пользовательские сети
docker network create --subnet 172.20.0.0/16 --ip-range 172.20.240.0/20 <net-name>
docker network connect --ip 172.20.128.2 <net-name> <cname>  // подключение контейнера к сети
docker run -it --network <net-name> ubuntu:16.04 bash        // запуск нового контейнера в сети

// --------------------------------
// --link <cname>:<link_name>
// 10003|80 <cwp> -> <smysql>
docker run --name <cmysql> -e MYSQL_ROOT_PASSWORD=<password> -d <mysql>
<pause> || docker logs <cmysql>
docker run --name <cwp> --link <cmysql>:<mysql> -p 10003:80 -d <wordpress>
