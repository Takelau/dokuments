
Ctrl+D           // остановка сервисов

// --------------------------------
//    V2
// --------------------------------
docker-compose config               // проверка конфигурации {--services, --volumes}
docker compose build                // создание образов

docker compose up --force-recreate  // Ctrl+D
docker compose up --no-start        // создание контейнера, тота и сети, без запуска контейнеров
docker compose up --no-build        // не запускать сборку контейненор
docker compose up --detach          // d-запуск с отсоединением от терминала
docker compose up --remove-orphans  // удаление старых контейнеров

docker compose start|stop|restart <cname>
docker compose pause|unpause <cname> // приостановка|запуск процессов в контейнере
docker compose exec <cname> ls       // запуск службы ls
docker compose run <cname> sh        // запуск нового контейнера
docker compose kill <cname>          // ничтожение контейнера службы
docker compose rm <cname>            // удаление заданного контейнера

docker compose down                  // удаляет контейнеры, сети и тома, но не оразы
docker compose down --rmi local|all  // + образы, созданные при запуске | local-без имен, all-все, включая локально кешированные

docker compose ps -a
docker compose ps --services     // запущенные сервисы
docker compose ps --quiet        // идентификатор контейнера

docker compose images


// --------------------------------
//    Monitor
// --------------------------------
docker compose logs -f --timestamps --tail="3" --no-color  // tail-ограничение кол-ва выводимых сообщений
docker compose top
docker compose events     // отслеживание событий


// --------------------------------
//    Volume
// --------------------------------
// NFS
services: volumes: <nfsvol>:
	driver_opts:
		type: "nfs"
		o: "addr=127.0.0.1,nolock,rw"
		device: ":/data"


// --------------------------------
//    Label
// --------------------------------
services: <sname>: build: labels: - com.packtpub.compose.app=<lname>
docker images --filter "label=com.packtpub.compose.app=<lname>"

services: <sname>: labels: - com.packtpub.compose.app=<lname>
docker ps --filter="label=com.packtpub.compose.app=task-<lname>"


// --------------------------------
//    Registry
// --------------------------------
// daemon.json
{
	"insecure-registries":["host.docker.internal:5000"],
	"builder":{...}
}
services:
	registry:
		image: registry:2
		ports:
		- 5000:5000


// --------------------------------
//    Profiles
// --------------------------------
services: phpmyadmin: profiles: ["debug"]
docker compose --profile debug up
docker compose --profile frontend --profile debug up


// --------------------------------
//    V1
// --------------------------------
docker-compose [-f <arg>...] [--profile <name>...] [options] [COMMAND] [ARGS...]
-f, --file FILE             // default: docker-compose.yml
-p, --project-name NAME     // default: directory name
--project-directory PATH    // default: the path of the Compose file
--profile NAME              // Specify a profile to enable
--verbose                   // Show more output
--log-level LEVEL           // Set log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
--no-ansi                   // Do not print ANSI control characters
--tls                       // Use TLS; implied by --tlsverify 

docker-compose build [options] [--build-arg key=val...] [SERVICE...]
--build-arg key=val
-m, --memory MEM        // memory limit
--compress              // gzip
--no-cache
-q, --quiet             // Don't print anything to `STDOUT`

docker-compose run [options] [-v VOLUME...] [-p PORT...] [-e KEY=VAL...] [-l KEY=VALUE...] SERVICE [COMMAND] [ARGS...]
docker-compose config [options]           // Validate and view the Compose file
docker-compose rm [options] [SERVICE...]  // f-без подтверждения, s-остановка контейнеров, v-удалить volumes

docker-compose up [options] [--scale SERVICE=NUM...] [SERVICE...]   // Builds, (re)creates, starts, and attaches to containers for a service
docker-compose down [options]    // Stops containers and removes containers, networks, volumes, and images created by up

docker-compose start [SERVICE...]             // Starts existing containers for a service
docker-compose stop [options] [SERVICE...]    // Stops running containers without removing them
docker-compose restart [options] [SERVICE...] // Restarts all stopped and running services

docker-compose ps [options] [SERVICE...]      // Lists containers
docker-compose top [SERVICE...]               // Displays the running processes
docker-compose images [options] [SERVICE...]  // List images used by the created containers
docker-compose logs [options] [SERVICE...]    // f-log output, t-timestamps, --tail="10"-10 последних записей

// env
// --------------------------------
docker-compose --env-file ./config/.env.dev up





