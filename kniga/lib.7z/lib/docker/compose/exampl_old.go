
// --------------------------------
// proxy + multy-db | network (метод 78)
// server (db)
FROM ubuntu:14.04
RUN apt-get update && apt-get install -y rlwrap sqlite3 socat
EXPOSE 12345

// docker­compose.yml
version: "3"
  services:
    server:
      command:
        socat TCP-L:12345,fork,reuseaddr   // прокси-сервер socat, соединяет вывод вызова SQLite с TCP-портом
        EXEC:'sqlite3 /opt/sqlite/db',pty  // EXEC сообщает socat запускать SQLite в файле /opt/sqlite/db для каждого подключения, присваивая псевдотерминал процессу
      build: .
      volumes:
      - /tmp/sqlitedbs/test:/opt/sqlite/db // host:container
      networks:
      - sqlnet
    proxy:
      command: socat TCP-L:12346,fork,reuseaddr TCP:server:12345
      build: .
      ports:
      - 12346:12346
      networks:
      - sqlnet
    networks:
      sqlnet:
        driver: bridge

docker-compose up
rlwrap telnet localhost 12346  // test connect


// --------------------------------
// env
1.
cat .env
TAG=1.5

cat docker-compose.yml
version: '3'
services:
  web:
    image: "webapp:${TAG}"

docker-compose config

2.
docker-compose --env-file ./config/.env.dev up
docker-compose --env-file ./config/.env.dev config

3.
web:
  env_file:
    - web.env

4.
web:
 environment:
   - DEBUG

docker-compose run -e DEBUG=1 web python console.py


// --------------------------------
// restart_policy
version: "3.9"
services:
  redis:
    image: redis:alpine
    deploy:
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s


// --------------------------------
// использование 'volumes'
version: "3.9"
services:
  frontend:
    image: node:lts
    volumes:
      - myapp:/home/node/app
volumes:
  myapp:
    external: true    // если 'myapp' создан 'docker volume create'

// --------------------------------
// cmd.sh
#!/bin/bash
set -e
if [ "$ENV" = 'DEV' ]; then
  echo "Running Development Server"
  exec python "identidock.py"
else
  echo "Running Production Server"
  exec uwsgi --http 0.0.0.0:9090 --wsgi-file /app/identidock.py --callable app --stats 0.0.0.0:9191
fi

// Dockerfile
FROM python:3.4
RUN groupadd -r uwsgi && useradd -r -g uwsgi uwsgi
RUN pip install Flask==0.10.1 uWSGI==2.0.8 requests==2.5.1 redis==2.10.3
WORKDIR /app
COPY app /app
COPY cmd.sh /
EXPOSE 9090 9191
USER uwsgi
CMD ["/cmd.sh"]

-> docker build -t identidock .
-> docker run -d -p 5000:5000 -e "ENV=DEV" --link dnmonster:dnmonster identidock

// docker-compose.yml
identidock:
  build: .
  ports:
   - "5000:5000"  // <- python
   - "9090:9090"  // <- nginx proxy_pass http://identidock:9090;
  environment:
    ENV: DEV 
  volumes:
    - ./app:/app
  links:
    - dnmonster
    - redis
dnmonster:
  image: amouat/dnmonster:1.0
redis:
  image: redis:3.0

-> docker-compose stop
-> docker-compose rm --force -v    // v-удаление томов
-> docker-compose build --no-cache
-> docker-compose up -d

// prod.yml
proxy:
  image: proxy:1.0
  links:
    - identidock
  ports:
    - "80:80"
  environment:
    - NGINX_HOST=45.55.251.164             // proxy entrypoint.sh
    - NGINX_PROXY=http://identidock:9090   // proxy_pass {{NGINX_PROXY}};
identidock:
  image: amouat/identidock:1.0
  links:
   - dnmonster
   - redis
  environment:
    ENV: PROD
dnmonster:
  image: amouat/dnmonster:1.0
redis:
  image: redis:3

-> docker-compose -f prod.yml stop
-> docker-compose -f prod.yml rm

// bash аналог (deploy.sh)
#!/bin/bash
set -e
echo " - Starting identidock system - "
docker run -d --restart=always --name redis redis:3
docker run -d --restart=always --name dnmonster amouat/dnmonster:1.0
docker run -d --restart=always --link dnmonster:dnmonster --link redis:redis \
  -e ENV=PROD --name identidock amouat/identidock:1.0
docker run -d --restart=always --name proxy --link identidock:identidock -p 80:80 \
  -e NGINX_HOST=45.55.251.164 -e NGINX_PROXY=http://identidock:9090 amouat/proxy:1.0
echo " - Started - "
