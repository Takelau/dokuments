
// --------------------------------
//    Go + Redis
// --------------------------------

https://github.com/PacktPublishing/A-Developer-s-Essential-Guide-to-Docker-Compose

Dockerfile
docker-compose.yaml
// redis
redis.conf
// redis-populate
redis-populate.sh     // скрипт заполнения БД redis
redis-populate.txt    // иструкции Redis с полезной информацией
env.redis-populate    // параметры соединеия с БД
// redis-backup
snapshot-backup.sh    // резервная копия БД в '/backup/*.rdb'

// docker-compose.yaml
services:
  task-manager:
    build:
      context: .
      labels:
        - com.packtpub.compose.app=task-manager
    image: <repo>:5000/task-manager:0.1
    ports:
      - 8080:8080
    environment:
      - REDIS_HOST=redis:6379
    depends_on:
      - redis
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/ping"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 5s
    networks:
      - task-manager-pubic-network
      - redis-network
    labels:
      - com.packtpub.compose.app=task-manager

  redis:
    image: redis
    ports:
      - 6379:6379
    entrypoint: ["redis-server","/usr/local/etc/redis/redis.conf"]
    volumes:
      - ./redis.conf:/usr/local/etc/redis/redis.conf   // bimnd config
      - redis-data:/data                               // volumes 'redis-data'
      - backup:/backup                                 // volumes 'backup'
    networks:
      - redis-network
    labels:
      - com.packtpub.compose.app=task-manager

  redis-backup:
    image: bash
    entrypoint: ["/snapshot-backup.sh"]
    depends_on:
      - redis
    environment:
      - BACKUP_PERIOD=10
    volumes:
      - ./snapshot-backup.sh:/snapshot-backup.sh
      - redis-data:/data:ro                           // volumes 'redis-data' только для чтения
      - backup:/backup                                // volumes 'backup'
    networks:
      - task-manager-pubic-network
    labels:
      - com.packtpub.compose.app=task-manager

  redis-populate:
    image: redis
    entrypoint: ["/redis-populate.sh","/redis-populate.txt"]
    depends_on:
      - redis
    env_file:
      - ./env.redis-populate
    volumes:
      - ./redis-populate.txt:/redis-populate.txt
      - ./redis-populate.sh:/redis-populate.sh
    networks:
    	- redis-network
    labels:
      - com.packtpub.compose.app=task-manager

	volumes:
	  redis-data:
	    labels:
	      - com.packtpub.compose.app=task-manager
	  backup:
	    labels:
	      - com.packtpub.compose.app=task-manager
	
	networks:
	  task-manager-pubic-network:
	    labels:
	      - com.packtpub.compose.app=task-manager
	  redis-network:
	    labels:
	      - com.packtpub.compose.app=task-manager

docker compose build    // запуск сборки image task-manager:0.1
docker compose push     // отправка образа в реестр
docker compose up


// Dockerfile
FROM golang:1.17-alpine
RUN apk add curl           // curl требуется для healthcheck
WORKDIR /app
COPY go.mod ./
COPY go.sum ./
RUN go mod download
COPY *.go ./
RUN go build -o /task_manager
EXPOSE 8080
CMD [ "/task_manager" ]

docker build . -t task-manager:0.1  // docker run --rm -p 8080:8080 --env REDIS_HOST=host.docker.internal:6379 task-manager:0.1


// main.go
  client = redis.NewClient(&redis.Options{
    Addr:     getStrEnv("REDIS_HOST", "localhost:6379"),  // <-- REDIS_HOST
    Password: getStrEnv("REDIS_PASSWORD", ""),
    DB:       getIntEnv("REDIS_DB", 0),
  })
  v := client.HGetAll(c, fmt.Sprintf("task:%s", id))
  func getStrEnv(key string, defaultValue string) string {
    if value := os.Getenv(key); len(value) == 0 { return defaultValue; }
    else { return value; }
  }


// redis-populate.sh
#!/bin/sh
cat $1| redis-cli -h $HOST -p $PORT


// redis-populate.txt
HMSET task:a3a597d1-26f8-43e5-be05-81373f2c0dc3 Id a3a597d1-26f8-43e5-be05-81373f2c0dc3 Name "Existing Task" Description "A task that was here before" Timestamp 1645393434000
ZADD tasks 1645393434000 "a3a597d1-26f8-43e5-be05-81373f2c0dc3"


// env.redis-populate
HOST=redis
PORT=6379


// redis.conf
dbfilename taskmanager.rdb  // имя резервной копии
save 60 1                   // создание снимка каждые 60 сек если изменился хотябы 1 ключ


// snapshot-backup.sh
#!/bin/sh
while true; do cp /data/taskmanager.rdb /backup/$(date +%s ).rdb; sleep $BACKUP_PERIOD; done
