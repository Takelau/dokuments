
// --------------------------------
// client + server | links (метод 77 - 280) 
1. // client
FROM debian
RUN apt-get update && apt-get install -y python
ADD client.py /client.py
CMD ["/usr/bin/python","/client.py"]

// client.py
s.connect(('talkto',2000))

docker build -t client .


2. // server
FROM debian
RUN apt-get update && apt-get install -y nmap  // nmap - установочный пакет ncat
CMD ncat -l 2000 -k --exec /bin/cat

docker build -t server .

// docker-compose.yml
version: "3"
  services:
    echo-server:
      image: server
      expose:
      - "2000"
    client:
      image: client
      links:
      - echo-server:talkto  // Обращения к «talkto» внутри клиента будут отправлены на эхо-сервер

docker-compose up