
// --------------------------------
//    Go + Micro
// --------------------------------

/location-service/Dockerfile  // локальный сервис
/location-service/main.go
/task-manager/Dockerfile      // клиентский сервис
/task-manager/main.go
/events-service/main.go       // локальная нагрузка
prometheus.yaml        // prometheus config
alerts.yml             // prometheus alert
docker-compose.yaml

// docker-compose.yaml
services: 
  location-service: 
    build: 
      context: ./location-service/
    image: location-service:0.1 
    environment: 
      - REDIS_HOST=redis:6379 
    depends_on: 
      - redis 
    networks: 
      - location-network 
      - redis-network 
      - monitoring-network            // prometheus network
    healthcheck: 
      test: ["CMD", "curl", "-f", "http://localhost:8080/ping"] 
      interval: 10s 
      timeout: 5s 
      retries: 5 
      start_period: 5s 

  task-manager: 
    build: 
      context: ./task-manager/
    image: task-manager:0.1
    ports: 
      - 8080:8080 
    environment: 
      - REDIS_HOST=redis:6379 
      - LOCATION_HOST=http://location-service:8080
    depends_on: 
      - redis 
      - location-service
    networks: 
      - location-network 
      - redis-network 
      - monitoring-network            // prometheus network
    healthcheck: 
      test: ["CMD", "curl", "-f", "http://localhost:8080/ping"] 
      interval: 10s 
      timeout: 5s 
      retries: 5 
      start_period: 5s 

  event-service: 
    build: 
      context: ./events-service/
    image: event-service:0.1 
    environment: 
      - REDIS_HOST=redis:6379
      - PUSH_GATEWAY=push-gateway:9091  // prometheus push-gateway
    depends_on: 
      - redis 
    networks: 
      - redis-network
      - monitoring-network              // prometheus network

  redis: 
    image: redis 
    networks:
      - redis-network

  prometheus:
    image: prom/prometheus
    ports: 
      - 9090:9090
    volumes:
      - ./prometheus.yaml:/etc/prometheus/prometheus.yml
      - ./alerts.yml:/etc/prometheus/alerts.yaml
    networks:
      - monitoring-network
    depends_on:
      - task-manager

  push-gateway:
    image: prom/pushgateway
    networks:
      - monitoring-network

networks:
  location-network:
  redis-network:
  monitoring-network:

// prometheus.yaml
scrape_configs: 
  - job_name: 'task-manager' 
    scrape_interval: 1m 
    metrics_path: '/metrics' 
    static_configs: 
      - targets: ['task-manager:8080'] 
  - job_name: 'location-service' 
    scrape_interval: 1m 
    metrics_path: '/metrics' 
    static_configs: 
      - targets: ['location-service:8080'] 
  - job_name: 'push-gateway' 
    scrape_interval: 1m 
    metrics_path: '/metrics' 
    static_configs: 
      - targets: ['push-gateway:9091'] 
rule_files:
  - '/etc/prometheus/alerts.yaml'

// alerts.yml
groups: 
- name: task-manager 
  rules: 
  - alert: too-many-tasks 
    expr: rate(task_event_processing_total[5m]) > 0.2    // в течении 5 мин частота добавления задач превышает 0,2 в 1 мин
    for: 1m 
    annotations: 
      summary: Too many tasks

// /location-service/Dockerfile
# syntax=docker/dockerfile:1
FROM golang:1.17-alpine
RUN apk add curl
WORKDIR /app
COPY go.mod ./
COPY go.sum ./
RUN go mod download
COPY *.go ./
RUN go build -o /location_service
EXPOSE 8080
CMD [ "/location_service" ]

// /location-service/main.go
client = redis.NewClient(&redis.Options{
	Addr:     getStrEnv("REDIS_HOST", "localhost:6379"),
	Password: getStrEnv("REDIS_PASSWORD", ""),
	DB:       getIntEnv("REDIS_DB", 0),
})
func main() {
	r.Run(":8080")
}

// /task-manager/Dockerfile
# syntax=docker/dockerfile:1
FROM golang:1.17-alpine
RUN apk add curl
WORKDIR /app
RUN mkdir location 
RUN mkdir task 
RUN mkdir stream
COPY go.mod ./
COPY go.sum ./
RUN go mod download
COPY *.go ./
COPY location/*.go ./location    <--*/
COPY task/*.go ./task            <--*/
COPY stream/*.go ./stream        <--*/
RUN go build -o /task_manager
EXPOSE 8080
CMD [ "/task_manager" ]

// /task-manager/main.go
client = redis.NewClient(&redis.Options{
	Addr:     getStrEnv("REDIS_HOST", "localhost:6379"),
	Password: getStrEnv("REDIS_PASSWORD", ""),
	DB:       getIntEnv("REDIS_DB", 0),
})
locationService = location.LocationService{
	LocationServiceEndpoint: getStrEnv("LOCATION_HOST", "http://localhost:8081"),
}
func (ls *LocationService) FindLocation(id string) (*Location, error) {
	endpoint := fmt.Sprintf("%s/location/%s", ls.LocationServiceEndpoint, id)
	respose, err := http.Get(endpoint)
}
func main() {
	r.Run(getStrEnv("TASK_MANAGER_HOST", ":8080"))   // НЕ ЗАДАН
}

// /events-service/main.go
import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/push"
)
var (
	client = redis.NewClient(&redis.Options{
		Addr:     getStrEnv("REDIS_HOST", "localhost:6379"),
		Password: getStrEnv("REDIS_PASSWORD", ""),
		DB:       getIntEnv("REDIS_DB", 0),
	})
	processingTime = prometheus.NewGauge(prometheus.GaugeOpts{ Name:"task_event_process_duration", Help:"Time it took to complete a task", })
	processedCounter = prometheus.NewCounterVec(prometheus.CounterOpts{ Name:"task_event_processing_total", Help:"How many tasks have been processed", },
		[]string{"task"},
	).WithLabelValues("task")
)
func pushProcessingDurationToPrometheus(processingTime prometheus.Gauge) {
	if err := push.New(getStrEnv("PUSH_GATEWAY", "http://localhost:9091"), "task_event_process_duration").
		Collector(processingTime).
		Grouping("db", "event-service").
		Push(); err != nil {
		fmt.Println("Could not push completion time to Pushgateway:", err)
	}
}
func pushProcessingCount(processedCounter prometheus.Counter) {
	if err := push.New(getStrEnv("PUSH_GATEWAY", "http://localhost:9091"), "task_event_processing_total").
		Collector(processedCounter).
		Grouping("db", "event-service").
		Push(); err != nil {
		fmt.Println("Could not push tasks processed to Pushgateway:", err)
	}
}
func main() {
	for {
		start := time.Now()
		// ... нагрузка ...
		millis := float64(time.Since(start).Milliseconds())

		processedCounter.Add(1)
		processingTime.Set(millis)

		pushProcessingDurationToPrometheus(processingTime)
		pushProcessingCount(processedCounter)
	}
}