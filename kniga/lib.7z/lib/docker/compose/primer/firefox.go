# Firefox over VNC

from	ubuntu:12.04
run	echo "deb http://archive.ubuntu.com/ubuntu precise main universe" > /etc/apt/sources.list
run	apt-get update
run	apt-get install -y x11vnc xvfb firefox
run	mkdir /.vnc
run	x11vnc -storepasswd 1234 ~/.vnc/passwd   // 1234 <- password
run	bash -c 'echo "firefox" >> /.bashrc
