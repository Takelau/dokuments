
// --------------------------------
//    Nginx
// --------------------------------
// 1. static-site/index.html
<!DOCTYPE html>
<html>
	<head><title>Test</title></head>
	<body><p>Test</p></body>
</html>

// 2. проверка 'curl localhost:8080/index.html'
docker run --rm -p 8080:80 --name nginx-compose -v $(pwd)/static-site:/usr/share/nginx/html nginx

// 3. docker-compose.yaml
services:
	nginx:
		image: nginx
		ports:
			- 8080:80
		volumes:
			- ./static-site:/usr/share/nginx/html

docker compose up

