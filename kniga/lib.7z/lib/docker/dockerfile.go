
FROM <o>:<tag>
LABEL version="1.0"
ARG web_user=nginx   // --build-arg web_user=apache - передача аргумета при сборке (docker build ...)
ADD        // распаковка .gz, .bz2, .xz, .tar
COPY from to | COPY ["from", "to"]  // копирование
CMD ["/bin/bash"]  //  выполняется только самая последняя инструкция CMD
ENTRYPOINT // определяет выполняемый файл (и аргументы по умолчанию)
ENV        // определяет переменные среды внутри образа
EXPOSE     // объявление порта
MAINTAINER // метаданные об авторе
ONBUILD    // тригеры для последующих сборок
RUN apt-get update; apt-get install -y nginx
USER       // пользователь под которым будет запущен контейнер (docker run -u nginx ...)
VOLUME     // объявляет заданный файл или каталог как том
WORKDIR    // определяет рабочий каталог для последующих инструкций: RUN,CMD,ENTRYPOINT,ADD,COPY


// --------------------------------
//    Env
// --------------------------------
ENV TARGET_DIR /opt/app
WORKDIR $TARGET_DIR

ENV PG_MAJOR=9.3
ENV PG_VERSION=9.3.4
RUN curl -SL https://example.com/postgres-$PG_VERSION.tar.xz | tar -xJC /usr/src/postgres && …


// --------------------------------
//    COPY & ADD
// --------------------------------
// копия конфигурационных файлов из папки 'conf.d/' в директорию '/etc/apache2/'
COPY conf.d/ /etc/apache2/ 


// --------------------------------
// распаковка архива в образ / gz bz2 xz tar
ADD arch.tar.gz /dir/

// --------------------------------
// передача аргумента из 'docker run'
COPY entrypoint.sh /
ENTRYPOINT ["/entrtypoint.sh"]      // вызывается при запуске 'docker run'
CMD ["PARAM"]                       // передача параметра в скрипт по умолчанию


// --------------------------------
//    Volume
// --------------------------------
// том хоста / права доступа
RUN useradd foo
RUN mkdir /data && touch /data/x
RUN chown -R foo:foo /data
VOLUME /data

// --------------------------------
// Контейнер данных (метод 37 155)
docker run -v /shared-data --name dc busybox      // создание контейнера данных 'dc'
docker run -it --volumes-from dc busybox /bin/sh  // доступ к каталогу через контейнер данных 'dc'


// --------------------------------
// Resilio (151)
[host1] docker run -d -p 8888:8888 -p 55555:55555 --name resilio ctlc/btsync
[host1] docker logs resilio  // <CODE>
[host1] docker run -i -t --volumes-from resilio ubuntu /bin/bash
	touch /data/shared_from_server_one
	ls /data
[host2] docker run -d -p 8888:8888 -p 55555:55555 --name resilio-client ctlc/btsync <CODE>
[host2] docker run -i -t --volumes-from resilio-client ubuntu bash
	ls /data


// --------------------------------
//    Общее
// --------------------------------
// ограничение прав
RUN groupadd -r user_grp && useradd -r -g user_grp user
USER user


// --------------------------------
// установка времени
FROM centos:7
RUN rm -rf /etc/localtime
RUN ln -s /usr/share/zoneinfo/GMT /etc/localtime
CMD date +%Z        // Показывает часовой пояс контейнера

// --------------------------------
// локали
RUN apt-get install -y locales
RUN locale-gen en_US.UTF-8
ENV LANG en_US.UTF-8
ENV LANGUAGE="en_US:en"

// CentOS
RUN localedef -i en_US -f UTF-8 en_US.UTF-8


// --------------------------------
//    Build
// --------------------------------
// отмена кеширования (варианты)
1. docker build --no-cache .
2. # коммент
3. ARG CACHEBUST=no  <- docker build --build-arg CACHEBUST=${RANDOM} .  // CACHEBUST=$(date +%s)
4. ADD https://web.ru/version  /dev/null

// --------------------------------
// multy-stage
FROM golang:1.21 as build        // stage 1 с именем 'build'
WORKDIR /src
COPY main.go .
RUN go build -o /bin/hello ./main.go

FROM scratch                     // stage 2 копирует файл 'hello' из сборки 'build'
COPY --from=build /bin/hello /bin/hello
CMD ["/bin/hello"]

docker build -t hello .

// --------------------------------
// Re-Build
#!/bin/bash
imageName=$1
containerName=$2
docker build -t $imageName -f Dockerfile  .
docker rm -f $containerName
docker run -d -p 5000:5000 --name $containerName $imageName

// --------------------------------
docker build -t <image>:latest -<<EOF
FROM busybox
RUN echo "test"
EOF

// --------------------------------
// https://docs.docker.com/build/building/context/#url-fragments
1. // dockerfile должен существовать на git
docker build https://github.com/user/myrepo.git
2. // если на git отсутствует dockerfile
docker build -t <image>:latest -f- https://github.com/user/myrepo.git <<EOF
FROM busybox
COPY hello.c ./
EOF


// --------------------------------
// нумерация слоёв по порядку (27)
// image_stepper
#!/bin/bash
IMAGE_NAME=$1
IMAGE_TAG=$2
if [[ $IMAGE_NAME = '' ]]
then
    echo "Usage: $0 IMAGE_NAME [ TAG ]"
    exit 1
fi
if [[ $IMAGE_TAG = '' ]]
then
	IMAGE_TAG=latest
fi
x=1
for id in $(docker history -q "${IMAGE_NAME}:${IMAGE_TAG}" | grep -vw missing | tac)
do
    docker tag "${id}" "${IMAGE_NAME}:${IMAGE_TAG}_step_$x"
    ((x++))
done

// Dockerfile
FROM ubuntu
RUN apt-get update -y && apt-get install -y docker.io
ADD image_stepper /usr/local/bin/image_stepper
ENTRYPOINT ["/usr/local/bin/image_stepper"]

docker build -t myimage -q .


// --------------------------------
// Сохранение истории Bash
# ~/.bashrc
1. alias dockbash='docker run -e HIST_FILE=/root/.bash_history -v=$HOME/.bash_history:/root/.bash_history'
2. 
function basher() {
	if [[ $1 = 'run' ]]
	then
		shift
		/usr/bin/docker run \
		-e HIST_FILE=/root/.bash_history \
		-v $HOME/.bash_history:/root/.bash_history "$@"
	else
		/usr/bin/docker "$@"
	fi
}
alias docker=basher


// --------------------------------
// .dockerignore
.git
*/.git
*/*/.git
*.sw?
