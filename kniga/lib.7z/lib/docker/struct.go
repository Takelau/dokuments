
docker ps -a
CONTAINER ID   IMAGE       COMMAND   CREATED       STATUS       PORTS     NAMES
304a71a0f2af   fedora:35   "bash"    2 hours ago   Up 2 hours             fed-1_0
4b0cc089a7d3   nami:1.5    "bash"    2 days ago    Up 2 hours             nami-1_5

docker images
REPOSITORY   TAG       IMAGE ID       CREATED        SIZE
nami         2.1       faa23c3a154b   2 days ago     107MB
nami         2.0       42e02eefb52f   2 days ago     107MB
nami         1.5       e0d582f1216a   4 days ago     107MB
ubuntu       20.04     54c9d81cbb44   3 weeks ago    72.8MB
fedora       35        b78af7a83692   2 months ago   153MB

docker inspect nami-1_5
"Image": "nami:1.5"
"Id": "4b0cc089a7d305438e24ea5fbbd557d21add09def4830a665d24255d2d22932a"
"Image": "sha256:e0d582f1216a3ddd07173a93e38a7227a123ef4498aaa0780418ffe8e438175a"
"HostsPath": "/var/lib/docker/containers/4b0cc089a7d305438e24ea5fbbd557d21add09def4830a665d24255d2d22932a/hosts"
"ShmSize": 67108864,
"LowerDir": "/var/lib/docker/overlay2/e7af623da0ceb86e5209ec1b015838eb2485f66e53221d81a859cfa3f07a7d28-init/diff:
             /var/lib/docker/overlay2/f25795b102c03f448ce10672bb22eb3fb8058e20d5a03b20dbdf3865133bc8ef/diff",
"UpperDir": "/var/lib/docker/overlay2/e7af623da0ceb86e5209ec1b015838eb2485f66e53221d81a859cfa3f07a7d28/diff"

docker inspect fed-1_0
"Image": "fedora:35"
"Id": "304a71a0f2af61cae10c19eb99b7ec715382d75d062481276e70ad76cfcc4e32"
"Image": "sha256:b78af7a836928efd44317e82c8f2f9c86bb83ae915deef1b58dc6465dfa5436e"
"HostsPath": "/var/lib/docker/containers/304a71a0f2af61cae10c19eb99b7ec715382d75d062481276e70ad76cfcc4e32/hosts"
"ShmSize": 67108864,
"LowerDir": "/var/lib/docker/overlay2/34d0c5543eddf0977ab149be2f34fe052ac786d90cff4f5e26cd05cae4a0bbda-init/diff:
             /var/lib/docker/overlay2/877d9915a9eb916093c7ac52d74826a7e5fa28a4c44254a838bd54f4d540352a/diff",
"UpperDir": "/var/lib/docker/overlay2/34d0c5543eddf0977ab149be2f34fe052ac786d90cff4f5e26cd05cae4a0bbda/diff",

docker inspect nami:1.5
"Id": "sha256:e0d582f1216a3ddd07173a93e38a7227a123ef4498aaa0780418ffe8e438175a"
"Parent": ""
"Container": ""
"WorkDir": "/var/lib/docker/overlay2/f25795b102c03f448ce10672bb22eb3fb8058e20d5a03b20dbdf3865133bc8ef/work"
"Layers": ["sha256:1abb53142465db5fcc962cf091c018f5e0664e928f4f2fd888a9ef3cf8c47c2d"]

docker inspect nami:2.0
"Id": "sha256:42e02eefb52f70101f4aff01d704b0cc4062f62e9a4b157ae54845c80d899a63"
"Parent": "sha256:e0d582f1216a3ddd07173a93e38a7227a123ef4498aaa0780418ffe8e438175a"
"Container": "4b0cc089a7d305438e24ea5fbbd557d21add09def4830a665d24255d2d22932a"
"WorkDir": "/var/lib/docker/overlay2/2fb841ee4f8c4aedcf41f6b5535b61de84b549055106be2ed97e5117f963c174/work"
"Layers": [
	"sha256:1abb53142465db5fcc962cf091c018f5e0664e928f4f2fd888a9ef3cf8c47c2d",
	"sha256:76ddc521da1475f2275d7c77573f551e1abd43ff9bc3aad4d117bd18919c8a0e"       <-- ?
]

docker inspect nami:2.1
"Id": "sha256:faa23c3a154b7ece7f38e67c507ccc1e7ff31539a9e89b43e0bd2637dc3a0561"
"Parent": ""
"Container": ""
"WorkDir": "/var/lib/docker/overlay2/ae1f8fc8c0bd5ea59761e16ec8541fbf1c0fa4d3da7c3467734c1b32b66d77ec/work"
"Layers": ["sha256:57508b0096629a44fe414e995608acd7312869f23152680a655ef5f2c5945a45"]

docker inspect fedora:35
"Id": "sha256:b78af7a836928efd44317e82c8f2f9c86bb83ae915deef1b58dc6465dfa5436e"
"Parent": ""
"Container": "7c20b53a548cb4c2febbdf8cfea3a8e0b9f2ec35a8bf9f5a715d6f69b6be8c34"
"WorkDir": "/var/lib/docker/overlay2/877d9915a9eb916093c7ac52d74826a7e5fa28a4c44254a838bd54f4d540352a/work"
"Layers": ["sha256:389adea752cd55355cae09d2b3038c0b155e992a0d32fcecb3d281abf6a8c5cf"]

docker inspect ubuntu:20.04
"Id": "sha256:54c9d81cbb440897908abdcaa98674db83444636c300170cfd211e40a66f704f"
"Parent": ""
"Container": "3d4cc5cf7dc1af55a2be4440b5be4f96ea35516b98407a9b9446c218bb43818a"
"WorkDir": "/var/lib/docker/overlay2/7d598bc1a78b815326f6e15a0877bc2179113ff83d470898395fa66adda7a0d3/work"
"Layers": ["sha256:36ffdceb4c77bf34325fb695e64ea447f688797f2f1e3af224c29593310578d2"]

┌<─ /var/lib/docker/containers ───────────────────────────────.[^]>┐
│.n                   Name                    │ Size  │Modify time │
│/..                                          │UP--DIR│Feb 23 13:56│
│/304a71a0f2af61cae10c19~481276e70ad76cfcc4e32│1218903│Feb 23 16:00│ fed-1_0
│/4b0cc089a7d305438e24ea~30a665d24255d2d22932a│ 853757│Feb 23 15:56│ nami-1_5

┌<─ /var/lib/docker/overlay2 ────────────────────────────────.[^]>┐
│.n                    Name                     │Size│Modify time │
│/..                                            │-DIR│Feb 23 13:56│
│/2fb841ee4f8c4aedcf41f6b~06be2ed97e5117f963c174│ 292│Feb 21 15:05│ nami:2.0 WorkDir
│/7d598bc1a78b815326f6e15~470898395fa66adda7a0d3│ 73M│Feb 18 20:20│ ubuntu:20.04 WorkDir
│/ae1f8fc8c0bd5ea59761e16~7c3467734c1b32b66d77ec│105M│Feb 21 15:20│ nami:2.1 WorkDir
│/34d0c5543eddf0977ab149b~ff4f5e26cd05cae4a0bbda│429M│Feb 23 16:00│ fed-1_0
│/34d0c5543eddf0977ab149b~e26cd05cae4a0bbda-init│  66│Feb 23 16:00│ fed-1_0
│/877d9915a9eb916093c7ac5~4254a838bd54f4d540352a│146M│Feb 23 15:58│ fed-1_0  fedora:35 WorkDir
│/e7af623da0ceb86e5209ec1~221d81a859cfa3f07a7d28│307M│Feb 23 15:56│ nami-1_5
│/e7af623da0ceb86e5209ec1~1a859cfa3f07a7d28-init│  66│Feb 21 15:00│ nami-1_5
│/f25795b102c03f448ce1067~a03b20dbdf3865133bc8ef│105M│Feb 21 15:00│ nami-1_5 nami:1.5 WorkDir

┌<─ /var/lib/docker/image/overlay2/layerdb/sha256 ──────────.[^]>┐
│.n                  Name                   │ Size  │Modify time │
│/..                                        │UP--DIR│Feb 18 20:20│
│/1abb53142465db5fcc962~2fd888a9ef3cf8c47c2d│ 185891│Feb 19 01:06│ nami:2.0 Layers  nami:1.5 Layers
│/36ffdceb4c77bf34325fb~3af224c29593310578d2│ 179582│Feb 16 21:20│ ubuntu:20.04 Layers
│/389adea752cd55355cae0~fcecb3d281abf6a8c5cf│ 456021│Feb 16 21:15│ fedora:35 Layers
│/57508b0096629a44fe414~680a655ef5f2c5945a45│ 185876│Feb 21 15:20│ nami:2.1 Layers
│/9caa3a81760cbeaffa587~c3e500686d7f6e57ecae│    629│Feb 21 15:05│

┌<─ /var/lib/docker/image/overlay2/imagedb/content/sha256 ───.[^]>┐
│.n                  Name                    │ Size  │Modify time │
│/..                                         │UP--DIR│Feb 15 20:50│
│ faa23c3a154b7ece7f38e~89b43e0bd2637dc3a0561│    889│Feb 21 15:20│ nami:2.1
│ 42e02eefb52f70101f4af~b157ae54845c80d899a63│   1111│Feb 21 15:05│ nami:2.0
│ e0d582f1216a3ddd07173~aa0780418ffe8e438175a│    889│Feb 19 01:06│ nami:1.5
│ 54c9d81cbb440897908ab~0170cfd211e40a66f704f│   1462│Feb 16 21:20│ ubuntu:20.04
│ b78af7a836928efd44317~eef1b58dc6465dfa5436e│   1995│Feb 16 21:15│ fedora:35

┌<─ /var/lib/docker ──────────────────────────────────────────.[^]>┐
│.n                    Name                      │Size│Modify time │
│/..                                             │-DIR│Feb 15 20:50│
│/builder                                        │ 16K│Feb 15 20:50│
│/buildkit                                       │ 64K│Feb 15 20:50│
│/containers                                     │  2M│Feb 23 16:00│
│/image                                          │994K│Feb 15 20:50│
│/network                                        │ 64K│Feb 15 20:50│
│/overlay2                                       │  1G│Feb 23 16:00│
│/plugins                                        │   0│Feb 15 20:50│
│/runtimes                                       │   0│Feb 23 13:56│
│/swarm                                          │   0│Feb 15 20:50│
│/tmp                                            │   0│Feb 23 13:56│
│/trust                                          │   0│Feb 15 20:50│
│/volumes                                        │ 32K│Feb 15 20:50│
│ test                                           │   6│Feb 15 19:21│
