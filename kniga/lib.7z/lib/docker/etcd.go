
// --------------------------------
//    etcd
// --------------------------------
// 1. proxy + backend  (метод 74 - 269)
IMG=quay.io/coreos/etcd:v3
docker pull $IMG

HTTPIP=http://192.168.1.123
CLUSTER="etcd0=$HTTPIP:2380,etcd1=$HTTPIP:2480,etcd2=$HTTPIP:2580"
ARGS="etcd"
ARGS="$ARGS -listen-client-urls http://0.0.0.0:2379"   // List of URLs to listen on for client traffic
ARGS="$ARGS -listen-peer-urls http://0.0.0.0:2380"     // List of URLs to listen on for peer traffic
ARGS="$ARGS -initial-cluster-state new"                // 'new' or 'existing'
ARGS="$ARGS -initial-cluster $CLUSTER"
docker run -d -p 2379:2379 -p 2380:2380 --name etcd0 $IMG $ARGS -name etcd0 -advertise-client-urls $HTTPIP:2379 -initial-advertise-peer-urls $HTTPIP:2380
docker run -d -p 2479:2379 -p 2480:2380 --name etcd1 $IMG $ARGS -name etcd1 -advertise-client-urls $HTTPIP:2479 -initial-advertise-peer-urls $HTTPIP:2480
docker run -d -p 2579:2379 -p 2580:2380 --name etcd2 $IMG $ARGS -name etcd2 -advertise-client-urls $HTTPIP:2579 -initial-advertise-peer-urls $HTTPIP:2580
// проверка
curl -L $HTTPIP:2579/version

// PROXY
docker run -d -p 8080:8080 --restart always --name etcd-proxy $IMG etcd -proxy on -listen-client-urls http://0.0.0.0:8080 -initial-cluster $CLUSTER
// проверка
curl -L $HTTPIP:8080/version  // {"etcdserver":"3.2.7","etcdcluster":"3.2.0"}


// 2. single node etcd
export NODE1=192.168.1.21
docker volume create --name etcd-data
export DATA_DIR="etcd-data"

REGISTRY=quay.io/coreos/etcd
REGISTRY=gcr.io/etcd-development/etcd  // available from v3.2.5

docker run -p 2379:2379 -p 2380:2380 --volume=${DATA_DIR}:/etcd-data --name etcd ${REGISTRY}:latest \
	/usr/local/bin/etcd \
	--data-dir=/etcd-data --name node1 \
	--initial-advertise-peer-urls http://${NODE1}:2380 --listen-peer-urls http://0.0.0.0:2380 \
	--advertise-client-urls http://${NODE1}:2379 --listen-client-urls http://0.0.0.0:2379 \
	--initial-cluster node1=http://${NODE1}:2380

etcdctl --endpoints=http://${NODE1}:2379 member list


// --------------------------------
//    systemd
// --------------------------------
// 1. container auto start | 1 host (метод 82)
// nano /etc/systemd/system/todo.service
[Unit]
Description=Simple ToDo Application
After=docker.service
Requires=docker.service
[Service]
Restart=always
ExecStartPre=/bin/bash -c '/usr/bin/docker rm -f todo || /bin/true'
ExecStartPre=/usr/bin/docker pull dockerinpractice/todo
ExecStart=/usr/bin/docker run --name todo -p 8000:8000 dockerinpractice/todo
ExecStop=/usr/bin/docker rm -f todo
[Install]
WantedBy=multi-user.target

systemctl enable todo.service
systemctl start  todo.service
systemctl status todo.service


// --------------------------------
// 2. proxy + backend | 1 host (метод 83)
// nano /etc/systemd/system/sqliteserver.service
[Unit]
Description=SQLite Docker Server
After=docker.service     // Запускает данный юнит после запуска службы Docke
Requires=docker.service  // Для успешного запуска этого юнита должна быть запущена служба Docker
[Service]
Restart=always
ExecStartPre=-/bin/touch /tmp/sqlitedbs/test // '-перед touch' указывает, что запуск должен завершиться неудачно, если команда возвращает код ошибки
ExecStartPre=-/bin/touch /tmp/sqlitedbs/live
ExecStartPre=/bin/bash -c '/usr/bin/docker kill sqliteserver  || /bin/true'
ExecStartPre=/bin/bash -c '/usr/bin/docker rm -f sqliteserver || /bin/true'
ExecStartPre=/usr/bin/docker pull dockerinpractice/docker-compose-sqlite
ExecStart=/usr/bin/docker run --name sqliteserver -v /tmp/sqlitedbs/test:/opt/sqlite/db dockerinpractice/docker-compose-sqlite \
// EXEC сообщает socat запускать SQLite в файле /opt/sqlite/db для каждого подключения, присваивая псевдотерминал процессу
/bin/bash -c 'socat TCP-L:12345,fork,reuseaddr EXEC:"sqlite3 /opt/sqlite/db",pty'
ExecStop=/usr/bin/docker rm -f sqliteserver
[Install]
WantedBy=multi-user.target

// /etc/systemd/system/sqliteproxy.service
[Unit]
Description=SQLite Docker Proxy
Requires=sqliteserver.service  // создание зависимости от 'sqliteserver'
After=sqliteserver.service     // последовательность запуска
[Service]
Restart=always
ExecStartPre=/bin/bash -c '/usr/bin/docker kill sqliteproxy  || /bin/true'
ExecStartPre=/bin/bash -c '/usr/bin/docker rm -f sqliteproxy || /bin/true'
ExecStartPre=/usr/bin/docker pull dockerinpractice/docker-compose-sqlite
ExecStart=/usr/bin/docker run --name sqliteproxy -p 12346:12346 --link sqliteserver:sqliteserver dockerinpractice/docker-compose-sqlite \
/bin/bash -c 'socat TCP-L:12346,fork,reuseaddr TCP:sqliteserver:12345'
ExecStop=/usr/bin/docker rm -f sqliteproxy
[Install]
WantedBy=multi-user.target

systemctl enable sqliteserver.service && systemctl enable sqliteproxy.service
systemctl start sqliteproxy  // авто запуск зависимотей
telnet localhost 12346       // тест
