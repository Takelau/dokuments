
// --------------------------------
//    Jenkins
// --------------------------------
// Jenkins сервер
FROM jenkins
COPY jenkins_plugins.txt /tmp/jenkins_plugins.txt
RUN /usr/local/bin/plugins.sh /tmp/jenkins_plugins.txt
USER root
RUN rm /tmp/jenkins_plugins.txt
RUN groupadd -g 999 docker
RUN addgroup -a jenkins docker
USER jenkins

// build + run
docker build -t jenkins_srv .
docker run --name jenkins-srv -p 8080:8080 -p 50000:50000 \
-v /var/run/docker.sock:/var/run/docker.sock -v /tmp:/var/jenkins_home \
-d jenkins_srv

// Swarm
--> http://localhost:8080
Manage Jenkins > Manage Plugins > Installed
(Управление Jenkins > Управление плагинами > Установлено) 
+ Swarm

// --------------------------------
// ведомое устройство Jenkins
FROM ubuntu:16.04
ENV DEBIAN_FRONTEND noninteractive
RUN groupadd -g 1000 jenkins_slave
RUN useradd -d /home/jenkins_slave -s /bin/bash -m jenkins_slave -u 1000 -g jenkins_slave
RUN echo jenkins_slave:jpass | chpasswd
RUN apt-get update && apt-get install -y openssh-server openjdk-8-jre wget iproute2
RUN mkdir -p /var/run/sshd
CMD ip route | grep "default via" | awk '{print $3}' && /usr/sbin/sshd -D

docker build -t jenkins_slave .
docker run --name jenkins-slave -ti -p 2222:22 jenkins_slave

--> http://localhost:8080
Build Executor Status > New Node  -> добавить имя узла как 'Permanent Agent'
- установите для удаленного корневого каталога значение /home/jenkins_slave;
- присвойте ему ярлык 'dockerslave';
- убедитесь, что выбрана опция 'Launch Slave Agents Via SSH';
- установите для хоста IP­адрес маршрута, видимый из контейнера (вывод с помощью команды docker run ранее);
- нажмите кнопку Add (Добавить), чтобы добавить учетные данные, и установите для имени пользователя значение «jenkins_slave» и пароль «jpass». Теперь выберите эти учетные данные из выпадающего списка;
- задайте для поля 'Host Key Verification Strategy' значение 'Manually Trusted Key Verification Strategy', при котором SSH­ключ будет принят при первом подключении, либо 'Non Verifying Verification Strategy', при котором проверка ключа выполняться не будет;
- нажмите Advanced (Дополнительно), чтобы открыть поле Порт, и установите для него значение 2222;
- нажмите Save (Сохранить)
--> Launch Slave Agent

Home -> New Item
- Создайте проект 'Freestyle'
- в разделе 'Build' нажмите 'Add Build Step' > 'Execute Shell' с командой 'echo done'
- Прокрутите страницу вверх и выберите 'Restrict Where Project Can Be Run' (Ограничить место выполнения проекта), введите выражение метки 'dockerslave'
- Вы должны увидеть, что 'Slaves In Label' имеет значение 1
--> Save
--> Build Now -> по ссылке build "# 1"
--> Console Output  // Finished: SUCCESS

// --------------------------------
// ведомое устройство Jenkins + Swarm plagin (client)
FROM ubuntu:16.04
ENV DEBIAN_FRONTEND noninteractive
RUN groupadd -g 1000 jenkins_slave
RUN useradd -d /home/jenkins_slave -s /bin/bash -m jenkins_slave -u 1000 -g jenkins_slave
RUN echo jenkins_slave:jpass | chpasswd
RUN apt-get update && apt-get install -y openssh-server openjdk-8-jre wget iproute2
RUN wget -O /home/jenkins_slave/swarm-client-3.4.jar https://repo.jenkins-ci.org/releases/org/jenkins-ci/plugins/swarm-client/3.4/swarm-client-3.4.jar
COPY startup.sh /usr/bin/startup.sh
RUN chmod +x /usr/bin/startup.sh
ENTRYPOINT ["/usr/bin/startup.sh"]

Имя пользователя и пароль должны быть учетной записью в вашем экземп­ляре Jenkins с разрешением на создание ведомых устройств

// startup.sh (java)
#!/bin/bash
export HOST_IP=$(ip route | grep ^default | awk '{print $3}')
export JENKINS_IP=${JENKINS_IP:-$HOST_IP}
export JENKINS_PORT=${JENKINS_PORT:-8080}
export JENKINS_LABELS=${JENKINS_LABELS:-swarm}
export JENKINS_HOME=${JENKINS_HOME:-$HOME}
echo "Starting up swarm client with args:"
echo "$@"
echo "and env:"
echo "$(env)"
set -x
java -jar /home/jenkins_slave/swarm-client-3.4.jar \
-sslFingerprints '[]' -fsroot "$JENKINS_HOME" -labels "$JENKINS_LABELS" \
-master http://$JENKINS_IP:$JENKINS_PORT "$@"

Home -> (New) Item
- Прокрутите страницу и выберите 'Restrict Where Project Can Be Run' -> 'swam'



