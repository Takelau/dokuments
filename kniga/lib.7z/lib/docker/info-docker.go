
https://github.com/aquasecurity/tracee/blob/main/builder/Dockerfile.alpine-tracee-container

Ctrl-P + Ctrl-Q  // выход из запущенного контейнера без его остновки
Ctrl+C           // завершение контейнера
Ctrl+Q           // отключиться от контейнера

usermod -aG docker <user>    // добавление пользователя в группу

host.docker.internal:8080

docker run [OPTIONS] IMAGE[:TAG] [COMMAND] [ARG...]     // ID=$(docker run -d -P nginx) -> $ID
docker run --name <cname> -d -p IP:HP:CP <o>            // d-фоновый режим, a-STDOUT, i-STDIN, t-терминал, h-имя хоста
docker run -i -t -v /host/dir:/cntr/dir <o> /bin/bash   // доступ к каталогу хоста
docker run -d -v $(pwd):/file:/file:ro <o>
docker run -i -t --volumes-from <cname> <o> /bin/bash   // подключение тома
docker run --rm -it --entrypoint bash <o> -c "ls -l"    // выполнение комманды в контейнере образа
	--restart=always            // Всегда перезапускать при выходе контейнера
	--restart=unless-stopped    // Всегда перезагружать, но помнить о явной остановке
	--restart=on-failure[:num]  // Перезапускать только в случае сбоя
	-e KEY=val  -e "ENV=DEV"    // определение переменных сред
	--env-file="file"           // файл с переменными среды
  --network=<net-name>        // подключение контейнера к сети
  --network=container:<cname> // подключенеи контейнера к контейнеру по его имени или ид
  --expose        // аналог инструкции EXPOSE (определяет номер порта или диапазон номеров портов)
  --entrypoint="" // заменяет ENTRYPOINT
  --isolation     // Container isolation technology
  --cpus          // Number of CPUs
  --memory, -m
  -p IP:HP:CP     // -p [optional_host_ip]:[host_port]:[container_port]/[optional_protocol]
                  // --publish target=[container_port],published=[optional_host_ip]:[host_port],protocol=[optional_protocol]
  --ip 172.30.100.104
  --mount "type=bind,source=/host/dir,target=/cntr/dir"
  --pid           // PID namespace to use
  --rm            // удалить контейнер по завершении
  --user, -u <name|uid>[:<group|gid>]
  --workdir, -w   // рабочая директория внутри контейнера
  --log-driver=journald

  --privileged    // Docker в Docker
  --read-only     // запуск контейнера с правами доступа только на чтение

docker build -t <repo>/<o>:<tag> --no-cache .     // echo ".git" > .dockerignore
docker build --build-arg CACHEBUST=$(date +%s) .  // ${RANDOM}
docker build - < <name>.tar.gz                    // STDIN

docker pull <repo>/<o>:<tag>                      // загрузка из хранилища
docker pull <ip>:5000/testing/image
docker push <repo>/<o>:<tag>                      // отправка в хранилище
docker commit [-a,m,c] <cname> <repo>/<o>:<tag>   // превращает контейнер в образ | m-коммент, a-автор, c-инструкция
docker export <cname> // экспортирует содержимое файловой системы контейнера в виде tar архива, направляя его в стандартный поток вывода STDOUT 
docker import
docker save/load      // сохраняется история

docker pause | unpause
docker restart | start | stop <cname> // stop = SIGTERM
docker attach <cname>                 // наблюдение / Ctrl+C закроет контейнер | Ctrl+Q - отключиться
docker exec -it <cname> bash          // запускает заданную команду внутри контейнера. (it-интерактивный режим, d-фоном)
docker kill <cname>                   // отправляет сигнал SIGKILL
docker kill -s SIGTRAP <cname>        // отправляет заданый сигнал
docker cp <?>                         // позволяет копировать файлы между файловыми системами контейнера и хоста
docker cp <cname>:/etc/nginx.conf nginx.conf  // копирует файл из контейнера в текущую директорию хоста

docker exec     <cname> sh -c "cat name.txt"
docker exec     <cname> echo "text"   // базовый режим - вывод на экран результатов работы
docker exec -d  <cname> find -ctime 7 -name '*log' -exec rm {} ;$  // режим демона
docker exec -it <cname> bash          // интерактивный режим - вход внутрь контейнера

docker rm -vf <cname>                 // удаление контейнера (v-удаление тома, f-работающего контейнера)
docker rm    $(docker ps -aq)
docker rm -v $(docker ps -aq -f status=exited)
docker rmi <o>:<tag>
docker ps -aq                  | xargs --no-run-if-empty docker rm -f
docker ps -aq -f status=exited | xargs --no-run-if-empty docker rm

// информация о контейнере и образе
docker search <o>        // поиск образа
docker search --filter is-official=true <o>
docker history <o>:<tag> // набор уровней образа: IMAGE | CREATED | CREATED BY | SIZE
docker inspect <cname>                 // информация о контейнере
docker inspect -f {{.Mounts}} <cname>  // 
docker port <cname>      // список портов и их сопостовлений
docker diff <cname>      // список файлов, измененных в работающем контейнере
docker logs <cname>      // список всех событий, произошедших внутри заданного контейнера
docker logs -f <cname>   // считывает журнальные записи работающего контейнера
docker stats <cname>     // CONTAINER | CPU % | MEM USAGE/LIMIT  ...
docker stats $(docker inspect -f {{.Name}} $(docker ps -q))  // статистика по всем контейнерам
docker top $(docker run -d <o>)  // = ps -f -u <ID>
docker top <cname>

docker version
docker info                   // created, restarting, running, paused, exited
docker ps -as                 // список (a-все, s-размер, q-только ID, l-последние созданные) контейнеров
docker ps -f key=value        // id, name, exited, status, network, ancestor, ...
docker ps -f status=exited    // created, restarting, running, removing, paused, exited, or dead
docker ps -f 'exited=0'       // 137-SIGKILL(9)
docker ps -f ancestor=ubuntu  // image, image:tag, image:tag@digest, short-id

docker images -a <repo>/<o>:<tag> // REPOSITORY | TAG | IMAGE ID | CREATED | SIZE
docker image ls                   // REPOSITORY | TAG | IMAGE ID | CREATED | SIZE
docker network ls                 // NETWORK ID | NAME | DRIVER | SCOPE
docker network inspect bridge     // JSON list
docker service ls                 // SERVICE ID | NAME | NETWORK | CONTAINER
docker container ls -a            // CONTAINER ID | IMAGE | COMMAND | CREATED | STATUS | PORTS | NAMES


// --------------------------------
//    Ports
// --------------------------------
-p 80:5000            h 80 -> c 5000
-p 8000-9000:5000     h rand(8000-9000) -> c 5000
-p 127.0.0.1:80:5000  h 127.0.0.1:80 -> c 5000
-p 127.0.0.1::5000    h 127.0.0.1:80 -> c 5000


// --------------------------------
//    Image
// --------------------------------
docker image history <o>      // H-размер и дата, q-только ID
docker image import [OPTIONS] file|URL|- [REPOSITORY[:TAG]]
docker image save / load      // сохранение / загрузка образа из tar архива | STDOUT / STDIN
docker image rm <o>           // удаление образа
docker image prune [OPTIONS]  // удалить не используемые образы | f-без подтверждения, a-без ссылок на контейнеры


// --------------------------------
//    Tag
// --------------------------------
docker tag <o_source>:<tag> <host>:5000/<o_target>:<tag>
docker tag <o> <repo>/<o>
docker tag <id> <repo>


// --------------------------------
//    Env
// --------------------------------
docker run --rm -p 8080:8080 --env REDIS_HOST=host.docker.internal:6379 <o>:<tag>
docker run --rm -p 8080:8080 --env REDIS_HOST=redis:6379 --network=<net-name> <o>:<tag>
docker run --rm -it --entrypoint bash <o> -c "ls -l"    // выполнение комманды в контейнере образа


// --------------------------------
//    Volume
// --------------------------------
docker volume create <name>
docker volume ls              // список томов [ f-фильтр, a-только наименования ]
docker volume inspect <name>  // информаци о томах
docker volume rm <name>       // удаление указанного каталога
docker volume prune           // удаление всех каталогов
docker inspect -f {{.Mounts}} <cname>  // HOST /var/lib/docker/volumes/...
docker inspect -f '{{json .Mounts}}' <cname>
docker volume ls -f="name=<vname>" --format='{{json .}}'
1.
docker run -d -v <name>:/cdir <o>
docker run -d --mount source=<name>,target=/cdir <o>       // source
2.
docker run -d -v "$(pwd)"/dir:/cdir <o>
docker run -d -v /hdir:/cdir <o>   
docker run -d --mount type=bind,src=/hdir,dst=/cdir <o>    // bind
// контейнер данных (метод 37 155)
docker run -v /shared-data --name dc busybox      // создание контейнера данных 'dc'
docker run -it --volumes-from dc busybox /bin/sh  // доступ к каталогу через контейнер данных 'dc'
// только для чтения
docker run -it --mount source=<name>,target=/cdir,readonly bash


// --------------------------------
//    SSHFS
// --------------------------------
1.   // 159
docker run -t -i --privileged debian /bin/bash
apt-get update && apt-get install sshfs
sshfs user@host:/rem/dir /local/dir
fusermount -u /local/dir   // демонтаж


// --------------------------------
//    Network
// --------------------------------
                       // driver
docker network create  -d macvlan  --subnet=172.16.86.0/24  --gateway=172.16.86.1  -o parent=eth0  <net-name>
docker network connect    <net-name> <cname>
docker network disconnect <net-name> <cname>
docker network inspect    <net-name>
docker network rm         <net-name>
docker network ls      // список сетей
docker network prune   // удалить все не используемые сети

docker run -it --network <net-name> <o> /bin/bash
docker run -it --network host --name <cname> nginx       // сеть в режиме HOST
docker run -it --link <cname>:<link_name> <o> /bin/bash  // добавляет запись 'link_name cname_ip' в /etc/hosts

docker inspect --format '{{.NetworkSettings.IPAddress}}' <cname>  // ip контейнера
docker inspect --format '{{json .NetworkSettings.Networks.bridge.NetworkID}}' <cname>|sed 's/"//g'  // ID сети контейнера


// --------------------------------
//    BackUp
// --------------------------------
1.
docker run -v /dbdata --name <cname> ubuntu /bin/bash
docker run --rm --volumes-from <cname> -v $(pwd):/backup ubuntu tar cvf /backup/backup.tar /dbdata
-- Restore
docker run --rm --volumes-from <cname> -v $(pwd):/backup ubuntu bash -c "cd /dbdata && tar xvf /backup/backup.tar --strip 1"
2.1
docker save <repo>:<tag> | gzip > <name>.tar.gz
docker save <repo>:<tag> -o <name>.tar | scp <name>.tar <ip>:/dir/<name>.tar
docker load -i <name>.tar.gz
2.2
docker save <repo>:<tag> | ssh <ip> docker load –
3.
docker export <cname>
docker import <name>.tar.gz 
cat <name>.tar.gz | docker import - <img>:<tag>
tar -c . | docker import - <dir>                    // импорт <*.tgz> из каталога
3.1
docker export <cname> | docker import - <img>:<tag> // сращивание образа
3.2
docker export $(docker run -d <repo>:<tag> true) | ssh <ip> docker import


// --------------------------------
//    Context
// --------------------------------
~/.docker/contexts/
docker context ls
docker context create --docker host=ssh://<user>@<ip> --description="desk" <name>
docker context use <name> | default
docker context inspect <name>
docker info
docker context export <name>   -> <name>.dockercontext  // export
docker context import <name> <name>.dockercontext       // import

export DOCKER_CONTEXT=<name>
export DOCKER_HOST=ssh://<user>@<ip>


// --------------------------------
//    X-Server
// --------------------------------
1. контейнер разработки
docker run -t -i \
-v /var/run/docker.sock:/var/run/docker.sock \  // для предоставления доступа к демону хоста
-v /tmp/.X11-unix:/tmp/.X11-unix \    // чтобы позволить запускать приложения на основе графического интерфейса
-e DISPLAY=$DISPLAY \                 // Устанавливает переменную среды, указывающую контейнеру использовать отображение хоста
--net=host --ipc=host \               // позволяют получить доступ к файлам межпроцессного взаимодействия хоста
-v /hdir:/cdir \
<o>


// --------------------------------
//    Копия образа в локальный реестр
// --------------------------------
docker pull debian  // образ Debian из Docker Hub
docker tag debian:wheezy <reestr>/<uname>/debian:mywheezy1
docker push <reestr>/<uname>/debian:mywheezy1


// --------------------------------
//    Реестр
// --------------------------------
docker login -u <user> -p <passwd>  // вход в реестр
docker logout
1.
// запуск реестра - v1
docker run -d -p 5000:5000 registry:2
// запуск реестра - v2
docker run -d -p 5000:5000 -v /<cdir>:/<hdir> registry:2     // docker run -d -p 5000:5000 -v $HOME/registry:/var/lib/registry registry:2
// на клиенте CentOS
запуск Docker с параметром --insecure-registry 192.168.1.100:5000
nano /etc/docker/daemon.json           
{ "insecure-registries" : [ "192.168.1.100:5000" ] }
docker push 192.168.1.100:5000/<o>:<tag>
2.
mkdir registry_certs
openssl req -newkey rsa:4096 -nodes -sha256 \
-keyout registry_certs/domain.key -x509 -days 365 \
-out registry_certs/domain.crt
 !! Common Name: Register_Host_Name !!
--> domain.crt  -> copy to file  -> /etc/docker/certs.d/<register_host_name>:<port>/ca.crt
--> domain.key  закрытый ключ
mkdir -p /etc/docker/certs.d/<register_host_name>:5000
cp registry_certs/domain.crt /etc/docker/certs.d/<register_host_name>:5000/ca.crt
service docker restart
// запуск реестра
docker run -d -p 5000:5000 \
-v $(pwd)/registry_certs:/certs \ 
-e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/domain.crt \
-e REGISTRY_HTTP_TLS_KEY=/certs/domain.key \ 
--restart=always --name registry registry:2
// проверка работы
docker pull debian:wheezy
docker tag debian:wheezy <register_host_name>:5000/debian:local
docker push <register_host_name>:5000/debian:local

// files dir
/etc/sysconfig/docker   OpenSuse, CentOS, Red Hat
/etc/default/docker     Ubuntu, Debian, Gentoo


// --------------------------------
//    Client - Server
// --------------------------------
// Server
docker daemon -H tcp://0.0.0.0:2375

// Client
// v1
export DOCKER_HOST=tcp://<ip>:2375
docker <subcommand>
// v2
docker -H tcp://<ip>:2375 <subcommand>


// --------------------------------
//    docker-machine
// --------------------------------
create  - Создает новый компьютер
ls      - Перечисляет хост-компьютеры Docker
stop    - Останавливает компьютер
start   - Запускает компьютер
restart - Останавливает и запускает компьютер
rm      - Уничтожает компьютер
kill    - Убивает компьютер
inspect - Возвращает представление метаданных компьютера в формате JSON
config  - Возвращает конфигурацию, необходимую для подключения к компьютеру
ip      - Возвращает IP-адрес компьютера
url     - Возвращает URL-адрес демона Docker на компьютере
upgrade - Обновляет версию Docker на хосте до последней версии

docker-machine create --driver virtualbox host1
docker-machine ssh host1


// --------------------------------
//    Info
// --------------------------------
docker system df [-v]  // Show docker disk usage
docker system info     // Display system-wide information
docker system prune    // Remove unused data


// --------------------------------
//    Test
// --------------------------------
alias dockernuke='docker ps -aq | xargs --no-run-if-empty docker rm -f'

// --------------------------------
docker run debian echo "Hello World"
docker run -i -t debian /bin/bash
docker run -i -t -h CONTAINER debian /bin/bash




// --------------------------------
Docker network
 - bridge      docker0 172.17.42.1 
 - host        все контейнеры используют IP хоста, запускается с флагом --net=host
 - container   используется пространство сетевых имен из другого контейнера
 - none

// --------------------------------
Continuous Integration (Непрерывная интеграция) - автоматизированный процесс сборки и тестирования кода
 - GitLab
 - GoCD
 - TeamCity
 - Jenkins
 - Travis CI (Node, PHP)

// --------------------------------
Source Control Management (SCM or version control)
 - Subversion
 - Mercurial
 - Git
 - Team Foundation Server.
 - Perforce

// --------------------------------
средства управления конфигурацией (configuration management – CM) 
 - Puppet
 - Chef
 - Ansible
 - Salt

// --------------------------------
ELK - Ведение журналов
 - Elasticsearch - механизм текстового поиска
 - Logstash      - инструмент чтения необработанных журнальных записей ( <- Logspout )
 - Kibana        - основанный на JavaScript графический интерфейс для Elasticsearch

// --------------------------------
реестр (registry)        - сервис, отвечающий за хранение и распространение образов (Docker Hub)
репозиторий (repository) - набор взаимосвязанных образов
тег (tag)                - алфавитно-цифровой идентификатор, присваиваемый образам внутри репозитория


// --------------------------------
//    Безопасность
// --------------------------------
Linux Namespaces   - пространства имен
cgroups            - контрольные группы ( systemd )
Linux Capabilities - средства управления привилегиями
SELinux            - мандатные системы обеспечения безопасности


