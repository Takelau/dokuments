
// -----------------------------------
//   CSS
// -----------------------------------

<div v-bind:class="{ active: isActive }"></div>
<div class="static" v-bind:class="{ active: isActive, 'text-danger': hasError }"></div>

data: {
  isActive: true,
  hasError: false
}

// -----------------------------------

<div v-bind:class="classObject"></div>
// var 1
data: {
  classObject: {
    active: true,
    'text-danger': false
  }
}

// var 2
data: {
  isActive: true,
  error: null
},
computed: {
  classObject: function () {
    return {
      active: this.isActive && !this.error,
      'text-danger': this.error && this.error.type === 'fatal',
    }
  }
}

// -----------------------------------

<div v-bind:class="[activeClass, errorClass]">
<div v-bind:class="[isActive ? activeClass : '', errorClass]">
<div v-bind:class="[{ active: isActive }, errorClass]">

data: {
  activeClass: 'active',
  errorClass:  'text-danger'
}

// -----------------------------------

<div v-bind:style="{ color: activeColor, fontSize: fontSize + 'px' }"></div>

data: {
  activeColor: 'red',
  fontSize: 30
}

// -----------------------------------

<div v-bind:style="styleObject"></div>

data: {
  styleObject: {
    color: 'red',
    fontSize: '13px'
  }
}

// -----------------------------------

<div v-bind:style="{ display: ['-webkit-box', '-ms-flexbox', 'flex'] }">

// -----------------------------------

// -----------------------------------

// -----------------------------------

// -----------------------------------







