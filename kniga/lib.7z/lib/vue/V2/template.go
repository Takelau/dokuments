
// -----------------------------------
//   Template
// -----------------------------------

{{#if ok}}
  <h1>Да</h1>
{{/if}}

<div v-if="type === 'A'">A</div>
<div v-else-if="type === 'B'">B</div>
<div v-else-if="type === 'C'">C</div>
<div v-else>Не A/B/C</div>

<template v-if="loginType === 'username'">
  <label>Имя пользователя</label>
  <input placeholder="Введите имя пользователя" key="username-input">
</template>
<template v-else>
  <label>Email</label>
  <input placeholder="Введите адрес email" key="email-input">
</template>

// -----------------------------------

// Слот с ограниченной областью видимости
<div class="child">
  <slot text="сообщение от потомка"></slot>
</div>

// В родителе, элемент <template> с особым атрибутом scope указывает, что это шаблон для слота с ограниченной областью видимости
<div class="parent">
  <child>
    <template scope="props">
      <span>сообщение от родителя</span>
      <span>{{ props.text }}</span>
    </template>
  </child>
</div>

// Результатом рендеринга кода выше будет
<div class="parent">
  <div class="child">
    <span>сообщение от родителя</span>
    <span>сообщение от потомка</span>
  </div>
</div>

// -----------------------------------

// слот с ограниченной областью видимости может быть и именованным
<my-awesome-list :items="items">
  <template slot="item" scope="props">
    <li class="my-fancy-item">{{ props.text }}</li>
  </template>
</my-awesome-list>

<ul>
  <slot name="item" v-for="item in items" :text="item.text">
	  // здесь — контент для резервного отображения
  </slot>
</ul>

// -----------------------------------

<ul v-if="items.length">
  <li v-for="item in items">{{ item.name }}</li>
</ul>
<p v-else>Ничего не найдено.</p

// -----------------------------------

<template v-if="loginType === 'username'">
  <label>Имя пользователя</label>
  <input placeholder="Введите имя пользователя" key="username-input">
</template>
<template v-else>
  <label>Email</label>
  <input placeholder="Введите адрес email" key="email-input">
</template>

// -----------------------------------

<my-component v-for="(item, index) in items" v-bind:item="item" v-bind:index="index" v-bind:key="item.id">
	...
</my-component>

// -----------------------------------


