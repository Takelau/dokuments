
// -----------------------------------
//   Директивы (v-)
// -----------------------------------

// -----------------------------------
//   v-if
// -----------------------------------
<div id="app-3">
  <p v-if="seen">Сейчас меня видно</p>
</div>

var app3 = new Vue({
  el: '#app-3',
  data: {seen: true}
})

// -----------------------------------

<div v-if="Math.random() > 0.5">Сейчас меня видно</div>
<div v-else>А теперь — нет</div>

// -----------------------------------
//  если мы хотим управлять отображением сразу нескольких элементов
<template v-if="ok">
  <h1>Заголовок</h1>
  <p>Абзац 1</p>
  <p>Абзац 2</p>
</template>

<template v-if="loginType === 'username'">
  <label>Имя пользователя</label>
  <input placeholder="Введите имя пользователя" key="username-input">
</template>
<template v-else>
  <label>Email</label>
  <input placeholder="Введите адрес email" key="email-input">
</template>

// -----------------------------------

<div v-if="type === 'A'">A</div>
<div v-else-if="type === 'B'">B</div>
<div v-else-if="type === 'C'">C</div>
<div v-else>Не A/B/C</div>


// -----------------------------------
//   v-show
// -----------------------------------
// элемент всегда оставаться в DOM, а изменяться будет лишь свойство display в его параметрах CSS
<h1 v-show="ok">Привет!</h1>


// -----------------------------------
//   v-for
// -----------------------------------
<div id="app-4">
  <ol>
    <li v-for="todo in todos">{{ todo.text }}</li>
  </ol>
</div>

var app4 = new Vue({
  el: '#app-4',
  data: {
    todos: [
      { text: 'Посадить дерево' },
      { text: 'Построить дом' },
      { text: 'Завершить кругосветное плавание' }
    ]
  }
})

app4.todos.push({ text: 'Новый элемент' })

// -----------------------------------

<ul id="app-5">
  <li v-for="(item, index) in items">
    {{ parentMessage }} - {{ index }} - {{ item.message }}
  </li>
</ul>

// -----------------------------------

<li v-for="todo in todos" v-if="!todo.isComplete">
  {{ todo }}
</li>

// -----------------------------------

// Методы внесения изменений
push()
pop()
shift()
unshift()
splice()
sort()
reverse()

// Замены в массиве
filter()
concat()
slice()

vm.items[indexOfItem] = newValue                 // не реактивное изменение
Vue.set(example1.items, indexOfItem, newValue)   // реактивное изменение
example1.items.splice(indexOfItem, 1, newValue)  // или так

// -----------------------------------

// -----------------------------------

// -----------------------------------

// -----------------------------------

// -----------------------------------

// -----------------------------------






