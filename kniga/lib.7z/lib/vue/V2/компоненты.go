
// -----------------------------------
//   Компоненты
// -----------------------------------

"build": "webpack main.js build.js --watch"

./components/hello.vue
./main.js

// hello.vue
<template>
  <h1>{{ hello }}</h1>
</template>

<script>
  module.exports = {
    data: function() {
      return {
        hello: 'Привет мир!'
      }
    }
  }
</script>

<style>
  h1 {color:blue;}
</style>

// main.js
var Vue = require('vue')
var hello = require('vue!./components/hello.vue')

new Vue({
  el: 'body',
  components: {
    hello: hello
  }
})


// -----------------------------------

<my-component  v-for="(item, index) in items"  v-bind:item="item"  v-bind:index="index"  v-bind:key="item.id"></my-component>

// -----------------------------------

Vue.component('example', {
  model: {                  // https://ru.vuejs.org/v2/guide/components.html
    prop:  'checked',
    event: 'change'
  },
  props: {
  	propA: Number,                        // простая проверка типа (`null` означает допустимость любого типа)
  	propB: [String, Number],              // несколько допустимых типов
		propC: {type:String, required:true},  // обязательное значение строкового типа
		propD: {type:Number, default:100},    // число со значением по умолчанию
		// значения по умолчанию для объектов и массивов должны задаваться через функцию
    propE: {
      type:Object,
      default: function (){ return { message:'привет!' } }
    },
    // пользовательская функция для валидации
    propF: {
      validator: function (value){ return value > 10 }
    }
  }
})

type
	String
	Number
	Boolean
	Function
	Object
	Array
	Symbol

// -----------------------------------

<div id="app-7">
  <ol>
    <todo-item  v-for="item in groceryList"  v-bind:todo="item"  v-bind:key="item.id"></todo-item>
  </ol>
</div>

Vue.component('todo-item', {
  props: ['todo'],
  template: '<li>{{ todo.text }}</li>'
})

var app7 = new Vue({
  el: '#app-7',
  data: {
    groceryList: [
      { id: 0, text: 'Овощи' },
      { id: 1, text: 'Сыр' },
      { id: 2, text: 'Что там ещё люди едят?' }
    ]
  }
})

// -----------------------------------
<div id="example-2">
  <simple-counter></simple-counter>
  <simple-counter></simple-counter>
  <simple-counter></simple-counter>
</div>

Vue.component('simple-counter', {
  template: '<button v-on:click="counter += 1">{{ counter }}</button>',
  data: function () {
  	return {
  	  counter: 0
 		}
  }
})

// -----------------------------------
<div>
  <input v-model="parentMsg">
  <child v-bind:my-message="parentMsg"></child>
</div>

Vue.component('child', {
  // camelCase в JavaScript
  props: ['myMessage'],
  template: '<span>{{ myMessage }}</span>'
})

// -----------------------------------
// Локальные компоненты
var Child = { template: '<div>Пользовательский компонент!</div>' }
new Vue({
  // ...
  components: {
    // <my-component> будет доступен только в шаблоне родителя
    'my-component': Child
  }
})

// -----------------------------------

<div id="todo-list-example">
  <input  v-model="newTodoText"  v-on:keyup.enter="addNewTodo"  placeholder="Добавить todo">
  <ul>
    <li  is="todo-item"  v-for="(todo, index) in todos"  v-bind:key="todo"  v-bind:title="todo"  v-on:remove="todos.splice(index, 1)"></li>
  </ul>
</div>

Vue.component('todo-item', {
  template: `<li>{{ title }}<button v-on:click="$emit('remove')">X</button></li>`,
  props: ['title']
})

new Vue({
  el: '#todo-list-example',
  data: {
    newTodoText: '',
    todos: ['Вымыть посуду', 'Вынести мусор', 'Подстричь газон']
  },
  methods: {
    addNewTodo: function () {
      this.todos.push(this.newTodoText)
      this.newTodoText = ''
    }
  }
})


// -----------------------------------
//   Прользовательские события
// -----------------------------------
<div id="counter-event-example">
  <p>{{ total }}</p>
  <button-counter v-on:increment="incrementTotal"></button-counter>
  <button-counter v-on:increment="incrementTotal"></button-counter>
</div>

Vue.component('button-counter', {
  template: '<button v-on:click="increment">{{ counter }}</button>',
  data: function () {
    return { counter:0 }
  },
  methods: {
    increment: function () {
      this.counter += 1
      this.$emit('increment')
    }
  },
})
new Vue({
  el: '#counter-event-example',
  data: {
    total: 0
  },
  methods: {
    incrementTotal: function () {
      this.total += 1
    }
  }
})

// -----------------------------------
<currency-input v-model="price"></currency-input>

Vue.component('currency-input', {
  template: `
    <span>
      $
      <input
        ref="input"
        v-bind:value="value"
        v-on:input="updateValue($event.target.value)"
      >
    </span>
  `,
  props: ['value'],
  methods: {
    // Вместо того, чтобы обновлять значение напрямую,
    // в этом методе мы выполняем нормализацию и форматирование
    // введённого значения, а затем порождаем событие,
    // уведомляющее родительский компонент об изменениях
    updateValue: function (value) {
      var formattedValue = value
        // Удалить пробелы с обеих сторон
        .trim()
        // Сократить до 2 знаков после запятой
        .slice(
          0,
          value.indexOf('.') === -1 ? value.length : value.indexOf('.') + 3
        )
      // Если значение не нормализовано — нормализуем вручную
      if (formattedValue !== value) {
        this.$refs.input.value = formattedValue
      }
      // Порождаем событие с обновлённым значением поля ввода
      this.$emit('input', Number(formattedValue))
    }
  }
})

// -----------------------------------
<div id="app">
  <currency-input  label="Price"     v-model="price"></currency-input>
  <currency-input  label="Shipping"  v-model="shipping"></currency-input>
  <currency-input  label="Handling"  v-model="handling"></currency-input>
  <currency-input  label="Discount"  v-model="discount"></currency-input>
  <p>Total: ${{ total }}</p>
</div>

Vue.component('currency-input', {
  template: '\
    <div>\
      <label v-if="label">{{ label }}</label>\
      <input ref="input"\
        v-bind:value="value"\
        v-on:input="updateValue($event.target.value)"\
        v-on:focus="selectAll"\
        v-on:blur="formatValue"\
      >\
    </div>\
  ',
  props: {
    value: { type:Number, default:0  },
    label: { type:String, default:'' }
  },
  mounted: function () {
    this.formatValue()
  },
  methods: {
    updateValue: function (value) {
      var result = currencyValidator.parse(value, this.value)
      if (result.warning) { this.$refs.input.value = result.value }
      this.$emit('input', result.value)
    },
    formatValue: function () {
      this.$refs.input.value = currencyValidator.format(this.value)
    },
    selectAll: function (event) {
      // Workaround for Safari bug
      // http://stackoverflow.com/questions/1269722/selecting-text-on-focus-using-jquery-not-working-in-safari-and-chrome
      setTimeout(function () {
      	event.target.select()
      }, 0)
    }
  }
})

new Vue({
  el: '#app',
  data: {
    price: 0,
    shipping: 0,
    handling: 0,
    discount: 0
  },
  computed: {
    total: function () {
      return ((
        this.price * 100 + 
        this.shipping * 100 + 
        this.handling * 100 - 
        this.discount * 100
      ) / 100).toFixed(2)
    }
  }
})
// -----------------------------------





