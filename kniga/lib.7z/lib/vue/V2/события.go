
// -----------------------------------
//   Обработка событий
// -----------------------------------

<a     v-on:click.stop="doThis"></a>              // событие click не будет всплывать дальш
<a     v-on:click.stop.prevent="doThat"></a>      // модификаторы можно объединять в цепочки
<a     v-on:click.once="doThis"></a>              // событие click сработает только 1 раз
<form  v-on:submit.prevent="onSubmit"></form>     // событие submit больше не будет перезагружать страницу
<form  v-on:submit.prevent></form>
<div   v-on:click.capture="doThis">...</div>      // событие направленное на внутренний элемент сначала обрабатывается здесь
<div   v-on:click.self="doThat">...</div>         // вызывать обработчик только в случае наступления события непосредственно на данном элементе

<input v-on:keyup.13="submit">     // вызвать vm.submit() только если keyCode равно 13
<input v-on:keyup.enter="submit">
<input     @keyup.enter="submit">

<input @keyup.alt.67="clear">      // Alt + C
<div   @click.ctrl="doSomething">  // Ctrl + Click

		Vue.config.keyCodes.f1 = 112
    .enter
    .tab
    .delete (ловит как “Delete”, так и “Backspace”)
    .esc
    .space
    .up
    .down
    .left
    .right

    .ctrl
    .alt
    .shift
    .meta


// -----------------------------------
<div id="app-1">
  <p>{{ message }}</p>
  <button v-on:click="reverseMessage">Обратить порядок букв в сообщении</button>
</div>

var app5 = new Vue({
  el: '#app-1',
  data: {
    message: 'Hello Vue.js!'
  },
  methods: {
    reverseMessage: function () {
      this.message = this.message.split('').reverse().join('')
    }
  }
})

// -----------------------------------
<div id="app-2">
  <button v-on:click="greet">Поприветствовать</button>
</div>

var app2 = new Vue({
  el: '#app-2,
  data: {
    name: 'Vue.js'
  },
  methods: {
    greet: function (event) {
      alert('Привет, ' + this.name + '!')  // `this` внутри методов указывает на экземпляр Vue
      if (event) {                         // `event` — нативное событие DOM
        alert(event.target.tagName)
      }
    }
  }
})
// вызывать методы можно и императивно
example2.greet()




