
// -----------------------------------
//   Form
// -----------------------------------

<input v-model.lazy="msg" >                 // синхронизируется после "change", а не "input"
<input v-model.number="age" type="number">  // если вы хотите автоматически приводить то, что ввёл пользователь к числ
<input v-model.trim="msg">

// -----------------------------------

<p style="white-space: pre">{{ message }}</p>
<textarea v-model="message" placeholder="введите несколько строчек"></textarea>

// -----------------------------------

<input type="checkbox" id="checkbox" v-model="checked">
<label for="checkbox">{{ checked }}</label>

// -----------------------------------

<input type="checkbox" id="jack" value="Jack" v-model="checkedNames"><label for="jack">Jack</label>
<input type="checkbox" id="john" value="John" v-model="checkedNames"><label for="john">John</label>
<input type="checkbox" id="mike" value="Mike" v-model="checkedNames"><label for="mike">Mike</label>
<span>Отмеченные имена: {{ checkedNames }}</span>

<input type="checkbox" v-model="toggle" v-bind:true-value="a" v-bind:false-value="b">
vm.toggle === vm.a    // если отмечено:
vm.toggle === vm.b    // если отметка снята:

// -----------------------------------

<input type="radio" id="one" value="One" v-model="picked"><label for="one">One</label>
<input type="radio" id="two" value="Two" v-model="picked"><label for="two">Two</label>
<span>Выбрано: {{ picked }}</span>

<input type="radio" v-model="pick" v-bind:value="a">
vm.pick === vm.a    // если отмечено:

// -----------------------------------

<select v-model="selected">
  <option disabled value="">Выберите один из вариантов</option>
  <option>A</option>
  <option>B</option>
  <option>C</option>
</select>
<span>Выбрано: {{ selected }}</span>

new Vue({
  el: '...',
  data: {
    selected: ''
  }
})

// -----------------------------------

<select v-model="selected" multiple>
  <option>A</option>
  <option>B</option>
  <option>C</option>
</select>
<span>Выбрано: {{ selected }}</span>


<select v-model="selected">
  <option v-bind:value="{ number: 123 }">123</option>
</select>
typeof vm.selected // -> 'object'
vm.selected.number // -> 123

// -----------------------------------

<select v-model="selected">
  <option v-for="option in options" v-bind:value="option.value">
    {{ option.text }}
  </option>
</select>
<span>Выбрано: {{ selected }}</span>

new Vue({
  el: '...',
  data: {
    selected: 'A',
    options: [
      { text: 'One',   value: 'A' },
      { text: 'Two',   value: 'B' },
      { text: 'Three', value: 'C' }
    ]
  }
})

// -----------------------------------

