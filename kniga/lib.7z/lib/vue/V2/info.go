

  jsfiddle.net
https://jsfiddle.net/chrisvfritz/50wL7mdz/

<script src="https://unpkg.com/vue"></script>


// -----------------------------------
//   Декларативный рендеринг
// -----------------------------------
<div id="app">{{ message }}</div>

var app = new Vue({
  el: '#app',
  data: {message:'Hello Vue!'}
})


// -----------------------------------
//   Хуки
// -----------------------------------
     new Vue()
  1. beforeCreate()
  2. created()
  3. beforeMount()
  4. mounted()
  5. beforeUpdate()
  6. updated()
  7. beforeDestroy()
  8. destroyed()

	push()
	pop()
	shift()
	unshift()
	splice()
	sort()
	reverse()
	example1.items.push({ message: 'Baz' })

	app.items[i] = newValue
	Vue.set(app.items, i, newValue)

	app.items.length = newLength
	app.items.splice(newLength)


// -----------------------------------
//   Инстант
// -----------------------------------
var app = new Vue({
	el: '...',
	data: {
		message:   '...',                                    
		question:  '...',                                  // <input v-model="question">
		todos: [{ text: 'txt', ... }, ...]
		classObject: { 'text-danger': false }              // <div v-bind:class="classObject"></div>
		firstName: '...',
		lastName:  '...'
	},
	computed: {
		cMethod: function () { return this.message+'!'; }  // <p>Изначальное сообщение: "{{ cMethod }}"</p>
		fullName: {
    	// геттер:
  	  get: function () {
    	  return this.firstName + ' ' + this.lastName
   		},
    	// сеттер:
    	set: function (newValue) {
      	var names = newValue.split(' ')
      	this.firstName = names[0]
     		this.lastName = names[names.length - 1]
    	}
  	}
	},
	filters: {
		fMethod: function (value) { return '...'; }        // <div v-bind:title="message | fMethod"></div>
	},
	watch: {
		question: function (newQuestion) {
			this.getAnswer(newMessage)
		}
	},
	methods: {
		getAnswer: function (newMessage){ ... }
	},
	components: {
		'my-component': Child               // var Child = { template: '<div>Пользовательский компонент!</div>' }
	}
})


// -----------------------------------
//   Директивы (v-)
// -----------------------------------
v-if='...'           // <p v-if="seen">Сейчас меня видно</p>
v-for='...'          // <li v-for="todo in todos">{{ todo.text }}</li>  <li v-for="(item, index) in items">...</li>

v-bind:id='...'      // <div v-bind:id="'list-'+idl"></div>
v-bind:title='...'   // <span v-bind:title="message">...</span> 
v-bind:href='...'    // <a v-bind:href="url"></a>
v-bind:class='...'   // <div v-bind:class="{ active: isActive }"></div>   <div class="static" v-bind:class="{ active:isActive, 'text-danger':hasError }"></div>
v-bind:value='...'   // <option v-for="option in options" v-bind:value="option.value">{{ option.text }}</option>
v-bind:href='...'    // <a v-bind:href="url"></a>
v-bind:disabled='...'  // <button v-bind:disabled="someDynamicCondition">Кнопка</button>

v-model='...'        // <input v-model="message">  <input type="checkbox" id="checkbox" v-model="checked">
v-model.lazy='...'   // <-- синхронизируется после "change", а не "input"  <input v-model.lazy="msg" >
v-model.number='...' // <-- автоматически приводит пользовательский ввод к числу
v-model.trim='...'   // <input v-model.trim="msg">

v-on:click='...'     // <button v-on:click="reverseMessage">  <a v-on:click="doSomething">
v-on:submit.prevent  // <form v-on:submit.prevent="onSubmit"></form>  <-- вызвать event.preventDefault()
v-html='...'         // <div v-html="rawHtml"></div>
v-show='...'         // <h1 v-show="ok">Привет!</h1>  <-- display (не поддерживает <template> и не работает с v-else)
v-once               // <span v-once>Это сообщение никогда не изменится: {{ msg }}</span>


// -----------------------------------
//   События
// -----------------------------------
$event.target.value   // <input  ref="input"  v-bind:value="value"  v-on:input="updateValue($event.target.value)">

event.target.select()
event.target.tagName
event.preventDefault()


// -----------------------------------
//   Вычисляемые свойства
// -----------------------------------
<div id="example">
  <p>Изначальное сообщение: "{{ message }}"</p>
  <p>Сообщение задом наперёд: "{{ reversedMessage }}"</p>
</div>

var vm = new Vue({
  el: '#example',
  data: {
    message: 'Привет'
  },
  computed: {
    reversedMessage: function () {
      // `this` указывает на экземпляр vm
      return this.message.split('').reverse().join('')
    }
  }
})

// -----------------------------------
<div id="example">{{ fullName }}</div>

var vm = new Vue({
  el: '#example',
  data: {
    firstName: 'Foo',
    lastName: 'Bar'
  },
  computed: {
    fullName: function () {
  	  get: function () {
    	  return this.firstName + ' ' + this.lastName
    	},
    	set: function (newValue) {
    	  var names = newValue.split(' ')
    	  this.firstName = names[0]
    	  this.lastName = names[names.length - 1]
    	}
    }
  }
})


// -----------------------------------
//   Watch
// -----------------------------------
<div id="watch-example">
  <p>
    Задайте вопрос, на который можно ответить "да" или "нет":
    <input v-model="question">
  </p>
  <p>{{ answer }}</p>
</div>

<script src="https://unpkg.com/axios@0.12.0/dist/axios.min.js"></script>
<script src="https://unpkg.com/lodash@4.13.1/lodash.min.js"></script>
<script>
var watchExampleVM = new Vue({
  el: '#watch-example',
  data: {
    question: '',
    answer: 'Пока вы не зададите вопрос, я не могу ответить!'
  },
  watch: {
    question: function (newQuestion) {
      this.answer = 'Ожидаю, когда вы закончите печатать...'
      this.getAnswer()
    }
  },
  methods: {
    // _.debounce — это функция из lodash, позволяющая ограничить то, насколько часто может выполняться определённая операция.
    // см. документацию: https://lodash.com/docs#debounce
    getAnswer: _.debounce(
      function () {
        if (this.question.indexOf('?') === -1) {
          this.answer = 'Вопросы обычно заканчиваются вопросительным знаком. ;-)'
          return
        }
        this.answer = 'Думаю...'
        var vm = this
        axios.get('https://yesno.wtf/api')
          .then(function (response) {
            vm.answer = _.capitalize(response.data.answer)
          })
          .catch(function (error) {
            vm.answer = 'Ошибка! Не могу связаться с API. ' + error
          })
      },
      500  // Это число миллисекунд, которое мы ждём, после того как пользователь прекратил печатать:
    )
  }
})
</script>













