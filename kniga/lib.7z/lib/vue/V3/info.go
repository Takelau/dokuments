
<%= VALUE %>     для неэкранированной подстановки
<%- VALUE %>     для экранированного HTML-кода
<% expression %> для потоков управления JavaScript

// v1
<link rel="icon" href="<%= BASE_URL %>favicon.ico">
// v2
<img :src="`${publicPath}my-image.png`">
data () {
  return {
    publicPath: process.env.BASE_URL
  }
}


// -----------------------------------
//   TEXT
// -----------------------------------