
// Sass
npm install   -D sass-loader sass      
npm install   -D sass-loader@^10 sass  // webpack 4, Vue CLI 4
npm install   -D fibers    // поддержка асинхронных вызовов
npm uninstall -D fibers    // удаление асинхронных вызовов
// Less
npm install -D less-loader less      
// Stylus
npm install -D stylus-loader stylus  

<style lang="scss">
$color: red;
</style>

// -----------------------------------
import styles     from './foo.module.css'
import sassStyles from './foo.module.scss'

