
// http://prgssr.ru/development/vvedenie-v-paketnyj-menedzher-npm-dlya-nachinayushih.html
// https://docs.npmjs.com/misc/config#shorthands-and-other-cli-niceties

which node       // /usr/local/bin/node
node --version   // v5.7.0

npm config list
npm config get prefix

npm list -g         // список глобально установленных пакетов
npm list -g --depth=0
npm ls --depth 0
npm ls -g --depth 0
npm cache clean     // очистка кеша ( ~/.npm )
npm install npm -g  // обновление npm
npm install npm@latest -g
npm search hook.io  // поиск пакета

npm init    // создает package.json

npm install uglify-js -g       // установка UglifyJS, глобально     uglifyjs example.js -o example.min.js   // mini file
npm install underscore@1.8.2   // локально, без -g 
npm uninstall underscore       // удаление локального пакета
npm uninstall underscore -g    // удаление глобального пакета
npm update underscore          // обновление

// ----------------------
// типичная установка
npm i --save pkg      // авто обновление package.json (установить пакет и сохранить как зависимость)
npm i -S pkg
npm i --save-dev pkg  // установить пакет только для использования в разработке (devDependency)
npm i -D pkg
npm list

