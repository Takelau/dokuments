
// -----------------------------------
//   V3
// -----------------------------------
@vue/cli                - vue create | serve | ui
@vue/cli-service-global - зависимость для разработки, устанавливается локально в каждый проект, создаваемый с помощью @vue/cli
                          vue-cli-service serve | build | inspect
@vue/cli-service        - ./node_modules/.bin/vue-cli-service
                          "scripts": {"serve":"vue-cli-service serve", "build":"vue-cli-service build"}
@vue/cli-plugin-<name>  - 

// требования
vue-cli -> @vue/cl
npm uninstall vue-cli -g  // удаление предыдущей версии Vue 1|2

Vue CLI 4.x требуется Node.js версии >= 8.9
nvm - управление несколькими версиями  |  https://github.com/nvm-sh/nvm

// глобальная установка & обновление
npm install -g @vue/cli   // vue --version
npm update  -g @vue/cli   // обновление

// обновление внутри проекта
vue upgrade [options] [plugin-name]  // --all, --to <version>
vue upgrade @vue/cli-plugin-<name>   // v3
vue upgrade  vue-cli-plugin-<name>   // v2


// -----------------------------------
// создание проекта
vue create --help
vue create <name>
cd <name>
npm run serve

// nano package.json
{
  "scripts": {
    "serve": "vue-cli-service serve",
    "build": "vue-cli-service build"
  }
}

// nano vue.config.js  | https://cli.vuejs.org/ru/config/#vue-config-js
module.exports = {
  ...
  publicPath: '/my-app/',  // https://www.foobar.com/my-app/
  devServer: {             // webpack.js.org/configuration/dev-server/
    proxy: 'http://localhost:4000',  // только XHR-запросы
    host: '0.0.0.0',
    port: 8080,
    server: 'https',       // with a self-signed certificate | v4.4.0+
    liveReload: true,
    watchFiles: ['public/**/*'],
  },
  cache: false,            // cache:{type:'memory'}
  chainWebpack: config => {
    config.plugins.delete('prefetch'), // удаляем prefetch плагинов
  },
}

// ssl
devServer: {
  server: {
    type: 'https',
    options: {
      ca:   './path/to/server.pem',
      pfx:  './path/to/server.pfx',
      key:  './path/to/server.key',
      cert: './path/to/server.crt',
      passphrase: 'webpack-dev-server',
      requestCert: true,
    },
  },
},

// tls
devServer: {
  server: {
    type: 'https',
    options: {
      minVersion: 'TLSv1.1',
      ca:   fs.readFileSync(path.join(__dirname, './ca.pem')),
      pfx:  fs.readFileSync(path.join(__dirname, './server.pfx')),
      key:  fs.readFileSync(path.join(__dirname, './server.key')),
      cert: fs.readFileSync(path.join(__dirname, './server.crt')),
      passphrase: 'webpack-dev-server',
      requestCert: true,
    },
  },
},

// ENV
.env                // загружается во всех случаях
.env.local          // загружается во всех случаях, игнорируется git
.env.[mode]         // загружается только в указанном режиме работы
.env.[mode].local   // загружается только в указанном режиме работы, игнорируется git
FOO=foo
BAR=bar
CONCAT=$FOO$BAR # CONCAT=foobar

console.log(process.env.CONCAT)                                  // доступ из консоли
process.env.VUE_APP_VERSION = require('./package.json').version  // переопределение в vue.config.js


// -----------------------------------
// запуск
vue-cli-service serve  [options] [entry] // --mode development
  --open         открыть браузер при запуске сервера
  --copy         скопировать url в буфер обмена при запуске сервера
  --mode         определить режим сборки (по умолчанию: development)
  --host         определить хост (по умолчанию: 0.0.0.0)
  --port         определить порт (по умолчанию: 8080)
  --https        использовать https (по умолчанию: false)
  --public       указать URL-адрес публичной сети для клиента HMR
  --skip-plugins имена плагинов через запятую, которые следует пропустить при запуске

npm run serve              // v1
npx vue-cli-service serve  // v2


// -----------------------------------
// тестирование
vue-cli-service test:unit  // --mode test
vue-cli-service test:e2e   // --mode production


// -----------------------------------
// изучение проекта
vue inspect > output.js
vue inspect --mode production > output.prod.js
vue inspect --rule vue     // именованное правило
vue inspect --plugin html  // плагин
vue inspect --rules        // ВСЕ именованные правила
vue inspect --plugins      // ВСЕ плагины


// -----------------------------------
// сборка проекта
vue-cli-service build [options] [entry|pattern]  // --mode production
  --mode             определить режим сборки (по умолчанию: production)
  --dest             определить каталог сборки (по умолчанию: dist)
  --modern           собирать приложение для современных браузеров с авто-фоллбэком для старых
  --no-unsafe-inline собирать приложение без внедрения инлайн-скриптов
  --target           app | lib | wc | wc-async (по умолчанию: app)
  --formats          список выходных форматов для сборок библиотек (по умолчанию: commonjs,umd,umd-min)
  --inline-vue       включить Vue в содержимое сборки библиотеки или веб-компонента
  --name             имя библиотеки или режим веб-компонента (по умолчанию: "name" в package.json или имя файла точки входа)
  --filename         имя выходного файла, только для 'lib' (по умолчанию: значение --name)
  --no-clean         не удалять каталог dist перед сборкой проекта
  --report           сгенерировать report.html для анализа содержимого сборки
  --report-json      сгенерировать report.json для анализа содержимого сборки
  --skip-plugins     имена плагинов через запятую, которые следует пропустить при запуске
  --watch            отслеживать изменения

vue-cli-service build --modern  // две версии, с поддержкой ES-модулей и без неё

// Library - удалить опцию "sideEffects": false из файла package.json
vue-cli-service build --target lib --inline-vue          // сборка будет содержать vue
vue-cli-service build --target lib --name myLib [entry]  // .js или .vue | src/App.vue по умолчанию
  dist/myLib.common.js  // сборка CommonJS для использования в сборщиках 
  dist/myLib.umd.js     // сборка UMD для использования в браузерах или с AMD загрузчиками
  dist/myLib.umd.min.js // минифицированная версия UMD сборки
  dist/myLib.css        // извлечённый CSS-файл

// Web Component
vue-cli-service build --target wc --inline-vue   // сборка будет содержать vue
vue-cli-service build --target wc --name my-element [entry]


// -----------------------------------
//   V2
// -----------------------------------

npm install -g vue-loader vue-template-compiler

/* vuejs-templates.github.io/webpack/ */
npm install -g vue-cli
vue init webpack my-project
cd my-project
npm install
npm run dev

/* webpack-simple - Webpack + vue-loader with proper config for source maps & hot-reload */
npm install -g webpack
npm install -g vue-cli
vue init webpack-simple my-project
cd my-project
npm install
npm run dev

/* Webpack + vue-loader setup with hot reload, linting, testing & css extraction */
npm install -g vue
npm install -g vue-cli
npm install -g webpack
vue init webpack my-project
cd my-project
npm install
npm install vue-i18n --save-dev
npm install vue-router --save-dev
npm install vue-resource --save-dev
npm install vue-cookie --save-dev
npm install vuedraggable --save-dev
npm install element-ui --save-dev
npm run dev

npm --init yes    // создание package.json
npm i             // install


