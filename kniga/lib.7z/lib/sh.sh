
#----------------------
#   SH
#----------------------
var1=5
var2=23skidoo
echo $var1  # 5
echo $var2  # 23skidoo

{ local a;
 a=123; }  # --> function

let "b+=5"
((c++))
let "z=5**3"  # 5*5*5


#----------------------
#   case
#----------------------
case "$variable" in
  abc)  echo "\$variable = abc" ;;
  xyz)  echo "\$variable = xyz" ;;
esac


#----------------------
#   for
#----------------------
for file in /{,usr/}bin/*calc
do
  if [ -x "$file" ]
  then
    echo $file
  fi
done
# /bin/ipcalc
# /usr/bin/kcalc
# /usr/bin/oidcalc

#----------------------
List="один два три"

for a in $List
do
  echo "$a"
done
# один
# два
# три

for a in "$List"
do
  echo "$a"
done
# один два три

for ((a=10, b=1; a <= LIMIT ; a++, b++))
do
  echo "$a-$b"
done


#----------------------
#   if
#----------------------
if [ condition1 ]
then
   command 1
elif [ condition2 ]
then
   command 2
else
   command 3
fi

[ $# -eq 0 ] && directorys=`pwd` || directorys=$@  # Если не было передано ни одного параметра, то директорией поиска считается текущая директория.
if [ -z "$1" ]        # наличае параметра 1 или a=''
if [[ -e $file ]]     # file=/etc/passwd проверка существования файла
if [ "$a" -eq "$b" ]  # значения равны
if [ "$a" -ne "$b" ]  # значения не равны
if [ "$a" -gt "$b" ]  # первое значение больше второго
if [ "$a" -ge "$b" ]  # первое значение больше или равно второму
if [ "$a" -lt "$b" ]  # первое значение меньше второго
if [ "$a" -le "$b" ]  # первое значение меньше или равно второму
(("$a" < "$b"))       # первое значение меньше второго
(("$a" <= "$b"))      # первое значение меньше или равно второму (внутри двойных круглых скобок)
if [ "$a" = "$b" ]    # строки равны
if [ "$a" == "$b" ]   # строки равны
if [ "$a" == "z*" ]   # истинно, когда $a равно z*
if [[ $a == z* ]]     # истинно, если $a начинается с символа "z"
if [ -n "$str" ]      # строка не пустая

-a  - логическое И
-o  - логическое ИЛИ
-f  - это файл    # http://www.bash-scripting.ru/abs/chunks/ch07s02.html
-s  - файл нулевого размера
-d  - это каталог
-b  - это блочное устройство
-p  - это канал (pipe)
-h  - это символическая ссылка
-S  - Это сокет
-t  - Это терминал
-r  - имеется право на чтение
-w  - имеется право на запись
-x  - имеется право на исполнение

# --------------------------------------
: > data.xxx  # File "data.xxx" now empty

# --------------------------------------
rm test.conf

echo "test1" >> test.conf
echo "test2" >> test.conf

{
echo "test3";
echo "test4";
} >> test.conf

cat <<EOT >> test.conf
test3
test4
EOT

# --------------------------------------
#!/bin/sh

PROCESS="$1"
PROCANDARGS=$*

while :
do
  RESULT=`pgrep ${PROCESS}`
  if [ "${RESULT:-null}" = null ]; then
    echo "${PROCESS} not running, starting "$PROCANDARGS
    $PROCANDARGS &
  else
    echo "running"
  fi
  sleep 10
done
# --------------------------------------
# --------------------------------------

