
// кол-во записей в таблице
SELECT COUNT(DISTINCT id) AS row_count FROM mag.folder WHERE block = 0;

// произвольная запись в таблице
SELECT id, name FROM mag.folder ORDER BY RANDOM() limit 1;

// вставка
INSERT INTO mag.folder(idserver, name, block) values($1, $2, $3) RETURNING id;
